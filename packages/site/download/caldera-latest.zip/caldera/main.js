/* Caldera 0.28.17 */
"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// (disabled):crypto
var require_crypto = __commonJS({
  "(disabled):crypto"() {
  }
});

// ../../node_modules/tweetnacl/nacl-fast.js
var require_nacl_fast = __commonJS({
  "../../node_modules/tweetnacl/nacl-fast.js"(exports, module2) {
    (function(nacl2) {
      "use strict";
      var gf = function(init) {
        var i, r = new Float64Array(16);
        if (init) for (i = 0; i < init.length; i++) r[i] = init[i];
        return r;
      };
      var randombytes = function() {
        throw new Error("no PRNG");
      };
      var _0 = new Uint8Array(16);
      var _9 = new Uint8Array(32);
      _9[0] = 9;
      var gf0 = gf(), gf1 = gf([1]), _121665 = gf([56129, 1]), D = gf([30883, 4953, 19914, 30187, 55467, 16705, 2637, 112, 59544, 30585, 16505, 36039, 65139, 11119, 27886, 20995]), D2 = gf([61785, 9906, 39828, 60374, 45398, 33411, 5274, 224, 53552, 61171, 33010, 6542, 64743, 22239, 55772, 9222]), X = gf([54554, 36645, 11616, 51542, 42930, 38181, 51040, 26924, 56412, 64982, 57905, 49316, 21502, 52590, 14035, 8553]), Y = gf([26200, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214]), I = gf([41136, 18958, 6951, 50414, 58488, 44335, 6150, 12099, 55207, 15867, 153, 11085, 57099, 20417, 9344, 11139]);
      function ts64(x, i, h, l) {
        x[i] = h >> 24 & 255;
        x[i + 1] = h >> 16 & 255;
        x[i + 2] = h >> 8 & 255;
        x[i + 3] = h & 255;
        x[i + 4] = l >> 24 & 255;
        x[i + 5] = l >> 16 & 255;
        x[i + 6] = l >> 8 & 255;
        x[i + 7] = l & 255;
      }
      function vn(x, xi, y, yi, n) {
        var i, d = 0;
        for (i = 0; i < n; i++) d |= x[xi + i] ^ y[yi + i];
        return (1 & d - 1 >>> 8) - 1;
      }
      function crypto_verify_16(x, xi, y, yi) {
        return vn(x, xi, y, yi, 16);
      }
      function crypto_verify_32(x, xi, y, yi) {
        return vn(x, xi, y, yi, 32);
      }
      function core_salsa20(o, p, k, c) {
        var j0 = c[0] & 255 | (c[1] & 255) << 8 | (c[2] & 255) << 16 | (c[3] & 255) << 24, j1 = k[0] & 255 | (k[1] & 255) << 8 | (k[2] & 255) << 16 | (k[3] & 255) << 24, j2 = k[4] & 255 | (k[5] & 255) << 8 | (k[6] & 255) << 16 | (k[7] & 255) << 24, j3 = k[8] & 255 | (k[9] & 255) << 8 | (k[10] & 255) << 16 | (k[11] & 255) << 24, j4 = k[12] & 255 | (k[13] & 255) << 8 | (k[14] & 255) << 16 | (k[15] & 255) << 24, j5 = c[4] & 255 | (c[5] & 255) << 8 | (c[6] & 255) << 16 | (c[7] & 255) << 24, j6 = p[0] & 255 | (p[1] & 255) << 8 | (p[2] & 255) << 16 | (p[3] & 255) << 24, j7 = p[4] & 255 | (p[5] & 255) << 8 | (p[6] & 255) << 16 | (p[7] & 255) << 24, j8 = p[8] & 255 | (p[9] & 255) << 8 | (p[10] & 255) << 16 | (p[11] & 255) << 24, j9 = p[12] & 255 | (p[13] & 255) << 8 | (p[14] & 255) << 16 | (p[15] & 255) << 24, j10 = c[8] & 255 | (c[9] & 255) << 8 | (c[10] & 255) << 16 | (c[11] & 255) << 24, j11 = k[16] & 255 | (k[17] & 255) << 8 | (k[18] & 255) << 16 | (k[19] & 255) << 24, j12 = k[20] & 255 | (k[21] & 255) << 8 | (k[22] & 255) << 16 | (k[23] & 255) << 24, j13 = k[24] & 255 | (k[25] & 255) << 8 | (k[26] & 255) << 16 | (k[27] & 255) << 24, j14 = k[28] & 255 | (k[29] & 255) << 8 | (k[30] & 255) << 16 | (k[31] & 255) << 24, j15 = c[12] & 255 | (c[13] & 255) << 8 | (c[14] & 255) << 16 | (c[15] & 255) << 24;
        var x0 = j0, x1 = j1, x2 = j2, x3 = j3, x4 = j4, x5 = j5, x6 = j6, x7 = j7, x8 = j8, x9 = j9, x10 = j10, x11 = j11, x12 = j12, x13 = j13, x14 = j14, x15 = j15, u;
        for (var i = 0; i < 20; i += 2) {
          u = x0 + x12 | 0;
          x4 ^= u << 7 | u >>> 32 - 7;
          u = x4 + x0 | 0;
          x8 ^= u << 9 | u >>> 32 - 9;
          u = x8 + x4 | 0;
          x12 ^= u << 13 | u >>> 32 - 13;
          u = x12 + x8 | 0;
          x0 ^= u << 18 | u >>> 32 - 18;
          u = x5 + x1 | 0;
          x9 ^= u << 7 | u >>> 32 - 7;
          u = x9 + x5 | 0;
          x13 ^= u << 9 | u >>> 32 - 9;
          u = x13 + x9 | 0;
          x1 ^= u << 13 | u >>> 32 - 13;
          u = x1 + x13 | 0;
          x5 ^= u << 18 | u >>> 32 - 18;
          u = x10 + x6 | 0;
          x14 ^= u << 7 | u >>> 32 - 7;
          u = x14 + x10 | 0;
          x2 ^= u << 9 | u >>> 32 - 9;
          u = x2 + x14 | 0;
          x6 ^= u << 13 | u >>> 32 - 13;
          u = x6 + x2 | 0;
          x10 ^= u << 18 | u >>> 32 - 18;
          u = x15 + x11 | 0;
          x3 ^= u << 7 | u >>> 32 - 7;
          u = x3 + x15 | 0;
          x7 ^= u << 9 | u >>> 32 - 9;
          u = x7 + x3 | 0;
          x11 ^= u << 13 | u >>> 32 - 13;
          u = x11 + x7 | 0;
          x15 ^= u << 18 | u >>> 32 - 18;
          u = x0 + x3 | 0;
          x1 ^= u << 7 | u >>> 32 - 7;
          u = x1 + x0 | 0;
          x2 ^= u << 9 | u >>> 32 - 9;
          u = x2 + x1 | 0;
          x3 ^= u << 13 | u >>> 32 - 13;
          u = x3 + x2 | 0;
          x0 ^= u << 18 | u >>> 32 - 18;
          u = x5 + x4 | 0;
          x6 ^= u << 7 | u >>> 32 - 7;
          u = x6 + x5 | 0;
          x7 ^= u << 9 | u >>> 32 - 9;
          u = x7 + x6 | 0;
          x4 ^= u << 13 | u >>> 32 - 13;
          u = x4 + x7 | 0;
          x5 ^= u << 18 | u >>> 32 - 18;
          u = x10 + x9 | 0;
          x11 ^= u << 7 | u >>> 32 - 7;
          u = x11 + x10 | 0;
          x8 ^= u << 9 | u >>> 32 - 9;
          u = x8 + x11 | 0;
          x9 ^= u << 13 | u >>> 32 - 13;
          u = x9 + x8 | 0;
          x10 ^= u << 18 | u >>> 32 - 18;
          u = x15 + x14 | 0;
          x12 ^= u << 7 | u >>> 32 - 7;
          u = x12 + x15 | 0;
          x13 ^= u << 9 | u >>> 32 - 9;
          u = x13 + x12 | 0;
          x14 ^= u << 13 | u >>> 32 - 13;
          u = x14 + x13 | 0;
          x15 ^= u << 18 | u >>> 32 - 18;
        }
        x0 = x0 + j0 | 0;
        x1 = x1 + j1 | 0;
        x2 = x2 + j2 | 0;
        x3 = x3 + j3 | 0;
        x4 = x4 + j4 | 0;
        x5 = x5 + j5 | 0;
        x6 = x6 + j6 | 0;
        x7 = x7 + j7 | 0;
        x8 = x8 + j8 | 0;
        x9 = x9 + j9 | 0;
        x10 = x10 + j10 | 0;
        x11 = x11 + j11 | 0;
        x12 = x12 + j12 | 0;
        x13 = x13 + j13 | 0;
        x14 = x14 + j14 | 0;
        x15 = x15 + j15 | 0;
        o[0] = x0 >>> 0 & 255;
        o[1] = x0 >>> 8 & 255;
        o[2] = x0 >>> 16 & 255;
        o[3] = x0 >>> 24 & 255;
        o[4] = x1 >>> 0 & 255;
        o[5] = x1 >>> 8 & 255;
        o[6] = x1 >>> 16 & 255;
        o[7] = x1 >>> 24 & 255;
        o[8] = x2 >>> 0 & 255;
        o[9] = x2 >>> 8 & 255;
        o[10] = x2 >>> 16 & 255;
        o[11] = x2 >>> 24 & 255;
        o[12] = x3 >>> 0 & 255;
        o[13] = x3 >>> 8 & 255;
        o[14] = x3 >>> 16 & 255;
        o[15] = x3 >>> 24 & 255;
        o[16] = x4 >>> 0 & 255;
        o[17] = x4 >>> 8 & 255;
        o[18] = x4 >>> 16 & 255;
        o[19] = x4 >>> 24 & 255;
        o[20] = x5 >>> 0 & 255;
        o[21] = x5 >>> 8 & 255;
        o[22] = x5 >>> 16 & 255;
        o[23] = x5 >>> 24 & 255;
        o[24] = x6 >>> 0 & 255;
        o[25] = x6 >>> 8 & 255;
        o[26] = x6 >>> 16 & 255;
        o[27] = x6 >>> 24 & 255;
        o[28] = x7 >>> 0 & 255;
        o[29] = x7 >>> 8 & 255;
        o[30] = x7 >>> 16 & 255;
        o[31] = x7 >>> 24 & 255;
        o[32] = x8 >>> 0 & 255;
        o[33] = x8 >>> 8 & 255;
        o[34] = x8 >>> 16 & 255;
        o[35] = x8 >>> 24 & 255;
        o[36] = x9 >>> 0 & 255;
        o[37] = x9 >>> 8 & 255;
        o[38] = x9 >>> 16 & 255;
        o[39] = x9 >>> 24 & 255;
        o[40] = x10 >>> 0 & 255;
        o[41] = x10 >>> 8 & 255;
        o[42] = x10 >>> 16 & 255;
        o[43] = x10 >>> 24 & 255;
        o[44] = x11 >>> 0 & 255;
        o[45] = x11 >>> 8 & 255;
        o[46] = x11 >>> 16 & 255;
        o[47] = x11 >>> 24 & 255;
        o[48] = x12 >>> 0 & 255;
        o[49] = x12 >>> 8 & 255;
        o[50] = x12 >>> 16 & 255;
        o[51] = x12 >>> 24 & 255;
        o[52] = x13 >>> 0 & 255;
        o[53] = x13 >>> 8 & 255;
        o[54] = x13 >>> 16 & 255;
        o[55] = x13 >>> 24 & 255;
        o[56] = x14 >>> 0 & 255;
        o[57] = x14 >>> 8 & 255;
        o[58] = x14 >>> 16 & 255;
        o[59] = x14 >>> 24 & 255;
        o[60] = x15 >>> 0 & 255;
        o[61] = x15 >>> 8 & 255;
        o[62] = x15 >>> 16 & 255;
        o[63] = x15 >>> 24 & 255;
      }
      function core_hsalsa20(o, p, k, c) {
        var j0 = c[0] & 255 | (c[1] & 255) << 8 | (c[2] & 255) << 16 | (c[3] & 255) << 24, j1 = k[0] & 255 | (k[1] & 255) << 8 | (k[2] & 255) << 16 | (k[3] & 255) << 24, j2 = k[4] & 255 | (k[5] & 255) << 8 | (k[6] & 255) << 16 | (k[7] & 255) << 24, j3 = k[8] & 255 | (k[9] & 255) << 8 | (k[10] & 255) << 16 | (k[11] & 255) << 24, j4 = k[12] & 255 | (k[13] & 255) << 8 | (k[14] & 255) << 16 | (k[15] & 255) << 24, j5 = c[4] & 255 | (c[5] & 255) << 8 | (c[6] & 255) << 16 | (c[7] & 255) << 24, j6 = p[0] & 255 | (p[1] & 255) << 8 | (p[2] & 255) << 16 | (p[3] & 255) << 24, j7 = p[4] & 255 | (p[5] & 255) << 8 | (p[6] & 255) << 16 | (p[7] & 255) << 24, j8 = p[8] & 255 | (p[9] & 255) << 8 | (p[10] & 255) << 16 | (p[11] & 255) << 24, j9 = p[12] & 255 | (p[13] & 255) << 8 | (p[14] & 255) << 16 | (p[15] & 255) << 24, j10 = c[8] & 255 | (c[9] & 255) << 8 | (c[10] & 255) << 16 | (c[11] & 255) << 24, j11 = k[16] & 255 | (k[17] & 255) << 8 | (k[18] & 255) << 16 | (k[19] & 255) << 24, j12 = k[20] & 255 | (k[21] & 255) << 8 | (k[22] & 255) << 16 | (k[23] & 255) << 24, j13 = k[24] & 255 | (k[25] & 255) << 8 | (k[26] & 255) << 16 | (k[27] & 255) << 24, j14 = k[28] & 255 | (k[29] & 255) << 8 | (k[30] & 255) << 16 | (k[31] & 255) << 24, j15 = c[12] & 255 | (c[13] & 255) << 8 | (c[14] & 255) << 16 | (c[15] & 255) << 24;
        var x0 = j0, x1 = j1, x2 = j2, x3 = j3, x4 = j4, x5 = j5, x6 = j6, x7 = j7, x8 = j8, x9 = j9, x10 = j10, x11 = j11, x12 = j12, x13 = j13, x14 = j14, x15 = j15, u;
        for (var i = 0; i < 20; i += 2) {
          u = x0 + x12 | 0;
          x4 ^= u << 7 | u >>> 32 - 7;
          u = x4 + x0 | 0;
          x8 ^= u << 9 | u >>> 32 - 9;
          u = x8 + x4 | 0;
          x12 ^= u << 13 | u >>> 32 - 13;
          u = x12 + x8 | 0;
          x0 ^= u << 18 | u >>> 32 - 18;
          u = x5 + x1 | 0;
          x9 ^= u << 7 | u >>> 32 - 7;
          u = x9 + x5 | 0;
          x13 ^= u << 9 | u >>> 32 - 9;
          u = x13 + x9 | 0;
          x1 ^= u << 13 | u >>> 32 - 13;
          u = x1 + x13 | 0;
          x5 ^= u << 18 | u >>> 32 - 18;
          u = x10 + x6 | 0;
          x14 ^= u << 7 | u >>> 32 - 7;
          u = x14 + x10 | 0;
          x2 ^= u << 9 | u >>> 32 - 9;
          u = x2 + x14 | 0;
          x6 ^= u << 13 | u >>> 32 - 13;
          u = x6 + x2 | 0;
          x10 ^= u << 18 | u >>> 32 - 18;
          u = x15 + x11 | 0;
          x3 ^= u << 7 | u >>> 32 - 7;
          u = x3 + x15 | 0;
          x7 ^= u << 9 | u >>> 32 - 9;
          u = x7 + x3 | 0;
          x11 ^= u << 13 | u >>> 32 - 13;
          u = x11 + x7 | 0;
          x15 ^= u << 18 | u >>> 32 - 18;
          u = x0 + x3 | 0;
          x1 ^= u << 7 | u >>> 32 - 7;
          u = x1 + x0 | 0;
          x2 ^= u << 9 | u >>> 32 - 9;
          u = x2 + x1 | 0;
          x3 ^= u << 13 | u >>> 32 - 13;
          u = x3 + x2 | 0;
          x0 ^= u << 18 | u >>> 32 - 18;
          u = x5 + x4 | 0;
          x6 ^= u << 7 | u >>> 32 - 7;
          u = x6 + x5 | 0;
          x7 ^= u << 9 | u >>> 32 - 9;
          u = x7 + x6 | 0;
          x4 ^= u << 13 | u >>> 32 - 13;
          u = x4 + x7 | 0;
          x5 ^= u << 18 | u >>> 32 - 18;
          u = x10 + x9 | 0;
          x11 ^= u << 7 | u >>> 32 - 7;
          u = x11 + x10 | 0;
          x8 ^= u << 9 | u >>> 32 - 9;
          u = x8 + x11 | 0;
          x9 ^= u << 13 | u >>> 32 - 13;
          u = x9 + x8 | 0;
          x10 ^= u << 18 | u >>> 32 - 18;
          u = x15 + x14 | 0;
          x12 ^= u << 7 | u >>> 32 - 7;
          u = x12 + x15 | 0;
          x13 ^= u << 9 | u >>> 32 - 9;
          u = x13 + x12 | 0;
          x14 ^= u << 13 | u >>> 32 - 13;
          u = x14 + x13 | 0;
          x15 ^= u << 18 | u >>> 32 - 18;
        }
        o[0] = x0 >>> 0 & 255;
        o[1] = x0 >>> 8 & 255;
        o[2] = x0 >>> 16 & 255;
        o[3] = x0 >>> 24 & 255;
        o[4] = x5 >>> 0 & 255;
        o[5] = x5 >>> 8 & 255;
        o[6] = x5 >>> 16 & 255;
        o[7] = x5 >>> 24 & 255;
        o[8] = x10 >>> 0 & 255;
        o[9] = x10 >>> 8 & 255;
        o[10] = x10 >>> 16 & 255;
        o[11] = x10 >>> 24 & 255;
        o[12] = x15 >>> 0 & 255;
        o[13] = x15 >>> 8 & 255;
        o[14] = x15 >>> 16 & 255;
        o[15] = x15 >>> 24 & 255;
        o[16] = x6 >>> 0 & 255;
        o[17] = x6 >>> 8 & 255;
        o[18] = x6 >>> 16 & 255;
        o[19] = x6 >>> 24 & 255;
        o[20] = x7 >>> 0 & 255;
        o[21] = x7 >>> 8 & 255;
        o[22] = x7 >>> 16 & 255;
        o[23] = x7 >>> 24 & 255;
        o[24] = x8 >>> 0 & 255;
        o[25] = x8 >>> 8 & 255;
        o[26] = x8 >>> 16 & 255;
        o[27] = x8 >>> 24 & 255;
        o[28] = x9 >>> 0 & 255;
        o[29] = x9 >>> 8 & 255;
        o[30] = x9 >>> 16 & 255;
        o[31] = x9 >>> 24 & 255;
      }
      function crypto_core_salsa20(out, inp, k, c) {
        core_salsa20(out, inp, k, c);
      }
      function crypto_core_hsalsa20(out, inp, k, c) {
        core_hsalsa20(out, inp, k, c);
      }
      var sigma = new Uint8Array([101, 120, 112, 97, 110, 100, 32, 51, 50, 45, 98, 121, 116, 101, 32, 107]);
      function crypto_stream_salsa20_xor(c, cpos, m, mpos, b, n, k) {
        var z = new Uint8Array(16), x = new Uint8Array(64);
        var u, i;
        for (i = 0; i < 16; i++) z[i] = 0;
        for (i = 0; i < 8; i++) z[i] = n[i];
        while (b >= 64) {
          crypto_core_salsa20(x, z, k, sigma);
          for (i = 0; i < 64; i++) c[cpos + i] = m[mpos + i] ^ x[i];
          u = 1;
          for (i = 8; i < 16; i++) {
            u = u + (z[i] & 255) | 0;
            z[i] = u & 255;
            u >>>= 8;
          }
          b -= 64;
          cpos += 64;
          mpos += 64;
        }
        if (b > 0) {
          crypto_core_salsa20(x, z, k, sigma);
          for (i = 0; i < b; i++) c[cpos + i] = m[mpos + i] ^ x[i];
        }
        return 0;
      }
      function crypto_stream_salsa20(c, cpos, b, n, k) {
        var z = new Uint8Array(16), x = new Uint8Array(64);
        var u, i;
        for (i = 0; i < 16; i++) z[i] = 0;
        for (i = 0; i < 8; i++) z[i] = n[i];
        while (b >= 64) {
          crypto_core_salsa20(x, z, k, sigma);
          for (i = 0; i < 64; i++) c[cpos + i] = x[i];
          u = 1;
          for (i = 8; i < 16; i++) {
            u = u + (z[i] & 255) | 0;
            z[i] = u & 255;
            u >>>= 8;
          }
          b -= 64;
          cpos += 64;
        }
        if (b > 0) {
          crypto_core_salsa20(x, z, k, sigma);
          for (i = 0; i < b; i++) c[cpos + i] = x[i];
        }
        return 0;
      }
      function crypto_stream(c, cpos, d, n, k) {
        var s = new Uint8Array(32);
        crypto_core_hsalsa20(s, n, k, sigma);
        var sn = new Uint8Array(8);
        for (var i = 0; i < 8; i++) sn[i] = n[i + 16];
        return crypto_stream_salsa20(c, cpos, d, sn, s);
      }
      function crypto_stream_xor(c, cpos, m, mpos, d, n, k) {
        var s = new Uint8Array(32);
        crypto_core_hsalsa20(s, n, k, sigma);
        var sn = new Uint8Array(8);
        for (var i = 0; i < 8; i++) sn[i] = n[i + 16];
        return crypto_stream_salsa20_xor(c, cpos, m, mpos, d, sn, s);
      }
      var poly1305 = function(key) {
        this.buffer = new Uint8Array(16);
        this.r = new Uint16Array(10);
        this.h = new Uint16Array(10);
        this.pad = new Uint16Array(8);
        this.leftover = 0;
        this.fin = 0;
        var t0, t1, t2, t3, t4, t5, t6, t7;
        t0 = key[0] & 255 | (key[1] & 255) << 8;
        this.r[0] = t0 & 8191;
        t1 = key[2] & 255 | (key[3] & 255) << 8;
        this.r[1] = (t0 >>> 13 | t1 << 3) & 8191;
        t2 = key[4] & 255 | (key[5] & 255) << 8;
        this.r[2] = (t1 >>> 10 | t2 << 6) & 7939;
        t3 = key[6] & 255 | (key[7] & 255) << 8;
        this.r[3] = (t2 >>> 7 | t3 << 9) & 8191;
        t4 = key[8] & 255 | (key[9] & 255) << 8;
        this.r[4] = (t3 >>> 4 | t4 << 12) & 255;
        this.r[5] = t4 >>> 1 & 8190;
        t5 = key[10] & 255 | (key[11] & 255) << 8;
        this.r[6] = (t4 >>> 14 | t5 << 2) & 8191;
        t6 = key[12] & 255 | (key[13] & 255) << 8;
        this.r[7] = (t5 >>> 11 | t6 << 5) & 8065;
        t7 = key[14] & 255 | (key[15] & 255) << 8;
        this.r[8] = (t6 >>> 8 | t7 << 8) & 8191;
        this.r[9] = t7 >>> 5 & 127;
        this.pad[0] = key[16] & 255 | (key[17] & 255) << 8;
        this.pad[1] = key[18] & 255 | (key[19] & 255) << 8;
        this.pad[2] = key[20] & 255 | (key[21] & 255) << 8;
        this.pad[3] = key[22] & 255 | (key[23] & 255) << 8;
        this.pad[4] = key[24] & 255 | (key[25] & 255) << 8;
        this.pad[5] = key[26] & 255 | (key[27] & 255) << 8;
        this.pad[6] = key[28] & 255 | (key[29] & 255) << 8;
        this.pad[7] = key[30] & 255 | (key[31] & 255) << 8;
      };
      poly1305.prototype.blocks = function(m, mpos, bytes) {
        var hibit = this.fin ? 0 : 1 << 11;
        var t0, t1, t2, t3, t4, t5, t6, t7, c;
        var d0, d1, d2, d3, d4, d5, d6, d7, d8, d9;
        var h0 = this.h[0], h1 = this.h[1], h2 = this.h[2], h3 = this.h[3], h4 = this.h[4], h5 = this.h[5], h6 = this.h[6], h7 = this.h[7], h8 = this.h[8], h9 = this.h[9];
        var r0 = this.r[0], r1 = this.r[1], r2 = this.r[2], r3 = this.r[3], r4 = this.r[4], r5 = this.r[5], r6 = this.r[6], r7 = this.r[7], r8 = this.r[8], r9 = this.r[9];
        while (bytes >= 16) {
          t0 = m[mpos + 0] & 255 | (m[mpos + 1] & 255) << 8;
          h0 += t0 & 8191;
          t1 = m[mpos + 2] & 255 | (m[mpos + 3] & 255) << 8;
          h1 += (t0 >>> 13 | t1 << 3) & 8191;
          t2 = m[mpos + 4] & 255 | (m[mpos + 5] & 255) << 8;
          h2 += (t1 >>> 10 | t2 << 6) & 8191;
          t3 = m[mpos + 6] & 255 | (m[mpos + 7] & 255) << 8;
          h3 += (t2 >>> 7 | t3 << 9) & 8191;
          t4 = m[mpos + 8] & 255 | (m[mpos + 9] & 255) << 8;
          h4 += (t3 >>> 4 | t4 << 12) & 8191;
          h5 += t4 >>> 1 & 8191;
          t5 = m[mpos + 10] & 255 | (m[mpos + 11] & 255) << 8;
          h6 += (t4 >>> 14 | t5 << 2) & 8191;
          t6 = m[mpos + 12] & 255 | (m[mpos + 13] & 255) << 8;
          h7 += (t5 >>> 11 | t6 << 5) & 8191;
          t7 = m[mpos + 14] & 255 | (m[mpos + 15] & 255) << 8;
          h8 += (t6 >>> 8 | t7 << 8) & 8191;
          h9 += t7 >>> 5 | hibit;
          c = 0;
          d0 = c;
          d0 += h0 * r0;
          d0 += h1 * (5 * r9);
          d0 += h2 * (5 * r8);
          d0 += h3 * (5 * r7);
          d0 += h4 * (5 * r6);
          c = d0 >>> 13;
          d0 &= 8191;
          d0 += h5 * (5 * r5);
          d0 += h6 * (5 * r4);
          d0 += h7 * (5 * r3);
          d0 += h8 * (5 * r2);
          d0 += h9 * (5 * r1);
          c += d0 >>> 13;
          d0 &= 8191;
          d1 = c;
          d1 += h0 * r1;
          d1 += h1 * r0;
          d1 += h2 * (5 * r9);
          d1 += h3 * (5 * r8);
          d1 += h4 * (5 * r7);
          c = d1 >>> 13;
          d1 &= 8191;
          d1 += h5 * (5 * r6);
          d1 += h6 * (5 * r5);
          d1 += h7 * (5 * r4);
          d1 += h8 * (5 * r3);
          d1 += h9 * (5 * r2);
          c += d1 >>> 13;
          d1 &= 8191;
          d2 = c;
          d2 += h0 * r2;
          d2 += h1 * r1;
          d2 += h2 * r0;
          d2 += h3 * (5 * r9);
          d2 += h4 * (5 * r8);
          c = d2 >>> 13;
          d2 &= 8191;
          d2 += h5 * (5 * r7);
          d2 += h6 * (5 * r6);
          d2 += h7 * (5 * r5);
          d2 += h8 * (5 * r4);
          d2 += h9 * (5 * r3);
          c += d2 >>> 13;
          d2 &= 8191;
          d3 = c;
          d3 += h0 * r3;
          d3 += h1 * r2;
          d3 += h2 * r1;
          d3 += h3 * r0;
          d3 += h4 * (5 * r9);
          c = d3 >>> 13;
          d3 &= 8191;
          d3 += h5 * (5 * r8);
          d3 += h6 * (5 * r7);
          d3 += h7 * (5 * r6);
          d3 += h8 * (5 * r5);
          d3 += h9 * (5 * r4);
          c += d3 >>> 13;
          d3 &= 8191;
          d4 = c;
          d4 += h0 * r4;
          d4 += h1 * r3;
          d4 += h2 * r2;
          d4 += h3 * r1;
          d4 += h4 * r0;
          c = d4 >>> 13;
          d4 &= 8191;
          d4 += h5 * (5 * r9);
          d4 += h6 * (5 * r8);
          d4 += h7 * (5 * r7);
          d4 += h8 * (5 * r6);
          d4 += h9 * (5 * r5);
          c += d4 >>> 13;
          d4 &= 8191;
          d5 = c;
          d5 += h0 * r5;
          d5 += h1 * r4;
          d5 += h2 * r3;
          d5 += h3 * r2;
          d5 += h4 * r1;
          c = d5 >>> 13;
          d5 &= 8191;
          d5 += h5 * r0;
          d5 += h6 * (5 * r9);
          d5 += h7 * (5 * r8);
          d5 += h8 * (5 * r7);
          d5 += h9 * (5 * r6);
          c += d5 >>> 13;
          d5 &= 8191;
          d6 = c;
          d6 += h0 * r6;
          d6 += h1 * r5;
          d6 += h2 * r4;
          d6 += h3 * r3;
          d6 += h4 * r2;
          c = d6 >>> 13;
          d6 &= 8191;
          d6 += h5 * r1;
          d6 += h6 * r0;
          d6 += h7 * (5 * r9);
          d6 += h8 * (5 * r8);
          d6 += h9 * (5 * r7);
          c += d6 >>> 13;
          d6 &= 8191;
          d7 = c;
          d7 += h0 * r7;
          d7 += h1 * r6;
          d7 += h2 * r5;
          d7 += h3 * r4;
          d7 += h4 * r3;
          c = d7 >>> 13;
          d7 &= 8191;
          d7 += h5 * r2;
          d7 += h6 * r1;
          d7 += h7 * r0;
          d7 += h8 * (5 * r9);
          d7 += h9 * (5 * r8);
          c += d7 >>> 13;
          d7 &= 8191;
          d8 = c;
          d8 += h0 * r8;
          d8 += h1 * r7;
          d8 += h2 * r6;
          d8 += h3 * r5;
          d8 += h4 * r4;
          c = d8 >>> 13;
          d8 &= 8191;
          d8 += h5 * r3;
          d8 += h6 * r2;
          d8 += h7 * r1;
          d8 += h8 * r0;
          d8 += h9 * (5 * r9);
          c += d8 >>> 13;
          d8 &= 8191;
          d9 = c;
          d9 += h0 * r9;
          d9 += h1 * r8;
          d9 += h2 * r7;
          d9 += h3 * r6;
          d9 += h4 * r5;
          c = d9 >>> 13;
          d9 &= 8191;
          d9 += h5 * r4;
          d9 += h6 * r3;
          d9 += h7 * r2;
          d9 += h8 * r1;
          d9 += h9 * r0;
          c += d9 >>> 13;
          d9 &= 8191;
          c = (c << 2) + c | 0;
          c = c + d0 | 0;
          d0 = c & 8191;
          c = c >>> 13;
          d1 += c;
          h0 = d0;
          h1 = d1;
          h2 = d2;
          h3 = d3;
          h4 = d4;
          h5 = d5;
          h6 = d6;
          h7 = d7;
          h8 = d8;
          h9 = d9;
          mpos += 16;
          bytes -= 16;
        }
        this.h[0] = h0;
        this.h[1] = h1;
        this.h[2] = h2;
        this.h[3] = h3;
        this.h[4] = h4;
        this.h[5] = h5;
        this.h[6] = h6;
        this.h[7] = h7;
        this.h[8] = h8;
        this.h[9] = h9;
      };
      poly1305.prototype.finish = function(mac, macpos) {
        var g = new Uint16Array(10);
        var c, mask, f, i;
        if (this.leftover) {
          i = this.leftover;
          this.buffer[i++] = 1;
          for (; i < 16; i++) this.buffer[i] = 0;
          this.fin = 1;
          this.blocks(this.buffer, 0, 16);
        }
        c = this.h[1] >>> 13;
        this.h[1] &= 8191;
        for (i = 2; i < 10; i++) {
          this.h[i] += c;
          c = this.h[i] >>> 13;
          this.h[i] &= 8191;
        }
        this.h[0] += c * 5;
        c = this.h[0] >>> 13;
        this.h[0] &= 8191;
        this.h[1] += c;
        c = this.h[1] >>> 13;
        this.h[1] &= 8191;
        this.h[2] += c;
        g[0] = this.h[0] + 5;
        c = g[0] >>> 13;
        g[0] &= 8191;
        for (i = 1; i < 10; i++) {
          g[i] = this.h[i] + c;
          c = g[i] >>> 13;
          g[i] &= 8191;
        }
        g[9] -= 1 << 13;
        mask = (c ^ 1) - 1;
        for (i = 0; i < 10; i++) g[i] &= mask;
        mask = ~mask;
        for (i = 0; i < 10; i++) this.h[i] = this.h[i] & mask | g[i];
        this.h[0] = (this.h[0] | this.h[1] << 13) & 65535;
        this.h[1] = (this.h[1] >>> 3 | this.h[2] << 10) & 65535;
        this.h[2] = (this.h[2] >>> 6 | this.h[3] << 7) & 65535;
        this.h[3] = (this.h[3] >>> 9 | this.h[4] << 4) & 65535;
        this.h[4] = (this.h[4] >>> 12 | this.h[5] << 1 | this.h[6] << 14) & 65535;
        this.h[5] = (this.h[6] >>> 2 | this.h[7] << 11) & 65535;
        this.h[6] = (this.h[7] >>> 5 | this.h[8] << 8) & 65535;
        this.h[7] = (this.h[8] >>> 8 | this.h[9] << 5) & 65535;
        f = this.h[0] + this.pad[0];
        this.h[0] = f & 65535;
        for (i = 1; i < 8; i++) {
          f = (this.h[i] + this.pad[i] | 0) + (f >>> 16) | 0;
          this.h[i] = f & 65535;
        }
        mac[macpos + 0] = this.h[0] >>> 0 & 255;
        mac[macpos + 1] = this.h[0] >>> 8 & 255;
        mac[macpos + 2] = this.h[1] >>> 0 & 255;
        mac[macpos + 3] = this.h[1] >>> 8 & 255;
        mac[macpos + 4] = this.h[2] >>> 0 & 255;
        mac[macpos + 5] = this.h[2] >>> 8 & 255;
        mac[macpos + 6] = this.h[3] >>> 0 & 255;
        mac[macpos + 7] = this.h[3] >>> 8 & 255;
        mac[macpos + 8] = this.h[4] >>> 0 & 255;
        mac[macpos + 9] = this.h[4] >>> 8 & 255;
        mac[macpos + 10] = this.h[5] >>> 0 & 255;
        mac[macpos + 11] = this.h[5] >>> 8 & 255;
        mac[macpos + 12] = this.h[6] >>> 0 & 255;
        mac[macpos + 13] = this.h[6] >>> 8 & 255;
        mac[macpos + 14] = this.h[7] >>> 0 & 255;
        mac[macpos + 15] = this.h[7] >>> 8 & 255;
      };
      poly1305.prototype.update = function(m, mpos, bytes) {
        var i, want;
        if (this.leftover) {
          want = 16 - this.leftover;
          if (want > bytes)
            want = bytes;
          for (i = 0; i < want; i++)
            this.buffer[this.leftover + i] = m[mpos + i];
          bytes -= want;
          mpos += want;
          this.leftover += want;
          if (this.leftover < 16)
            return;
          this.blocks(this.buffer, 0, 16);
          this.leftover = 0;
        }
        if (bytes >= 16) {
          want = bytes - bytes % 16;
          this.blocks(m, mpos, want);
          mpos += want;
          bytes -= want;
        }
        if (bytes) {
          for (i = 0; i < bytes; i++)
            this.buffer[this.leftover + i] = m[mpos + i];
          this.leftover += bytes;
        }
      };
      function crypto_onetimeauth(out, outpos, m, mpos, n, k) {
        var s = new poly1305(k);
        s.update(m, mpos, n);
        s.finish(out, outpos);
        return 0;
      }
      function crypto_onetimeauth_verify(h, hpos, m, mpos, n, k) {
        var x = new Uint8Array(16);
        crypto_onetimeauth(x, 0, m, mpos, n, k);
        return crypto_verify_16(h, hpos, x, 0);
      }
      function crypto_secretbox(c, m, d, n, k) {
        var i;
        if (d < 32) return -1;
        crypto_stream_xor(c, 0, m, 0, d, n, k);
        crypto_onetimeauth(c, 16, c, 32, d - 32, c);
        for (i = 0; i < 16; i++) c[i] = 0;
        return 0;
      }
      function crypto_secretbox_open(m, c, d, n, k) {
        var i;
        var x = new Uint8Array(32);
        if (d < 32) return -1;
        crypto_stream(x, 0, 32, n, k);
        if (crypto_onetimeauth_verify(c, 16, c, 32, d - 32, x) !== 0) return -1;
        crypto_stream_xor(m, 0, c, 0, d, n, k);
        for (i = 0; i < 32; i++) m[i] = 0;
        return 0;
      }
      function set25519(r, a) {
        var i;
        for (i = 0; i < 16; i++) r[i] = a[i] | 0;
      }
      function car25519(o) {
        var i, v, c = 1;
        for (i = 0; i < 16; i++) {
          v = o[i] + c + 65535;
          c = Math.floor(v / 65536);
          o[i] = v - c * 65536;
        }
        o[0] += c - 1 + 37 * (c - 1);
      }
      function sel25519(p, q2, b) {
        var t, c = ~(b - 1);
        for (var i = 0; i < 16; i++) {
          t = c & (p[i] ^ q2[i]);
          p[i] ^= t;
          q2[i] ^= t;
        }
      }
      function pack25519(o, n) {
        var i, j, b;
        var m = gf(), t = gf();
        for (i = 0; i < 16; i++) t[i] = n[i];
        car25519(t);
        car25519(t);
        car25519(t);
        for (j = 0; j < 2; j++) {
          m[0] = t[0] - 65517;
          for (i = 1; i < 15; i++) {
            m[i] = t[i] - 65535 - (m[i - 1] >> 16 & 1);
            m[i - 1] &= 65535;
          }
          m[15] = t[15] - 32767 - (m[14] >> 16 & 1);
          b = m[15] >> 16 & 1;
          m[14] &= 65535;
          sel25519(t, m, 1 - b);
        }
        for (i = 0; i < 16; i++) {
          o[2 * i] = t[i] & 255;
          o[2 * i + 1] = t[i] >> 8;
        }
      }
      function neq25519(a, b) {
        var c = new Uint8Array(32), d = new Uint8Array(32);
        pack25519(c, a);
        pack25519(d, b);
        return crypto_verify_32(c, 0, d, 0);
      }
      function par25519(a) {
        var d = new Uint8Array(32);
        pack25519(d, a);
        return d[0] & 1;
      }
      function unpack25519(o, n) {
        var i;
        for (i = 0; i < 16; i++) o[i] = n[2 * i] + (n[2 * i + 1] << 8);
        o[15] &= 32767;
      }
      function A(o, a, b) {
        for (var i = 0; i < 16; i++) o[i] = a[i] + b[i];
      }
      function Z(o, a, b) {
        for (var i = 0; i < 16; i++) o[i] = a[i] - b[i];
      }
      function M(o, a, b) {
        var v, c, t0 = 0, t1 = 0, t2 = 0, t3 = 0, t4 = 0, t5 = 0, t6 = 0, t7 = 0, t8 = 0, t9 = 0, t10 = 0, t11 = 0, t12 = 0, t13 = 0, t14 = 0, t15 = 0, t16 = 0, t17 = 0, t18 = 0, t19 = 0, t20 = 0, t21 = 0, t22 = 0, t23 = 0, t24 = 0, t25 = 0, t26 = 0, t27 = 0, t28 = 0, t29 = 0, t30 = 0, b0 = b[0], b1 = b[1], b2 = b[2], b3 = b[3], b4 = b[4], b5 = b[5], b6 = b[6], b7 = b[7], b8 = b[8], b9 = b[9], b10 = b[10], b11 = b[11], b12 = b[12], b13 = b[13], b14 = b[14], b15 = b[15];
        v = a[0];
        t0 += v * b0;
        t1 += v * b1;
        t2 += v * b2;
        t3 += v * b3;
        t4 += v * b4;
        t5 += v * b5;
        t6 += v * b6;
        t7 += v * b7;
        t8 += v * b8;
        t9 += v * b9;
        t10 += v * b10;
        t11 += v * b11;
        t12 += v * b12;
        t13 += v * b13;
        t14 += v * b14;
        t15 += v * b15;
        v = a[1];
        t1 += v * b0;
        t2 += v * b1;
        t3 += v * b2;
        t4 += v * b3;
        t5 += v * b4;
        t6 += v * b5;
        t7 += v * b6;
        t8 += v * b7;
        t9 += v * b8;
        t10 += v * b9;
        t11 += v * b10;
        t12 += v * b11;
        t13 += v * b12;
        t14 += v * b13;
        t15 += v * b14;
        t16 += v * b15;
        v = a[2];
        t2 += v * b0;
        t3 += v * b1;
        t4 += v * b2;
        t5 += v * b3;
        t6 += v * b4;
        t7 += v * b5;
        t8 += v * b6;
        t9 += v * b7;
        t10 += v * b8;
        t11 += v * b9;
        t12 += v * b10;
        t13 += v * b11;
        t14 += v * b12;
        t15 += v * b13;
        t16 += v * b14;
        t17 += v * b15;
        v = a[3];
        t3 += v * b0;
        t4 += v * b1;
        t5 += v * b2;
        t6 += v * b3;
        t7 += v * b4;
        t8 += v * b5;
        t9 += v * b6;
        t10 += v * b7;
        t11 += v * b8;
        t12 += v * b9;
        t13 += v * b10;
        t14 += v * b11;
        t15 += v * b12;
        t16 += v * b13;
        t17 += v * b14;
        t18 += v * b15;
        v = a[4];
        t4 += v * b0;
        t5 += v * b1;
        t6 += v * b2;
        t7 += v * b3;
        t8 += v * b4;
        t9 += v * b5;
        t10 += v * b6;
        t11 += v * b7;
        t12 += v * b8;
        t13 += v * b9;
        t14 += v * b10;
        t15 += v * b11;
        t16 += v * b12;
        t17 += v * b13;
        t18 += v * b14;
        t19 += v * b15;
        v = a[5];
        t5 += v * b0;
        t6 += v * b1;
        t7 += v * b2;
        t8 += v * b3;
        t9 += v * b4;
        t10 += v * b5;
        t11 += v * b6;
        t12 += v * b7;
        t13 += v * b8;
        t14 += v * b9;
        t15 += v * b10;
        t16 += v * b11;
        t17 += v * b12;
        t18 += v * b13;
        t19 += v * b14;
        t20 += v * b15;
        v = a[6];
        t6 += v * b0;
        t7 += v * b1;
        t8 += v * b2;
        t9 += v * b3;
        t10 += v * b4;
        t11 += v * b5;
        t12 += v * b6;
        t13 += v * b7;
        t14 += v * b8;
        t15 += v * b9;
        t16 += v * b10;
        t17 += v * b11;
        t18 += v * b12;
        t19 += v * b13;
        t20 += v * b14;
        t21 += v * b15;
        v = a[7];
        t7 += v * b0;
        t8 += v * b1;
        t9 += v * b2;
        t10 += v * b3;
        t11 += v * b4;
        t12 += v * b5;
        t13 += v * b6;
        t14 += v * b7;
        t15 += v * b8;
        t16 += v * b9;
        t17 += v * b10;
        t18 += v * b11;
        t19 += v * b12;
        t20 += v * b13;
        t21 += v * b14;
        t22 += v * b15;
        v = a[8];
        t8 += v * b0;
        t9 += v * b1;
        t10 += v * b2;
        t11 += v * b3;
        t12 += v * b4;
        t13 += v * b5;
        t14 += v * b6;
        t15 += v * b7;
        t16 += v * b8;
        t17 += v * b9;
        t18 += v * b10;
        t19 += v * b11;
        t20 += v * b12;
        t21 += v * b13;
        t22 += v * b14;
        t23 += v * b15;
        v = a[9];
        t9 += v * b0;
        t10 += v * b1;
        t11 += v * b2;
        t12 += v * b3;
        t13 += v * b4;
        t14 += v * b5;
        t15 += v * b6;
        t16 += v * b7;
        t17 += v * b8;
        t18 += v * b9;
        t19 += v * b10;
        t20 += v * b11;
        t21 += v * b12;
        t22 += v * b13;
        t23 += v * b14;
        t24 += v * b15;
        v = a[10];
        t10 += v * b0;
        t11 += v * b1;
        t12 += v * b2;
        t13 += v * b3;
        t14 += v * b4;
        t15 += v * b5;
        t16 += v * b6;
        t17 += v * b7;
        t18 += v * b8;
        t19 += v * b9;
        t20 += v * b10;
        t21 += v * b11;
        t22 += v * b12;
        t23 += v * b13;
        t24 += v * b14;
        t25 += v * b15;
        v = a[11];
        t11 += v * b0;
        t12 += v * b1;
        t13 += v * b2;
        t14 += v * b3;
        t15 += v * b4;
        t16 += v * b5;
        t17 += v * b6;
        t18 += v * b7;
        t19 += v * b8;
        t20 += v * b9;
        t21 += v * b10;
        t22 += v * b11;
        t23 += v * b12;
        t24 += v * b13;
        t25 += v * b14;
        t26 += v * b15;
        v = a[12];
        t12 += v * b0;
        t13 += v * b1;
        t14 += v * b2;
        t15 += v * b3;
        t16 += v * b4;
        t17 += v * b5;
        t18 += v * b6;
        t19 += v * b7;
        t20 += v * b8;
        t21 += v * b9;
        t22 += v * b10;
        t23 += v * b11;
        t24 += v * b12;
        t25 += v * b13;
        t26 += v * b14;
        t27 += v * b15;
        v = a[13];
        t13 += v * b0;
        t14 += v * b1;
        t15 += v * b2;
        t16 += v * b3;
        t17 += v * b4;
        t18 += v * b5;
        t19 += v * b6;
        t20 += v * b7;
        t21 += v * b8;
        t22 += v * b9;
        t23 += v * b10;
        t24 += v * b11;
        t25 += v * b12;
        t26 += v * b13;
        t27 += v * b14;
        t28 += v * b15;
        v = a[14];
        t14 += v * b0;
        t15 += v * b1;
        t16 += v * b2;
        t17 += v * b3;
        t18 += v * b4;
        t19 += v * b5;
        t20 += v * b6;
        t21 += v * b7;
        t22 += v * b8;
        t23 += v * b9;
        t24 += v * b10;
        t25 += v * b11;
        t26 += v * b12;
        t27 += v * b13;
        t28 += v * b14;
        t29 += v * b15;
        v = a[15];
        t15 += v * b0;
        t16 += v * b1;
        t17 += v * b2;
        t18 += v * b3;
        t19 += v * b4;
        t20 += v * b5;
        t21 += v * b6;
        t22 += v * b7;
        t23 += v * b8;
        t24 += v * b9;
        t25 += v * b10;
        t26 += v * b11;
        t27 += v * b12;
        t28 += v * b13;
        t29 += v * b14;
        t30 += v * b15;
        t0 += 38 * t16;
        t1 += 38 * t17;
        t2 += 38 * t18;
        t3 += 38 * t19;
        t4 += 38 * t20;
        t5 += 38 * t21;
        t6 += 38 * t22;
        t7 += 38 * t23;
        t8 += 38 * t24;
        t9 += 38 * t25;
        t10 += 38 * t26;
        t11 += 38 * t27;
        t12 += 38 * t28;
        t13 += 38 * t29;
        t14 += 38 * t30;
        c = 1;
        v = t0 + c + 65535;
        c = Math.floor(v / 65536);
        t0 = v - c * 65536;
        v = t1 + c + 65535;
        c = Math.floor(v / 65536);
        t1 = v - c * 65536;
        v = t2 + c + 65535;
        c = Math.floor(v / 65536);
        t2 = v - c * 65536;
        v = t3 + c + 65535;
        c = Math.floor(v / 65536);
        t3 = v - c * 65536;
        v = t4 + c + 65535;
        c = Math.floor(v / 65536);
        t4 = v - c * 65536;
        v = t5 + c + 65535;
        c = Math.floor(v / 65536);
        t5 = v - c * 65536;
        v = t6 + c + 65535;
        c = Math.floor(v / 65536);
        t6 = v - c * 65536;
        v = t7 + c + 65535;
        c = Math.floor(v / 65536);
        t7 = v - c * 65536;
        v = t8 + c + 65535;
        c = Math.floor(v / 65536);
        t8 = v - c * 65536;
        v = t9 + c + 65535;
        c = Math.floor(v / 65536);
        t9 = v - c * 65536;
        v = t10 + c + 65535;
        c = Math.floor(v / 65536);
        t10 = v - c * 65536;
        v = t11 + c + 65535;
        c = Math.floor(v / 65536);
        t11 = v - c * 65536;
        v = t12 + c + 65535;
        c = Math.floor(v / 65536);
        t12 = v - c * 65536;
        v = t13 + c + 65535;
        c = Math.floor(v / 65536);
        t13 = v - c * 65536;
        v = t14 + c + 65535;
        c = Math.floor(v / 65536);
        t14 = v - c * 65536;
        v = t15 + c + 65535;
        c = Math.floor(v / 65536);
        t15 = v - c * 65536;
        t0 += c - 1 + 37 * (c - 1);
        c = 1;
        v = t0 + c + 65535;
        c = Math.floor(v / 65536);
        t0 = v - c * 65536;
        v = t1 + c + 65535;
        c = Math.floor(v / 65536);
        t1 = v - c * 65536;
        v = t2 + c + 65535;
        c = Math.floor(v / 65536);
        t2 = v - c * 65536;
        v = t3 + c + 65535;
        c = Math.floor(v / 65536);
        t3 = v - c * 65536;
        v = t4 + c + 65535;
        c = Math.floor(v / 65536);
        t4 = v - c * 65536;
        v = t5 + c + 65535;
        c = Math.floor(v / 65536);
        t5 = v - c * 65536;
        v = t6 + c + 65535;
        c = Math.floor(v / 65536);
        t6 = v - c * 65536;
        v = t7 + c + 65535;
        c = Math.floor(v / 65536);
        t7 = v - c * 65536;
        v = t8 + c + 65535;
        c = Math.floor(v / 65536);
        t8 = v - c * 65536;
        v = t9 + c + 65535;
        c = Math.floor(v / 65536);
        t9 = v - c * 65536;
        v = t10 + c + 65535;
        c = Math.floor(v / 65536);
        t10 = v - c * 65536;
        v = t11 + c + 65535;
        c = Math.floor(v / 65536);
        t11 = v - c * 65536;
        v = t12 + c + 65535;
        c = Math.floor(v / 65536);
        t12 = v - c * 65536;
        v = t13 + c + 65535;
        c = Math.floor(v / 65536);
        t13 = v - c * 65536;
        v = t14 + c + 65535;
        c = Math.floor(v / 65536);
        t14 = v - c * 65536;
        v = t15 + c + 65535;
        c = Math.floor(v / 65536);
        t15 = v - c * 65536;
        t0 += c - 1 + 37 * (c - 1);
        o[0] = t0;
        o[1] = t1;
        o[2] = t2;
        o[3] = t3;
        o[4] = t4;
        o[5] = t5;
        o[6] = t6;
        o[7] = t7;
        o[8] = t8;
        o[9] = t9;
        o[10] = t10;
        o[11] = t11;
        o[12] = t12;
        o[13] = t13;
        o[14] = t14;
        o[15] = t15;
      }
      function S(o, a) {
        M(o, a, a);
      }
      function inv25519(o, i) {
        var c = gf();
        var a;
        for (a = 0; a < 16; a++) c[a] = i[a];
        for (a = 253; a >= 0; a--) {
          S(c, c);
          if (a !== 2 && a !== 4) M(c, c, i);
        }
        for (a = 0; a < 16; a++) o[a] = c[a];
      }
      function pow2523(o, i) {
        var c = gf();
        var a;
        for (a = 0; a < 16; a++) c[a] = i[a];
        for (a = 250; a >= 0; a--) {
          S(c, c);
          if (a !== 1) M(c, c, i);
        }
        for (a = 0; a < 16; a++) o[a] = c[a];
      }
      function crypto_scalarmult(q2, n, p) {
        var z = new Uint8Array(32);
        var x = new Float64Array(80), r, i;
        var a = gf(), b = gf(), c = gf(), d = gf(), e = gf(), f = gf();
        for (i = 0; i < 31; i++) z[i] = n[i];
        z[31] = n[31] & 127 | 64;
        z[0] &= 248;
        unpack25519(x, p);
        for (i = 0; i < 16; i++) {
          b[i] = x[i];
          d[i] = a[i] = c[i] = 0;
        }
        a[0] = d[0] = 1;
        for (i = 254; i >= 0; --i) {
          r = z[i >>> 3] >>> (i & 7) & 1;
          sel25519(a, b, r);
          sel25519(c, d, r);
          A(e, a, c);
          Z(a, a, c);
          A(c, b, d);
          Z(b, b, d);
          S(d, e);
          S(f, a);
          M(a, c, a);
          M(c, b, e);
          A(e, a, c);
          Z(a, a, c);
          S(b, a);
          Z(c, d, f);
          M(a, c, _121665);
          A(a, a, d);
          M(c, c, a);
          M(a, d, f);
          M(d, b, x);
          S(b, e);
          sel25519(a, b, r);
          sel25519(c, d, r);
        }
        for (i = 0; i < 16; i++) {
          x[i + 16] = a[i];
          x[i + 32] = c[i];
          x[i + 48] = b[i];
          x[i + 64] = d[i];
        }
        var x32 = x.subarray(32);
        var x16 = x.subarray(16);
        inv25519(x32, x32);
        M(x16, x16, x32);
        pack25519(q2, x16);
        return 0;
      }
      function crypto_scalarmult_base(q2, n) {
        return crypto_scalarmult(q2, n, _9);
      }
      function crypto_box_keypair(y, x) {
        randombytes(x, 32);
        return crypto_scalarmult_base(y, x);
      }
      function crypto_box_beforenm(k, y, x) {
        var s = new Uint8Array(32);
        crypto_scalarmult(s, x, y);
        return crypto_core_hsalsa20(k, _0, s, sigma);
      }
      var crypto_box_afternm = crypto_secretbox;
      var crypto_box_open_afternm = crypto_secretbox_open;
      function crypto_box(c, m, d, n, y, x) {
        var k = new Uint8Array(32);
        crypto_box_beforenm(k, y, x);
        return crypto_box_afternm(c, m, d, n, k);
      }
      function crypto_box_open(m, c, d, n, y, x) {
        var k = new Uint8Array(32);
        crypto_box_beforenm(k, y, x);
        return crypto_box_open_afternm(m, c, d, n, k);
      }
      var K = [
        1116352408,
        3609767458,
        1899447441,
        602891725,
        3049323471,
        3964484399,
        3921009573,
        2173295548,
        961987163,
        4081628472,
        1508970993,
        3053834265,
        2453635748,
        2937671579,
        2870763221,
        3664609560,
        3624381080,
        2734883394,
        310598401,
        1164996542,
        607225278,
        1323610764,
        1426881987,
        3590304994,
        1925078388,
        4068182383,
        2162078206,
        991336113,
        2614888103,
        633803317,
        3248222580,
        3479774868,
        3835390401,
        2666613458,
        4022224774,
        944711139,
        264347078,
        2341262773,
        604807628,
        2007800933,
        770255983,
        1495990901,
        1249150122,
        1856431235,
        1555081692,
        3175218132,
        1996064986,
        2198950837,
        2554220882,
        3999719339,
        2821834349,
        766784016,
        2952996808,
        2566594879,
        3210313671,
        3203337956,
        3336571891,
        1034457026,
        3584528711,
        2466948901,
        113926993,
        3758326383,
        338241895,
        168717936,
        666307205,
        1188179964,
        773529912,
        1546045734,
        1294757372,
        1522805485,
        1396182291,
        2643833823,
        1695183700,
        2343527390,
        1986661051,
        1014477480,
        2177026350,
        1206759142,
        2456956037,
        344077627,
        2730485921,
        1290863460,
        2820302411,
        3158454273,
        3259730800,
        3505952657,
        3345764771,
        106217008,
        3516065817,
        3606008344,
        3600352804,
        1432725776,
        4094571909,
        1467031594,
        275423344,
        851169720,
        430227734,
        3100823752,
        506948616,
        1363258195,
        659060556,
        3750685593,
        883997877,
        3785050280,
        958139571,
        3318307427,
        1322822218,
        3812723403,
        1537002063,
        2003034995,
        1747873779,
        3602036899,
        1955562222,
        1575990012,
        2024104815,
        1125592928,
        2227730452,
        2716904306,
        2361852424,
        442776044,
        2428436474,
        593698344,
        2756734187,
        3733110249,
        3204031479,
        2999351573,
        3329325298,
        3815920427,
        3391569614,
        3928383900,
        3515267271,
        566280711,
        3940187606,
        3454069534,
        4118630271,
        4000239992,
        116418474,
        1914138554,
        174292421,
        2731055270,
        289380356,
        3203993006,
        460393269,
        320620315,
        685471733,
        587496836,
        852142971,
        1086792851,
        1017036298,
        365543100,
        1126000580,
        2618297676,
        1288033470,
        3409855158,
        1501505948,
        4234509866,
        1607167915,
        987167468,
        1816402316,
        1246189591
      ];
      function crypto_hashblocks_hl(hh, hl, m, n) {
        var wh = new Int32Array(16), wl = new Int32Array(16), bh0, bh1, bh2, bh3, bh4, bh5, bh6, bh7, bl0, bl1, bl2, bl3, bl4, bl5, bl6, bl7, th, tl, i, j, h, l, a, b, c, d;
        var ah0 = hh[0], ah1 = hh[1], ah2 = hh[2], ah3 = hh[3], ah4 = hh[4], ah5 = hh[5], ah6 = hh[6], ah7 = hh[7], al0 = hl[0], al1 = hl[1], al2 = hl[2], al3 = hl[3], al4 = hl[4], al5 = hl[5], al6 = hl[6], al7 = hl[7];
        var pos = 0;
        while (n >= 128) {
          for (i = 0; i < 16; i++) {
            j = 8 * i + pos;
            wh[i] = m[j + 0] << 24 | m[j + 1] << 16 | m[j + 2] << 8 | m[j + 3];
            wl[i] = m[j + 4] << 24 | m[j + 5] << 16 | m[j + 6] << 8 | m[j + 7];
          }
          for (i = 0; i < 80; i++) {
            bh0 = ah0;
            bh1 = ah1;
            bh2 = ah2;
            bh3 = ah3;
            bh4 = ah4;
            bh5 = ah5;
            bh6 = ah6;
            bh7 = ah7;
            bl0 = al0;
            bl1 = al1;
            bl2 = al2;
            bl3 = al3;
            bl4 = al4;
            bl5 = al5;
            bl6 = al6;
            bl7 = al7;
            h = ah7;
            l = al7;
            a = l & 65535;
            b = l >>> 16;
            c = h & 65535;
            d = h >>> 16;
            h = (ah4 >>> 14 | al4 << 32 - 14) ^ (ah4 >>> 18 | al4 << 32 - 18) ^ (al4 >>> 41 - 32 | ah4 << 32 - (41 - 32));
            l = (al4 >>> 14 | ah4 << 32 - 14) ^ (al4 >>> 18 | ah4 << 32 - 18) ^ (ah4 >>> 41 - 32 | al4 << 32 - (41 - 32));
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            h = ah4 & ah5 ^ ~ah4 & ah6;
            l = al4 & al5 ^ ~al4 & al6;
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            h = K[i * 2];
            l = K[i * 2 + 1];
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            h = wh[i % 16];
            l = wl[i % 16];
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            b += a >>> 16;
            c += b >>> 16;
            d += c >>> 16;
            th = c & 65535 | d << 16;
            tl = a & 65535 | b << 16;
            h = th;
            l = tl;
            a = l & 65535;
            b = l >>> 16;
            c = h & 65535;
            d = h >>> 16;
            h = (ah0 >>> 28 | al0 << 32 - 28) ^ (al0 >>> 34 - 32 | ah0 << 32 - (34 - 32)) ^ (al0 >>> 39 - 32 | ah0 << 32 - (39 - 32));
            l = (al0 >>> 28 | ah0 << 32 - 28) ^ (ah0 >>> 34 - 32 | al0 << 32 - (34 - 32)) ^ (ah0 >>> 39 - 32 | al0 << 32 - (39 - 32));
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            h = ah0 & ah1 ^ ah0 & ah2 ^ ah1 & ah2;
            l = al0 & al1 ^ al0 & al2 ^ al1 & al2;
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            b += a >>> 16;
            c += b >>> 16;
            d += c >>> 16;
            bh7 = c & 65535 | d << 16;
            bl7 = a & 65535 | b << 16;
            h = bh3;
            l = bl3;
            a = l & 65535;
            b = l >>> 16;
            c = h & 65535;
            d = h >>> 16;
            h = th;
            l = tl;
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            b += a >>> 16;
            c += b >>> 16;
            d += c >>> 16;
            bh3 = c & 65535 | d << 16;
            bl3 = a & 65535 | b << 16;
            ah1 = bh0;
            ah2 = bh1;
            ah3 = bh2;
            ah4 = bh3;
            ah5 = bh4;
            ah6 = bh5;
            ah7 = bh6;
            ah0 = bh7;
            al1 = bl0;
            al2 = bl1;
            al3 = bl2;
            al4 = bl3;
            al5 = bl4;
            al6 = bl5;
            al7 = bl6;
            al0 = bl7;
            if (i % 16 === 15) {
              for (j = 0; j < 16; j++) {
                h = wh[j];
                l = wl[j];
                a = l & 65535;
                b = l >>> 16;
                c = h & 65535;
                d = h >>> 16;
                h = wh[(j + 9) % 16];
                l = wl[(j + 9) % 16];
                a += l & 65535;
                b += l >>> 16;
                c += h & 65535;
                d += h >>> 16;
                th = wh[(j + 1) % 16];
                tl = wl[(j + 1) % 16];
                h = (th >>> 1 | tl << 32 - 1) ^ (th >>> 8 | tl << 32 - 8) ^ th >>> 7;
                l = (tl >>> 1 | th << 32 - 1) ^ (tl >>> 8 | th << 32 - 8) ^ (tl >>> 7 | th << 32 - 7);
                a += l & 65535;
                b += l >>> 16;
                c += h & 65535;
                d += h >>> 16;
                th = wh[(j + 14) % 16];
                tl = wl[(j + 14) % 16];
                h = (th >>> 19 | tl << 32 - 19) ^ (tl >>> 61 - 32 | th << 32 - (61 - 32)) ^ th >>> 6;
                l = (tl >>> 19 | th << 32 - 19) ^ (th >>> 61 - 32 | tl << 32 - (61 - 32)) ^ (tl >>> 6 | th << 32 - 6);
                a += l & 65535;
                b += l >>> 16;
                c += h & 65535;
                d += h >>> 16;
                b += a >>> 16;
                c += b >>> 16;
                d += c >>> 16;
                wh[j] = c & 65535 | d << 16;
                wl[j] = a & 65535 | b << 16;
              }
            }
          }
          h = ah0;
          l = al0;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[0];
          l = hl[0];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[0] = ah0 = c & 65535 | d << 16;
          hl[0] = al0 = a & 65535 | b << 16;
          h = ah1;
          l = al1;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[1];
          l = hl[1];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[1] = ah1 = c & 65535 | d << 16;
          hl[1] = al1 = a & 65535 | b << 16;
          h = ah2;
          l = al2;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[2];
          l = hl[2];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[2] = ah2 = c & 65535 | d << 16;
          hl[2] = al2 = a & 65535 | b << 16;
          h = ah3;
          l = al3;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[3];
          l = hl[3];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[3] = ah3 = c & 65535 | d << 16;
          hl[3] = al3 = a & 65535 | b << 16;
          h = ah4;
          l = al4;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[4];
          l = hl[4];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[4] = ah4 = c & 65535 | d << 16;
          hl[4] = al4 = a & 65535 | b << 16;
          h = ah5;
          l = al5;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[5];
          l = hl[5];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[5] = ah5 = c & 65535 | d << 16;
          hl[5] = al5 = a & 65535 | b << 16;
          h = ah6;
          l = al6;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[6];
          l = hl[6];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[6] = ah6 = c & 65535 | d << 16;
          hl[6] = al6 = a & 65535 | b << 16;
          h = ah7;
          l = al7;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[7];
          l = hl[7];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[7] = ah7 = c & 65535 | d << 16;
          hl[7] = al7 = a & 65535 | b << 16;
          pos += 128;
          n -= 128;
        }
        return n;
      }
      function crypto_hash(out, m, n) {
        var hh = new Int32Array(8), hl = new Int32Array(8), x = new Uint8Array(256), i, b = n;
        hh[0] = 1779033703;
        hh[1] = 3144134277;
        hh[2] = 1013904242;
        hh[3] = 2773480762;
        hh[4] = 1359893119;
        hh[5] = 2600822924;
        hh[6] = 528734635;
        hh[7] = 1541459225;
        hl[0] = 4089235720;
        hl[1] = 2227873595;
        hl[2] = 4271175723;
        hl[3] = 1595750129;
        hl[4] = 2917565137;
        hl[5] = 725511199;
        hl[6] = 4215389547;
        hl[7] = 327033209;
        crypto_hashblocks_hl(hh, hl, m, n);
        n %= 128;
        for (i = 0; i < n; i++) x[i] = m[b - n + i];
        x[n] = 128;
        n = 256 - 128 * (n < 112 ? 1 : 0);
        x[n - 9] = 0;
        ts64(x, n - 8, b / 536870912 | 0, b << 3);
        crypto_hashblocks_hl(hh, hl, x, n);
        for (i = 0; i < 8; i++) ts64(out, 8 * i, hh[i], hl[i]);
        return 0;
      }
      function add(p, q2) {
        var a = gf(), b = gf(), c = gf(), d = gf(), e = gf(), f = gf(), g = gf(), h = gf(), t = gf();
        Z(a, p[1], p[0]);
        Z(t, q2[1], q2[0]);
        M(a, a, t);
        A(b, p[0], p[1]);
        A(t, q2[0], q2[1]);
        M(b, b, t);
        M(c, p[3], q2[3]);
        M(c, c, D2);
        M(d, p[2], q2[2]);
        A(d, d, d);
        Z(e, b, a);
        Z(f, d, c);
        A(g, d, c);
        A(h, b, a);
        M(p[0], e, f);
        M(p[1], h, g);
        M(p[2], g, f);
        M(p[3], e, h);
      }
      function cswap(p, q2, b) {
        var i;
        for (i = 0; i < 4; i++) {
          sel25519(p[i], q2[i], b);
        }
      }
      function pack(r, p) {
        var tx = gf(), ty = gf(), zi = gf();
        inv25519(zi, p[2]);
        M(tx, p[0], zi);
        M(ty, p[1], zi);
        pack25519(r, ty);
        r[31] ^= par25519(tx) << 7;
      }
      function scalarmult(p, q2, s) {
        var b, i;
        set25519(p[0], gf0);
        set25519(p[1], gf1);
        set25519(p[2], gf1);
        set25519(p[3], gf0);
        for (i = 255; i >= 0; --i) {
          b = s[i / 8 | 0] >> (i & 7) & 1;
          cswap(p, q2, b);
          add(q2, p);
          add(p, p);
          cswap(p, q2, b);
        }
      }
      function scalarbase(p, s) {
        var q2 = [gf(), gf(), gf(), gf()];
        set25519(q2[0], X);
        set25519(q2[1], Y);
        set25519(q2[2], gf1);
        M(q2[3], X, Y);
        scalarmult(p, q2, s);
      }
      function crypto_sign_keypair(pk, sk, seeded) {
        var d = new Uint8Array(64);
        var p = [gf(), gf(), gf(), gf()];
        var i;
        if (!seeded) randombytes(sk, 32);
        crypto_hash(d, sk, 32);
        d[0] &= 248;
        d[31] &= 127;
        d[31] |= 64;
        scalarbase(p, d);
        pack(pk, p);
        for (i = 0; i < 32; i++) sk[i + 32] = pk[i];
        return 0;
      }
      var L = new Float64Array([237, 211, 245, 92, 26, 99, 18, 88, 214, 156, 247, 162, 222, 249, 222, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16]);
      function modL(r, x) {
        var carry, i, j, k;
        for (i = 63; i >= 32; --i) {
          carry = 0;
          for (j = i - 32, k = i - 12; j < k; ++j) {
            x[j] += carry - 16 * x[i] * L[j - (i - 32)];
            carry = Math.floor((x[j] + 128) / 256);
            x[j] -= carry * 256;
          }
          x[j] += carry;
          x[i] = 0;
        }
        carry = 0;
        for (j = 0; j < 32; j++) {
          x[j] += carry - (x[31] >> 4) * L[j];
          carry = x[j] >> 8;
          x[j] &= 255;
        }
        for (j = 0; j < 32; j++) x[j] -= carry * L[j];
        for (i = 0; i < 32; i++) {
          x[i + 1] += x[i] >> 8;
          r[i] = x[i] & 255;
        }
      }
      function reduce(r) {
        var x = new Float64Array(64), i;
        for (i = 0; i < 64; i++) x[i] = r[i];
        for (i = 0; i < 64; i++) r[i] = 0;
        modL(r, x);
      }
      function crypto_sign(sm, m, n, sk) {
        var d = new Uint8Array(64), h = new Uint8Array(64), r = new Uint8Array(64);
        var i, j, x = new Float64Array(64);
        var p = [gf(), gf(), gf(), gf()];
        crypto_hash(d, sk, 32);
        d[0] &= 248;
        d[31] &= 127;
        d[31] |= 64;
        var smlen = n + 64;
        for (i = 0; i < n; i++) sm[64 + i] = m[i];
        for (i = 0; i < 32; i++) sm[32 + i] = d[32 + i];
        crypto_hash(r, sm.subarray(32), n + 32);
        reduce(r);
        scalarbase(p, r);
        pack(sm, p);
        for (i = 32; i < 64; i++) sm[i] = sk[i];
        crypto_hash(h, sm, n + 64);
        reduce(h);
        for (i = 0; i < 64; i++) x[i] = 0;
        for (i = 0; i < 32; i++) x[i] = r[i];
        for (i = 0; i < 32; i++) {
          for (j = 0; j < 32; j++) {
            x[i + j] += h[i] * d[j];
          }
        }
        modL(sm.subarray(32), x);
        return smlen;
      }
      function unpackneg(r, p) {
        var t = gf(), chk = gf(), num2 = gf(), den = gf(), den2 = gf(), den4 = gf(), den6 = gf();
        set25519(r[2], gf1);
        unpack25519(r[1], p);
        S(num2, r[1]);
        M(den, num2, D);
        Z(num2, num2, r[2]);
        A(den, r[2], den);
        S(den2, den);
        S(den4, den2);
        M(den6, den4, den2);
        M(t, den6, num2);
        M(t, t, den);
        pow2523(t, t);
        M(t, t, num2);
        M(t, t, den);
        M(t, t, den);
        M(r[0], t, den);
        S(chk, r[0]);
        M(chk, chk, den);
        if (neq25519(chk, num2)) M(r[0], r[0], I);
        S(chk, r[0]);
        M(chk, chk, den);
        if (neq25519(chk, num2)) return -1;
        if (par25519(r[0]) === p[31] >> 7) Z(r[0], gf0, r[0]);
        M(r[3], r[0], r[1]);
        return 0;
      }
      function crypto_sign_open(m, sm, n, pk) {
        var i;
        var t = new Uint8Array(32), h = new Uint8Array(64);
        var p = [gf(), gf(), gf(), gf()], q2 = [gf(), gf(), gf(), gf()];
        if (n < 64) return -1;
        if (unpackneg(q2, pk)) return -1;
        for (i = 0; i < n; i++) m[i] = sm[i];
        for (i = 0; i < 32; i++) m[i + 32] = pk[i];
        crypto_hash(h, m, n);
        reduce(h);
        scalarmult(p, q2, h);
        scalarbase(q2, sm.subarray(32));
        add(p, q2);
        pack(t, p);
        n -= 64;
        if (crypto_verify_32(sm, 0, t, 0)) {
          for (i = 0; i < n; i++) m[i] = 0;
          return -1;
        }
        for (i = 0; i < n; i++) m[i] = sm[i + 64];
        return n;
      }
      var crypto_secretbox_KEYBYTES = 32, crypto_secretbox_NONCEBYTES = 24, crypto_secretbox_ZEROBYTES = 32, crypto_secretbox_BOXZEROBYTES = 16, crypto_scalarmult_BYTES = 32, crypto_scalarmult_SCALARBYTES = 32, crypto_box_PUBLICKEYBYTES = 32, crypto_box_SECRETKEYBYTES = 32, crypto_box_BEFORENMBYTES = 32, crypto_box_NONCEBYTES = crypto_secretbox_NONCEBYTES, crypto_box_ZEROBYTES = crypto_secretbox_ZEROBYTES, crypto_box_BOXZEROBYTES = crypto_secretbox_BOXZEROBYTES, crypto_sign_BYTES = 64, crypto_sign_PUBLICKEYBYTES = 32, crypto_sign_SECRETKEYBYTES = 64, crypto_sign_SEEDBYTES = 32, crypto_hash_BYTES = 64;
      nacl2.lowlevel = {
        crypto_core_hsalsa20,
        crypto_stream_xor,
        crypto_stream,
        crypto_stream_salsa20_xor,
        crypto_stream_salsa20,
        crypto_onetimeauth,
        crypto_onetimeauth_verify,
        crypto_verify_16,
        crypto_verify_32,
        crypto_secretbox,
        crypto_secretbox_open,
        crypto_scalarmult,
        crypto_scalarmult_base,
        crypto_box_beforenm,
        crypto_box_afternm,
        crypto_box,
        crypto_box_open,
        crypto_box_keypair,
        crypto_hash,
        crypto_sign,
        crypto_sign_keypair,
        crypto_sign_open,
        crypto_secretbox_KEYBYTES,
        crypto_secretbox_NONCEBYTES,
        crypto_secretbox_ZEROBYTES,
        crypto_secretbox_BOXZEROBYTES,
        crypto_scalarmult_BYTES,
        crypto_scalarmult_SCALARBYTES,
        crypto_box_PUBLICKEYBYTES,
        crypto_box_SECRETKEYBYTES,
        crypto_box_BEFORENMBYTES,
        crypto_box_NONCEBYTES,
        crypto_box_ZEROBYTES,
        crypto_box_BOXZEROBYTES,
        crypto_sign_BYTES,
        crypto_sign_PUBLICKEYBYTES,
        crypto_sign_SECRETKEYBYTES,
        crypto_sign_SEEDBYTES,
        crypto_hash_BYTES,
        gf,
        D,
        L,
        pack25519,
        unpack25519,
        M,
        A,
        S,
        Z,
        pow2523,
        add,
        set25519,
        modL,
        scalarmult,
        scalarbase
      };
      function checkLengths(k, n) {
        if (k.length !== crypto_secretbox_KEYBYTES) throw new Error("bad key size");
        if (n.length !== crypto_secretbox_NONCEBYTES) throw new Error("bad nonce size");
      }
      function checkBoxLengths(pk, sk) {
        if (pk.length !== crypto_box_PUBLICKEYBYTES) throw new Error("bad public key size");
        if (sk.length !== crypto_box_SECRETKEYBYTES) throw new Error("bad secret key size");
      }
      function checkArrayTypes() {
        for (var i = 0; i < arguments.length; i++) {
          if (!(arguments[i] instanceof Uint8Array))
            throw new TypeError("unexpected type, use Uint8Array");
        }
      }
      function cleanup(arr) {
        for (var i = 0; i < arr.length; i++) arr[i] = 0;
      }
      nacl2.randomBytes = function(n) {
        var b = new Uint8Array(n);
        randombytes(b, n);
        return b;
      };
      nacl2.secretbox = function(msg, nonce, key) {
        checkArrayTypes(msg, nonce, key);
        checkLengths(key, nonce);
        var m = new Uint8Array(crypto_secretbox_ZEROBYTES + msg.length);
        var c = new Uint8Array(m.length);
        for (var i = 0; i < msg.length; i++) m[i + crypto_secretbox_ZEROBYTES] = msg[i];
        crypto_secretbox(c, m, m.length, nonce, key);
        return c.subarray(crypto_secretbox_BOXZEROBYTES);
      };
      nacl2.secretbox.open = function(box, nonce, key) {
        checkArrayTypes(box, nonce, key);
        checkLengths(key, nonce);
        var c = new Uint8Array(crypto_secretbox_BOXZEROBYTES + box.length);
        var m = new Uint8Array(c.length);
        for (var i = 0; i < box.length; i++) c[i + crypto_secretbox_BOXZEROBYTES] = box[i];
        if (c.length < 32) return null;
        if (crypto_secretbox_open(m, c, c.length, nonce, key) !== 0) return null;
        return m.subarray(crypto_secretbox_ZEROBYTES);
      };
      nacl2.secretbox.keyLength = crypto_secretbox_KEYBYTES;
      nacl2.secretbox.nonceLength = crypto_secretbox_NONCEBYTES;
      nacl2.secretbox.overheadLength = crypto_secretbox_BOXZEROBYTES;
      nacl2.scalarMult = function(n, p) {
        checkArrayTypes(n, p);
        if (n.length !== crypto_scalarmult_SCALARBYTES) throw new Error("bad n size");
        if (p.length !== crypto_scalarmult_BYTES) throw new Error("bad p size");
        var q2 = new Uint8Array(crypto_scalarmult_BYTES);
        crypto_scalarmult(q2, n, p);
        return q2;
      };
      nacl2.scalarMult.base = function(n) {
        checkArrayTypes(n);
        if (n.length !== crypto_scalarmult_SCALARBYTES) throw new Error("bad n size");
        var q2 = new Uint8Array(crypto_scalarmult_BYTES);
        crypto_scalarmult_base(q2, n);
        return q2;
      };
      nacl2.scalarMult.scalarLength = crypto_scalarmult_SCALARBYTES;
      nacl2.scalarMult.groupElementLength = crypto_scalarmult_BYTES;
      nacl2.box = function(msg, nonce, publicKey, secretKey) {
        var k = nacl2.box.before(publicKey, secretKey);
        return nacl2.secretbox(msg, nonce, k);
      };
      nacl2.box.before = function(publicKey, secretKey) {
        checkArrayTypes(publicKey, secretKey);
        checkBoxLengths(publicKey, secretKey);
        var k = new Uint8Array(crypto_box_BEFORENMBYTES);
        crypto_box_beforenm(k, publicKey, secretKey);
        return k;
      };
      nacl2.box.after = nacl2.secretbox;
      nacl2.box.open = function(msg, nonce, publicKey, secretKey) {
        var k = nacl2.box.before(publicKey, secretKey);
        return nacl2.secretbox.open(msg, nonce, k);
      };
      nacl2.box.open.after = nacl2.secretbox.open;
      nacl2.box.keyPair = function() {
        var pk = new Uint8Array(crypto_box_PUBLICKEYBYTES);
        var sk = new Uint8Array(crypto_box_SECRETKEYBYTES);
        crypto_box_keypair(pk, sk);
        return { publicKey: pk, secretKey: sk };
      };
      nacl2.box.keyPair.fromSecretKey = function(secretKey) {
        checkArrayTypes(secretKey);
        if (secretKey.length !== crypto_box_SECRETKEYBYTES)
          throw new Error("bad secret key size");
        var pk = new Uint8Array(crypto_box_PUBLICKEYBYTES);
        crypto_scalarmult_base(pk, secretKey);
        return { publicKey: pk, secretKey: new Uint8Array(secretKey) };
      };
      nacl2.box.publicKeyLength = crypto_box_PUBLICKEYBYTES;
      nacl2.box.secretKeyLength = crypto_box_SECRETKEYBYTES;
      nacl2.box.sharedKeyLength = crypto_box_BEFORENMBYTES;
      nacl2.box.nonceLength = crypto_box_NONCEBYTES;
      nacl2.box.overheadLength = nacl2.secretbox.overheadLength;
      nacl2.sign = function(msg, secretKey) {
        checkArrayTypes(msg, secretKey);
        if (secretKey.length !== crypto_sign_SECRETKEYBYTES)
          throw new Error("bad secret key size");
        var signedMsg = new Uint8Array(crypto_sign_BYTES + msg.length);
        crypto_sign(signedMsg, msg, msg.length, secretKey);
        return signedMsg;
      };
      nacl2.sign.open = function(signedMsg, publicKey) {
        checkArrayTypes(signedMsg, publicKey);
        if (publicKey.length !== crypto_sign_PUBLICKEYBYTES)
          throw new Error("bad public key size");
        var tmp = new Uint8Array(signedMsg.length);
        var mlen = crypto_sign_open(tmp, signedMsg, signedMsg.length, publicKey);
        if (mlen < 0) return null;
        var m = new Uint8Array(mlen);
        for (var i = 0; i < m.length; i++) m[i] = tmp[i];
        return m;
      };
      nacl2.sign.detached = function(msg, secretKey) {
        var signedMsg = nacl2.sign(msg, secretKey);
        var sig = new Uint8Array(crypto_sign_BYTES);
        for (var i = 0; i < sig.length; i++) sig[i] = signedMsg[i];
        return sig;
      };
      nacl2.sign.detached.verify = function(msg, sig, publicKey) {
        checkArrayTypes(msg, sig, publicKey);
        if (sig.length !== crypto_sign_BYTES)
          throw new Error("bad signature size");
        if (publicKey.length !== crypto_sign_PUBLICKEYBYTES)
          throw new Error("bad public key size");
        var sm = new Uint8Array(crypto_sign_BYTES + msg.length);
        var m = new Uint8Array(crypto_sign_BYTES + msg.length);
        var i;
        for (i = 0; i < crypto_sign_BYTES; i++) sm[i] = sig[i];
        for (i = 0; i < msg.length; i++) sm[i + crypto_sign_BYTES] = msg[i];
        return crypto_sign_open(m, sm, sm.length, publicKey) >= 0;
      };
      nacl2.sign.keyPair = function() {
        var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
        var sk = new Uint8Array(crypto_sign_SECRETKEYBYTES);
        crypto_sign_keypair(pk, sk);
        return { publicKey: pk, secretKey: sk };
      };
      nacl2.sign.keyPair.fromSecretKey = function(secretKey) {
        checkArrayTypes(secretKey);
        if (secretKey.length !== crypto_sign_SECRETKEYBYTES)
          throw new Error("bad secret key size");
        var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
        for (var i = 0; i < pk.length; i++) pk[i] = secretKey[32 + i];
        return { publicKey: pk, secretKey: new Uint8Array(secretKey) };
      };
      nacl2.sign.keyPair.fromSeed = function(seed) {
        checkArrayTypes(seed);
        if (seed.length !== crypto_sign_SEEDBYTES)
          throw new Error("bad seed size");
        var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
        var sk = new Uint8Array(crypto_sign_SECRETKEYBYTES);
        for (var i = 0; i < 32; i++) sk[i] = seed[i];
        crypto_sign_keypair(pk, sk, true);
        return { publicKey: pk, secretKey: sk };
      };
      nacl2.sign.publicKeyLength = crypto_sign_PUBLICKEYBYTES;
      nacl2.sign.secretKeyLength = crypto_sign_SECRETKEYBYTES;
      nacl2.sign.seedLength = crypto_sign_SEEDBYTES;
      nacl2.sign.signatureLength = crypto_sign_BYTES;
      nacl2.hash = function(msg) {
        checkArrayTypes(msg);
        var h = new Uint8Array(crypto_hash_BYTES);
        crypto_hash(h, msg, msg.length);
        return h;
      };
      nacl2.hash.hashLength = crypto_hash_BYTES;
      nacl2.verify = function(x, y) {
        checkArrayTypes(x, y);
        if (x.length === 0 || y.length === 0) return false;
        if (x.length !== y.length) return false;
        return vn(x, 0, y, 0, x.length) === 0 ? true : false;
      };
      nacl2.setPRNG = function(fn) {
        randombytes = fn;
      };
      (function() {
        var crypto2 = typeof self !== "undefined" ? self.crypto || self.msCrypto : null;
        if (crypto2 && crypto2.getRandomValues) {
          var QUOTA = 65536;
          nacl2.setPRNG(function(x, n) {
            var i, v = new Uint8Array(n);
            for (i = 0; i < n; i += QUOTA) {
              crypto2.getRandomValues(v.subarray(i, i + Math.min(n - i, QUOTA)));
            }
            for (i = 0; i < n; i++) x[i] = v[i];
            cleanup(v);
          });
        } else if (typeof require !== "undefined") {
          crypto2 = require_crypto();
          if (crypto2 && crypto2.randomBytes) {
            nacl2.setPRNG(function(x, n) {
              var i, v = crypto2.randomBytes(n);
              for (i = 0; i < n; i++) x[i] = v[i];
              cleanup(v);
            });
          }
        }
      })();
    })(typeof module2 !== "undefined" && module2.exports ? module2.exports : self.nacl = self.nacl || {});
  }
});

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => CalderaPlugin
});
module.exports = __toCommonJS(main_exports);

// src/page-import.ts
function fillFromPage(s, page2) {
  if (!page2) return s;
  const out = { ...s };
  for (const k of ["name", "headline", "summary"]) if (!String(out[k] ?? "").trim() && page2[k]) out[k] = page2[k];
  for (const k of ["now", "links", "timeline", "projects"]) if (!(out[k] && out[k].length) && page2[k]?.length) out[k] = page2[k];
  return out;
}
function photoPlan(avatarPath, hubUrl, handle, ext) {
  if (String(avatarPath ?? "").trim() || !["jpg", "png", "webp"].includes(String(ext)) || !/^[a-z0-9-]+$/.test(handle)) return null;
  return { from: `${hubUrl.replace(/\/$/, "")}/@${handle}/img/photo.${ext}`, to: `Caldera/photo.${ext}` };
}
var isPageCode = (code) => /^CAL-P-[\w-]{10,}$/.test(code);

// src/main.ts
var import_obsidian11 = require("obsidian");

// ../core/src/index.ts
var import_tweetnacl = __toESM(require_nacl_fast(), 1);

// ../core/src/flags.ts
var G = globalThis;
var FLAGS = G.__calderaFlags || (G.__calderaFlags = { garden: false });
var gardenEnabled = () => FLAGS.garden;

// ../core/src/features.ts
var UNLOCK = [
  { id: "live", label: "Live visitors on your city", why: "People visiting your sites parachute into your city in real time, and signups get a celebration." },
  { id: "agents", label: "Your AI agents on the map", why: "Your coding agents fly over the repos they're working in, so the city shows what's being built right now." },
  { id: "ai", label: "AI usage on your profile", why: "Tokens by model and provider: the clearest sign you build with AI." },
  { id: "private", label: "Private web view", why: "Your private sections in any browser when you're signed in, with links back into Obsidian." },
  { id: "story", label: "Timeline and projects with links", why: "Your story and live projects, each linking to the real thing." },
  { id: "code", label: "Your GitHub city", why: "Your repos as a living city: buildings grow with commits." }
];
function unlockChecklist(s) {
  return UNLOCK.filter((i) => s[i.id] !== void 0).map((i) => ({ ...i, done: !!s[i.id] }));
}
function featurePrompt(id, o = {}) {
  const hub = (o.hubUrl || "https://caldera.social").replace(/\/$/, ""), vault = o.vaultPath || "<ABSOLUTE PATH TO MY OBSIDIAN VAULT>";
  const page2 = `${hub}/@${o.handle || "<my handle>"}/`, act = o.activityFile || "Caldera/activity.json";
  const keys = o.hosted ? `${hub}/me (signed in with GitHub), section "Live traffic on your city"` : `Obsidian: Settings -> Caldera -> "Live traffic on your city"`;
  const head2 = (what) => `Help me turn on ${what} on my Caldera page (${page2}).${o.hosted ? "" : ` Caldera builds that page from my Obsidian vault: ${vault}`}

`;
  const rules = `

Rules:
${PRIVACY_RULES}
- Show me every change before you make it. Never read or edit .obsidian/plugins/caldera/data.json - it holds my private key.`;
  switch (id) {
    case "live":
      return head2("live visitors on my city") + liveSteps(keys) + rules;
    case "agents":
      return o.agentSetup ? o.agentSetup : head2("my AI agents on the map") + agentSteps(o.hosted ? `${hub}/me` : `Obsidian: Settings -> Caldera -> "AI agents on your city" -> Copy setup prompt`) + rules;
    case "ai":
      return head2("AI usage on my profile") + aiSteps(vault, act) + rules;
    case "private":
      return head2("my private web view") + privateSteps(hub) + rules;
    case "story":
      return head2("a timeline and projects with links") + storySteps(vault) + rules;
    case "code":
      return head2("my GitHub city") + codeSteps(vault, o.hosted) + rules;
    case "email":
      return head2("the daily summary email") + `1. In ${o.hosted ? `${hub}/me` : "Obsidian: Settings -> Caldera -> Daily summary email"}, I type my email address (you don't need to - it's my choice which address).
2. Caldera emails a confirm link; I click it. Every email has a one-click unsubscribe.
It arrives about 8am Pacific, only on days something happened: visits, friend requests, kudos, links into my notes.` + rules;
    case "modules":
      return head2("my own sections (custom modules)") + `${MODULES_HELP}

1. Ask me what I'd like on my page that the standard sections don't cover, and suggest 3 modules that fit me (only from things that are already public).
2. Draft the full Markdown of each one and show me.
3. Create only the ones I approve, one note each in "Caldera/modules/". Use place: side for short ones (office hours, links, stack).` + rules;
    case "groups":
      return head2("groups") + `1. Ask me which communities I belong to (a class, a Discord, a company, a cohort) and suggest short group names (lowercase, dashes), for example producthunt.
2. I join in ${o.hosted ? `${hub}/me` : "Obsidian: Settings -> Caldera -> Groups"} (comma separated). Each group is a town of everyone's cities at ${hub}/g/<name>; share that link with the group.` + rules;
  }
}
function liveSteps(keys) {
  return `Live visitors: every visit to my websites rides through my Caldera city in real time (new visitors parachute in, signups get a celebration). Counts only: no cookies, no IP addresses, no personal data.
1. Get my snippets from ${keys}: one line per district (project), like <script async src="https://caldera.social/t/1.js" integrity="sha384-..." crossorigin="anonymous" data-site="KEY"><\/script>. Paste each line exactly as given, integrity included: it makes the browser refuse any script that isn't the published one. Districts marked private stay "Private" to visitors.
2. For each website I run, find its repo on this computer and the project/district it belongs to (ask me if unsure), and add that district's line to the site's shared layout so every page has it (for example the root layout, _app/_document, base template or index.html head). Don't add it twice.
3. Mark conversions where they happen: call caldera('signup') after a signup and caldera('buy') after a purchase (guard with if (window.caldera)).
4. Deploy each site the way it's normally deployed (ask me first if it goes to production), open the site, then open my city: the visit should appear within a minute.`;
}
function agentSteps(where) {
  return `AI agents on the map: each coding agent I run appears as a drone over the repo it's working in (state and a short task title only - never code, prompts or file contents; private repos stay "Private").
1. Ask me to copy my personal agent setup prompt from ${where} (it contains my agent key and secret - keep them out of every repo) and paste it here.
2. Follow that prompt exactly: it installs ~/.caldera/agent-hook.mjs, writes ~/.caldera/agent.json (chmod 600) and adds hooks to ~/.claude/settings.json, keeping any hooks already there. Repeat on each computer I code on.`;
}
function aiSteps(vault, act) {
  return `AI usage: tokens processed for me, by model and provider (counts only - never prompts, file names or costs).
1. On the computer where I run Obsidian, Caldera already reads Claude Code (~/.claude/projects) and Codex (~/.codex/sessions) logs by itself. If the AI usage section is empty, check those folders exist here.
2. To include other computers or my own products' API usage, write an "ai" block into "${vault}/${act}" from a scheduled script (no AI call per run): {"total": <tokens in the window>, "window_days": 45, "models": [["Claude Opus 5.5", n]], "providers": [["Anthropic", n]], "sources": [["Coding agents (3 machines)", n], ["Product APIs", n]], "note": "one short public sentence"}, and "tokens" per day in each "days" entry. Keep "prompt_version" and every other key already in that file.`;
}
function privateSteps(hub) {
  return `Private web view: my page plus the private sections only I see (today, patterns, goals, visits, sources), in any browser when I'm signed in, with notes linking back into Obsidian.
1. In Obsidian: Settings -> Caldera -> turn on "Private web view". Caldera pushes my private sections to ${hub} encrypted, and shows them only to me when signed in. (I turn this on myself.)
2. Sign in on each browser or phone: open my page, tap "Sign in" (GitHub, an email link, or a code from Obsidian), then use the Public view | Private view switch.`;
}
function storySteps(vault) {
  return `Timeline and projects: my story and live work, each linking to the real thing.
1. In "${vault}/Caldera/profile.md", propose "timeline" lines from things already public about me: "Year | milestone | one-line detail", chapters as "era | Name | 2015-2020", and links as [[Name|https://...]] (linked names also become links in my side menu).
2. Propose "projects" lines for my public projects: "Name | status | https://live-url".
3. Optionally propose "sidebar" groups ("Companies | A, B, C | optional/vault/folder") and "knows" lines ("Label | vault folder", counts only).
Show me everything first; write only what I approve. The page republishes about a minute after profile.md changes.`;
}
function codeSteps(vault, hosted) {
  return hosted ? `My GitHub city is built from my public GitHub repos automatically. To add private repos (never names or code), install the Caldera GitHub app on the repos I choose from my account page, then pick how they show in Settings > Privacy > Private repos on my city: padlocked in place, anonymous (one separate district, no sizes or activity) or hidden.` : `GitHub city: my repos as a living city (districts are projects, buildings are repos, taller = more commits).
1. Make sure "${vault}/Caldera/profile.md" links include my code host: "GitHub | https://github.com/<me>" (or "Forgejo | https://<server>/<me>" for Forgejo, Gitea or Codeberg). Caldera then builds the city from my public repos itself.
2. For private repos too (never named), the setup prompt's routine can write Caldera/city.json with the gh CLI - paste the full Caldera setup prompt for that.
3. Choose how private repos show on my PUBLIC city: set privateRepos in "${vault}/Caldera/profile.md" to show (padlocked buildings in place: no names, but size, activity and the project they sit beside are visible), anonymous (one separate padlocked district, no sizes, activity or projects) or hidden (no trace). Ask me which I want; my private view always shows everything.`;
}
function upgradePrompt(missing, o = {}) {
  const hub = (o.hubUrl || "https://caldera.social").replace(/\/$/, "");
  if (!missing.length) return `My Caldera page (${hub}/@${o.handle || "<my handle>"}/) already has every feature turned on. Nothing to do.`;
  const parts = missing.map((id, n) => `### ${n + 1}. ${id === "email" ? "Daily summary email" : id === "groups" ? "Groups" : UNLOCK.find((u) => u.id === id).label}
${featurePrompt(id, o).split("\n\nRules:")[0].split("\n\n").slice(1).join("\n\n") || featurePrompt(id, o)}`);
  return `Help me upgrade my Caldera page (${hub}/@${o.handle || "<my handle>"}/) with the features it doesn't use yet. Do them in order, ask me before each one, and skip any I say no to.${o.vaultPath ? `
Vault: ${o.vaultPath}` : ""}

${parts.join("\n\n")}

Rules:
${PRIVACY_RULES}
- Show me every change before you make it. Never read or edit .obsidian/plugins/caldera/data.json - it holds my private key.`;
}

// ../core/src/agent-prompt.ts
var PROMPT_VERSION = 6;
var MODULES_HELP = `Custom modules: I can add my own sections to the page. Each module is one Markdown note in "Caldera/modules/" (for example "Caldera/modules/Reading list.md"); the note becomes a section titled with its file name. Optional frontmatter: title (a different title), place (main = the main column under "Now", side = the right-hand column), order (lower numbers first, default 50), publish (false keeps it as a draft). The body is ordinary Markdown: paragraphs, ## subheadings, lists, checkboxes, tables, quotes, code, links ([label](https://...)), images from the vault (![[image.png]], under 2 MB each), and [[@handle/Their note]] links to other members. No HTML, scripts or embeds (they show as plain text), and email addresses and phone numbers are removed. Up to 12 modules. The page republishes about a minute after any change in that folder; deleting the note removes the section. Good modules: reading list, talks and podcasts, my stack, office hours, what I'm looking for, FAQ, press, a changelog of what I shipped. Everything in a module is public.`;
var PRIVACY_RULES = `Everything public is on the open internet, can be copied forever, and can affect other people. Be very cautious. Never write any of these into anything public:
- Other people: no names, initials, handles, photos or descriptions that identify anyone I meet, work with, hire, date, advise or invest with. Say "a founder", "the team", "a friend" only when it adds nothing identifying - usually leave it out.
- Meetings: no meetings, calls, lunches, dinners, interviews or events - not their titles, times, dates, attendees, or that they happened with someone specific.
- Times and places: no times of day, schedules, travel, cities, venues, addresses, offices, home or "where I am".
- Secret or sensitive work: no unannounced, stealth, confidential or NDA projects, codenames, deals, fundraising, investors, acquisitions, valuations, hiring, firing or anything said in confidence.
- Things that can get someone in trouble: legal, medical, health, HR, money, salaries, debts, relationships, family, children, politics, religion.
- Proprietary methods: no trading strategies, signals, indicators, thresholds, regime or risk rules, entry/exit logic, win rates, model weights, prompts, data sources or other trade secrets - in the journal, my notes or anywhere public. Name the theme only ("worked on the trading system").
- Contact details and links: no emails, phone numbers or links to private documents. No money amounts at all.
Describe work only by its public theme ("shipped a release", "wrote about design") and only name things I have already made public on my page (my own public projects, topics and links). If you are unsure, leave it out - an empty field is fine. Caldera also drops any journal line that looks sensitive before publishing.`;
function agentPrompt(o = {}) {
  const hub = (o.hubUrl || "https://caldera.social").replace(/\/$/, "");
  const vault = o.vaultPath || "<ABSOLUTE PATH TO MY OBSIDIAN VAULT>";
  const activity = o.activityFile || "Caldera/activity.json";
  const zip = o.zipUrl || hub + "/download/caldera-latest.zip";
  const topics = o.publicTopics?.length ? o.publicTopics.map((t) => "#" + t).join(", ") : "the tags I allow-listed in Settings -> Caldera -> Public topics";
  const page2 = o.handle ? `${hub}/@${o.handle}/` : `${hub}/@<my handle>/`;
  const rel = "https://github.com/schoettle-cmd/caldera/releases/latest/download";
  const plugin = `1. ${o.zipUrl ? `Download ${zip} and unzip it into "<vault>/.obsidian/plugins/caldera/" so that folder contains main.js, manifest.json and styles.css` : `Download main.js, manifest.json and styles.css from the official GitHub release, ${rel}/<file> (only from that address), into "<vault>/.obsidian/plugins/caldera/". Check manifest.json says "id": "caldera" and "author": "mjonesone, LLC"`} (create the folders if needed).
2. Add "caldera" to the JSON array in "<vault>/.obsidian/community-plugins.json" (create the file as ["caldera"] if it does not exist). Do not remove other entries.`;
  const welcome = `Caldera opens a Welcome window where I type my name and pick a handle; it creates my identity on this device, publishes my profile and opens it in my browser. Do NOT create the identity, read the plugin's data.json, or handle my keys yourself - that file holds my private key. Wait until I tell you my profile is live, then continue with step 2.`;
  const install = o.installed ? `## 1. Install
Caldera is already installed and enabled in this vault. Skip to step 2.
` : `## 0. Obsidian itself (if I'm new - many people are - this step sets everything up; skip it only if I already use Obsidian)
1. Check whether Obsidian is installed (macOS: /Applications/Obsidian.app or ~/Applications/Obsidian.app; Windows: %LOCALAPPDATA%\\Programs\\Obsidian\\Obsidian.exe; Linux: the obsidian command, Flatpak md.obsidian.Obsidian, or an Obsidian AppImage).
2. If it is not installed, tell me you are about to install Obsidian (the free official app from https://obsidian.md), then install it:
   - macOS: brew install --cask obsidian  (no Homebrew? download https://obsidian.md/download , open the .dmg and copy Obsidian.app into /Applications)
   - Windows: winget install --id Obsidian.Obsidian -e  (or run the installer from https://obsidian.md/download)
   - Linux: flatpak install -y flathub md.obsidian.Obsidian  (or the AppImage / .deb from https://obsidian.md/download)
   If you cannot install software here, give me the download link and wait until I tell you it's installed. Do not open Obsidian yet.
3. If I don't have a vault yet, make one for me, completely, BEFORE Obsidian opens it:
   a. Ask where I'd like my notes; if I don't care, use ~/Documents/Notes (Windows: %USERPROFILE%\\Documents\\Notes). Create the folder, a "Welcome.md" note in it ("# Welcome" and one line saying this is my vault), and an empty ".obsidian" folder inside it. That folder is now my vault; use its absolute path below.
   b. Install the plugin into it now (exactly as in step 1 below), so it is ready on first launch.
   c. Make Obsidian quit if it is running (it rewrites its vault list on exit). Then register the vault in Obsidian's vault list, a JSON file at:
      macOS ~/Library/Application Support/obsidian/obsidian.json - Windows %APPDATA%\\obsidian\\obsidian.json - Linux ~/.config/obsidian/obsidian.json (Flatpak: ~/.var/app/md.obsidian.Obsidian/config/obsidian/obsidian.json).
      Create the folder and file if missing. The file looks like {"vaults":{"<id>":{"path":"<absolute vault path>","ts":<now in ms>,"open":true}}}. Add my vault under a new random 16-character lowercase hex id, keep every other key and vault already in the file, and write valid JSON.
   d. Open it: macOS  open "obsidian://open?path=<url-encoded absolute vault path>"  - Windows  start "" "obsidian://open?path=..."  - Linux  xdg-open "obsidian://open?path=..." . If Obsidian instead shows its vault picker, tell me to click "Open folder as vault" and choose that folder.
   e. Tell me, in plain words: in Obsidian, open Settings (the gear, bottom left) -> Community plugins -> click "Turn on community plugins". (If Obsidian shows a "Trust author and enable plugins" prompt instead, click that.) Caldera is already switched on, so its Welcome window appears right away. ${welcome}
   Steps a-e replace step 1 - after e, go straight to step 2.

## 1. Install the plugin (when I already have a vault)
${plugin.replace(/<vault>/g, vault)}
3. Tell me to restart Obsidian (quit fully, then open it). If Obsidian asks, I turn off Restricted mode (Settings -> Community plugins -> Turn on community plugins) and make sure Caldera is switched on. ${welcome}
`;
  const extras = o.extras ? `
${o.extras.trim()}
` : "";
  const G2 = gardenEnabled();
  const richItems = (xs) => xs.filter((x) => !!x).map((x, i) => `${i + 1}. ${x}`).join("\n");
  return `You are helping me run Caldera, the social layer for my Obsidian vault (${hub}). Caldera builds a public profile page from my vault; the more of my real activity it can count, the richer that page is. Follow these instructions exactly. (Caldera setup prompt v${PROMPT_VERSION})

Vault: ${vault}${o.vaultPath ? "" : "\n(If I did not fill this in, find my vault yourself: it is the folder that contains a .obsidian folder. If there is more than one, ask me which. If there is none, I probably don't have Obsidian yet - many people don't - so start with step 0.)"}
My public page: ${page2}

THIS PROMPT IS SAFE TO PASTE AGAIN. Every time I paste it (for example after a Caldera update), first take stock of what is already set up - scheduled jobs, "${activity}", "Caldera/city.json", "Caldera/profile.md", journal fields in my daily notes - then repair anything broken, upgrade it to these instructions, and only add what is missing. Never create a second scheduled job that does the same thing; update the existing one in place.

${install}
## 2. Connect every source of activity I have (this is what makes the page rich)
Check each source below on this computer and tell me which you can reach. Use the ones that work; for the ones that don't, say what it would take (for example "connect your calendar to me") and move on.
- Calendar: events I attended (a calendar connector, or a calendar app's local data).
- Email: emails I sent (a mail connector, or the mail app's local data).
- AI usage (Caldera already reads Claude Code and Codex logs on THIS computer by itself; you add other computers and my products' API usage): Claude Code (~/.claude/projects/**/*.jsonl: assistant messages have message.model and message.usage; count each message.id once; tokens = input + output + cache read + cache write) and Codex (~/.codex/sessions/**/*.jsonl: event_msg token_count -> last_token_usage.total_tokens, model from turn_context). Prompts = user messages I typed in those sessions. Add other tools only if they keep local usage logs.
- Code: git commits I authored, in repositories on this computer, plus my code host if I use one: GitHub (the gh CLI or the GitHub API), or Forgejo / Gitea / Codeberg (the tea CLI or the /api/v1 REST API on that server, with my access token if I have one).
- Documents: files I produced or filed (for example new files in Documents/Downloads I saved, or attachments filed into the vault).
Then write a small script for the routine below that computes these counts with code (no AI call per run).

## 3. Routine (4 times per workday: 9am, 12pm, 3pm and 6pm my local time, Monday to Friday)
Schedule ONE job on my computer (cron, launchd, Task Scheduler, or your own scheduler) at those four times. Nothing overnight and nothing on weekends; Monday's first run catches up the weekend. Keep it light on AI tokens: compute counts with code that reads logs, not with an AI call; read a calendar connector at most once a day and cache the result; and never rewrite a journal entry that already exists.
A. Journal entry (first run of each workday only, for YESTERDAY; on Monday also Saturday and Sunday if they had activity; skip any day that already has caldera_headline). Open (or create) that day's daily note, named YYYY-MM-DD.md, wherever my daily notes live. Add these frontmatter properties, keeping everything already in the note:
   caldera_headline: one sentence, the shape of the day
   caldera_focus: 2-4 short items, what I worked on
   caldera_wins: 1-3 short items, what got done
   caldera_themes: 1-3 single words
   Write them from my notes, calendar, sent email, commits and AI sessions for that day - whatever you can access.
   Name my projects the way they appear in Caldera/profile.md "projects" when they come up${G2 ? ": Caldera grows a garden page for each project (and each distinctive theme) from these journal lines, adding a dated entry whenever it comes up" : ", so the journal and the projects line up"}.

B. Activity counts (every run, for today and yesterday). Update "${vault}/${activity}" (create it if missing). Format:
   { "prompt_version": ${PROMPT_VERSION},
     "days": [ { "date": "YYYY-MM-DD", "meetings": 0, "emails": 0, "prompts": 0, "commits": 0, "docs": 0, "tokens": 0 } ],
     "ai": { "total": 0, "window_days": 45, "models": [["Claude Opus 5.5", 0]], "providers": [["Anthropic", 0]] },
     "code": { "commits": 0, "repos": 0, "languages": ["Python"], "weekly": [0], "url": "https://github.com/<me>", "start": "Mon YYYY" } }
   One object per date: replace that date's object if it exists, keep the last 60 days, and only include counts you can actually measure (omit the rest - never guess). meetings = calendar events attended, emails = emails I sent, prompts = AI prompts I sent, commits = git commits I authored, docs = documents/attachments I produced or filed, tokens = AI tokens processed for me that day. Notes are counted by the plugin itself. Always write "prompt_version": ${PROMPT_VERSION} - Caldera uses it to tell me when this routine is out of date.
   AI usage ("tokens" per day and the "ai" block, last 45 days): group by model (readable names) and by provider. Never include prompts, file names or costs.
   Code ("code" block): count my commits in the last 52 weeks per week across my repositories, number of repos, and top 4 languages. Counts only - never names of private repositories.
   AI sources (optional, inside "ai"): "sources": [["Coding agents (3 machines)", n], ["Product APIs", n]] and "note": one short public sentence on what's counted.
   Optional extras (only if I have the data; each makes a section of my page): "projects": {"<public project name from profile.md>": <commits this year>} (commit counts next to each project); "knows": [["Companies", 252], ["People", 101]] (What it knows: notes per vault folder, counts only); "inbox": {"total": n, "kinds": [["Reports", 61]], "series": {"label": "Pitch decks received per week", "weeks": [["Aug 3", 5]]}} (Inbox to knowledge: if an agent files my email attachments into the vault, documents by kind - counts only, never names); "numbers": [["145", "daily digests written"]] (a few headline numbers).

C. City (every run, only if I use GitHub, Forgejo, Gitea or Codeberg). Keep "${vault}/Caldera/city.json" fresh: {"generated": "<ISO time>", "source": "github <my login>" (or "forgejo <https://server/my login>"), "repos": [{"name", "project", "public", "language", "commits", "weeks", "week", "today", "pushed", "url", "description"}]} with one row per repo I own (private ones too, if the gh CLI is signed in): project = which of my projects it belongs to (group repos into districts; ask me once how to group them), public = true only for public repos, commits = commits in the last 52 weeks, weeks = the last 12 weekly commit counts, week = commits in the last 7 days, today = commits today, pushed = last push time, url and description only for public repos. On GitHub use gh api user/repos and repos/<owner>/<repo>/stats/commit_activity. On Forgejo / Gitea / Codeberg use GET /api/v1/user/repos (or /api/v1/users/<me>/repos) and page through /api/v1/repos/<owner>/<repo>/commits?limit=50, counting by commit.author.date yourself (that endpoint ignores "since"). Caldera turns it into a little city on my page: districts are projects, buildings are repos. Visitors see public repos; private ones never show names, and I choose how much else they show with privateRepos in Caldera/profile.md: show (the default: locked glass buildings in place, so size, activity and the project they sit beside are visible, never names), anonymous (one separate padlocked district, no sizes or activity) or hidden (no trace). Ask me once which I want and set it. Full details only in my own Private view. If you cannot reach the API, instead make sure my profile is a line in "links" in Caldera/profile.md ("GitHub | https://github.com/<me>", or "Forgejo | https://<server>/<me>" for Forgejo, Gitea or Codeberg) - Caldera then builds the city from my public repos itself. With no code host at all, Caldera builds the city from my vault folders.

D. Publish. If Caldera auto-publish is on (Settings -> Caldera -> Auto-publish every N hours), you are done. Otherwise ask me to run "Caldera: Publish my profile" from the command palette.

After setting up the job, run it once now, then backfill: for each of the last 14 days that has activity, add the journal fields from A to that day's daily note. Show me the 14 entries before writing them.

## 4. Make the page rich (once; on a re-paste, only fill what is still empty)
Anything that would become PUBLIC needs my explicit yes first: show me exactly what you propose, wait for my answer, then make only the approved changes.
${richItems([
    `Page text, in "${vault}/Caldera/profile.md": "headline" (one line), "summary" (2 sentences, links as [[Label|https://...]]), "now" (3 lines on what I'm doing now), "timeline" (only things already public: "Year | milestone | one-line detail", grouped into chapters with "era | Name | 2015-2020" lines), "projects" (Name | status | https://link, only public projects) and "links" (Label | https://url - include my GitHub profile if I have one: that turns on the Code section and the city). Offer to set a profile photo: save an image I choose into "Caldera/img/" and set "photo" to that path. Optional: offer a masthead (the wide cover image across the top of the page, about 3:1 such as 1800x600, under 2 MB): an image I choose or a free-to-use one I approve, saved into "Caldera/img/" with "banner" set to its path. Also suggest "sidebar" groups (Group | item, item), up to 14 "graph" note names (people/companies/projects I'm comfortable showing - the page shows how many notes link to each), and 6 "backlinks" (Title | short context).`,
    G2 ? `My garden (public notes). Find 3-8 notes that would be good to grow in public: evergreen essays, how-tos, reading notes, overviews of work that is already public. Skip anything about people, clients, deals, money, health, family or unannounced work. List them with one line each on why, and a suggested stage (seedling = rough, budding = taking shape, evergreen = worked through). After I approve, add to the frontmatter of the approved notes only: "caldera: garden", "stage: <stage>" and "license: all-rights" (ask me if I want "cc-by" instead). The WHOLE note becomes a public page, so read every line and point out anything private first.` : null,
    `Custom modules. ${MODULES_HELP} Suggest 2-3 modules that fit me (draft the full Markdown of each from things that are already public), and create only the ones I approve.`,
    `Notes friends can receive. Suggest notes I might want to share with friends as encrypted cards (frameworks, checklists, templates). After I approve, add "caldera: friends" to their frontmatter.`,
    `Public topics. List my 10 most-used tags that are safe to show publicly (no client, company or people tags), with a short label for each. I add them myself in Settings -> Caldera -> Public topics. Do not edit plugin settings.`,
    `Goals. If "${vault}/Caldera/Goals.md" doesn't exist, offer to create it with my current goals (checkboxes under ## headings). It stays private: it powers the goals section only I see.`
  ])}

## 5. The live city, my private side and my people (ask me first for each; skip what's already on)
A. ${liveSteps(`Obsidian: Settings -> Caldera -> "Live traffic on your city" (GitHub sign-ups: ${hub}/me)`)}
B. ${agentSteps(`Obsidian: Settings -> Caldera -> "AI agents on your city" -> Copy setup prompt (GitHub sign-ups: ${hub}/me)`)}
C. ${privateSteps(hub)}
D. Daily summary email: tell me I can add my email in Obsidian: Settings -> Caldera -> Daily summary email (then click the confirm link). It only sends on days something happened (visits, friend requests, kudos, links into my notes). Don't type an address for me.
E. Groups: ask which communities I'm in and suggest short group names (lowercase, dashes, like producthunt); I join in Settings -> Caldera -> Groups. Each group is a town of everyone's cities at ${hub}/g/<name>.
F. Friends and kudos need no setup: tell me I can follow people and send kudos from anyone's page (signed in; people who follow each other are friends), people I share public GitHub repos with are connected automatically, and the World map (${hub}/world) shows everyone's city.${extras}

## 6. Privacy rules (these override everything above)
${PRIVACY_RULES}
Themes and topics: only use topics among ${topics}.
Also: never write to any other part of the vault, never change notes' privacy markings (caldera: public${G2 ? " / garden" : ""} / friends / private) without asking, ${G2 ? "never move notes into or out of the Garden folder, " : ""}never touch .obsidian/plugins/caldera/data.json - it holds my private key.

## 7. Report
When you finish, show me a short checklist of every source and feature - calendar, email, AI usage, code, documents, journal, city, page text (headline, summary, now, timeline, projects, sidebar, photo, masthead), custom modules, extras (what it knows, inbox to knowledge, project commits), ${G2 ? "garden, " : ""}live visitors, agents on the map, private web view, daily email, groups - marked connected, skipped (and why) or needs me. After each scheduled run, the job only needs to log what it wrote. Then tell me to run "Caldera: Preview my public profile", check it, and publish.

## 8. Later
- Changing my page: name, headline, photo, banner, links, properties, topics, which sections show and whether I'm listed live in the frontmatter of "${vault}/Caldera/profile.md". Edit it (same privacy rules) and the page republishes within about a minute. New sections of my own are modules: one note each in "${vault}/Caldera/modules/". Guide: ${hub}/guide.html
${G2 ? `- My garden home: ${hub}/@<my handle>/garden.html shows live my notes, links from other gardens, gravity (goodwill friends give), help credits (100 to start; ask bounties are held until awarded, returned after 30 days, no cash value), my open asks and offers, friends and weekly rank.
` : ""}- My profile inside Obsidian: the ribbon icon "My Caldera profile" opens my page as a tab. "Private view" adds private sections only I see (visits, today, on this day, patterns, goals, and a checklist of which sources are connected); "Public view" shows the page as visitors see it.
- When Caldera tells me my setup prompt is out of date, I copy it again ("Caldera: Copy the AI setup prompt") and paste it here; you upgrade the routine in place.`;
}
function editPrompt(o = {}) {
  const hub = (o.hubUrl || "https://caldera.social").replace(/\/$/, "");
  const vault = o.vaultPath || "<ABSOLUTE PATH TO MY OBSIDIAN VAULT>";
  return `Help me change my Caldera profile (${hub}/@${o.handle || "<my handle>"}/). Caldera builds that public page from my Obsidian vault.

Vault: ${vault}${o.vaultPath ? "" : "\n(If I did not fill this in, find my vault yourself: it is the folder that contains a .obsidian folder. If there is more than one, ask me which.)"}

Where things live:
- Name, headline, photo, banner, links, properties, topics, which sections show, and directory listing: the frontmatter of "Caldera/profile.md". Keep its format. Photo and banner are paths to images inside the vault.
- A note on my page: add "caldera: public" to that note's frontmatter (title and first paragraph are shown). Remove it to take the note down.
- My daily journal: caldera_headline / caldera_focus / caldera_wins / caldera_themes in daily notes named YYYY-MM-DD.md.
- Activity counts: "Caldera/activity.json".
- ${MODULES_HELP}
The page republishes automatically about a minute after Caldera/profile.md or a module changes. For anything else, tell me to run "Caldera: Publish my profile".

Rules:
- Show me the exact change before you make it, and only make what I approve.
${PRIVACY_RULES}
- Never read or edit .obsidian/plugins/caldera/data.json - it holds my private key. My handle can only be changed in Settings -> Caldera.

What I want to change: <DESCRIBE THE CHANGE>`;
}

// ../core/src/privacy.ts
var RULES = [
  ["time", /\b\d{1,2}(:\d{2})?\s?(a\.?m\.?|p\.?m\.?)\b|\b\d{1,2}:\d{2}\b|\b(noon|midnight|o'clock|this morning|this afternoon|tonight|tomorrow|tmrw)\b/i],
  ["meeting", /\b(meeting|meetings|met with|meet with|meets with|call with|calls with|called|zoom|lunch|dinner|breakfast|coffee|drinks|catch[- ]?up|1[:-]1|one[- ]on[- ]one|interview(ed)?|pitched|pitch meeting|sync with|session with|appointment|attendee|agenda|board meeting|offsite|hosted|visited|visit to|trip|flight|flew|travel(l?ed|ing)?)\b/i],
  ["location", /\b(?:in|at|from|to|near|around)\s+(?:the\s+)?[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*/],
  // case-sensitive: "in Santa Monica", not "in the category"
  ["place", /\b(street|st\.|avenue|ave\.|boulevard|blvd|road|rd\.|lane|suite|ste\.|hotel|restaurant|airport|hq|headquarters|downtown|neighborhood|zip code|address|office in|offices in)\b/i],
  ["secret", /\b(secret|confidential|stealth|unannounced|under wraps|nda|non[- ]disclosure|private beta|embargo(ed)?|off the record|internal only|not public|leak(ed)?|rumou?r|codename|code name)\b/i],
  ["trouble", /\b(lawsuit|sue[ds]?|legal|lawyer|attorney|court|settlement|investigation|fired|firing|layoffs?|laid off|resign(ed|ation)?|hr\b|complaint|harass\w*|divorce|custody|diagnos\w*|therapy|therapist|doctor|hospital|surgery|medical|health|pregnan\w*|arrest\w*|police|debt|bankrupt\w*|salary|raise|bonus|equity|valuation|term sheet|acquisition|acquire[ds]?|merger|investor|investors|fundrais\w*|round|due diligence|diligence|cap table)\b/i],
  ["money", /[$€£¥]\s?\d|\b\d[\d,.]*\s?(k|m|mm|bn|million|billion|thousand|usd|dollars?|euros?)\b/i],
  ["contact", /[\w.+-]+@[\w-]+\.[\w.]+|(?<!\d)(\+?\d[\d .()-]{7,}\d)(?!\d)|https?:\/\/|www\./i],
  ["family", /\b(wife|husband|partner|girlfriend|boyfriend|ex-wife|ex-husband|son|daughter|kids?|children|mom|dad|mother|father|brother|sister|family)\b/i]
];
var BASE_ALLOW = [
  "Obsidian",
  "Caldera",
  "Claude",
  "Claude Code",
  "ChatGPT",
  "OpenAI",
  "Codex",
  "Cursor",
  "GitHub",
  "Git",
  "Google",
  "Gmail",
  "Apple",
  "iOS",
  "Android",
  "Mac",
  "macOS",
  "Windows",
  "Linux",
  "Notion",
  "Slack",
  "Discord",
  "Figma",
  "Python",
  "JavaScript",
  "TypeScript",
  "React",
  "Node",
  "AI",
  "API",
  "LLM",
  "MCP",
  "SQL",
  "CSS",
  "HTML",
  "PDF",
  "CRM",
  "SEO",
  "UX",
  "UI",
  "Markdown",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday",
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
  "Building",
  "Operations",
  "Research",
  "Writing",
  "Design",
  "Shipping",
  "Learning"
];
function publicTextFilter(allowed = []) {
  const allow = new Set([...BASE_ALLOW, ...allowed].flatMap((a) => [a.toLowerCase(), ...a.toLowerCase().split(/\s+/)]).filter(Boolean));
  const why = (line) => {
    const t = String(line ?? "").trim();
    if (!t) return null;
    for (const [name, rx] of RULES) {
      const m = t.match(rx);
      if (!m) continue;
      if (name === "location") {
        const words2 = m[0].match(/[A-Z][a-z]+/g) || [];
        if (words2.length && words2.every((w) => allow.has(w.toLowerCase()))) continue;
      }
      return name;
    }
    const words = t.split(/\s+/);
    for (let i = 1; i < words.length; i++) {
      const w = words[i].replace(/[^A-Za-z'-]/g, "");
      if (!/^[A-Z][a-z]{1,}/.test(w)) continue;
      if (/[.!?:]$/.test(words[i - 1])) continue;
      if (allow.has(w.toLowerCase()) || allow.has(w.toLowerCase().replace(/'s$/, ""))) continue;
      return "name";
    }
    return null;
  };
  const f = ((line) => why(line) === null);
  f.why = why;
  return f;
}

// ../core/src/checklist.ts
var ITEMS = [
  { id: "photo", label: "Profile photo", why: "A face (or a logo) makes people trust the page and follow you back." },
  { id: "banner", label: "Masthead", why: "A wide cover image across the top makes the page feel like yours and shows in link previews." },
  { id: "headline", label: "Headline", why: "One line under your name that says what you do." },
  { id: "summary", label: "About you", why: "Two sentences so a visitor knows why to follow you." },
  { id: "links", label: "Links", why: "Where else to find you: your site, GitHub, socials." },
  { id: "garden", label: "First garden note", why: "One note grown in public gives visitors something to read and link to." },
  { id: "friend", label: "First friend", why: "Friends see your updates, link your notes and give you gravity." },
  { id: "group", label: "Join a group", why: "Groups are towns of everyone's cities, and people in them are suggested to you." },
  { id: "email", label: "Daily summary email", why: "Hear when people visit, link your notes or ask to be friends." }
];
function pageChecklist(s) {
  return ITEMS.filter((i) => !(i.id === "garden" && (s.garden === void 0 || !gardenEnabled()))).map((i) => ({ ...i, done: i.id === "summary" ? s.summary !== false : i.id === "garden" ? !!s.garden : !!s[i.id] }));
}
function imagePrompt(kind, o = {}) {
  const hub = (o.hubUrl || "https://caldera.social").replace(/\/$/, ""), vault = o.vaultPath || "<ABSOLUTE PATH TO MY OBSIDIAN VAULT>";
  const what = kind === "banner" ? `a masthead: the wide cover image across the top of my page. It should be about 3:1 (for example 1800x600), landscape, calm enough that my name and photo read on top of it, and under 2 MB (JPG or WebP).` : `a profile photo: square, at least 400x400, my face or my logo, under 1 MB (JPG, PNG or WebP).`;
  const key = kind === "banner" ? "banner" : "photo", file = kind === "banner" ? "banner" : "photo";
  return `Help me add ${what}

My Caldera page: ${hub}/@${o.handle || "<my handle>"}/ . Caldera builds it from my Obsidian vault.
Vault: ${vault}

1. Ask me which image to use. Offer three routes: (a) I point you at a photo I already have, (b) you find a free-to-use image I approve (say where it's from and its license), ${kind === "banner" ? "or (c) you make one (a simple abstract or landscape image, or an image generator I already use)" : "or (c) I'll take one now"}.
2. Crop or resize it to the size above if you can, and save it as "${vault}/Caldera/${file}.jpg" (or .png / .webp to match).
3. In the frontmatter of "${vault}/Caldera/profile.md", set ${key}: "Caldera/${file}.jpg" (the path inside the vault). Change nothing else.
4. Caldera republishes the page about a minute after profile.md changes. Tell me to look at ${hub}/@${o.handle || "<my handle>"}/ .

Rules:
${PRIVACY_RULES}
- The image is public: no other people's faces without their OK, no screens, documents, addresses or anything readable that's private.
- Never read or edit .obsidian/plugins/caldera/data.json - it holds my private key.`;
}

// ../core/src/links.ts
var A_TAG = /<a\b([^>]*)>/gi;
var attr = (attrs, name) => {
  const m = attrs.match(new RegExp(`\\s${name}\\s*=\\s*("([^"]*)"|'([^']*)'|([^\\s"'>]+))`, "i"));
  return m ? m[2] ?? m[3] ?? m[4] ?? "" : null;
};
var setAttr = (attrs, name, value) => {
  const re = new RegExp(`\\s${name}\\s*=\\s*("[^"]*"|'[^']*'|[^\\s"'>]+)`, "i");
  return re.test(attrs) ? attrs.replace(re, ` ${name}="${value}"`) : `${attrs.replace(/\s*\/?$/, "")} ${name}="${value}"`;
};
function isExternalHref(href, ownHosts) {
  const h = href.trim();
  if (!/^https?:\/\//i.test(h) && !h.startsWith("//")) return false;
  try {
    const host = new URL(h.startsWith("//") ? "https:" + h : h).host.toLowerCase();
    return !ownHosts.some((o) => o && host === o.toLowerCase());
  } catch {
    return false;
  }
}
function externalLinksNewWindow(html, ownHosts) {
  return html.replace(A_TAG, (whole, attrs) => {
    const href = attr(attrs, "href");
    if (href == null || !isExternalHref(href, ownHosts)) return whole;
    const rel = new Set(String(attr(attrs, "rel") || "").split(/\s+/).filter(Boolean).map((x) => x.toLowerCase()));
    rel.add("noopener");
    rel.add("noreferrer");
    let a = setAttr(attrs, "target", "_blank");
    a = setAttr(a, "rel", [...rel].join(" "));
    return `<a${a}>`;
  });
}

// ../core/src/index.ts
var PROTOCOL_VERSION = 1;
var B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function b58encode(bytes) {
  let n = 0n;
  for (const b of bytes) n = (n << 8n) + BigInt(b);
  let out = "";
  while (n > 0n) {
    out = B58[Number(n % 58n)] + out;
    n /= 58n;
  }
  for (const b of bytes) {
    if (b === 0) out = "1" + out;
    else break;
  }
  return out;
}
function b58decode(s) {
  let n = 0n;
  for (const c of s) {
    const i = B58.indexOf(c);
    if (i < 0) throw new Error("bad base58");
    n = n * 58n + BigInt(i);
  }
  const bytes = [];
  while (n > 0n) {
    bytes.unshift(Number(n & 255n));
    n >>= 8n;
  }
  for (const c of s) {
    if (c === "1") bytes.unshift(0);
    else break;
  }
  return new Uint8Array(bytes);
}
var b64 = {
  enc(u) {
    let s = "";
    for (const b of u) s += String.fromCharCode(b);
    return btoa(s);
  },
  dec(s) {
    const bin = atob(s);
    const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u;
  }
};
var utf8 = (s) => new TextEncoder().encode(s);
var fromUtf8 = (u) => new TextDecoder().decode(u);
function canonical(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return "[" + value.map(canonical).join(",") + "]";
  const obj = value;
  return "{" + Object.keys(obj).filter((k) => obj[k] !== void 0).sort().map((k) => JSON.stringify(k) + ":" + canonical(obj[k])).join(",") + "}";
}
function newIdentity() {
  const sign2 = import_tweetnacl.default.sign.keyPair();
  const box = import_tweetnacl.default.box.keyPair();
  return {
    id: idFromPublicKey(sign2.publicKey),
    signPublic: b64.enc(sign2.publicKey),
    signSecret: b64.enc(sign2.secretKey),
    boxPublic: b64.enc(box.publicKey),
    boxSecret: b64.enc(box.secretKey)
  };
}
function idFromPublicKey(pk) {
  return "cal:" + b58encode(pk);
}
function publicKeyFromId(id) {
  if (!id.startsWith("cal:")) throw new Error("not a caldera id");
  const pk = b58decode(id.slice(4));
  if (pk.length !== 32) throw new Error("bad id length");
  return pk;
}
function signingBytes(e) {
  return utf8(canonical({ v: e.v, type: e.type, from: e.from, ts: e.ts, body: e.body }));
}
function sign(identity, type, body, ts = (/* @__PURE__ */ new Date()).toISOString()) {
  const unsigned = { v: PROTOCOL_VERSION, type, from: identity.id, ts, body };
  const sig = import_tweetnacl.default.sign.detached(signingBytes(unsigned), b64.dec(identity.signSecret));
  return { ...unsigned, sig: b64.enc(sig) };
}
function verify(e) {
  try {
    if (!e || e.v !== PROTOCOL_VERSION || typeof e.sig !== "string") return false;
    return import_tweetnacl.default.sign.detached.verify(signingBytes(e), b64.dec(e.sig), publicKeyFromId(e.from));
  } catch {
    return false;
  }
}
function envelopeHash(e) {
  return b64.enc(import_tweetnacl.default.hash(utf8(canonical(e)))).slice(0, 43);
}
function seal(plaintext, recipientBoxPublic, sender) {
  const nonce = import_tweetnacl.default.randomBytes(import_tweetnacl.default.box.nonceLength);
  const box = import_tweetnacl.default.box(utf8(plaintext), nonce, b64.dec(recipientBoxPublic), b64.dec(sender.boxSecret));
  return { nonce: b64.enc(nonce), box: b64.enc(box) };
}
function open(sealed, senderBoxPublic, recipient) {
  const out = import_tweetnacl.default.box.open(b64.dec(sealed.box), b64.dec(sealed.nonce), b64.dec(senderBoxPublic), b64.dec(recipient.boxSecret));
  return out ? fromUtf8(out) : null;
}
var ACTIVITY_WEIGHTS = { meetings: 6, emails: 2, prompts: 1, commits: 0.5, notes: 0.25, docs: 1 };
var ACTIVITY_CAPS = { notes: 60, docs: 40, commits: 200 };
function activityScore(c) {
  let s = 0;
  for (const [k, w] of Object.entries(ACTIVITY_WEIGHTS)) {
    s += w * Math.min(c[k] ?? 0, ACTIVITY_CAPS[k] ?? Infinity);
  }
  return Math.round(s);
}

// src/auto.ts
var import_obsidian = require("obsidian");

// src/city.ts
function cleanSites(v) {
  const out = [];
  for (const x of Array.isArray(v) ? v : [v]) {
    let h = String(x ?? "").trim().toLowerCase();
    if (!h) continue;
    try {
      h = new URL(/^[a-z][a-z0-9+.-]*:\/\//.test(h) ? h : "https://" + h).hostname;
    } catch {
      continue;
    }
    h = h.replace(/^www\./, "");
    if (/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(h) && h.length <= 253 && h !== "github.com" && h !== "github.io" && !out.includes(h)) out.push(h);
    if (out.length >= 6) break;
  }
  return out.length ? out : void 0;
}
var privateCluster = (n) => n <= 0 ? 0 : n <= 5 ? 3 : n <= 20 ? 8 : 15;
function noteKind(path, garden) {
  if (garden) return "garden";
  const p = path.toLowerCase();
  if (/(^|\/)(daily|digest|journal|daily-digest)|(^|\/)\d{4}-\d{2}-\d{2}/.test(p)) return "day";
  if (/(^|\/)concepts?\//.test(p)) return "concept";
  if (/(^|\/)(entities|people|companies|orgs?|contacts)\//.test(p)) return "entity";
  if (/(^|\/)(sources?|raw|clippings?|emails?|inbox|transcripts?|meetings?)\//.test(p)) return "source";
  return "note";
}
var PLUMBING = /^(_?index|hot|log|logs?|readme|home|start here|moc|maps? of content|toc|table of contents|inbox|dashboard|overview)$/i;
function underground(all, hubs, gardenSlug, now = Date.now(), max = 320) {
  const notes = all.filter((n) => !PLUMBING.test(n.title.trim()));
  const byPath = new Map(notes.map((n) => [n.path, n]));
  const inb = /* @__PURE__ */ new Map(), DAY3 = 864e5;
  let links = 0;
  for (const n of notes) for (const t of new Set(n.out)) if (byPath.has(t) && t !== n.path) {
    inb.set(t, (inb.get(t) || 0) + 1);
    links++;
  }
  const anchor = /* @__PURE__ */ new Map(), hubOf = new Map(Object.entries(hubs).map(([proj, path]) => [path, proj]));
  for (const [proj, hp] of Object.entries(hubs)) anchor.set(hp, proj);
  for (const n of notes) if (!anchor.has(n.path)) {
    const hs = [...new Set(n.out.filter((t) => hubOf.has(t)))];
    if (hs.length === 1 && (inb.get(n.path) || 0) <= 40) anchor.set(n.path, hubOf.get(hs[0]));
  }
  for (const [proj, hp] of Object.entries(hubs)) for (const t of byPath.get(hp)?.out || []) if (byPath.has(t) && !anchor.has(t) && (inb.get(t) || 0) <= 3) anchor.set(t, proj);
  const outN = (n) => new Set(n.out.filter((t) => byPath.has(t) && t !== n.path)).size;
  const score = (n) => (inb.get(n.path) || 0) * 2 + outN(n) * 0.5 + (anchor.has(n.path) ? 3 : 0) + (hubOf.has(n.path) ? 1e3 : 0) + (now - n.mtime < 2 * DAY3 ? 4 : 0);
  const picked = [...notes].sort((a, b) => score(b) - score(a)).slice(0, max);
  const idx = new Map(picked.map((n, i) => [n.path, i]));
  const nodes = picked.map((n) => {
    const g = gardenSlug(n.title);
    return { t: n.title, p: n.path, k: noteKind(n.path, !!g), n: inb.get(n.path) || 0, o: outN(n), a: Math.max(0, Math.round((now - n.ctime) / DAY3)), m: Math.max(0, Math.round((now - n.mtime) / DAY3)), d: anchor.get(n.path), g };
  });
  const seen = /* @__PURE__ */ new Set(), edges = [];
  const deg = (i) => nodes[i].n + nodes[i].o;
  const cand = [];
  for (const n of picked) for (const t of n.out) {
    const a = idx.get(n.path), b = idx.get(t);
    if (b === void 0 || a === b) continue;
    const k = a < b ? a + ":" + b : b + ":" + a;
    if (!seen.has(k)) {
      seen.add(k);
      cand.push([a, b]);
    }
  }
  cand.sort((x, y) => deg(y[0]) + deg(y[1]) - deg(x[0]) - deg(x[1]));
  edges.push(...cand.slice(0, 1600));
  const sediment = {};
  for (const n of notes) if (!idx.has(n.path)) {
    const k = noteKind(n.path, false);
    sediment[k] = (sediment[k] || 0) + 1;
  }
  const orphans = notes.filter((n) => !inb.get(n.path) && !outN(n)).length;
  return { nodes, edges, total: notes.length, links, orphans, sediment, editedToday: notes.filter((n) => now - n.mtime < DAY3).length };
}
function publicUnderground(u, publicDistricts) {
  const pub = new Set(publicDistricts);
  return { ...u, nodes: u.nodes.map((n) => ({ k: n.g ? "garden" : n.k, n: n.n, o: n.o, a: n.a, m: n.m, d: n.d ? pub.has(n.d) ? n.d : pub.has("Private") ? "Private" : void 0 : void 0, ...n.g ? { t: n.t, g: n.g } : {} })) };
}
var esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var num = (v) => Math.max(0, Math.floor(Number(v) || 0));
function parseCityRepos(raw) {
  const rows = Array.isArray(raw?.repos) ? raw.repos : [];
  return rows.filter((r) => r && typeof r.name === "string" && r.name.trim()).slice(0, 300).map((r) => ({
    name: String(r.name).slice(0, 80),
    project: String(r.project || "Other").slice(0, 60),
    public: r.public === true,
    language: String(r.language || "Other").slice(0, 30),
    commits: num(r.commits),
    week: num(r.week),
    today: num(r.today),
    weeks: (Array.isArray(r.weeks) ? r.weeks : []).slice(-12).map(num),
    pushed: typeof r.pushed === "string" ? r.pushed.slice(0, 40) : void 0,
    created: typeof r.created === "string" ? r.created.slice(0, 40) : void 0,
    size: num(r.size),
    url: r.public === true && /^https:\/\//.test(String(r.url || "")) ? String(r.url) : void 0,
    description: r.public === true && r.description ? String(r.description).slice(0, 200) : void 0,
    sites: cleanSites(r.sites ?? r.homepage)
  }));
}
function vaultRepos(notes, now = Date.now()) {
  const by = /* @__PURE__ */ new Map(), DAY3 = 864e5;
  for (const n of notes) {
    const parts = n.path.split("/");
    if (parts.length < 2) parts.unshift("Notes");
    const key = parts.slice(0, Math.min(2, parts.length - 1)).join("/");
    const r = by.get(key) || { name: key, project: parts[0], public: false, language: "Notes", commits: 0, weeks: Array(12).fill(0), week: 0, today: 0 };
    const age = (now - n.mtime) / DAY3;
    if (age < 365) r.commits++;
    if (age < 84) r.weeks[11 - Math.floor(age / 7)]++;
    if (age < 7) r.week++;
    if (age < 1) r.today++;
    r.size = (r.size || 0) + 1;
    by.set(key, r);
  }
  return [...by.values()].map((r) => ({ ...r, commits: Math.max(1, r.commits) })).sort((a, b) => b.commits - a.commits).slice(0, 120);
}
function cityData(repos, notes, generated) {
  const by = /* @__PURE__ */ new Map();
  for (const r of repos) by.set(r.project, [...by.get(r.project) || [], r]);
  const districts = [...by.entries()].map(([name, rs]) => {
    const nn = notes(name);
    return { name, notes: nn.n, notePaths: nn.paths.slice(0, 6), repos: rs.sort((a, b) => b.commits - a.commits) };
  }).sort((a, b) => b.repos.reduce((s, r) => s + r.commits, 0) - a.repos.reduce((s, r) => s + r.commits, 0));
  return { generated, districts, private: true };
}
var LOCKED_STEPS = [1, 10, 25, 50, 100, 250, 500, 1e3, 2500, 5e3];
var coarse = (n) => n <= 0 ? 0 : LOCKED_STEPS.reduce((b, s) => n >= s ? s : b, 1);
var locked = (r, project) => ({ name: "", project, public: false, locked: true, language: "Private", commits: coarse(r.commits), weeks: [], week: r.week > 0 ? 1 : 0, today: 0 });
function scrubSignHosts(districts) {
  return districts.map((d) => {
    const names = new Set(d.repos.filter((r) => !r.kind && !r.locked && r.name).map((r) => r.name.toLowerCase()));
    if (!d.repos.some((r) => r.kind && r.meta?.on && !names.has(String(r.meta.on).toLowerCase()))) return d;
    return { ...d, repos: d.repos.map((r) => r.kind && r.meta?.on && !names.has(String(r.meta.on).toLowerCase()) ? { ...r, meta: { ...r.meta, on: void 0 } } : r) };
  });
}
function applyPrivateMode(c, mode) {
  if (!mode || mode === "show" || mode === "named" || c.private) return c;
  const isPriv = (r) => !!r.locked || r.public !== true || !r.name;
  let n = 0;
  const districts = [], moved = [];
  for (const d of c.districts) {
    if (d.apart) {
      n += d.repos.length;
      continue;
    }
    const go = d.name === "Apps & sites" ? [] : d.repos.filter((r) => r.kind && r.pv);
    moved.push(...go);
    const pub2 = d.repos.filter((r) => !isPriv(r) && !go.includes(r));
    n += d.repos.filter(isPriv).length;
    if (pub2.length || d.notes > 0 && !/^(private|vault)$/i.test(d.name)) districts.push({ ...d, repos: pub2 });
  }
  if (moved.length) {
    let g = districts.find((x) => x.name === "Apps & sites");
    if (!g) {
      g = { name: "Apps & sites", notes: 0, repos: [] };
      districts.push(g);
    }
    g.repos.push(...moved.map((r) => ({ ...r, project: "Apps & sites", pv: void 0 })));
  }
  const label = c.kind === "vault" ? "Vault" : "Private";
  if (mode === "anonymous" && n > 0)
    districts.push({ name: label, notes: 0, apart: true, repos: Array.from({ length: privateCluster(n) }, () => ({ name: "", project: label, public: false, locked: true, language: "Private", commits: 25, weeks: [], week: 0, today: 0 })) });
  const pub = districts.flatMap((d) => d.repos).filter((r) => !r.locked);
  return {
    ...c,
    districts: scrubSignHosts(districts),
    privateMode: mode,
    totals: { commits: pub.reduce((s, r) => s + (Number(r.commits) || 0), 0), active: pub.filter((r) => r.week > 0).length },
    under: c.under ? publicUnderground(c.under, districts.filter((d) => !d.apart).map((d) => d.name)) : void 0
  };
}
function publicCity(c, publicProjects, mode = "show", hideRepos = []) {
  if (mode === "named") return publicCityNamed(c, hideRepos);
  return applyPrivateMode(publicCityShow(c, publicProjects), mode);
}
function publicCityNamed(c, hideRepos = []) {
  const hide = new Set(hideRepos.map((h) => h.trim().toLowerCase()).filter(Boolean));
  const named = (r) => r.public ? r : hide.has(r.name.toLowerCase()) ? locked(r, r.project) : {
    name: r.name,
    project: r.project,
    public: false,
    priv: true,
    language: r.language || "Other",
    commits: r.commits,
    weeks: (r.weeks || []).slice(-12),
    week: r.week,
    today: r.today,
    pushed: r.pushed,
    created: r.created,
    size: r.size,
    ...r.sites ? { sites: r.sites } : {}
  };
  const districts = c.districts.map((d) => ({ name: d.name, notes: d.notes, repos: d.repos.map(named) }));
  const all = c.districts.flatMap((d) => d.repos);
  return {
    generated: c.generated,
    kind: c.kind,
    districts,
    private: false,
    privateMode: "named",
    totals: { commits: all.reduce((s, r) => s + r.commits, 0), active: all.filter((r) => r.week > 0).length },
    under: c.under ? publicUnderground(c.under, districts.map((d) => d.name)) : void 0
  };
}
function publicCityShow(c, publicProjects) {
  const pub = new Set(publicProjects.map((p) => p.toLowerCase()));
  const districts = [], hidden = [];
  for (const d of c.districts) {
    const listed = pub.has(d.name.toLowerCase()) || d.repos.some((r) => r.public);
    if (!listed) {
      hidden.push(...d.repos.map((r) => locked(r, c.kind === "vault" ? "Vault" : "Private")));
      continue;
    }
    districts.push({ name: d.name, notes: pub.has(d.name.toLowerCase()) ? d.notes : 0, repos: d.repos.map((r) => r.public ? r : locked(r, d.name)) });
  }
  if (hidden.length) districts.push({ name: c.kind === "vault" ? "Vault" : "Private", notes: 0, repos: hidden.sort((a, b) => b.commits - a.commits) });
  const all = c.districts.flatMap((d) => d.repos);
  return {
    generated: c.generated,
    kind: c.kind,
    districts,
    private: false,
    totals: { commits: all.reduce((s, r) => s + r.commits, 0), active: all.filter((r) => r.week > 0).length },
    under: c.under ? publicUnderground(c.under, districts.map((d) => d.name)) : void 0
  };
}
var PADLOCK_LEGEND = '<span><i style="background:#5C6B86"></i>&#128274; Private</span>';
var PADLOCK_SHOW = " Glass buildings with a padlock are private repos: you can see the city grow, not what's inside.";
var PADLOCK_ANON = " The padlocked district holds private work, kept anonymous: no names, sizes, projects or activity.";
function cityPadlockNote(city) {
  const lockedAny = city.districts.some((d) => d.repos.some((r) => r.locked));
  return city.kind === "vault" || city.private || !lockedAny ? "" : city.privateMode === "anonymous" ? PADLOCK_ANON : PADLOCK_SHOW;
}
function cityRows(city) {
  return city.districts.map((d) => d.apart ? `<tr><td>${esc(d.name)} &#128274;</td><td colspan="4">Private work, kept anonymous</td></tr>` : `<tr><td>${esc(d.name)}</td><td>${d.repos.length}</td><td>${d.repos.reduce((s, r) => s + r.commits, 0).toLocaleString("en-US")}</td><td>${d.repos.reduce((s, r) => s + r.week, 0)}</td><td>${d.notes}</td></tr>`).join("");
}
function cityStats(city) {
  const repos = city.districts.flatMap((d) => d.repos), notes = city.districts.reduce((s, d) => s + d.notes, 0);
  const total = city.totals?.commits ?? repos.reduce((s, r) => s + r.commits, 0), active = city.totals?.active ?? repos.filter((r) => r.week > 0).length;
  const anon = !!city.privateMode && city.privateMode !== "show", nb = anon ? repos.filter((r) => !r.locked).length : repos.length;
  return `<div class="c-stats"><div><b>${nb}</b><span>${anon ? "public buildings" : "buildings"}</span></div><div><b>${total.toLocaleString("en-US")}</b><span>${city.kind === "vault" ? "notes edited this year" : "commits this year"}</span></div><div><b>${active}</b><span>busy this week</span></div><div><b>${(city.kind === "vault" ? city.under?.total ?? notes : notes).toLocaleString("en-US")}</b><span>${city.kind === "vault" ? "notes in the vault" : "notes in town"}</span></div></div>`;
}
function renderCity(site, city) {
  const repos = city.districts.flatMap((d) => d.repos);
  const total = city.totals?.commits ?? repos.reduce((s, r) => s + r.commits, 0), active = city.totals?.active ?? repos.filter((r) => r.week > 0).length, notes = city.districts.reduce((s, d) => s + d.notes, 0);
  const json = JSON.stringify({ ...city, openBase: site.openBase || "" }).replace(/</g, "\\u003c");
  const icon = site.icon ? `<link rel="icon" href="${esc(site.icon)}" type="image/png">` : `<link rel="icon" href="assets/favicon.svg" type="image/svg+xml">`;
  const rows = cityRows(city);
  return `<!doctype html><html lang="en"${site.theme === "light" ? ' data-theme="light"' : ""}><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(site.name)}'s city</title>
<meta name="robots" content="noindex, nofollow"><meta name="generator" content="Caldera for Obsidian">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400&display=swap">
${icon}<link rel="stylesheet" href="assets/theme.css"><link rel="stylesheet" href="assets/profile.css"><style>${CITY_CSS}</style></head><body>
<div class="tabs"><a class="tab" href="index.html">${esc(site.name)}.md</a><span class="tab is-active">City</span><span class="spacer"></span></div>
<div class="shell">${site.nav ? site.nav(0, "city.html") : ""}<main class="note"><div class="c-main">
<div class="g-crumbs c-crumbs"><a href="index.html">${esc(site.handle ? "@" + site.handle : site.name)}</a> / City${site.github && /^https:\/\/github\.com\/[\w.-]+\/?$/.test(site.github) ? ` &middot; <a class="c-gh" href="${esc(site.github)}" target="_blank" rel="noopener">GitHub &#8599;</a>` : ""}</div>
<h1 class="c-title">${esc(site.name)}'s city</h1>
<p class="c-lede">${city.kind === "vault" ? `Built from ${esc(site.name)}'s Obsidian vault: every folder is a building, taller means more notes written this year, lit windows mean notes written this week. Folder names stay private.${city.under ? " Go underground to see the notes and the links between them." : ""}` : `Every project is a district and every repo a building: taller means more commits this year, lit windows mean commits this week, a crane means it's being built right now. The houses around each district are the Obsidian notes about that project.${city.private ? " <b>Private view:</b> every repo, including private ones." : cityPadlockNote(city)}`}</p>
${cityStats(city)}
<div class="c-stage" id="stage"><canvas id="city" aria-label="Isometric city of ${repos.length} projects"></canvas>
<div class="c-tools"><button id="t-labels" aria-pressed="true" title="Labels">&#x1F3F7;&#xFE0F;<span class="t-txt"> Labels</span></button><button id="t-sky">Auto</button><button id="t-wx" title="Weather">Weather</button>${city.under ? '<button id="t-under" aria-pressed="false">&#x2B07;<span class="t-txt"> Underground</span></button>' : ""}<button id="t-snd" aria-pressed="false" title="Sound for arrivals, signups and sales (off)">&#x1F507;</button><button id="t-reset" title="Reset the view">&#x21BA;<span class="t-txt"> Reset</span></button><button id="t-pop" aria-label="Pop out a small window" title="Pop out a small window">&#x29C9;<span class="t-txt"> Pop out</span></button><button id="t-full" aria-label="Full screen" title="Full screen">&#x26F6;<span class="t-txt"> Full screen</span></button></div>
<div class="c-toasts" aria-live="polite"></div><div class="c-mininame" aria-hidden="true"><i></i>${esc(site.name)}</div>
<div class="c-card" id="card" hidden></div><div class="c-hint">Drag to move &middot; scroll or pinch to zoom &middot; tap a building</div></div>
<div class="c-legend"><span><i style="background:#3178C6"></i>TypeScript</span><span><i style="background:#E8C547"></i>JavaScript</span><span><i style="background:#4FB89A"></i>Python</span><span><i style="background:#E07A4F"></i>HTML</span><span><i style="background:#F05138"></i>Swift</span><span><i style="background:#8A8A93"></i>Other</span>${repos.some((r) => r.locked) ? PADLOCK_LEGEND : ""}${repos.some((r) => r.kind) ? '<span><i style="background:#6C63FF"></i>Apps</span><span><i style="background:#1FA39A"></i>Websites</span>' : ""}<span>&#127959; built this week</span><span>&#127968; notes about the project</span></div>
<div class="c-table-wrap"><table class="c-table"><thead><tr><th>District</th><th>Buildings</th><th>Commits this year</th><th>This week</th><th>Notes</th></tr></thead><tbody>${rows}</tbody></table></div>
${city.generated ? `<p class="c-foot">GitHub counts from ${esc(new Date(city.generated).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }))}.</p>` : ""}
</div></main></div>
<script type="application/json" id="city-data">${json}<\/script>
<script>${CITY_JS}<\/script></body></html>`;
}
function citySnapshot(city, o) {
  const LANG = { TypeScript: "#3178C6", JavaScript: "#E8C547", Python: "#4FB89A", HTML: "#E07A4F", Swift: "#F05138", CSS: "#6E5BD0", Shell: "#7FB24A", Go: "#2FB5D6", Rust: "#C9744A", App: "#6C63FF", Web: "#1FA39A" };
  const shade = (hex, f2) => {
    const n = parseInt(hex.slice(1), 16);
    const c = [n >> 16, n >> 8 & 255, n & 255].map((v) => Math.round(Math.min(255, v * f2)));
    return `rgb(${c.join(",")})`;
  };
  const TW = 64, TH = 32, ds = city.districts.slice(0, 14);
  const area = ds.reduce((a, d) => {
    const k = Math.max(2, Math.ceil(Math.sqrt(Math.min(d.repos.length, 36))));
    return a + (k + 1) * (k + 1);
  }, 0);
  const maxW = Math.max(8, Math.ceil(Math.sqrt(area) * 1.25));
  const ts = [], blocks = [];
  let x = 1, y = 1, rowH = 0;
  for (const d of ds) {
    const rs = d.repos.slice(0, 36), k = Math.max(2, Math.ceil(Math.sqrt(rs.length)));
    if (d.apart && (x > 1 || y > 1)) {
      if (x > 1) {
        x = 1;
        y += rowH + 1;
        rowH = 0;
      }
      y += 2;
    } else if (x + k > maxW && x > 1) {
      x = 1;
      y += rowH + 1;
      rowH = 0;
    }
    blocks.push({ x, y, k });
    const cells = [];
    for (let j = 0; j < k; j++) for (let i = 0; i < k; i++) cells.push([x + i, y + j]);
    cells.sort((a, b) => a[0] + a[1] - (b[0] + b[1]));
    rs.forEach((r, i) => ts.push({ x: cells[i][0], y: cells[i][1], r }));
    x += k + 1;
    rowH = Math.max(rowH, k);
  }
  const iso2 = (gx, gy) => [(gx - gy) * TW / 2, (gx + gy) * TH / 2];
  const ht = (r) => Math.min(150, 10 + 14 * Math.log2(1 + Math.max(0, r.commits)));
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  const grow = (px, py) => {
    minX = Math.min(minX, px);
    maxX = Math.max(maxX, px);
    minY = Math.min(minY, py);
    maxY = Math.max(maxY, py);
  };
  const f = (n) => n.toFixed(1), out = [];
  for (const b of blocks) {
    const p = [iso2(b.x - 0.15, b.y - 0.15), iso2(b.x + b.k - 0.85, b.y - 0.15), iso2(b.x + b.k - 0.85, b.y + b.k - 0.85), iso2(b.x - 0.15, b.y + b.k - 0.85)].map(([px, py]) => [px, py + TH / 2]);
    p.forEach(([px, py]) => grow(px, py));
    out.push(`<polygon class="cp-pad" points="${p.map((q2) => q2.map(f).join(",")).join(" ")}"/>`);
  }
  ts.sort((a, b) => a.x + a.y - (b.x + b.y) || a.x - b.x);
  let win = 0;
  for (const t of ts) {
    const [cx, c0] = iso2(t.x, t.y), cy = c0 + TH / 2, a = TW / 2 * 0.62, b = TH / 2 * 0.62, h = ht(t.r);
    const col = t.r.locked ? "#5C6B86" : LANG[t.r.language] || "#8A8A93";
    const P = (pts) => pts.map((q2) => q2.map(f).join(",")).join(" ");
    grow(cx - a, cy - h - b);
    grow(cx + a, cy + b);
    out.push(`<polygon fill="${shade(col, 0.62)}" points="${P([[cx - a, cy - h], [cx, cy + b - h], [cx, cy + b], [cx - a, cy]])}"/><polygon fill="${shade(col, 0.82)}" points="${P([[cx + a, cy - h], [cx, cy + b - h], [cx, cy + b], [cx + a, cy]])}"/><polygon fill="${shade(col, 1.08)}" points="${P([[cx, cy - b - h], [cx + a, cy - h], [cx, cy + b - h], [cx - a, cy - h]])}"/>`);
    const busy2 = t.r.week > 0, rows = Math.min(8, Math.floor((h - 6) / 9));
    for (let k = 0; k < rows; k++) for (const u of [0.3, 0.7]) {
      const wx = cx + a * u, wy = cy + b * (1 - u) - 6 - k * 9;
      const lit = busy2 && (t.x * 7 + t.y * 3 + k + (u > 0.5 ? 1 : 0)) % 3 !== 0;
      out.push(`<polygon class="${lit ? `cp-w cp-on${win++ % 5}${t.r.locked ? " cp-cool" : ""}` : "cp-w"}" points="${P([[wx - 2.5, wy + 1.2], [wx + 2.5, wy - 1.2], [wx + 2.5, wy - 4.8], [wx - 2.5, wy - 2.4]])}"/>`);
    }
  }
  const pad = 18, vb = `${f(minX - pad)} ${f(minY - pad)} ${f(maxX - minX + pad * 2)} ${f(maxY - minY + pad * 2)}`;
  const repos = city.districts.flatMap((d) => d.repos), total = city.totals?.commits ?? repos.reduce((a, r) => a + r.commits, 0), busy = city.totals?.active ?? repos.filter((r) => r.week > 0).length;
  const nb = city.privateMode && city.privateMode !== "show" ? repos.filter((r) => !r.locked).length : repos.length;
  const e = (v) => v.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  return `<style>.city-peek{display:block;position:relative;margin:18px 0 26px;border-radius:12px;overflow:hidden;text-decoration:none;color:#E8EEF8;background:radial-gradient(ellipse at 50% 120%,#1d2b4a 0%,#0c1222 60%,#080b14 100%);border:1px solid rgba(140,170,220,.18);transition:border-color .2s,transform .2s}
.city-peek:hover{border-color:rgba(140,190,255,.5);transform:translateY(-1px)}.city-peek svg{display:block;width:100%;height:auto;max-height:300px}
.cp-pad{fill:rgba(120,150,210,.10);stroke:rgba(140,170,230,.22);stroke-width:1}.cp-w{fill:rgba(10,16,30,.55)}[class*=cp-on]{fill:#FFD98A;animation:cpw 4s ease-in-out infinite}
.cp-on1{animation-delay:-.8s}.cp-on2{animation-delay:-1.6s}.cp-on3{animation-delay:-2.4s}.cp-on4{animation-delay:-3.2s}@keyframes cpw{0%,100%{opacity:1}50%{opacity:.35}}
.cp-cool{fill:#BFD8FF}@media (prefers-reduced-motion:reduce){[class*=cp-on]{animation:none}}
.cp-bar{position:absolute;left:0;right:0;bottom:0;display:flex;gap:12px;align-items:baseline;justify-content:space-between;flex-wrap:wrap;padding:28px 16px 12px;background:linear-gradient(transparent,rgba(6,9,18,.88));font:500 13px/1.3 "IBM Plex Sans",system-ui,sans-serif}
.cp-bar b{font-size:15px}.cp-bar .cp-go{color:#9CC4FF;white-space:nowrap}.cp-bar .cp-n{opacity:.75}
.city-peek.sky-dawn{background:linear-gradient(#3A4A7E,#E0899A 62%,#FFCB8E)}.city-peek.sky-day{background:linear-gradient(#7FB8EA,#CFE6F7 66%,#EAF4FB)}
.city-peek.sky-dusk{background:linear-gradient(#3E3A6E,#C8607A 60%,#F4B26B)}.city-peek.sky-evening{background:linear-gradient(#0B0E2A,#23285A 60%,#4A3F7A)}
.city-peek.sky-day .cp-pad,.city-peek.sky-dawn .cp-pad{fill:rgba(70,110,70,.22);stroke:rgba(50,90,60,.35)}
.city-peek.sky-day [class*=cp-on]{fill:rgba(205,228,250,.95);animation:none}.city-peek.sky-day .cp-w{fill:rgba(40,60,90,.45)}.city-peek.sky-dawn [class*=cp-on]{fill:#FFE2A8}</style>
<a class="city-peek" href="${e(o.href || "city.html")}" aria-label="Open ${e(o.name)}'s city"><svg viewBox="${vb}" preserveAspectRatio="xMidYMid meet" role="img" aria-hidden="true">${out.join("")}</svg>
<span class="cp-bar"><span><b>${e(o.name)}'s city</b> <span class="cp-n">&middot; ${nb} building${nb === 1 ? "" : "s"}${city.privateMode === "anonymous" && repos.some((r) => r.locked) ? " + private work" : ""} &middot; ${total.toLocaleString("en-US")} ${city.kind === "vault" ? `note${total === 1 ? "" : "s"} edited` : `commit${total === 1 ? "" : "s"}`} this year${busy ? ` &middot; ${busy} busy this week` : ""}</span></span><span class="cp-go">Explore the city &rarr;</span></span></a><script>(function(a){var d=new Date(),m=d.getHours()*60+d.getMinutes(),k=m<345?'':m<450?'dawn':m<1042?'day':m<1140?'dusk':m<1237?'evening':'';if(a&&k)a.classList.add('sky-'+k)})(document.currentScript&&document.currentScript.previousElementSibling)<\/script>`;
}
var CITY_CSS = `
.c-main{max-width:1100px;margin:0 auto;padding:28px 20px 64px}
.c-crumbs{font-size:var(--text-sm);color:var(--text-muted);margin-bottom:6px}.c-crumbs a{color:var(--text-muted)}.c-crumbs a.c-gh{color:var(--accent-text,#B9A6FF)}
.c-title{font-family:var(--font-serif,'Source Serif 4',Georgia,serif);font-size:2.1rem;margin:0 0 8px;color:var(--text-strong)}
.c-lede{color:var(--text-muted);max-width:70ch;margin:0 0 16px}
.c-stats{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:14px}
.c-stats div{flex:1 1 120px;background:var(--bg-raised);border:1px solid var(--line);border-radius:var(--radius-md,10px);padding:10px 14px;display:flex;flex-direction:column}
.c-stats b{font-size:1.5rem;font-variant-numeric:tabular-nums;color:var(--text-strong)}.c-stats span{font-size:var(--text-xs,12px);color:var(--text-muted)}
.c-stage{position:relative;height:min(72vh,720px);min-height:420px;border-radius:var(--radius-md,10px);overflow:hidden;border:1px solid rgba(61,242,255,.35);box-shadow:0 0 24px rgba(61,242,255,.12);background:#010207;touch-action:none}
.c-heli{position:absolute;left:50%;top:70px;transform:translateX(-50%);z-index:4;pointer-events:none;font:600 11px/1 ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:.06em;color:#FFD9A0;background:rgba(2,6,12,.86);border:1px solid rgba(255,190,90,.5);border-radius:999px;padding:6px 11px;white-space:nowrap;max-width:calc(100% - 24px);overflow:hidden;text-overflow:ellipsis}.c-heli[hidden]{display:none}
.c-stage canvas{width:100%;height:100%;display:block;cursor:grab}.c-stage canvas.c-link{cursor:pointer}.c-stage canvas.drag{cursor:grabbing}
.c-tools{position:absolute;top:10px;right:10px;display:flex;gap:6px}
.c-tools .t-sw{display:inline-block;width:10px;height:10px;border-radius:50%;vertical-align:-1px;background:conic-gradient(#A78BFA 0 25%,#2DD4BF 0 50%,#FBBF24 0 75%,#FB7185 0)}
.w-topics{position:absolute;left:10px;top:10px;z-index:3;display:flex;flex-direction:column;gap:4px;max-width:min(240px,calc(100% - 20px));padding:8px 11px;border-radius:10px;background:rgba(2,6,12,.84);border:1px solid rgba(61,242,255,.3);color:#E6F6FF;font:500 12px/1.35 'IBM Plex Sans',Arial,sans-serif;pointer-events:none}
.w-topics b{font-weight:600;color:#BFF8FF;margin-bottom:2px}.w-topics span{display:flex;align-items:center;gap:7px}.w-topics i{display:inline-block;width:10px;min-width:10px;height:10px;border-radius:3px;flex:0 0 10px}.w-topics[hidden]{display:none}
@media (max-width:600px){.w-topics{top:52px;gap:3px;padding:7px 9px;font-size:11px;max-width:min(200px,calc(100% - 20px))}}
.c-tools button{font:500 12px var(--font-mono,'IBM Plex Mono',monospace);padding:5px 10px;border-radius:999px;border:1px solid rgba(61,242,255,.45);background:rgba(2,6,12,.8);color:#BFF8FF;cursor:pointer}
.c-tools button[aria-pressed="false"]{opacity:.6}
.c-under{position:absolute;left:10px;bottom:10px;width:min(300px,calc(100% - 20px));background:rgba(2,6,12,.86);border:1px solid rgba(181,140,255,.45);border-radius:10px;padding:8px 10px;color:#E3DAFF;font:12px/1.45 var(--font-mono,'IBM Plex Mono',monospace)}
.c-under b{color:#fff}.c-under{cursor:pointer}.c-under.c-min>:not(.uh){display:none}.c-under.c-min,.c-live.c-min{width:auto}.c-under .chev,.c-live .chev{float:right;opacity:.7;margin-left:8px}.c-under .lg{display:flex;flex-wrap:wrap;gap:2px 10px;margin-top:4px;color:#A99BD0}.c-under .lg i{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:4px;vertical-align:0}
.c-stage.c-dig .c-hint{display:none}
.c-stage.c-full{position:fixed;inset:0;z-index:9999;height:100%;min-height:0;border-radius:0;border:0}
.c-stage:fullscreen{height:100%;border-radius:0;border:0}
/* arrivals: toasts for signups and sales */
.c-gift{margin-top:10px;padding-top:9px;border-top:1px solid rgba(255,255,255,.12);display:flex;flex-direction:column;gap:5px}.c-gift-b{all:unset;cursor:pointer;align-self:flex-start;display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border-radius:999px;background:linear-gradient(90deg,#FFD98A,#FFB65C);color:#2A1A00;font:700 12.5px var(--font-body,'IBM Plex Sans',Arial,sans-serif);text-decoration:none}.c-gift-b:hover{filter:brightness(1.06)}.c-gift-b:disabled{opacity:.6;cursor:default}.c-gift-b:focus-visible{outline:2px solid #FFD98A;outline-offset:2px}
.c-toasts{position:absolute;left:10px;top:48px;z-index:3;display:flex;flex-direction:column;gap:6px;pointer-events:none;max-width:calc(100% - 20px)}
.c-toast{font:600 12px/1.3 var(--font-mono,'IBM Plex Mono',monospace);padding:6px 11px;border-radius:9px;background:rgba(2,6,12,.9);color:#fff;border:1px solid #FF4FD8;box-shadow:0 0 14px rgba(255,79,216,.45);animation:ctin .35s ease-out,ctout .6s ease-in 4.6s forwards;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.c-toast.buy{border-color:#FFD23F;box-shadow:0 0 14px rgba(255,210,63,.5)}
@keyframes ctin{from{opacity:0;transform:translateY(-8px) scale(.96)}to{opacity:1;transform:none}}@keyframes ctout{to{opacity:0;transform:translateY(-6px)}}
html.c-mini .c-toasts{left:6px;top:6px}html.c-mini .c-toast{font-size:10.5px;padding:4px 8px}
/* mini: the pop-out window (city.html#mini, the watch page, or a picture-in-picture window): just the city, filling the window */
.c-mininame{display:none}
html.c-mini,html.c-mini body{height:100%;overflow:hidden;background:#010207}
html.c-mini .c-stage{position:fixed;inset:0;z-index:2147483000;height:100%;min-height:0;border:0;border-radius:0;box-shadow:none}
html.c-mini .c-hint,html.c-mini #t-pop,html.c-mini #t-full{display:none}
html.c-mini .c-tools{top:6px;right:6px;opacity:0;transition:opacity .2s}html.c-mini .c-stage:hover .c-tools{opacity:1}html.c-mini .c-tools .t-txt{display:none}
html.c-mini .c-tools button{padding:3px 8px;font-size:11px}
.c-today{position:absolute;left:10px;bottom:10px;z-index:2;padding:4px 10px;border-radius:999px;background:rgba(8,12,22,.72);color:#E6F6FF;font:500 12px/1.3 'IBM Plex Mono',ui-monospace,monospace;pointer-events:none;backdrop-filter:blur(4px)}
html.c-mini .c-today{display:none}
.c-today.c-today-in{position:static;display:block;padding:0 0 6px;margin:0 0 6px;border-radius:0;background:none;backdrop-filter:none;border-bottom:1px solid rgba(61,242,255,.25);font-size:11px;color:#CFEFFF}
.c-stage:not(.c-dig) .c-hint~.c-today{bottom:42px}@media (max-width:600px){.c-stage:not(.c-dig) .c-hint~.c-today{bottom:10px}}
.c-setup{position:relative;margin:10px 0 4px;padding:10px 40px 10px 14px;border:1px solid var(--line,#2A2A2F);border-radius:var(--radius-md,10px);background:var(--bg-raised,#18181B);font-size:var(--text-sm,14px);color:var(--text,#E6E6EA)}
.c-su-row{display:flex;flex-wrap:wrap;align-items:center;gap:6px 12px;padding:3px 0}.c-su-row span{flex:1 1 260px;color:var(--text-muted,#9A9AA6)}
.c-setup button{cursor:pointer;font:inherit;font-size:13px;border-radius:999px;border:1px solid var(--line,#2A2A2F);background:transparent;color:var(--accent-text,#B9A6FF);padding:3px 12px}
.c-setup .c-su-go{border-color:var(--accent,#8B6CF6)}.c-setup .c-su-x{position:absolute;top:6px;right:8px;border:0;color:var(--text-muted,#9A9AA6);font-size:18px;padding:0 6px}
.c-su-panel{margin-top:8px;padding-top:8px;border-top:1px solid var(--line,#2A2A2F)}.c-su-panel p{margin:0 0 8px;color:var(--text-muted,#9A9AA6)}
.c-su-site{display:flex;flex-wrap:wrap;align-items:center;gap:6px 10px;margin:6px 0}.c-su-site b{min-width:120px}.c-su-site code{flex:1 1 280px;font:12px/1.4 'IBM Plex Mono',ui-monospace,monospace;background:var(--bg-sunken,#0E0E11);border-radius:6px;padding:5px 8px;overflow-x:auto;white-space:nowrap}
.c-setup .c-su-ai{margin-top:4px;background:var(--accent,#8B6CF6);color:#fff;border-color:transparent}
html.c-mini .c-live{right:6px;bottom:6px;font-size:10.5px;padding:5px 8px}
html.c-mini .c-mininame{display:flex;align-items:center;gap:6px;position:absolute;left:8px;bottom:7px;font:500 11px var(--font-mono,'IBM Plex Mono',monospace);color:rgba(191,248,255,.78);letter-spacing:.04em;pointer-events:none;text-shadow:0 1px 3px #000}
html.c-mini .c-mininame i{width:6px;height:6px;border-radius:50%;background:#3DF2FF;box-shadow:0 0 6px #3DF2FF}
.c-hint{position:absolute;left:10px;bottom:10px;font:12px var(--font-sans,sans-serif);color:rgba(232,232,238,.75);background:rgba(14,19,32,.6);padding:4px 8px;border-radius:6px;pointer-events:none}
.c-card{position:absolute;left:10px;top:10px;width:min(300px,calc(100% - 20px));max-height:calc(100% - 60px);overflow:auto;background:rgba(18,22,34,.94);border:1px solid rgba(255,255,255,.14);border-radius:10px;padding:12px 14px;color:#E8E8EE;font:13px/1.45 var(--font-sans,'IBM Plex Sans',sans-serif);box-shadow:0 10px 30px rgba(0,0,0,.35)}
.c-card h3{margin:0 0 2px;font-size:15px;color:#fff}.c-card .k{color:#9A9AA6;font-size:12px}.c-card a{color:#B9A6FF}
.c-card .row{display:flex;justify-content:space-between;gap:8px;margin-top:4px}.c-card .x{position:absolute;top:6px;right:8px;background:none;border:0;color:#9A9AA6;font-size:16px;cursor:pointer}
.c-card .sp{display:flex;align-items:flex-end;gap:2px;height:28px;margin:8px 0 2px}.c-card .sp i{flex:1;background:#8B6CF6;border-radius:2px 2px 0 0;min-height:2px}
.c-card.is-dir{top:58px;width:min(340px,calc(100% - 20px));max-height:calc(100% - 110px);padding:12px 12px 8px}.c-card.is-dir .d-head{padding-right:22px;margin-bottom:8px}.c-card.is-dir .d-head b{font-size:15px;color:#fff}
.c-card .d-sel{padding:10px;margin:0 0 8px;border-radius:9px;background:rgba(139,108,246,.14);border:1px solid rgba(139,108,246,.45)}.c-card .d-visit{font-weight:600}
.c-card .d-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:2px}
.c-card .d-row{display:flex;gap:10px;align-items:center;width:100%;text-align:left;background:none;border:1px solid transparent;border-radius:8px;padding:6px;color:#E8E8EE;font:inherit;cursor:pointer;min-height:44px}
.c-card .d-row:hover{background:rgba(255,255,255,.06)}.c-card .d-row:focus-visible{outline:2px solid #B9A6FF;outline-offset:1px}.c-card .d-row.is-on{background:rgba(139,108,246,.2);border-color:rgba(139,108,246,.55)}
.c-card .d-txt{display:flex;flex-direction:column;min-width:0}.c-card .d-name{font-weight:600;color:#fff;overflow-wrap:anywhere}.c-card .d-meta{font-size:12px;color:#9A9AA6;overflow-wrap:anywhere}
@media (max-width:600px){.c-card.is-dir{left:0;right:0;top:auto;bottom:0;width:auto;max-height:62%;border-radius:14px 14px 0 0;padding-bottom:calc(10px + env(safe-area-inset-bottom,0px))}}
.c-legend{display:flex;flex-wrap:wrap;gap:6px 14px;margin:10px 0 18px;font-size:var(--text-sm);color:var(--text-muted)}
.c-legend i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:5px;vertical-align:-1px}
.c-table-wrap{overflow-x:auto}.c-table{width:100%;border-collapse:collapse;font-size:var(--text-sm);font-variant-numeric:tabular-nums}
.c-table th,.c-table td{text-align:left;padding:7px 10px;border-bottom:1px solid var(--line)}.c-table th{color:var(--text-muted);font-weight:500}
.c-foot{font-size:var(--text-xs,12px);color:var(--text-muted);margin-top:12px}
.c-live{position:absolute;right:10px;bottom:10px;width:min(260px,calc(100% - 20px));max-height:62%;overflow-y:auto;overscroll-behavior:contain;touch-action:pan-y;scrollbar-width:thin;scrollbar-color:rgba(61,242,255,.4) transparent;background:rgba(2,6,12,.86);border:1px solid rgba(61,242,255,.4);border-radius:10px;padding:8px 10px;color:#CFEFFF;font:12px/1.4 var(--font-mono,'IBM Plex Mono',monospace);box-shadow:0 0 18px rgba(61,242,255,.12)}
.c-live .h{display:flex;align-items:center;gap:6px;color:#fff;font-weight:600;letter-spacing:.06em;margin-bottom:4px}.c-live .dot{width:7px;height:7px;border-radius:50%;background:#FF3B5C;box-shadow:0 0 8px #FF3B5C;animation:clive 1.6s infinite}
.c-live .r{display:flex;justify-content:space-between;gap:8px;padding:2px 0;border-top:1px solid rgba(61,242,255,.12)}.c-live .r span:first-child{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.c-live .r b{color:#fff;font-weight:600;white-space:nowrap}
.c-live .m{color:#7FA6B8}.c-live .s{font-size:11px;padding-bottom:2px}.c-live .bar{display:inline-block;height:6px;border-radius:3px;background:#3DF2FF;box-shadow:0 0 6px #3DF2FF;vertical-align:1px}.c-live .lg i{display:inline-block;width:7px;height:7px;border-radius:50%;margin:0 4px 0 8px;vertical-align:0}.c-live .lg i:first-child{margin-left:0}
@keyframes clive{50%{opacity:.35}}
.c-live .h{cursor:pointer}.c-live.c-min>:not(.h){display:none}.c-live.c-min .h{margin:0}
.c-live .q{font-size:11px;padding-top:3px;border-top:1px solid rgba(61,242,255,.12)}
@media (max-width:600px){.c-live{max-height:55%;font-size:11px}.c-hint{display:none}.c-tools .t-txt{display:none}
.c-tools{left:6px;right:6px;flex-wrap:nowrap;justify-content:flex-end;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch}.c-tools::-webkit-scrollbar{display:none}
.c-tools button{flex:none;white-space:nowrap;min-width:32px;padding:4px 9px;line-height:1.2}}
@media (max-width:600px){.c-main{padding:20px 16px 48px}.c-title{font-size:1.7rem}.c-stage{height:50vh;height:min(50svh,460px);min-height:300px}}
`;
var SF_PLACE_JS = String.raw`function sfPlace(ds,world,bh,dormant){
  function hs(t){var h=0;t=String(t||'');for(var i=0;i<t.length;i++)h=(h*31+t.charCodeAt(i))|0;return Math.abs(h)}
  function rr(s){var x=Math.sin(s)*10000;return x-Math.floor(x)}
  function tiers(h){return h>110?[[.78,h*.6],[.62,h*.26],[.46,h*.14]]:h>70?[[.78,h*.72],[.6,h*.28]]:[[.78,h]]}
  var top=null,tb=-1,used={roof:0,blade:0,wall:0,fascia:0},out=[];
  ds.forEach(function(d){(d.repos||[]).forEach(function(r){if(!r.kind&&bh(r)>tb){tb=bh(r);top=r}})});
  function faceVs(h){var t=tiers(h),v=['fascia'];if(t[0][1]>=(world?30:40))v.push('wall');if(h>=(world?56:72))v.push('blade');return v}
  ds.forEach(function(d){
    var ls=(d.repos||[]).filter(function(r){return r.kind}).sort(function(a,b){return String(a.name).localeCompare(String(b.name))||String(a.url||'').localeCompare(String(b.url||''))});
    if(!ls.length)return;
    var hosts=d.apart?[]:(d.repos||[]).filter(function(r){return !r.kind&&!r.locked&&r.name}).map(function(r){var h=bh(r),t=tiers(h);
      return {r:r,roof:t[t.length-1][0]>=.6&&r!==top&&!(r.week>0&&!dormant(r)),L:false,R:false,n:0,vs:faceVs(h)}}).sort(function(a,b){return String(a.r.name).localeCompare(String(b.r.name))});
    ls.forEach(function(l){var sd=hs(l.name+'|'+(d.nb||'')+'|'+d.name),on=String((l.meta||{}).on||'').toLowerCase(),tied=null,cand=[];
      if(on)hosts.forEach(function(H){if(String(H.r.name).toLowerCase()===on)tied=H});
      hosts.forEach(function(H,hi){var tie=H===tied?-1000:0,pref=sd%2?'R':'L';
        if(H.roof===true)cand.push({H:H,v:'roof',side:pref,s:tie+(tie?-500:0)+used.roof*10+H.n*6+rr(sd+hi*13.7)*5});
        ['L','R'].forEach(function(sdn){if(H[sdn])return;H.vs.forEach(function(v,vi){cand.push({H:H,v:v,side:sdn,s:tie+used[v]*10+H.n*6+(sdn===pref?0:1)+rr(sd+hi*13.7+vi*3.1)*5})})})});
      if(cand.length){cand.sort(function(a,b){return a.s-b.s});var c=cand[0];used[c.v]++;c.H.n++;if(c.v==='roof')c.H.roof='used';else c.H[c.side]=true;
        out.push({r:l,host:c.H.r,v:c.v,side:c.side});return}
      var own=['roof','wall','fascia'].map(function(v,vi){return {v:v,s:used[v]*10+rr(sd+vi*7.7)*5}}).sort(function(a,b){return a.s-b.s})[0].v;used[own]++;
      out.push({r:l,host:l,v:own,side:sd%2?'R':'L'})})});
  return out}`;
var CITY_JS = String.raw`(function(){
var D=JSON.parse(document.getElementById('city-data').textContent);
var cv=document.getElementById('city'),st=document.getElementById('stage'),cx=cv.getContext('2d'),card=document.getElementById('card');
var TW=64,TH=32,LANG={TypeScript:'#3178C6',JavaScript:'#E8C547',Python:'#4FB89A',HTML:'#E07A4F',Swift:'#F05138',CSS:'#6E5BD0',Shell:'#7FB24A',Go:'#2FB5D6',Rust:'#C9744A',App:'#6C63FF',Web:'#1FA39A'};
var reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
var hr=new Date().getHours(),night=hr<6||hr>=19,labels=true;
var MINI=/[#&]mini\b/.test(location.hash)||window.CALDERA_MINI===1;if(MINI){document.documentElement.classList.add('c-mini');labels=false}
function rnd(s){var x=Math.sin(s)*10000;return x-Math.floor(x)}
function hash(t){var h=0;for(var i=0;i<t.length;i++)h=(h*31+t.charCodeAt(i))|0;return Math.abs(h)}
function shade(hex,f){var n=parseInt(hex.slice(1),16),r=n>>16,g=n>>8&255,b=n&255;r=Math.round(Math.min(255,r*f));g=Math.round(Math.min(255,g*f));b=Math.round(Math.min(255,b*f));return 'rgb('+r+','+g+','+b+')'}
var now=Date.now(),DAY=864e5;
// ---- layout: districts are square blocks packed in rows with 1-tile roads between them
var blocks=[],tiles={},W=0,H=0,x=1,y=1,rowH=0;
function placeDistrict(d,x,y,k,houses){
  var b={d:d,x:x,y:y,k:k};blocks.push(b);
  var cells=[];for(var j=0;j<k;j++)for(var i=0;i<k;i++)cells.push([x+i,y+j]);
  cells.sort(function(a,c){return (a[0]+a[1])-(c[0]+c[1])});   // biggest towers at the back
  d.repos.forEach(function(r,i){var c=cells[i];tiles[c[0]+','+c[1]]={t:'b',r:r,d:d}});
  var hi=d.repos.length,left=houses;
  while(left>0&&hi<cells.length){var c=cells[hi++];var n=Math.min(4,left);left-=n;tiles[c[0]+','+c[1]]={t:'h',n:n,d:d}}
  for(;hi<cells.length;hi++){var c2=cells[hi];tiles[c2[0]+','+c2[1]]={t:'p',d:d}}
  return b}
// ---- storefronts as signage (see sfPlace): a listing hangs its sign on a building and stops taking a plot of its own
${SF_PLACE_JS}
var SFA=new Map();(function(){var pl=sfPlace(D.districts,!!D.world,bh,dormant),gone=new Set();
  pl.forEach(function(p){var L=SFA.get(p.host);if(!L){L=[];SFA.set(p.host,L)}L.push({r:p.r,v:p.v,side:p.side});if(p.host!==p.r)gone.add(p.r)});
  if(gone.size)D.districts.forEach(function(d){d.repos=d.repos.filter(function(r){return !gone.has(r)})})})();
var NBS=[],NBM={},AVX={},AVY={};
if(D.world){
  // the world: each member is a neighborhood (their own districts packed together), neighborhoods sit on a loose grid
  // with wide grass margins and an avenue on every grid line, so nothing overlaps and one tall member can't wall off the rest
  D.districts.forEach(function(d){var key=d.nb||d.name;if(!NBM[key]){NBM[key]={key:key,ds:[]};NBS.push(NBM[key])}NBM[key].ds.push(d)});
  NBS.forEach(function(n){var ar=0;n.ds.forEach(function(d){d._h=Math.min(d.notes||0,16);var need=d.repos.length+Math.ceil(d._h/4);d._k=Math.max(2,Math.ceil(Math.sqrt(need)));ar+=(d._k+1)*(d._k+1)});
    var mw=Math.max(3,Math.ceil(Math.sqrt(ar)*1.1)),lx=0,ly=0,rh=0,w=0,h=0;
    n.ds.forEach(function(d){if(d.apart&&(lx>0||ly>0)){if(lx>0){lx=0;ly+=rh+1;rh=0}ly+=2}else if(lx+d._k>mw&&lx>0){lx=0;ly+=rh+1;rh=0}d._lx=lx;d._ly=ly;lx+=d._k+1;rh=Math.max(rh,d._k);w=Math.max(w,lx-1);h=Math.max(h,ly+rh)});n.w=w;n.h=h});
  var GAP=5,cols=Math.max(1,Math.ceil(Math.sqrt(NBS.length*1.3))),rows=Math.max(1,Math.ceil(NBS.length/cols)),CWs=[],CHs=[],X0=[1],Y0=[1];
  NBS.forEach(function(n,ix){n.cx=ix%cols;n.cy=Math.floor(ix/cols);CWs[n.cx]=Math.max(CWs[n.cx]||0,n.w);CHs[n.cy]=Math.max(CHs[n.cy]||0,n.h)});   // each column/row only as wide as its biggest member
  for(var ci=0;ci<cols;ci++)X0.push(X0[ci]+(CWs[ci]||0)+GAP);for(var rj=0;rj<rows;rj++)Y0.push(Y0[rj]+(CHs[rj]||0)+GAP);
  NBS.forEach(function(n){n.ax=X0[n.cx];n.ay=Y0[n.cy];n.ox=n.ax+Math.ceil(GAP/2)+Math.floor((CWs[n.cx]-n.w)/2);n.oy=n.ay+Math.ceil(GAP/2)+Math.floor((CHs[n.cy]-n.h)/2);
    n.blocks=n.ds.map(function(d){return placeDistrict(d,n.ox+d._lx,n.oy+d._ly,d._k,d._h)});
    var big=n.blocks.slice().sort(function(a,b){return b.d.repos.length-a.d.repos.length})[0];big.rep=true;n.rep=big;big.nbo=n});
  W=X0[cols]+1;H=Y0[rows]+1;
  X0.forEach(function(v){AVX[v]=1});Y0.forEach(function(v){AVY[v]=1});
  for(var aj=1;aj<H;aj++)for(var ai=1;ai<W;ai++)if(AVX[ai]||AVY[aj])tiles[ai+','+aj]={t:'r',av:1};
  // a short street from each neighborhood's ring road out to the avenue on its left and above, so cars can reach every member
  NBS.forEach(function(n){var my=n.oy+Math.floor(n.h/2),mx=n.ox+Math.floor(n.w/2);
    for(var si=n.ax;si<n.ox-1;si++)tiles[si+','+my]={t:'r'};for(var sj=n.ay;sj<n.oy-1;sj++)tiles[mx+','+sj]={t:'r'}});
}else{
var area=D.districts.reduce(function(s,d){var n=d.repos.length+Math.ceil(Math.min(d.notes,40)/4);var k=Math.max(2,Math.ceil(Math.sqrt(n)));return s+(k+1)*(k+1)},0);
var maxW=Math.max(8,Math.ceil(Math.sqrt(area)*1.25));
D.districts.forEach(function(d){
  var houses=Math.min(d.notes,40),need=d.repos.length+Math.ceil(houses/4),k=Math.max(2,Math.ceil(Math.sqrt(need)));
  if(d.apart&&(x>1||y>1)){if(x>1){x=1;y+=rowH+1;rowH=0}y+=2}else if(x+k>maxW&&x>1){x=1;y+=rowH+1;rowH=0}   // the anonymous private district stands apart
  placeDistrict(d,x,y,k,houses);
  x+=k+1;rowH=Math.max(rowH,k);W=Math.max(W,x);H=Math.max(H,y+rowH+1);
});
W=Math.max(W,maxW)+1;H+=1;
}
function near(i,j){for(var a=-1;a<=1;a++)for(var b=-1;b<=1;b++){var n=tiles[(i+a)+','+(j+b)];if(n&&(n.t==='b'||n.t==='h'||n.t==='p'))return true}return false}
for(var j=0;j<=H;j++)for(var i=0;i<=W;i++){var key=i+','+j;if(!tiles[key])tiles[key]={t:(i===0||j===0||i===W||j===H)?'g':near(i,j)?'r':'g'}}
// ---- free tools (window.CALDERA_TOOLS, set by the hub): a Workshop beside a road in the maker's city, or on the World
// map one Market plaza (2x2) near the middle with a stall per tool. Click it for the list; nothing is hosted here.
var TOOLS=Array.isArray(window.CALDERA_TOOLS)?window.CALDERA_TOOLS.filter(function(t){return t&&t.id&&t.name}).slice(0,24):[],SHOP=null;
(function(){if(!TOOLS.length)return;var best=null,bd=1e9,g=function(i,j){var t=tiles[i+','+j];return t&&t.t==='g'&&!water(i,j)&&i>0&&j>0&&i<W&&j<H},
  rd=function(i,j){return isRoad(i-1,j)||isRoad(i+1,j)||isRoad(i,j-1)||isRoad(i,j+1)};
  for(var j=1;j<H;j++)for(var i=1;i<W;i++){if(!g(i,j)||(!D.world&&Math.hypot(i-W,j-H)<4))continue;   // a city's front corner is the drones' sky base
    var ok=D.world?[0,1,2].every(function(a){return [0,1,2].every(function(b2){return g(i+a,j+b2)})})&&[0,1,2].some(function(a){return rd(i+a,j)||rd(i,j+a)||rd(i+2,j+a)||rd(i+a,j+2)}):rd(i,j);if(!ok)continue;
    var bt=function(a,b){var t=tiles[a+','+b];return t&&(t.t==='b')},clear=D.world?!(bt(i+2,j)||bt(i,j+2)||bt(i+2,j+1)||bt(i+1,j+2)||bt(i+2,j+2)):!(bt(i+1,j)||bt(i,j+1)||bt(i+1,j+1)||bt(i+2,j+1)||bt(i+1,j+2));
    // World: the open middle, nothing tall in front. A city: the front edge, nearest the viewer, so no tower can hide it
    var d=D.world?Math.hypot(i-W/2,j-H/2)-(clear?1000:0):-(i+j)+.6*Math.abs(i-j)-(clear?1000:0);if(d<bd){bd=d;best=[i,j]}}
  if(!best)return;SHOP={i:best[0],j:best[1],big:!!D.world};tiles[best[0]+','+best[1]]={t:'w'};
  if(D.world)for(var a=0;a<3;a++)for(var b2=0;b2<3;b2++)if(a||b2)tiles[(best[0]+a)+','+(best[1]+b2)]={t:'wp'}})();
// ---- buildings
var maxC=1;D.districts.forEach(function(d){d.repos.forEach(function(r){maxC=Math.max(maxC,r.commits)})});
function bh(r){if(r.kind)return D.world?30:46;return D.world?14+Math.min(110,Math.round(20*Math.log2(1+r.commits/8))):16+Math.min(230,Math.round(34*Math.log2(1+r.commits/8)))}
var maxH=0,ranked=[];D.districts.forEach(function(d){d.repos.forEach(function(r){maxH=Math.max(maxH,bh(r));ranked.push(r)})});
ranked.sort(function(a,b){return (b.week*20+b.commits)-(a.week*20+a.commits)});var topSet=ranked.slice(0,12);
function dormant(r){return r.pushed&&now-Date.parse(r.pushed)>60*DAY&&!r.week}
// ---- view
var dpr=1,vw=0,vh=0,cam={x:0,y:0,z:1};
function iso(i,j){return {x:(i-j)*TW/2,y:(i+j)*TH/2}}
var FITZ=0;   // the zoom that fits the whole map: world labels loosen their budget as you zoom past it
function fit(){var r=st.getBoundingClientRect();dpr=window.devicePixelRatio||1;vw=r.width;vh=r.height;cv.width=vw*dpr;cv.height=vh*dpr;
  var spanX=(W+H)*TW/2+TW,spanY=(W+H)*TH/2+maxH+40;cam.z=Math.min(1.6,Math.max(D.world?.08:.3,Math.min(vw/spanX,vh/spanY)*.98));
  var c=iso(W/2,H/2);cam.x=vw/2-c.x*cam.z;cam.y=vh/2-c.y*cam.z+(maxH/2)*cam.z;
  if(under){var y0=iso(0,0).y-maxH*.6,y1=iso(W,H).y+DROP+DSPAN+20;cam.z=Math.min(1.4,Math.max(.25,Math.min(vw/spanX,vh/(y1-y0))*.96));cam.x=vw/2-c.x*cam.z;cam.y=vh/2-((y0+y1)/2)*cam.z}
  FITZ=cam.z;dirty=true;UDIRTY=true}
// ---- cars wander the roads
var roads=[];for(var k in tiles)if(tiles[k].t==='r'){var p=k.split(',');roads.push([+p[0],+p[1]])}
var traffic=D.districts.reduce(function(s,d){return s+d.repos.reduce(function(a,r){return a+r.week},0)},0);
var cars=[];for(var c=0;c<Math.min(70,4+Math.round(traffic/6))&&roads.length;c++){var s=roads[Math.floor(rnd(c+1)*roads.length)];cars.push({i:s[0],j:s[1],ti:s[0],tj:s[1],t:1,col:['#F2F2F5','#E85D75','#4FB89A','#E8C547','#7AA7FF'][c%5]})}
// ---- live traffic on the owner's own sites (polled from the hub, or posted in by Obsidian): every visitor rides out of
// their district as a light (white), signups pulse pink, purchases fire a gold beam. Public pages get activity levels only.
var LV={d:{},seen:'',mode:''},vis=[],pulses=[],VCOL='#FFFFFF',SCOL='#FF4FD8',BCOL='#FFD23F';
var byName={};blocks.forEach(function(b){byName[b.d.name]=b});if(D.world)NBS.forEach(function(n){byName[n.key]=n.rep});
function exits(b){if(b.ex)return b.ex;b.ex=[];for(var j=b.y-1;j<=b.y+b.k;j++)for(var i=b.x-1;i<=b.x+b.k;i++)if(isRoad(i,j))b.ex.push([i,j]);return b.ex}
function spawn(b,col,fast){var ex=exits(b);if(!ex.length||vis.length>160)return;var s=ex[Math.floor(Math.random()*ex.length)];
  var v={i:s[0],j:s[1],ti:s[0],tj:s[1],t:1,col:col,b:b,born:performance.now(),life:14000+Math.random()*9000,sp:fast?.06:.045};step(v);vis.push(v)}
function pulse(b,col,big){var p=iso(b.x+b.k/2-.5,b.y+b.k/2-.5);pulses.push({x:p.x,y:p.y,col:col,born:performance.now(),big:big})}
function onLive(data){if(D.world&&data&&data.lit&&typeof data.lit==='object')LIT=data.lit;if(data&&data.districts&&typeof data.districts==='object'){var gt={},gs={};for(var gk in data.districts){var gd=data.districts[gk]||{},gv=+gd.glow;if(gv>0)gt[gk]=Math.min(1,gv);if(gd.sites&&typeof gd.sites==='object'){var sm={},sn=0;for(var sk in gd.sites){var sv=+gd.sites[sk];if(sv>0&&sn<24){sm[String(sk).slice(0,40)]=Math.min(1,sv);sn++}}if(sn)gs[gk]=sm}}GT=gt;GS=gs}if(D.world&&data&&typeof data.members==='number'&&typeof worldGrew==='function')worldGrew(data.members);if(!data||typeof data!=='object'||!data.districts||typeof data.districts!=='object')return;LV.mode=data.private?'private':'public';LV.d=data.districts;
  if(!LV.on&&Object.keys(LV.d).length){LV.on=true;cars.length=0}   // live data replaces the ambient traffic: from now on every car is a real visitor
  if(LV.on)reconcile();
  if(Array.isArray(data.agents))agentsIn(data.agents);
  if(Array.isArray(data.events)){var first=!LV.seen,fresh=data.events.filter(function(ev){return ev&&ev.ts>LV.seen&&(ev.k!=='view'||ev.n)}).reverse();
    var nv=0,nc=0;if(!first)fresh.slice(-40).forEach(function(ev){if(ev.k==='kudos')return void setTimeout(function(){kudosBurst(ev)},(nc++)*900);var b=byName[ev.d]||byName.Private;if(!b)return;
      if(ev.k==='view')return void setTimeout(function(){arrive(b,'view')},(nv++)*350);
      setTimeout(function(){spawn(b,ev.k==='buy'?BCOL:SCOL,true);pulse(b,ev.k==='buy'?BCOL:SCOL,ev.k==='buy');celebrate(b,ev.k,ev.d);arrive(b,ev.k)},(nc++)*900)});
    data.events.forEach(function(ev){if(ev&&ev.ts>LV.seen)LV.seen=ev.ts});if(!LV.seen)LV.seen=String(data.at||'0')}
  if(data.arrivals&&typeof data.arrivals==='object'&&LV.at)Object.keys(data.arrivals).forEach(function(k){var a=data.arrivals[k]||{},b=byName[k]||byName.Private;if(!b)return;   // public: counts only
    for(var i=0;i<Math.min(+a.v||0,40);i++)(function(i){setTimeout(function(){arrive(b,'view')},i*350)})(i);
    for(var j=0;j<Math.min(+a.s||0,5);j++)(function(j){setTimeout(function(){pulse(b,SCOL,false);celebrate(b,'signup',k);arrive(b,'signup')},j*900)})(j);
    for(var m2=0;m2<Math.min(+a.b||0,5);m2++)(function(m2){setTimeout(function(){pulse(b,BCOL,true);celebrate(b,'buy',k)},m2*900+400)})(m2)});
  onDay(data);liveConnected();
  if(data.at)LV.at=String(data.at);
  hud();draw()}
// ---- arrivals: every new visitor drops in from the sky onto its district (parachute, landing ring, walks to a building);
// a signup is a beam of light, confetti and a toast; a sale is a gold coin burst. Capped and queued when it floods.
var FX={drops:[],queue:[],parts:[],beams:[],more:{}},MAXDROP=MINI?5:8,toasts=document.querySelector('.c-toasts'),sound=false,AC=null;
try{sound=localStorage.getItem('caldera-sound')==='1'}catch(err){}
function arrive(b,kind){if(!b)return;if(FX.drops.length>=MAXDROP){if(FX.queue.length<24)FX.queue.push(b);else{var mo=FX.more[b.d.name]||(FX.more[b.d.name]={n:0,b:b});mo.n++;mo.until=performance.now()+5000}return}
  var path=arrivalPath(b);if(!path)return;var p=path[0];
  FX.drops.push({x:p.x,y:p.y,path:path,col:kind==='signup'?SCOL:kind==='buy'?BCOL:null,born:performance.now(),sw:Math.random()*6.28});tone([880,1320],.05)}
function toast(kind,district){if(!toasts)return;var t=document.createElement('div');t.className='c-toast'+(kind==='buy'?' buy':'');
  var priv=LV.mode!=='private'&&district==='Private';   // public pages never name a private project
  t.textContent=kind==='buy'?(priv?'\u{1F4B0} A sale':'\u{1F4B0} New sale · '+district):(priv?'✨ Someone joined':'✨ New signup · '+district);
  toasts.insertBefore(t,toasts.firstChild);while(toasts.children.length>3)toasts.removeChild(toasts.lastChild);setTimeout(function(){if(t.parentNode)t.parentNode.removeChild(t)},5200)}
// kudos: the emoji rises over the city from a random district, with a toast naming who sent it (private feed only)
var KEMO={heart:'\u2764\uFE0F',up:'\u{1F44D}',fire:'\u{1F525}',sparkle:'\u2728'};
function kudosBurst(ev){var ks=Object.keys(byName),b=byName[ks[Math.floor(Math.random()*ks.length)]];var em=KEMO[ev.e]||KEMO.heart;
  if(toasts){var t=document.createElement('div');t.className='c-toast';t.textContent=em+' '+(typeof ev.from==='string'&&/^[a-z0-9-]{1,40}$/.test(ev.from)?'@'+ev.from:'Someone')+' sent you kudos';toasts.insertBefore(t,toasts.firstChild);while(toasts.children.length>3)toasts.removeChild(toasts.lastChild);setTimeout(function(){if(t.parentNode)t.parentNode.removeChild(t)},5200)}
  if(!b)return;var c0=iso(b.x+b.k/2-.5,b.y+b.k/2-.5),tn=performance.now();
  for(var i=0;i<(MINI?10:18);i++){var a=-Math.PI/2+(Math.random()-.5)*1.4,v=50+Math.random()*60;FX.parts.push({x:c0.x,y:c0.y-60,vx:Math.cos(a)*v,vy:Math.sin(a)*v-140,emo:em,born:tn+i*70,life:2600+Math.random()*700,rot:0})}
  tone([659,880,1175],.07)}
function celebrate(b,kind,district){if(!b)return;toast(kind,district||(D.world?b.d.nb:b.d.name)||b.d.name);var c0=iso(b.x+b.k/2-.5,b.y+b.k/2-.5),tn=performance.now(),buy=kind==='buy';
  FX.beams.push({x:c0.x,y:c0.y,col:buy?BCOL:SCOL,born:tn});
  var CONF=['#FF4FD8','#3DF2FF','#FFD23F','#7CFF6B','#FF7A45','#B58CFF'];
  for(var i=0;i<(MINI?26:48);i++){var a=Math.random()*6.28,v=40+Math.random()*(buy?70:110);FX.parts.push({x:c0.x,y:c0.y-(buy?40:130)*Math.max(1,.9/cam.z),vx:Math.cos(a)*v,vy:Math.sin(a)*v*.7-(buy?120:60),col:buy?(i%3?'#FFD23F':'#FFF1A8'):CONF[i%CONF.length],born:tn+Math.random()*120,life:1800+Math.random()*900,coin:buy,rot:Math.random()*6})}
  tone(buy?[784,988,1319,1568]:[523,659,784,1047],.09)}
function tone(fs,len){if(!sound)return;try{AC=AC||new (window.AudioContext||window.webkitAudioContext)();var t0=AC.currentTime;fs.forEach(function(f,i){var o=AC.createOscillator(),g=AC.createGain();o.type='triangle';o.frequency.value=f;
  g.gain.setValueAtTime(0,t0+i*len);g.gain.linearRampToValueAtTime(.06,t0+i*len+.01);g.gain.exponentialRampToValueAtTime(.0001,t0+i*len+len*2.2);o.connect(g);g.connect(AC.destination);o.start(t0+i*len);o.stop(t0+i*len+len*2.4)})}catch(err){}}
function person(c,x,y,col,s){c.fillStyle=col;c.strokeStyle=sky==='day'||sky==='dusk'?'rgba(10,14,30,.75)':'rgba(0,0,0,.55)';c.lineWidth=.8;
  c.beginPath();c.arc(x,y-9*s,2.2*s,0,7);c.fill();c.stroke();c.beginPath();c.moveTo(x-1.6*s,y-6.5*s);c.lineTo(x+1.6*s,y-6.5*s);c.lineTo(x+1.2*s,y-2*s);c.lineTo(x-1.2*s,y-2*s);c.closePath();c.fill();c.stroke();
  c.strokeStyle=col;c.lineWidth=1.2*s;c.beginPath();c.moveTo(x-.8*s,y-2*s);c.lineTo(x-1.4*s,y);c.moveTo(x+.8*s,y-2*s);c.lineTo(x+1.4*s,y);c.stroke()}
function drawFx(){var tn=performance.now(),more=Object.keys(FX.more);if(!FX.drops.length&&!FX.parts.length&&!FX.beams.length&&!more.length)return;
  var c=cx;c.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);var day=sky==='day',col=day?'#1E6FD9':'#7FE7FF',K=Math.max(1.25,1.1/cam.z);   // effects keep a readable size when zoomed out
  FX.beams=FX.beams.filter(function(b){return tn-b.born<2400});FX.beams.forEach(function(b){var pr=(tn-b.born)/2400,a=pr<.15?pr/.15:1-(pr-.15)/.85;c.save();if(!day)c.globalCompositeOperation='lighter';
    var g=c.createLinearGradient(0,b.y-420*K,0,b.y);g.addColorStop(0,'rgba(255,255,255,0)');g.addColorStop(1,b.col);c.globalAlpha=a*.85;c.fillStyle=g;var w=(10+8*Math.sin(pr*9))*K;c.fillRect(b.x-w/2,b.y-420*K,w,420*K);
    c.globalAlpha=a*.6;c.fillRect(b.x-1.5*K,b.y-420*K,3*K,420*K);c.restore()});
  FX.drops=FX.drops.filter(function(d){var t=tn-d.born;if(t<1950)return true;if(FX.queue.length)setTimeout(function(){arrive(FX.queue.shift(),'view')},60);return false});
  FX.drops.forEach(function(d){var t=tn-d.born,x=d.x,y=d.y,FALL=1300,S=PS,R=Math.max(1,.9/cam.z);   // the person and parachute are street scale; only the trail and landing ring stay readable when zoomed out
    if(t<FALL){var f=t/FALL,e2=f*f*(3-2*f),sw=Math.sin(t/180+d.sw)*3*S*(1-f);x+=sw;y=d.y-200*(1-e2);
      c.save();var g=c.createLinearGradient(0,y-60*R,0,y-6*S);g.addColorStop(0,'rgba(255,255,255,0)');g.addColorStop(1,day?'rgba(30,111,217,.4)':'rgba(127,231,255,.55)');c.strokeStyle=g;c.lineWidth=1.2*R;c.beginPath();c.moveTo(x-sw*.6,y-60*R);c.lineTo(x,y-13*S);c.stroke();
      c.fillStyle=day?'#FF6B4A':'#FF4FD8';c.beginPath();c.arc(x,y-19*S,7.5*S,Math.PI,0);c.closePath();c.fill();c.strokeStyle=day?'rgba(0,0,0,.45)':'rgba(255,255,255,.55)';c.lineWidth=.45;c.beginPath();c.moveTo(x-7.5*S,y-19*S);c.lineTo(x-1.4*S,y-8*S);c.moveTo(x+7.5*S,y-19*S);c.lineTo(x+1.4*S,y-8*S);c.stroke();c.restore();
      walkerFig(c,x,y,d.col||col,S,1,0,0)}
    else{if(!d.walk){d.walk=true;walker(d.path,false,d.col)}var t2=t-FALL;if(t2<650){var pr=t2/650;c.save();c.strokeStyle=d.col||col;c.globalAlpha=1-pr;c.lineWidth=1.1;c.beginPath();c.ellipse(d.x,d.y,(3+pr*12)*R,(3+pr*12)*.5*R,0,0,7);c.stroke();
      c.fillStyle=day?'rgba(120,100,80,.35)':'rgba(200,230,255,.25)';for(var k=0;k<5;k++){var a2=k*1.256+d.sw;c.beginPath();c.arc(d.x+Math.cos(a2)*(2+pr*7),d.y+Math.sin(a2)*(1+pr*3.5)-pr*2,.8*(1-pr),0,7);c.fill()}c.restore()}}});
  FX.parts=FX.parts.filter(function(p){return tn-p.born<p.life});FX.parts.forEach(function(p){var t=Math.max(0,tn-p.born)/1000,x=p.x+p.vx*K*t,y=p.y+(p.vy*t+140*t*t)*K,a=1-(tn-p.born)/p.life;if(t<=0)return;
    if(p.emo){c.save();c.globalAlpha=Math.max(0,a);c.font=Math.round(15*K)+'px "Apple Color Emoji","Segoe UI Emoji",sans-serif';c.textAlign='center';c.fillText(p.emo,p.x+p.vx*K*t,p.y+(p.vy*t+40*t*t)*K);c.restore();return}
    c.save();c.globalAlpha=Math.max(0,a);c.fillStyle=p.col;if(p.coin){c.beginPath();c.ellipse(x,y,(3.2*Math.abs(Math.cos(t*8+p.rot))+.6)*K,3.2*K,0,0,7);c.fill();c.strokeStyle='#B8860B';c.lineWidth=.6;c.stroke()}
    else{c.translate(x,y);c.rotate(t*6+p.rot);c.fillRect(-2*K,-1*K,4*K,2*K)}c.restore()});
  more.forEach(function(k){var m=FX.more[k];if(tn>m.until){delete FX.more[k];return}var p2=iso(m.b.x+m.b.k/2-.5,m.b.y-.5);tronPill(c,p2.x,p2.y-40,'+'+m.n+' arriving',day?'#1E6FD9':'#7FE7FF','600 10.5px ui-monospace,monospace')})}
var HND=(location.pathname.match(/\/@([a-z0-9-]+)\//)||[])[1]||'';
// ---- people on foot: arrivals land at street scale (the size of the cars) and walk to a building's door; people who
// left walk back out as faint ghosts; worn paths show where the day's visitors went. All drawn under the buildings
// layer so a building in front hides whoever is behind it.
var WID=0,PS=.55,WALKS=[],WMAX=MINI?16:40,WQ=[],GHOSTCOL='#A9C2D8',DEPSEEN={},DEPFIRST=true,TRACES=[],TODAY=null,lastWT=0;
function roadPath(a,b,max){if(a[0]===b[0]&&a[1]===b[1])return [a];var key=function(t){return t[0]+','+t[1]},prev={},q=[a],seen={};seen[key(a)]=1;
  while(q.length){var t=q.shift();if(t[0]===b[0]&&t[1]===b[1]){var out=[t],k=key(t);while(prev[k]){out.unshift(prev[k]);k=key(prev[k])}return out}
    if(max&&q.length>4000)break;[[1,0],[-1,0],[0,1],[0,-1]].forEach(function(d){var n=[t[0]+d[0],t[1]+d[1]],kn=key(n);if(!seen[kn]&&isRoad(n[0],n[1])){seen[kn]=1;prev[kn]=t;q.push(n)}})}return null}
function adjRoads(i,j){return [[i+1,j],[i-1,j],[i,j+1],[i,j-1]].filter(function(n){return isRoad(n[0],n[1])})}
// a building with a street outside its door (falls back to any building in the district)
// how much a tile is hidden from the viewer by tall buildings standing in front of it
function hiddenBy(i,j){var h=0;for(var d=0;d<=9;d++)[[d+1,d],[d,d+1],[d+1,d+1]].forEach(function(o){var t=tiles[(i+o[0])+','+(j+o[1])];if(t&&t.t==='b'&&bh(t.r)>(o[0]+o[1]-1)*TH/2)h+=1});return h}   // a tower in front (same screen column, nearer) covers the street behind it
function doorFor(b){var bl=BDIST[b.d.name]||[],ex=exits(b);if(!bl.length||!ex.length)return null;var cands=[];
  bl.forEach(function(o){ex.forEach(function(E){var d=Math.abs(E[0]-o.i)+Math.abs(E[1]-o.j);if(d<1||d>2)return;
    var mid=d===2?[Math.round((E[0]+o.i)/2),Math.round((E[1]+o.j)/2)]:null;if(mid){var mt=tiles[mid[0]+','+mid[1]];if(!mt||(mt.t!=='p'&&mt.t!=='r'))return}   // across an open plaza only, never through a building or the houses
    cands.push({o:o,E:E,d:d,h:hiddenBy(E[0],E[1])+(mid?hiddenBy(mid[0],mid[1]):0)+(d-1)*.5+(E[0]+E[1]<o.i+o.j?.25:0)})})});
  if(!cands.length)return null;cands.sort(function(p,q){return p.h-q.h});var best=cands.filter(function(x){return x.h<=cands[0].h+.01});return best[Math.floor(Math.random()*best.length)]}   // doors the viewer can see: walking in should be visible
function wpts(tl){var pts=[];for(var k=0;k<tl.length;k++){var a=tl[k],b=tl[k+1]||tl[k-1]||a,p=iso(a[0],a[1]),q=iso(b[0],b[1]),dx=q.x-p.x,dy=q.y-p.y,l=Math.hypot(dx,dy)||1,s=k+1<tl.length?1:-1;
    pts.push({x:p.x-(-dy/l)*7*s,y:p.y-(dx/l*.5)*7*s})}return pts}
function lerpPt(a,b,f){return {x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f}}
function walker(pts,ghost,col,delay){var len=0,seg=[];for(var k=1;k<pts.length;k++){var l=Math.hypot(pts[k].x-pts[k-1].x,pts[k].y-pts[k-1].y);seg.push(l);len+=l}
  var w={pts:pts,seg:seg,len:Math.max(1,len),d:0,sp:ghost?14:18,ghost:ghost,col:col,id:++WID,born:performance.now()+(delay||0)};
  if(WALKS.length>=WMAX){if(WQ.length<40)WQ.push(w);return}WALKS.push(w)}
function walkAt(w){var d=w.d;for(var k=0;k<w.seg.length;k++){if(d<=w.seg[k]){var f=d/(w.seg[k]||1),a=w.pts[k],b=w.pts[k+1];return {x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f,ux:(b.x-a.x)/(w.seg[k]||1),uy:(b.y-a.y)/(w.seg[k]||1)}}d-=w.seg[k]}
  var z=w.pts[w.pts.length-1];return {x:z.x,y:z.y,ux:0,uy:0}}
// arrival: the street path from where the parachute lands to the door (the last stretch goes in through it)
function arrivalPath(b){var df=doorFor(b);if(!df)return null;var ex=exits(b).filter(function(t){var d=Math.abs(t[0]-df.E[0])+Math.abs(t[1]-df.E[1]);return d>=2&&d<=4}).sort(function(p,q){return hiddenBy(p[0],p[1])-hiddenBy(q[0],q[1])}),L=ex.length?ex[Math.floor(Math.random()*Math.ceil(ex.length/2))]:df.E;
  var tl=roadPath(L,df.E,1)||[df.E],pts=wpts(tl),door=iso(df.o.i,df.o.j),Ec=iso(df.E[0],df.E[1]);pts.push(lerpPt(Ec,door,1-.58/df.d),lerpPt(Ec,door,1-.42/df.d));return pts}
function departurePath(b){var df=doorFor(b);if(!df)return null;var ex=exits(b),best=df.E,bd=-1;ex.forEach(function(t){var d=Math.abs(t[0]-df.E[0])+Math.abs(t[1]-df.E[1]);if(d<=6&&d>bd&&Math.random()<.7){bd=d;best=t}});
  var door=iso(df.o.i,df.o.j),Ec=iso(df.E[0],df.E[1]),tl=roadPath(df.E,best,1)||[df.E];return [lerpPt(Ec,door,1-.45/df.d),lerpPt(Ec,door,1-.6/df.d)].concat(wpts(tl))}
function ghostOut(b,delay){if(!b)return;var p=departurePath(b);if(p)walker(p,true,GHOSTCOL,delay)}
function stepWalks(tn){var dt=lastWT?Math.min(100,tn-lastWT):0;lastWT=tn;
  WALKS=WALKS.filter(function(w){if(tn<w.born)return true;w.d+=w.sp*dt/1000;return w.d<w.len});
  while(WALKS.length<WMAX&&WQ.length){var w=WQ.shift();w.born=Math.max(w.born,tn);WALKS.push(w)}}
// a person at street scale: head, body and two legs that stride (3 frames) along the direction of travel
function walkerFig(c,x,y,col,s,wf,ux,uy){var st=[-1,0,1,0][wf]*1.5*s;c.fillStyle=col;c.beginPath();c.arc(x,y-9*s,2.2*s,0,7);c.fill();
  c.beginPath();c.moveTo(x-1.6*s,y-6.5*s);c.lineTo(x+1.6*s,y-6.5*s);c.lineTo(x+1.2*s,y-2*s);c.lineTo(x-1.2*s,y-2*s);c.closePath();c.fill();
  c.strokeStyle=col;c.lineWidth=1.25*s;c.lineCap='round';c.beginPath();c.moveTo(x-.6*s,y-2*s);c.lineTo(x-.9*s+ux*st,y+uy*st*.5);c.moveTo(x+.6*s,y-2*s);c.lineTo(x+.9*s-ux*st,y-uy*st*.5);c.stroke();
  c.beginPath();c.moveTo(x-1.5*s,y-6*s);c.lineTo(x-1.9*s-ux*st*.6,y-3.4*s);c.moveTo(x+1.5*s,y-6*s);c.lineTo(x+1.9*s+ux*st*.6,y-3.4*s);c.stroke()}
function drawWalks(){if(INTRO)return;if(!WALKS.length)return;var c=cx,tn=performance.now();c.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);
  var day=sky==='day',live=day?'#1E5FBF':'#BFF3FF',shade=day?'rgba(0,0,0,.22)':'rgba(0,0,0,.35)';
  WALKS.slice().sort(function(a,b){return walkAt(a).y-walkAt(b).y}).forEach(function(w){if(tn<w.born)return;var p=walkAt(w),f=w.d/w.len,a;
    if(w.ghost)a=.42*Math.min(1,w.d/8)*(f>.7?Math.max(0,1-(f-.7)/.3):1);else a=f>.86?Math.max(0,1-(f-.86)/.14):1;   // arrivals fade into the doorway, ghosts fade at the district edge
    if(a<=0)return;var wf=Math.floor(w.d/2.4)%4;c.save();c.globalAlpha=a;
    c.fillStyle=shade;c.beginPath();c.ellipse(p.x+1,p.y+.6,2.4*PS,1*PS,0,0,7);c.fill();
    walkerFig(c,p.x,p.y,w.ghost?GHOSTCOL:(w.col||live),PS,wf,p.ux,p.uy);c.restore()})}
// worn paths: footprints between the street and each busy building's door, brighter with more visitors today (log
// scale), newer visits counting more; they reset at the viewer's local midnight
function buildTraces(){TRACES=[];if(!TODAY)return;var mid=new Date();mid.setHours(0,0,0,0);var m0=mid.getTime(),Q15=9e5,wmax=0,W={};
  Object.keys(TODAY).forEach(function(k){var x=TODAY[k],t0=Date.parse(x.t0)||0,w=0;(x.q||[]).forEach(function(n,i){var ts=t0+i*Q15;if(ts<m0||!n)return;w+=n*(.35+.65*Math.max(0,Math.min(1,(ts-m0)/(Date.now()-m0||1))))});W[k]=w;wmax=Math.max(wmax,w)});
  if(!wmax)return;Object.keys(W).forEach(function(k){var b=byName[k];if(!b||!W[k])return;var br=Math.log(1+W[k])/Math.log(1+wmax);
    var bl=(BDIST[b.d.name]||[]).filter(function(o){return adjRoads(o.i,o.j).length}).sort(function(p,q){return ((q.r.week||0)*20+(q.r.commits||0))-((p.r.week||0)*20+(p.r.commits||0))}).slice(0,3);
    bl.forEach(function(o,ix){var E=adjRoads(o.i,o.j).sort(function(p,q){return (q[0]+q[1])-(p[0]+p[1])})[0],Ec=iso(E[0],E[1]),door=iso(o.i,o.j),pts=[];
      var nb=adjRoads(E[0],E[1]).filter(function(n){return !(n[0]===o.i&&n[1]===o.j)})[0];if(nb){var q=iso(nb[0],nb[1]);pts.push(lerpPt(q,Ec,.35))}pts.push(Ec,lerpPt(Ec,door,.42));
      TRACES.push({pts:pts,a:br*(1-ix*.25),seed:o.i*31+o.j*7})})})}
function drawTraces(){if(!TRACES.length||sky==='grid')return;var c=cx;c.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);var k=wxKind(),day=sky==='day'||sky==='dusk';
  var wet=k==='rain'||k==='storm'||k==='drizzle',col=k==='snow'?(day?'60,85,125':'170,190,220'):!day?(wet?'170,200,240':'200,214,236'):wet?'12,20,34':'70,52,36';   // wet prints at night catch the street light
  TRACES.forEach(function(t){for(var s=0;s<t.pts.length-1;s++){var a=t.pts[s],b=t.pts[s+1],l=Math.hypot(b.x-a.x,b.y-a.y),n=Math.floor(l/3.2),ux=(b.x-a.x)/(l||1),uy=(b.y-a.y)/(l||1);
    for(var i=0;i<n;i++){var f=(i+.5)/n,side=i%2?1:-1,x=a.x+(b.x-a.x)*f-uy*side*1.3,y=a.y+(b.y-a.y)*f+ux*side*.65,al=(.1+.5*t.a)*(day?1:.85)*(.75+.25*rnd(t.seed+i*3.1+s));
      c.fillStyle='rgba('+col+','+al.toFixed(3)+')';c.beginPath();c.ellipse(x,y,1.15,.6,Math.atan2(uy,ux),0,7);c.fill();
      if(k==='rain'||k==='storm'){c.fillStyle='rgba(200,225,255,'+(al*.5).toFixed(3)+')';c.fillRect(x-.3,y-.4,.6,.3)}}}})}
// ---- weather: the viewer's real local weather (hub lookup, or Obsidian passing it in), or what they pick
var WX=null,WXMODES=['auto','clear','rain','snow','fog'],WXMODE='auto',WXN={auto:'Auto',clear:'Clear',partly:'Partly cloudy',overcast:'Overcast',drizzle:'Drizzle',rain:'Rain',storm:'Storm',snow:'Snow',fog:'Fog'};
try{var wv=localStorage.getItem('caldera-weather');if(wv&&WXMODES.indexOf(wv)>=0)WXMODE=wv}catch(err){}
var hw0=location.hash.match(/[#&]wx=([a-z]+)/);if(hw0)WXMODE=hw0[1];   // #wx=storm etc. for checking
function wxKind(){if(WXMODE!=='auto')return WXMODE;return WX&&WX.c?WX.c:'clear'}
function wxCloud(){var k=wxKind();if(WXMODE==='auto'&&WX&&WX.c)return Math.max(+WX.cloud||0,{rain:80,storm:95,drizzle:70,snow:80,fog:60,overcast:90}[k]||0);return {clear:8,partly:40,overcast:92,fog:65,drizzle:75,rain:88,storm:98,snow:85}[k]||10}
function wxWind(){var w=WXMODE==='auto'&&WX?+WX.wind||0:12,d=WXMODE==='auto'&&WX?(+WX.dir||270):250;return {vx:-Math.sin(d*Math.PI/180)*w,w:w}}   // meteorological: the direction it blows FROM
var CLOUDS=[],CLW=0,CLH=0,lastCT=0;
function cloudColor(){var k=wxKind(),dark=k==='storm'?.55:k==='rain'||k==='overcast'||k==='snow'?.3:k==='drizzle'||k==='fog'?.2:0;
  if(sky==='night')return 'rgba('+Math.round(52-dark*20)+','+Math.round(60-dark*20)+','+Math.round(82-dark*20)+',.62)';
  if(sky==='dusk')return 'rgba('+Math.round(255-dark*120)+','+Math.round(200-dark*90)+','+Math.round(190-dark*70)+',.6)';
  var g=Math.round(255-dark*110);return 'rgba('+g+','+(g+2>255?255:g+2)+','+(g+6>255?255:g+6)+','+(.82+dark*.15).toFixed(2)+')'}
function newCloud(edge){var s=.6+Math.random()*.9,ww=60*s+40;return {x:edge==null?Math.random()*(vw+2*ww)-ww:edge<0?-ww-Math.random()*40:vw+ww+Math.random()*40,y:(.04+Math.random()*.3)*vh,s:s,v:.7+Math.random()*.6,w:ww,p:Math.floor(Math.random()*3),gone:false}}
// clouds keep their own positions frame to frame: they drift with the wind, wrap only once fully off screen, and are
// never re-randomized by a resize, a phase change or a live update
function stepClouds(tn){if(!vw)return;var dt=lastCT?Math.min(200,tn-lastCT)/1000:0;lastCT=tn;
  if(CLW&&(CLW!==vw||CLH!==vh)){var fx=vw/CLW,fy=vh/CLH;CLOUDS.forEach(function(c){c.x*=fx;c.y*=fy})}CLW=vw;CLH=vh;
  var want=Math.round(1+wxCloud()/100*(MINI?6:10)),wd=wxWind(),dir=wd.vx<0?-1:1,sp=6+Math.min(40,Math.abs(wd.vx))*.9;
  if(!CLOUDS.length)for(var i=0;i<want;i++)CLOUDS.push(newCloud(null));
  var live=CLOUDS.filter(function(c){return !c.gone}).length;
  if(live>want){for(var j=0;j<CLOUDS.length&&live>want;j++)if(!CLOUDS[j].gone){CLOUDS[j].gone=true;live--}}   // retire extras: they drift off, never vanish
  while(live<want){CLOUDS.push(newCloud(-dir));live++}
  CLOUDS.forEach(function(c){c.x+=dir*sp*c.v*dt});
  CLOUDS=CLOUDS.filter(function(c){var off=dir>0?c.x-c.w>vw:c.x+c.w<0;if(!off)return true;if(c.gone)return false;var n=newCloud(-dir);c.x=n.x;c.y=n.y;c.s=n.s;c.w=n.w;return true})}
function drawClouds(c){var col=cloudColor();c.fillStyle=col;CLOUDS.forEach(function(k){var s=k.s;[[0,0,22],[18,4,16],[-18,5,15],[8,-8,15],[-6,-6,13],[30,6,11]].slice(0,5+k.p%2).forEach(function(b){c.beginPath();c.arc(k.x+b[0]*s,k.y+b[1]*s,b[2]*s,0,7);c.fill()})})}
var PRECIP=[],flash=0,nextBolt=0;
function stepPrecip(dt){var k=wxKind(),n=k==='storm'?(MINI?110:220):k==='rain'?(MINI?80:160):k==='drizzle'?(MINI?40:80):k==='snow'?(MINI?60:130):0;
  if(WXMODE==='auto'&&WX&&(k==='rain'||k==='storm'))n=Math.round(n*Math.min(1.4,.6+(+WX.precip||0)/4));
  while(PRECIP.length<n)PRECIP.push({x:Math.random()*vw,y:Math.random()*vh,z:.6+Math.random()*.6,snow:k==='snow'});
  if(PRECIP.length>n)PRECIP.length=n;var wd=wxWind(),slant=Math.max(-.6,Math.min(.6,wd.vx/45));
  PRECIP.forEach(function(p){p.snow=k==='snow';var vy=p.snow?28*p.z:(k==='drizzle'?260:520)*p.z;p.y+=vy*dt;p.x+=(p.snow?(slant*30+Math.sin((p.y+p.z*99)/30)*12):slant*vy)*dt;
    if(p.y>vh){p.y=-10;p.x=Math.random()*(vw+80)-40}if(p.x<-40)p.x+=vw+80;if(p.x>vw+40)p.x-=vw+80})}
function drawWeather(){var k=wxKind();if(sky==='grid')return;var c=cx;c.setTransform(dpr,0,0,dpr,0,0);var night=sky==='night',tn=performance.now();
  var gloom=k==='storm'?.24:k==='rain'?.14:k==='drizzle'?.08:k==='overcast'?.06:k==='snow'?.04:0;if(gloom){c.fillStyle='rgba(12,18,30,'+gloom+')';c.fillRect(0,0,vw,vh)}
  if(k==='snow'){c.fillStyle='rgba(235,242,250,'+(night?.08:.16)+')';c.fillRect(0,0,vw,vh)}
  if(k==='fog'){var g=c.createLinearGradient(0,vh*.15,0,vh);g.addColorStop(0,night?'rgba(70,78,96,.18)':'rgba(214,220,226,.28)');g.addColorStop(1,night?'rgba(70,78,96,.5)':'rgba(214,220,226,.6)');c.fillStyle=g;c.fillRect(0,0,vw,vh);
    c.fillStyle=night?'rgba(90,100,120,.12)':'rgba(240,244,248,.18)';for(var b=0;b<3;b++){var y=vh*(.45+b*.17)+Math.sin(tn/4000+b)*8,x=((tn/90+b*300)%(vw+400))-200;c.beginPath();c.ellipse(x,y,260,30,0,0,7);c.fill()}}
  if(PRECIP.length){var wd=wxWind(),slant=Math.max(-.6,Math.min(.6,wd.vx/45));
    if(k==='snow'){c.fillStyle=night?'rgba(220,230,245,.8)':'rgba(255,255,255,.95)';PRECIP.forEach(function(p){c.beginPath();c.arc(p.x,p.y,1.1+p.z*.9,0,7);c.fill()})}
    else{c.strokeStyle=night?'rgba(170,195,230,.45)':'rgba(70,95,130,.42)';c.lineWidth=1;c.beginPath();PRECIP.forEach(function(p){var l=(k==='drizzle'?5:11)*p.z;c.moveTo(p.x,p.y);c.lineTo(p.x-slant*l,p.y-l)});c.stroke()}}
  if(k==='storm'){if(tn>nextBolt){flash=tn;nextBolt=tn+6000+Math.random()*9000}var fa2=tn-flash;if(fa2<520){var a=fa2<90?.5:fa2<160?.08:fa2<240?.35:Math.max(0,.35*(1-(fa2-240)/280));c.fillStyle='rgba(230,236,255,'+a.toFixed(3)+')';c.fillRect(0,0,vw,vh)}}}
// sunrise and sunset from the viewer's real location drive Auto's day (falls back to fixed hours)
function sunKeys(){if(!WX||!WX.sunrise||!WX.sunset)return null;var r=new Date(WX.sunrise),s=new Date(WX.sunset),sr=r.getHours()*60+r.getMinutes(),ss=s.getHours()*60+s.getMinutes();
  if(!(sr>120&&ss>sr+240&&ss<1430))return null;var k=[[0,'night'],[sr-75,'night'],[sr+15,'dawn'],[sr+120,'day'],[ss-110,'day'],[ss-10,'dusk'],[ss+60,'evening'],[Math.min(1439,ss+150),'night'],[1440,'night']];
  for(var i=1;i<k.length;i++)if(k[i][0]<=k[i-1][0])k[i][0]=k[i-1][0]+1;return k}
function applyWeather(){var k=sunKeys();if(k)DAYKEYS=k;applySky();if(typeof skyLabel==='function')skyLabel();if(typeof wxLabel==='function')wxLabel();dirty=true}
// ---- today: "142 site visits today · 9 people on the sites now", from the live feed
var todayEl=null;function todayLine(){if(!TODAY||MINI)return;var v=0;Object.keys(TODAY).forEach(function(k){v+=+TODAY[k].v||0});
  var here=LV.mode==='private'?Object.keys(LV.d).reduce(function(s,k){return s+(+LV.d[k].now||0)},0):null,any=Object.keys(LV.d).some(function(k){return LV.d[k].level>0});
  if(!todayEl){todayEl=document.createElement('div');todayEl.className='c-today';st.appendChild(todayEl)}
  var lvp=st.querySelector('.c-live'),inLive=!!lvp&&st.clientWidth<600;   // phones: no room for two overlays at the bottom
  if(inLive&&todayEl.parentNode!==lvp){lvp.insertBefore(todayEl,lvp.firstChild);todayEl.classList.add('c-today-in')}else if(!inLive&&todayEl.parentNode!==st){st.appendChild(todayEl);todayEl.classList.remove('c-today-in')}
  todayEl.textContent=v.toLocaleString('en-US')+(v===1?' site visit':' site visits')+' today'+(here!=null?' · '+here+(here===1?' person':' people')+' on the sites now':any?' · live now':'');todayEl.title='Visits to the sites in this city in the last 24 hours, and people on them right now'}
function onDay(data){if(data.today&&typeof data.today==='object'){TODAY=data.today;buildTraces();todayLine()}
  var plan=[];
  if(Array.isArray(data.departures))data.departures.forEach(function(x){var id=x.v+'|'+x.ts;if(DEPSEEN[id]||!x.d)return;DEPSEEN[id]=1;plan.push(byName[x.d]||byName.Private)});
  if(data.left&&typeof data.left==='object')Object.keys(data.left).forEach(function(k){for(var i=0;i<Math.min(+data.left[k]||0,30);i++)plan.push(byName[k]||byName.Private)});
  plan=plan.filter(Boolean);
  if(DEPFIRST){DEPFIRST=false;plan=plan.slice(-20);plan.forEach(function(b,i){ghostOut(b,600+i*(19000/Math.max(1,plan.length)))});return}   // replay the last half hour in the first ~20 s
  plan.slice(-12).forEach(function(b,i){ghostOut(b,i*450)})}
// ---- owner only: turn on live visitors / agent drones (never shown to visitors: the hub sends it only to the owner)
var setupEl=null,SETUP=null;
function copyText(t,btn){var done=function(){var o=btn.textContent;btn.textContent='Copied';setTimeout(function(){btn.textContent=o},1600)};
  try{navigator.clipboard.writeText(t).then(done,function(){fallbackCopy(t)&&done()})}catch(err){fallbackCopy(t)&&done()}}
function fallbackCopy(t){try{var ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();var ok=document.execCommand('copy');document.body.removeChild(ta);return ok}catch(err){return false}}
function setupDismissed(){try{return localStorage.getItem('caldera-setup-dismissed')==='1'}catch(err){return false}}
function ownerSetup(o){SETUP=o;if(MINI||!o||setupDismissed()||o.dismissed)return;var needLive=o.liveOff&&o.sites&&o.sites.length,needAg=o.agentsOff&&o.agentPrompt;if(!needLive&&!needAg){if(setupEl)setupEl.remove();return}
  if(!setupEl){setupEl=document.createElement('div');setupEl.className='c-setup';st.parentNode.insertBefore(setupEl,st.nextSibling)}
  var snip=function(s){return '<script async src="'+o.hub+(o.sri?'/t/1.js" integrity="'+o.sri+'" crossorigin="anonymous':'/t.js')+'" data-site="'+s.key+'"></'+'script>'};
  var aiLive='Add Caldera live traffic to my websites, so visits show up as people arriving in my Caldera city.\n\nFor each site below, find the repo that builds that site, add the tag to the shared layout so it loads on every page (in <head>), deploy it, then open the live site and confirm a visit appears in my city at '+o.hub+(HND?'/@'+HND+'/city.html':'')+' (it shows within about 10 seconds).\n\nOn the signup success step call window.caldera && caldera(\'signup\'), and after a purchase caldera(\'buy\').\n\n'+(o.sites||[]).map(function(s){return '- '+s.project+':\n  '+snip(s)}).join('\n');
  setupEl.innerHTML=(needLive?'<div class="c-su-row"><span>Live visitors are off. See people arrive in your city as they visit your sites.</span><button type="button" class="c-su-go" data-p="live">Set up &rarr;</button></div>':'')
    +(needAg?'<div class="c-su-row"><span>Watch your AI agents work in your city.</span><button type="button" class="c-su-go" data-p="agents">Set up &rarr;</button></div>':'')
    +'<button type="button" class="c-su-x" aria-label="Dismiss" title="Hide this">&times;</button>'
    +(needLive?'<div class="c-su-panel" data-panel="live" hidden><p>Paste each district\'s line into that site\'s pages (in the shared layout\'s &lt;head&gt;). Every visit then drops into that district live. Mark conversions with <code>caldera(\'signup\')</code> and <code>caldera(\'buy\')</code>.</p>'
      +(o.sites||[]).map(function(s,i){return '<div class="c-su-site"><b>'+e(s.project)+'</b><code id="su-s'+i+'">'+e(snip(s))+'</code><button type="button" data-copy="su-s'+i+'">Copy</button></div>'}).join('')
      +'<button type="button" class="c-su-ai" data-ai="live">Copy prompt for my AI</button></div>':'')
    +(needAg?'<div class="c-su-panel" data-panel="agents" hidden><p>Paste this into Claude Code on each computer you use. Each agent then flies as a drone over the repo it is working in.</p><button type="button" class="c-su-ai" data-ai="agents">Copy prompt for my AI</button></div>':'');
  setupEl.querySelectorAll('.c-su-go').forEach(function(bt){bt.onclick=function(){var p=setupEl.querySelector('[data-panel="'+bt.getAttribute('data-p')+'"]');if(p)p.hidden=!p.hidden}});
  setupEl.querySelectorAll('[data-copy]').forEach(function(bt){bt.onclick=function(){copyText(document.getElementById(bt.getAttribute('data-copy')).textContent,bt)}});
  setupEl.querySelectorAll('.c-su-ai').forEach(function(bt){bt.onclick=function(){copyText(bt.getAttribute('data-ai')==='live'?aiLive:o.agentPrompt,bt)}});
  setupEl.querySelector('.c-su-x').onclick=function(){try{localStorage.setItem('caldera-setup-dismissed','1')}catch(err){}if(window.parent!==window)parent.postMessage({caldera:'setup-dismiss'},'*');setupEl.remove();setupEl=null}}
function liveConnected(){if(!setupEl||!SETUP||!SETUP.liveOff)return;var any=Object.keys(LV.d).some(function(k){return (+LV.d[k].views||0)>0||(+LV.d[k].level||0)>0});if(!any)return;
  SETUP.liveOff=false;ownerSetup(SETUP);var seen=false;try{seen=localStorage.getItem('caldera-live-connected')==='1';localStorage.setItem('caldera-live-connected','1')}catch(err){}
  if(!seen&&toasts){var t=document.createElement('div');t.className='c-toast';t.textContent='✅ Live visitors connected';toasts.insertBefore(t,toasts.firstChild);setTimeout(function(){if(t.parentNode)t.parentNode.removeChild(t)},6000)}}
// extras from the hub (weather endpoint, owner setup) or from Obsidian (postMessage)
var EX=window.CALDERA_EXTRAS||null;
function fetchWx(){if(!EX||!EX.weather||document.hidden)return;fetch(EX.weather,{cache:'no-store'}).then(function(r){return r.ok?r.json():null}).then(function(w){if(w&&w.c){WX=w;applyWeather()}}).catch(function(){})}
if(EX){if(EX.weather){setTimeout(fetchWx,300);setInterval(fetchWx,15*60000)}if(EX.owner)setTimeout(function(){ownerSetup(EX.owner)},50)}
window.addEventListener('message',function(ev){var m=ev.data;if(ev.source!==parent||!m||m.caldera!=='extras'||!m.data)return;if(m.data.weather&&m.data.weather.c){WX=m.data.weather;applyWeather()}if(m.data.owner)ownerSetup(m.data.owner)});

// ---- agents: a drone over the building each AI agent is working in. Working = beam into the roof, thinking = circling,
// waiting for you = parked on the sky base, blinking amber. The sky base is a small deck hovering over the city's front
// corner (in the world: each neighborhood's front corner, where nothing stands in front of it), tethered to the ground by
// a thread of light; idle agents park on it as small drones and working ones lift off it to fly to their building. Public pages only get district + state, never what it's doing.
var AG={},AGC={working:'#3DF2FF',thinking:'#B58CFF',waiting:'#FFB020',idle:'#6F7C8F',done:'#6F7C8F'},BREPO={},BDIST={};
for(var bk in tiles){var tb=tiles[bk];if(tb.t!=='b')continue;var bij=bk.split(','),bo={i:+bij[0],j:+bij[1],r:tb.r};if(tb.r.name)BREPO[tb.r.name.toLowerCase()]=bo;(BDIST[tb.d.name]=BDIST[tb.d.name]||[]).push(bo)}
if(D.world)NBS.forEach(function(n){BDIST[n.key]=[];n.ds.forEach(function(d){BDIST[n.key]=BDIST[n.key].concat(BDIST[d.name]||[])})});   // a member's drones only ever fly to their own buildings
var HQI=1.3,HQJ=H-1.3,HQP=iso(HQI,HQJ),HQS=.36;   // Agent HQ: a parking grid on the island's west corner, laid out along the streets
function hqAt(a){var n=D.world&&a&&NBM[a.d];return n?{i:n.ox+n.w+.15,j:n.oy+n.h+.15}:{i:W-.55,j:H-.55}}
var LIFT=46,DOCKMAX=24;   // how high the sky base hovers (px), and how many drones it shows parked before it reads "+n"
function dockAt(a){var hq=hqAt(a);return iso(hq.i,hq.j)}   // the ground point under the sky base
function deckOf(n){return Math.min(36,13+Math.sqrt(Math.min(n,DOCKMAX))*5)}   // deck radius grows with the drones parked on it
function bob(tn){return Math.sin(tn/1600)*1.6}
function hqDims(n){var cols=Math.max(1,Math.ceil(Math.sqrt(n)));return {cols:cols,rows:Math.max(1,Math.ceil(n/cols))}}
function agentsIn(list){var tn=performance.now(),seen={};list.slice(0,80).forEach(function(a){if(!a||!a.id)return;seen[a.id]=1;var g=AG[a.id];
    if(!g){var h0=dockAt(a);g=AG[a.id]={x:h0.x,y:h0.y-40,born:tn,seed:hash(String(a.id))}}g.a=a;g.gone=0});
  for(var id in AG)if(!seen[id]&&!AG[id].gone)AG[id].gone=tn;if(D.world)dirty=true}
function agentSpot(g,tn,slot,nslot){var a=g.a,b=null;
  if(a.state==='working'||a.state==='thinking'){b=(a.repo&&BREPO[String(a.repo).toLowerCase()])||null;if(!b&&a.d&&BDIST[a.d]){var l=BDIST[a.d];b=l[g.seed%l.length]}}
  if(!b){var dk=dockAt(a),n=Math.min(nslot,DOCKMAX),r=deckOf(nslot)*.8,ang=slot*2.39996,rad=r*Math.sqrt((Math.min(slot,DOCKMAX-1)+.5)/n);
    return {x:dk.x+Math.cos(ang)*rad,y:dk.y-LIFT+bob(tn)+Math.sin(ang)*rad*.5-3,roof:null,hq:true,hidden:slot>=DOCKMAX}}
  var p=iso(b.i,b.j),h=bh(b.r),y=p.y-h-24;
  if(a.state==='thinking')return {x:p.x+Math.cos(tn/900+g.seed)*14,y:y+Math.sin(tn/900+g.seed)*7,roof:null};
  return {x:p.x+Math.sin(tn/1300+g.seed)*3,y:y+Math.sin(tn/500+g.seed)*2,roof:p.y-h}}
function drawAgents(c,tn){var ids=Object.keys(AG);if(!ids.length)return;var parked=ids.filter(function(id){var s=AG[id].a.state;return !(s==='working'||s==='thinking')}),k=0;
  // the sky base: one per city (in the world, per neighborhood); its label goes through the world label pass
  var groups={};ids.forEach(function(id){var key=D.world?(AG[id].a.d||''):'';(groups[key]=groups[key]||[]).push(id)});
  Object.keys(groups).forEach(function(key){var gp=groups[key].filter(function(id){return parked.indexOf(id)>=0});if(!gp.length&&D.world)return;
    var g0=dockAt(AG[groups[key][0]].a),r=deckOf(gp.length),cx0=g0.x,cy0=g0.y-LIFT+bob(tn);
    c.save();c.lineCap='round';
    c.fillStyle='rgba(61,242,255,.10)';c.beginPath();c.ellipse(g0.x,g0.y,r*.55,r*.27,0,0,7);c.fill();   // its light on the ground
    c.setLineDash([2,4]);c.strokeStyle='rgba(143,180,232,.45)';c.lineWidth=1;c.beginPath();c.moveTo(g0.x,g0.y);c.lineTo(cx0,cy0+7);c.stroke();c.setLineDash([]);   // tether
    var ug=c.createRadialGradient(cx0,cy0+8,0,cx0,cy0+8,r*1.1);ug.addColorStop(0,'rgba(61,242,255,.28)');ug.addColorStop(1,'rgba(61,242,255,0)');c.fillStyle=ug;c.beginPath();c.ellipse(cx0,cy0+8,r*1.1,r*.6,0,0,7);c.fill();   // underglow
    c.fillStyle='#1B2233';c.beginPath();c.ellipse(cx0,cy0+4,r,r*.5,0,0,7);c.fill();c.fillRect(cx0-r,cy0,r*2,4);   // deck edge (the slab's thickness)
    var dg=c.createLinearGradient(cx0,cy0-r*.5,cx0,cy0+r*.5);dg.addColorStop(0,'#3A4560');dg.addColorStop(1,'#283147');c.fillStyle=dg;c.strokeStyle='rgba(143,180,232,.85)';c.lineWidth=1.2;c.beginPath();c.ellipse(cx0,cy0,r,r*.5,0,0,7);c.fill();c.stroke();   // deck
    c.strokeStyle='rgba(143,180,232,.25)';c.beginPath();c.ellipse(cx0,cy0,r*.62,r*.31,0,0,7);c.stroke();   // landing ring
    c.globalCompositeOperation='lighter';for(var li=0;li<10;li++){var la=li/10*6.283,on=(Math.floor(tn/400)+li)%2===0,lx=cx0+Math.cos(la)*r,ly=cy0+Math.sin(la)*r*.5;c.fillStyle=on?'rgba(61,242,255,.95)':'rgba(61,242,255,.25)';c.beginPath();c.arc(lx,ly,1.3,0,7);c.fill()}   // rim lights
    c.restore();
    if(D.world||!labels)return;
    var nw=gp.filter(function(id){return AG[id].a.state==='waiting'}).length,ni=gp.length-nw;tronPill(c,g0.x,g0.y+16,'SKY BASE'+(ni?' · '+ni+' parked':'')+(nw?' · '+nw+' waiting on you':'')+(gp.length>DOCKMAX?' · +'+(gp.length-DOCKMAX)+' more':''),'#9FC3FF','600 9px ui-monospace,monospace')});
  var slotOf={};Object.keys(groups).forEach(function(key){groups[key].filter(function(id){return parked.indexOf(id)>=0}).forEach(function(id,ix,arr){slotOf[id]=[ix,arr.length]})});
  ids.forEach(function(id){var g=AG[id],a=g.a,sp=agentSpot(g,tn,slotOf[id]?slotOf[id][0]:0,slotOf[id]?slotOf[id][1]:1);
    g.x+=(sp.x-g.x)*.05;g.y+=(sp.y-g.y)*.05;var f=g.gone?Math.max(0,1-(tn-g.gone)/1500):Math.min(1,(tn-g.born)/600);if(f<=0){delete AG[id];return}
    var col=AGC[a.state]||AGC.working,blink=a.state==='waiting'?(.55+.45*Math.abs(Math.sin(tn/380))):(a.state==='idle'||a.state==='done')?.45:1;
    c.save();c.globalAlpha=f;c.globalCompositeOperation='lighter';
    if(sp.roof!=null&&Math.abs(g.x-sp.x)<6){var gb=c.createLinearGradient(0,g.y,0,sp.roof);gb.addColorStop(0,col);gb.addColorStop(1,'rgba(61,242,255,0)');c.fillStyle=gb;c.globalAlpha=f*(.55+.25*Math.sin(tn/160));c.beginPath();c.moveTo(g.x-2,g.y);c.lineTo(g.x+2,g.y);c.lineTo(g.x+9,sp.roof);c.lineTo(g.x-9,sp.roof);c.closePath();c.fill();c.globalAlpha=f}
    if(sp.hq){if(!sp.hidden){var pc=a.state==='waiting'?'#FFB020':'#8FB4E8';c.globalAlpha=f*(a.state==='waiting'?blink:.95);c.strokeStyle=pc;c.lineWidth=1.1;c.shadowColor=pc;c.shadowBlur=a.state==='waiting'?10:3;
      c.beginPath();c.ellipse(g.x,g.y,5,2.2,0,0,7);c.stroke();c.shadowBlur=0;c.fillStyle='#FFFFFF';c.beginPath();c.moveTo(g.x,g.y-3.2);c.lineTo(g.x+2.6,g.y);c.lineTo(g.x,g.y+1.8);c.lineTo(g.x-2.6,g.y);c.closePath();c.fill()}
      c.restore();g.sx=g.x*cam.z+cam.x;g.sy=g.y*cam.z+cam.y;return}
    var sc=1,gl=c.createRadialGradient(g.x,g.y,0,g.x,g.y,22*sc);gl.addColorStop(0,col);gl.addColorStop(1,'rgba(0,0,0,0)');c.globalAlpha=f*.6*blink;c.fillStyle=gl;c.beginPath();c.arc(g.x,g.y,22*sc,0,7);c.fill();c.globalAlpha=f*blink;
    c.strokeStyle=col;c.lineWidth=1.4;c.shadowColor=col;c.shadowBlur=8;c.setLineDash([4,3]);c.lineDashOffset=-tn/40;c.beginPath();c.ellipse(g.x,g.y,11*sc,5.5*sc,0,0,7);c.stroke();c.setLineDash([]);
    c.fillStyle='#FFFFFF';c.beginPath();c.moveTo(g.x,g.y-6*sc);c.lineTo(g.x+5*sc,g.y);c.lineTo(g.x,g.y+3.5*sc);c.lineTo(g.x-5*sc,g.y);c.closePath();c.fill();c.restore();
    g.sx=g.x*cam.z+cam.x;g.sy=g.y*cam.z+cam.y;
    if(labels&&a.label&&!sp.hq&&(cam.z>.55||ids.length<=8))tronPill(c,g.x,g.y-15,a.label,col,'600 9px ui-monospace,monospace')})}
// ---- visitor helicopters: the people who visited this member's profile over the last days. On a member's city they
// replay day by day (oldest first), flying in from the edge to circle the city, and the last two days keep circling;
// in the world they circle each neighborhood, more for more recent visitors. Counts only: who visited is never sent.
var HELIS=[],HPILL=null,HMAX=D.world?90:120;
function heliCenter(key){if(D.world){var n=NBM[key];if(!n)return null;var p=iso(n.ox+n.w/2,n.oy+n.h/2);return {x:p.x,y:p.y-70,r:Math.max(50,(n.w+n.h)*TW/6)}}
  var p0=iso(W/2,H/2);return {x:p0.x,y:p0.y-150,r:Math.max(90,Math.min(320,(W+H)*TW/7))}}
function heliAdd(key,born,stay,seed){if(HELIS.length>=HMAX)return;var c=heliCenter(key);if(!c)return;var a=rnd(seed)*6.283,ed=iso(-6,H*rnd(seed+1));
  HELIS.push({c:c,born:born,stay:stay,seed:seed,ang:a,sp:(.00016+rnd(seed+2)*.00014)*(rnd(seed+3)<.5?-1:1),fx:D.world?c.x+Math.cos(a)*c.r*3:ed.x,fy:D.world?c.y-c.r*2:ed.y-220,rr:c.r*(.55+rnd(seed+4)*.5),alt:rnd(seed+5)*40})}
function heliScale(){return D.world?Math.min(10,Math.max(1,.85/cam.z)):Math.min(2.6,Math.max(1.5,1.1/cam.z))}
function heliPos(h,tn){var age=tn-h.born;if(age<0)return null;var k=Math.min(1,age/2200),e=k<.5?2*k*k:1-Math.pow(-2*k+2,2)/2,ang=h.ang+h.sp*tn,ox=h.c.x+Math.cos(ang)*h.rr,oy=h.c.y-h.alt+Math.sin(ang)*h.rr*.45;
  var x=h.fx+(ox-h.fx)*e,y=h.fy+(oy-h.fy)*e,f=Math.min(1,age/400);if(h.stay&&age>h.stay){var g=Math.min(1,(age-h.stay)/1800);f*=1-g;x+=g*420;y-=g*160}
  return {x:x,y:y,f:f,face:(k<1?(ox>h.fx?1:-1):(-Math.sin(ang)*(h.sp>0?1:-1)>0?1:-1))}}
var HLIV=[['#F3E9D6','#C8B996','#E8A33D'],['#1F2A44','#141C30','#F2C14E'],['#E9EEF4','#B8C2CF','#D9433B'],['#2B2B2E','#18181A','#E8B44A'],['#F4F1EA','#C9C2B2','#2F7DD1']];   // body, belly, stripe
// A helicopter in 3/4 side view, drawn in local units (about 30 wide) and scaled: shaped fuselage with shading and a
// livery stripe, glossy canopy, engine housing, tapered tail with fin, stabilizer and tail-rotor disc, four-blade main
// rotor with a motion-blur disc, skids on struts, nav lights + strobe + beacon, a soft shadow and (some) a searchlight.
// Speed: everything static (body, shading, rotor disc, nav lights, shadow) is painted once per livery and size bucket
// into an offscreen sprite; each frame only blits the sprite and strokes the moving parts (blades, beacon, strobe).
// No gradients or shadowBlur per frame, off-screen helicopters are skipped, tiny ones skip the moving parts.
var HSPR={},HSPRN=0,HX0=-25,HY0=-14,HW=49,HH=66;   // sprite bounds in local units
function heliBody(c,L){c.lineJoin='round';c.lineCap='round';
  c.fillStyle='rgba(0,0,0,.22)';c.beginPath();c.ellipse(0,46,13,3.2,0,0,7);c.fill();   // soft shadow below
  c.fillStyle=L[1];c.beginPath();c.moveTo(-6,-2.6);c.lineTo(-21,-3.4);c.lineTo(-21,-1.6);c.lineTo(-6,1.6);c.closePath();c.fill();
  c.fillStyle=L[0];c.beginPath();c.moveTo(-6,-2.6);c.lineTo(-21,-3.4);c.lineTo(-21,-2.6);c.lineTo(-6,-.6);c.closePath();c.fill();
  c.fillStyle=L[2];c.beginPath();c.moveTo(-18.5,-3.2);c.lineTo(-22.5,-8.6);c.lineTo(-20.6,-8.6);c.lineTo(-17,-3.1);c.closePath();c.fill();   // vertical fin
  c.fillStyle=L[1];c.beginPath();c.moveTo(-17,-1.9);c.lineTo(-19.5,.6);c.lineTo(-18.4,.6);c.lineTo(-15.6,-1.9);c.closePath();c.fill();   // stabilizer
  c.fillStyle='rgba(235,240,248,.28)';c.beginPath();c.ellipse(-21.8,-5.4,.9,3.4,0,0,7);c.fill();   // tail rotor disc
  var fg=c.createLinearGradient(0,-6,0,6);fg.addColorStop(0,L[0]);fg.addColorStop(.55,L[0]);fg.addColorStop(1,L[1]);c.fillStyle=fg;c.strokeStyle='rgba(20,16,10,.65)';c.lineWidth=.7;
  c.beginPath();c.moveTo(-7,-2.8);c.bezierCurveTo(-5,-6.4,4,-6.6,8.5,-3.4);c.bezierCurveTo(11.6,-1.2,11.4,2.6,8.2,4.2);c.bezierCurveTo(4,5.8,-3,5.6,-7,2.2);c.closePath();c.fill();c.stroke();
  c.fillStyle=L[2];c.beginPath();c.moveTo(-6.6,.8);c.bezierCurveTo(-2,2.2,4,2.2,10.2,1.2);c.lineTo(10,2.3);c.bezierCurveTo(4,3.3,-2,3.3,-6.8,1.9);c.closePath();c.fill();   // livery stripe
  c.fillStyle=L[1];c.beginPath();c.moveTo(-4,-5.2);c.bezierCurveTo(-2,-7.4,3,-7.4,4.6,-5.6);c.lineTo(-4,-5.2);c.fill();   // engine housing
  c.fillStyle='#2A2F38';c.beginPath();c.ellipse(-4.6,-5.4,.9,.6,0,0,7);c.fill();   // exhaust
  var cg=c.createLinearGradient(5,-5,11,1);cg.addColorStop(0,'#BFE6FF');cg.addColorStop(.5,'#4E8FC4');cg.addColorStop(1,'#1D3A5A');c.fillStyle=cg;
  c.beginPath();c.moveTo(4.2,-4.6);c.bezierCurveTo(7.6,-4.4,10.4,-2.4,10.6,.4);c.lineTo(5.6,.4);c.closePath();c.fill();
  c.fillStyle='rgba(255,255,255,.75)';c.beginPath();c.moveTo(5.2,-4);c.bezierCurveTo(7,-3.8,8.4,-3,9,-2);c.lineTo(8.2,-1.8);c.bezierCurveTo(7.6,-2.6,6.6,-3.2,5.2,-3.4);c.closePath();c.fill();   // glint
  c.fillStyle='#24486B';c.beginPath();c.roundRect?c.roundRect(-.6,-3.6,4,2.6,.8):c.rect(-.6,-3.6,4,2.6);c.fill();   // side window
  c.strokeStyle='rgba(20,16,10,.5)';c.lineWidth=.45;c.beginPath();c.moveTo(4.4,-4.4);c.lineTo(4.6,3.8);c.stroke();   // door seam
  c.strokeStyle='#2A2F38';c.lineWidth=.9;c.beginPath();c.moveTo(-3.4,4.6);c.lineTo(-4.2,7.4);c.moveTo(4,4.6);c.lineTo(4.6,7.4);c.stroke();   // skids
  c.lineWidth=1.1;c.beginPath();c.moveTo(-7,7.4);c.lineTo(8,7.4);c.quadraticCurveTo(9.6,7.4,10,6.2);c.stroke();
  c.strokeStyle='#2A2F38';c.lineWidth=1;c.beginPath();c.moveTo(0,-6.6);c.lineTo(0,-8.6);c.stroke();   // mast
  c.fillStyle='rgba(225,232,242,.13)';c.beginPath();c.ellipse(0,-8.8,21,3.6,0,0,7);c.fill();   // rotor blur disc
  c.globalCompositeOperation='lighter';c.shadowBlur=5;c.shadowColor='#FF3B30';c.fillStyle='#FF5A50';c.beginPath();c.arc(-.5,4.6,.6,0,7);c.fill();   // nav lights
  c.shadowColor='#38E07B';c.fillStyle='#4CF08D';c.beginPath();c.arc(2.6,4.4,.6,0,7);c.fill()}
function heliSprite(li,R){var key=li+':'+R,s=HSPR[key];if(s)return s;if(HSPRN>60){HSPR={};HSPRN=0}
  s=document.createElement('canvas');s.width=Math.ceil(HW*R);s.height=Math.ceil(HH*R);var g=s.getContext('2d');g.scale(R,R);g.translate(-HX0,-HY0);heliBody(g,HLIV[li]);HSPR[key]=s;HSPRN++;return s}
var HGLOW=null;function heliGlow(){if(HGLOW)return HGLOW;HGLOW=document.createElement('canvas');HGLOW.width=HGLOW.height=32;var g=HGLOW.getContext('2d'),r=g.createRadialGradient(16,16,0,16,16,16);r.addColorStop(0,'rgba(255,255,255,1)');r.addColorStop(.25,'rgba(255,255,255,.55)');r.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=r;g.fillRect(0,0,32,32);return HGLOW}
var HBEAM=null;function heliBeam(){if(HBEAM)return HBEAM;HBEAM=document.createElement('canvas');HBEAM.width=88;HBEAM.height=232;var g=HBEAM.getContext('2d'),sg=g.createLinearGradient(0,0,0,232);sg.addColorStop(0,'rgba(255,240,200,.22)');sg.addColorStop(1,'rgba(255,240,200,0)');g.fillStyle=sg;g.beginPath();g.moveTo(41,0);g.lineTo(47,0);g.lineTo(88,232);g.lineTo(0,232);g.closePath();g.fill();return HBEAM}
function drawHeli(c,x,y,s,tn,seed,face,ps){var li=seed%HLIV.length,k=.62,R=Math.min(8,Math.max(.5,Math.pow(2,Math.round(Math.log2(ps)*3)/3))),spr=heliSprite(li,R),big=ps*30>22;
  c.save();c.translate(x,y);
  if(!D.world&&seed%5===0){var oc=c.globalCompositeOperation;c.globalCompositeOperation='lighter';c.drawImage(heliBeam(),-22*s,4*s,44*s,116*s);c.globalCompositeOperation=oc}   // searchlight
  c.scale(s*k*face,s*k);c.rotate(.07+Math.sin(tn/900+seed)*.02);   // nose-down cruise tilt, gentle bob
  c.drawImage(spr,HX0,HY0,HW,HH);
  if(!big){c.restore();return}
  var tr=Math.cos(tn/22+seed)*3.3,ra=tn/60+seed;c.lineCap='round';c.strokeStyle='rgba(255,255,255,.75)';c.lineWidth=.7;c.beginPath();c.moveTo(-21.8,-5.4-tr);c.lineTo(-21.8,-5.4+tr);c.stroke();   // tail rotor
  c.strokeStyle='rgba(250,252,255,.85)';c.lineWidth=.9;c.beginPath();for(var b=0;b<4;b++){var a=ra+b*1.5708;c.moveTo(0,-8.8);c.lineTo(Math.cos(a)*21,-8.8+Math.sin(a)*3.6)}c.stroke();   // main rotor
  c.fillStyle='#3A3F48';c.fillRect(-1.4,-9.5,2.8,1.4);   // hub
  var on=Math.floor(tn/650+seed)%2===0,st=Math.floor(tn/90+seed*3)%14===0;
  if(on||st){var G=heliGlow();c.globalCompositeOperation='lighter';if(on){c.fillStyle='#FF463C';c.fillRect(-1.6,-7.5,1.2,1.2);c.globalAlpha*=.8;c.drawImage(G,-4.5,-10.4,7,7);c.globalAlpha/=.8}if(st)c.drawImage(G,-26,-7.4,9.2,9.2)}   // beacon, tail strobe
  c.restore()}
function drawHelis(c,tn){if(!HELIS.length)return;var s=heliScale(),ps=s*.62*cam.z*dpr,m=40*s*cam.z,x0=-cam.x/cam.z-m/cam.z,y0=-cam.y/cam.z-m/cam.z,x1=(vw-cam.x)/cam.z+m/cam.z,y1=(vh-cam.y)/cam.z+m/cam.z;
  HELIS=HELIS.filter(function(h){var p=heliPos(h,tn);if(!p)return true;if(p.f<=0&&h.stay&&tn-h.born>h.stay)return false;if(p.f<=0)return true;
    if(p.x<x0||p.x>x1||p.y<y0||p.y>y1)return true;   // off screen
    c.globalAlpha=p.f;drawHeli(c,p.x,p.y,s,tn,h.seed,p.face,ps);return true});c.globalAlpha=1}
function heliPill(t){if(!labels||MINI||!st)return;if(!HPILL){HPILL=document.createElement('div');HPILL.className='c-heli';HPILL.style.cssText='position:absolute;left:50%;top:70px;transform:translateX(-50%);z-index:4;pointer-events:none;font:600 11px/1 ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:.06em;color:#FFD9A0;background:rgba(2,6,12,.86);border:1px solid rgba(255,190,90,.5);border-radius:999px;padding:6px 11px;white-space:nowrap;max-width:calc(100% - 24px);overflow:hidden;text-overflow:ellipsis';HPILL.setAttribute('role','status');HPILL.setAttribute('aria-live','polite');st.appendChild(HPILL)}HPILL.textContent=t;HPILL.style.display=t?'':'none'}
function heliCity(days){if(!Array.isArray(days)||!days.length)return;days=days.slice(-7);var tot=days.reduce(function(s,d){return s+(+d[1]||0)},0);if(!tot)return;
  var lab='\u{1F681} VISITORS · last '+days.length+' days · '+tot,DN=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],t0=performance.now()+1500,per=1000,nd=days.length;
  if(reduce){days.slice(-2).forEach(function(d){for(var k=0;k<Math.min(12,+d[1]||0);k++)heliAdd('',t0-9000,0,hash(d[0]+k)%100000)});heliPill(lab);return}
  days.forEach(function(d,i){var n=Math.min(12,+d[1]||0),keep=i>=nd-2;for(var k=0;k<n;k++)heliAdd('',t0+i*per+k*140,keep?0:3800,hash(d[0]+':'+k)%100000);
    setTimeout(function(){var dt=new Date(d[0]+'T12:00:00Z'),v=+d[1]||0;heliPill('\u{1F681} '+DN[dt.getUTCDay()]+' '+(dt.getUTCMonth()+1)+'/'+dt.getUTCDate()+' · '+v+' visitor'+(v===1?'':'s'))},1500+i*per)});
  setTimeout(function(){heliPill(lab)},1500+nd*per+600)}
function heliWorld(m){if(!m||typeof m!=='object')return;var tn=performance.now();Object.keys(m).sort(function(a,b){return (+m[b]||0)-(+m[a]||0)}).forEach(function(key){var v=+m[key]||0;if(v<=0||!NBM[key])return;
  var n=Math.min(12,Math.max(1,Math.round(Math.log2(1+v)*2)));for(var k=0;k<n;k++)heliAdd(key,reduce?tn-9000:tn+800+rnd(hash(key)+k)*5000,0,(hash(key)+k*7919)%100000)});var tot=Object.keys(m).reduce(function(s,k){return s+(NBM[k]?(+m[k]||0):0)},0);if(tot)heliPill('\u{1F681} helicopters = profile visitors \u00B7 last 3 days \u00B7 '+tot)}
(function(){var u=D.world?'/v1/visits':(HND?'/v1/visits/'+HND:'');if(!u||!window.fetch)return;
  var go=function(){fetch(u).then(function(r){return r.ok?r.json():null}).then(function(j){if(!j)return;if(D.world)heliWorld(j.m);else heliCity(j.days);if(reduce)frame()}).catch(function(){})};   // after first paint; the API is cached 5 min
  setTimeout(function(){window.requestIdleCallback?requestIdleCallback(go,{timeout:2000}):go()},700)})();
// ---- the Underground: the vault under the city. Notes = nodes (size = notes linking in), links = tunnels,
// depth = age, notes about a project sit under its district with roots up into it. Toggle with the Underground button.
var U=D.under||null,under=false,UL=document.createElement('canvas'),uc=UL.getContext('2d'),UP=[],upulse=[],UDIRTY=true;
var UK={concept:'#3DF2FF',entity:'#B58CFF',source:'#4F7BFF',day:'#FF9E3D',garden:'#4FF2A0',note:'#9FB4FF'},UKN={concept:'Concepts',entity:'People & companies',source:'Sources',day:'Daily notes',garden:'Garden (public)',note:'Notes'};
var DROP=0,DSPAN=0;
if(U){DROP=Math.max(140,maxH*.7+70);DSPAN=Math.max(160,(W+H)*TH/2*.45);
  var KA={concept:[.5,.5],entity:[.25,.75],source:[.8,.8],note:[.75,.25],garden:[.5,.18]};
  U.nodes.forEach(function(n,ix){var h1=rnd(hash((n.p||'')+ix)+1),h2=rnd(hash((n.p||'')+ix)+7),b=n.d&&byName[n.d],i,j;
    if(b){i=b.x-.3+h1*(b.k+.6);j=b.y-.3+h2*(b.k+.6)}
    else if(n.k==='day'){var t=1-Math.min(1,n.a/365);i=1+t*(W-2)+(h1-.5)*1.5;j=1+t*(H-2)+(h2-.5)*1.5}
    else{var ka=KA[n.k]||KA.note,ang=h1*6.283,rad=Math.sqrt(h2)*Math.min(W,H)*.2;i=ka[0]*W+Math.cos(ang)*rad;j=ka[1]*H+Math.sin(ang)*rad}
    var age=Math.min(1,Math.log(1+n.a)/Math.log(731)),q=iso(i,j);UP[ix]={x:q.x,y:q.y+DROP+age*DSPAN,r:Math.min(12,1.6+Math.sqrt(n.n)*.9),c:UK[n.k]||UK.note}});
  U.adj=U.nodes.map(function(){return []});U.edges.forEach(function(e){if(U.adj[e[0]]&&U.adj[e[1]]){U.adj[e[0]].push(e[1]);U.adj[e[1]].push(e[0])}});
  U.byPath={};U.nodes.forEach(function(n,ix){if(n.p)U.byPath[n.p]=ix})}
function ustrata(c){var lv=[[7,'this week'],[30,'this month'],[365,'this year'],[2000,'older']];
  lv.forEach(function(l){var age=Math.min(1,Math.log(1+l[0])/Math.log(731)),dy=DROP+age*DSPAN,a=iso(0,0),b=iso(W,0),d=iso(W,H),e2=iso(0,H);
    c.strokeStyle='rgba(181,140,255,.13)';c.lineWidth=1;c.setLineDash([3,6]);c.beginPath();c.moveTo(a.x,a.y+dy);c.lineTo(b.x,b.y+dy);c.lineTo(d.x,d.y+dy);c.lineTo(e2.x,e2.y+dy);c.closePath();c.stroke();c.setLineDash([]);
    c.font='600 9px ui-monospace,monospace';c.fillStyle='rgba(181,140,255,.55)';c.textAlign='right';c.fillText(l[1].toUpperCase(),e2.x-8,e2.y+dy+3);c.textAlign='left'})}
function drawUnder(){var c=uc;c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,UL.width,UL.height);c.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);
  ustrata(c);
  // sediment: the notes not drawn one by one
  var sed=0;for(var sk in U.sediment)sed+=U.sediment[sk];var ns=Math.min(500,Math.round(sed/3)),kinds=Object.keys(U.sediment),acc=0,cum=kinds.map(function(k){acc+=U.sediment[k];return acc});
  for(var z=0;z<ns;z++){var r1=rnd(z*3+1),r2=rnd(z*7+2),r3=rnd(z*11+3),q=iso(r1*W,r2*H),kk=kinds[cum.findIndex(function(v){return v>=r3*acc})]||'note';c.fillStyle=UK[kk]||UK.note;c.globalAlpha=.16;c.fillRect(q.x,q.y+DROP+DSPAN*(.55+r3*.45),1.4,1.4)}
  c.globalAlpha=1;c.globalCompositeOperation='lighter';
  // roots: each district's notes hang from the middle of its block
  blocks.forEach(function(b){var top=iso(b.x+b.k/2-.5,b.y+b.k/2-.5),kids=[];U.nodes.forEach(function(n,ix){if(n.d===b.d.name)kids.push(ix)});if(!kids.length)return;
    kids.sort(function(a,b2){return U.nodes[b2].n-U.nodes[a].n}).slice(0,14).forEach(function(ix){var p=UP[ix],g=c.createLinearGradient(0,top.y,0,p.y);g.addColorStop(0,'rgba(255,255,255,.5)');g.addColorStop(1,'rgba(181,140,255,.05)');
      c.strokeStyle=g;c.lineWidth=1.1;c.beginPath();c.moveTo(top.x,top.y);c.bezierCurveTo(top.x,top.y+(p.y-top.y)*.5,p.x,p.y-(p.y-top.y)*.4,p.x,p.y);c.stroke()});
    c.fillStyle='rgba(255,255,255,.8)';c.beginPath();c.ellipse(top.x,top.y,6,3,0,0,7);c.fill()});
  // tunnels
  c.lineWidth=.8;U.edges.forEach(function(e){var a=UP[e[0]],b=UP[e[1]];if(!a||!b)return;var hi=usel!=null&&(e[0]===usel||e[1]===usel);
    c.strokeStyle=hi?'#FFFFFF':a.c;c.globalAlpha=hi?.85:.14;c.lineWidth=hi?1.4:.8;c.beginPath();c.moveTo(a.x,a.y);c.quadraticCurveTo((a.x+b.x)/2,(a.y+b.y)/2+14,b.x,b.y);c.stroke()});
  c.globalAlpha=1;
  U.nodes.forEach(function(n,ix){var p=UP[ix];if(p.r>3.5){var g=c.createRadialGradient(p.x,p.y,0,p.x,p.y,p.r*2.6);g.addColorStop(0,p.c);g.addColorStop(1,'rgba(0,0,0,0)');c.globalAlpha=.55;c.fillStyle=g;c.beginPath();c.arc(p.x,p.y,p.r*2.6,0,7);c.fill()}
    c.globalAlpha=1;c.fillStyle=p.c;c.beginPath();c.arc(p.x,p.y,p.r*.55,0,7);c.fill();if(ix===usel){c.strokeStyle='#fff';c.lineWidth=1.5;c.beginPath();c.arc(p.x,p.y,p.r+3,0,7);c.stroke()}});
  c.globalCompositeOperation='source-over';
  if(labels){var top=U.nodes.map(function(n,ix){return ix}).filter(function(ix){return U.nodes[ix].t}).sort(function(a,b){return U.nodes[b].n-U.nodes[a].n}).slice(0,cam.z>1.1?40:16);
    var placed=[];c.font='600 9px ui-monospace,monospace';
    top.forEach(function(ix){var n=U.nodes[ix],p=UP[ix],tx=n.t.length>22?n.t.slice(0,21)+'\u2026':n.t,w=c.measureText(tx).width+16,y=p.y-p.r-6,bx=[p.x-w/2,y-18,p.x+w/2,y+2];
      if(placed.some(function(q){return bx[0]<q[2]&&bx[2]>q[0]&&bx[1]<q[3]&&bx[3]>q[1]}))return;placed.push(bx);tronPill(c,p.x,y,tx,UK[n.k]||UK.note,'600 9px ui-monospace,monospace')})}}
var usel=null;
function upulseFrom(ix){if(ix==null||!UP[ix])return;var tn=performance.now();upulse.push({ring:ix,born:tn});(U.adj[ix]||[]).slice(0,10).forEach(function(j,k){upulse.push({a:ix,b:j,born:tn+k*90})})}
function drawUnderLive(c,tn){c.save();c.globalCompositeOperation='lighter';
  U.nodes.forEach(function(n,ix){if(n.m>1)return;var p=UP[ix],pr=((tn/1600)+ix*.13)%1;c.strokeStyle=p.c;c.globalAlpha=(1-pr)*.7;c.lineWidth=1.2;c.beginPath();c.arc(p.x,p.y,p.r+2+pr*10,0,7);c.stroke()});
  upulse=upulse.filter(function(u){return tn-u.born<1800});upulse.forEach(function(u){var t=(tn-u.born)/1400;if(t<0)return;
    if(u.ring!=null){var p=UP[u.ring];c.strokeStyle='#FFFFFF';c.globalAlpha=Math.max(0,1-t);c.lineWidth=2;c.beginPath();c.arc(p.x,p.y,p.r+4+t*26,0,7);c.stroke();return}
    var a=UP[u.a],b=UP[u.b];if(t>1)return;var mx=(a.x+b.x)/2,my=(a.y+b.y)/2+14,x=(1-t)*(1-t)*a.x+2*(1-t)*t*mx+t*t*b.x,y=(1-t)*(1-t)*a.y+2*(1-t)*t*my+t*t*b.y;
    c.globalAlpha=1;c.fillStyle='#FFFFFF';c.beginPath();c.arc(x,y,2,0,7);c.fill()});c.restore()}
var underEl=null;function underPanel(){if(!underEl){underEl=document.createElement('div');underEl.className='c-under'+(st.clientWidth<600?' c-min':'');underEl.setAttribute('role','button');underEl.title='Tap to fold or unfold';st.appendChild(underEl);
    underEl.addEventListener('click',function(ev){if(ev.target.closest&&ev.target.closest('a'))return;underEl.classList.toggle('c-min');var c=underEl.querySelector('.chev');if(c)c.textContent=underEl.classList.contains('c-min')?'\u25B4':'\u25BE'})}underEl.hidden=!under;if(!under)return;
  var ks=['concept','entity','source','day','garden','note'].filter(function(k){return U.nodes.some(function(n){return n.k===k})});
  underEl.innerHTML='<div class="uh"><b>THE UNDERGROUND</b><span class="chev">'+(underEl.classList.contains('c-min')?'\u25B4':'\u25BE')+'</span></div><div>'+U.total.toLocaleString('en-US')+' notes &middot; '+U.links.toLocaleString('en-US')+' links &middot; '+U.orphans+' unconnected'+(U.editedToday?' &middot; '+U.editedToday+' edited today':'')+'</div>'
    +'<div class="lg">'+ks.map(function(k){return '<span><i style="background:'+UK[k]+'"></i>'+UKN[k]+'</span>'}).join('')+'</div><div style="margin-top:4px;color:#A99BD0">Bigger = more notes link to it. Deeper = older. Roots go up to the project the notes are about.</div>'}
function noteCard(ix){var n=U.nodes[ix];usel=ix;UDIRTY=true;var open='';
  if(n.p)open=D.openBase?'<a href="'+e(D.openBase+encodeURIComponent(n.p))+'" target="_blank" rel="noopener">Open in Obsidian &#8599;</a>':'<a href="#" data-open="'+e(n.p)+'">Open note</a>';
  else if(n.g)open='<a href="n/'+e(n.g)+'.html">Read it in the garden &#8599;</a>';
  var ago=function(d){return d<=0?'today':d===1?'yesterday':d<60?d+' days ago':Math.round(d/30)+' months ago'};
  card.classList.remove('is-dir');card.innerHTML='<button class="x" aria-label="Close">&times;</button><h3>'+(n.t?e(n.t):'A note')+'</h3><div class="k" style="color:'+(UK[n.k]||UK.note)+'">'+e(UKN[n.k]||'Note')+(n.d?' &middot; under '+e(n.d):'')+'</div>'
    +'<div class="row"><span>Notes linking here</span><b>'+n.n+'</b></div><div class="row"><span>Links out</span><b>'+n.o+'</b></div>'
    +'<div class="row"><span>Created</span><b>'+ago(n.a)+'</b></div><div class="row"><span>Last edited</span><b>'+ago(n.m)+'</b></div>'
    +(n.t?'':'<p style="margin:6px 0 0">What this note says is private.</p>')+(open?'<p style="margin:8px 0 0">'+open+'</p>':'');
  card.hidden=false;card.querySelector('.x').onclick=function(){usel=null;UDIRTY=true;card.hidden=true};upulseFrom(ix)}
window.addEventListener('message',function(ev){var m=ev.data;if(ev.source===parent&&m&&m.caldera==='note'&&U&&typeof m.p==='string'){var ix=U.byPath[m.p];if(ix!=null){U.nodes[ix].m=0;upulseFrom(ix)}}});
// one car per person on the site right now (private: exact count from the last 5 minutes; public: a coarse level)
function reconcile(){var tn=performance.now(),total=0;blocks.forEach(function(b){var x=LV.d[D.world?(b.rep?b.d.nb:''):b.d.name],want=!x?0:LV.mode==='private'?Math.min(30,+x.now||0):([0,2,4,7,11][+x.level||0]||0);
  if(total+want>120)want=Math.max(0,120-total);total+=want;
  var mine=cars.filter(function(c){return c.b===b&&!c.gone});
  for(var n=mine.length;n<want;n++){var ex=exits(b);if(!ex.length)break;var s0=ex[Math.floor(Math.random()*ex.length)],c={i:s0[0],j:s0[1],ti:s0[0],tj:s0[1],t:1,b:b,born:tn,col:['#F2F2F5','#E85D75','#4FB89A','#E8C547','#7AA7FF'][Math.floor(Math.random()*5)]};step(c);cars.push(c)}
  mine.slice(want).forEach(function(c){c.gone=tn})})}
function fa(c,tn){return c.gone?Math.max(0,1-(tn-c.gone)/1500):c.born?Math.min(1,(tn-c.born)/800):1}
function agentLine(){var n={},ids=Object.keys(AG).filter(function(id){return !AG[id].gone});if(!ids.length)return '';ids.forEach(function(id){var s=AG[id].a.state;n[s]=(n[s]||0)+1});
  return '<div class="q"><span style="color:#fff">AI agents</span> '+['working','thinking','waiting','idle'].filter(function(s){return n[s]}).map(function(s){return '<span style="color:'+AGC[s]+'">'+n[s]+' '+(s==='waiting'?'waiting on you':s)+'</span>'}).join(' &middot; ')+'</div>'}
var liveEl=null;function hud(){if(!liveEl){liveEl=document.createElement('div');liveEl.className='c-live'+(st.clientWidth<600?' c-min':'');liveEl.setAttribute('aria-live','polite');st.appendChild(liveEl);if(typeof todayLine==='function')setTimeout(todayLine,0);
    liveEl.addEventListener('click',function(ev){if(ev.target.closest&&ev.target.closest('.h'))liveEl.classList.toggle('c-min')})}
  var ks=Object.keys(LV.d).filter(function(k){return byName[k]});
  if(LV.mode==='private'){ks.sort(function(a,b){return (LV.d[b].now-LV.d[a].now)||(LV.d[b].views-LV.d[a].views)});var tot=ks.reduce(function(s,k){return s+(+LV.d[k].now||0)},0);
    // busy districts get a row (at most 5); the rest share one quiet line so the panel never needs to scroll
    var busy=ks.filter(function(k){return LV.d[k].now>0||LV.d[k].signups>0||LV.d[k].buys>0}).slice(0,5),quiet=ks.filter(function(k){return busy.indexOf(k)<0});
    liveEl.innerHTML='<div class="h"><i class="dot"></i>LIVE &middot; '+tot+' on your sites now</div>'
     +(ks.length?'':'<div class="s m">No visits yet. Paste a district\'s snippet from Caldera settings &gt; Live traffic on your city into that site.</div>')
     +busy.map(function(k){var x=LV.d[k];return '<div class="r"><span>'+e(k)+'</span><b>'+(+x.now||0)+' now</b></div><div class="s m">'+(+x.views||0).toLocaleString('en-US')+' views'+(x.signups?' &middot; '+x.signups+' signups':'')+(x.buys?' &middot; '+x.buys+' sales':'')+' in 24h</div>'}).join('')
     +agentLine()+(quiet.length?'<div class="q m">Quiet now: '+quiet.map(function(k){return e(k)+' '+(+LV.d[k].views||0)}).join(' &middot; ')+' views in 24h</div>':'')
     +'<div class="lg m" style="margin-top:4px">Each car is someone on that site now.<br><i style="background:'+SCOL+'"></i>signup<i style="background:'+BCOL+'"></i>sale</div>'}
  else{var any=ks.some(function(k){return LV.d[k].level>0});ks.sort(function(a,b){return LV.d[b].level-LV.d[a].level});
    liveEl.innerHTML='<div class="h"><i class="dot"></i>LIVE &middot; '+(any?'people on these sites right now':'quiet right now')+'</div>'+agentLine()
     +ks.filter(function(k){return LV.d[k].level>0}).map(function(k){return '<div class="r"><span>'+e(k)+'</span><b><i class="bar" style="width:'+(LV.d[k].level*14)+'px"></i></b></div>'}).join('')}}
var CL=window.CALDERA_LIVE;function poll(){if(document.hidden)return;fetch(CL.url+(LV.at?(CL.url.indexOf('?')<0?'?':'&')+'since='+encodeURIComponent(LV.at):''),{cache:'no-store'}).then(function(r){return r.ok?r.json():null}).then(onLive).catch(function(){})}
if(CL&&typeof CL.url==='string'){setTimeout(poll,600);setInterval(poll,10000)}
window.addEventListener('message',function(ev){var m=ev.data;if((ev.source===parent||window.CALDERA_MINI===1)&&m&&m.caldera==='live')onLive(m.data)});
function step(car){var o=[[1,0],[-1,0],[0,1],[0,-1]].map(function(d){return [car.ti+d[0],car.tj+d[1]]}).filter(function(n){var t=tiles[n[0]+','+n[1]];return t&&t.t==='r'&&!(n[0]===car.i&&n[1]===car.j)});
  if(!o.length)o=[[car.i,car.j]];var n=o[Math.floor(Math.random()*o.length)];car.i=car.ti;car.j=car.tj;car.ti=n[0];car.tj=n[1];car.t=0}
// ---- palettes: the lighting follows the viewer's clock (Auto: night, dawn, day, dusk, evening, blended), or a phase they pick
var sky='night';night=true;
var PAL={
 day:{sky:['#7FB8EA','#CFE6F7','#EAF4FB'],grass:'#7DBB6E',grass2:'#8CC77C',park:'#6FB262',walk:'#D9D6CE',walkSide:'#B7B2A6',plaza:'#E6E2D8',road:'#5A606B',road2:'#626873',line:'rgba(255,255,255,.75)',water:['#4C9BD6','#3A82BD'],earth:['#8A6A4A','#6E5238'],light:1,win:'rgba(196,224,248,.85)',winOff:'rgba(60,82,110,.55)',lamp:0,shadow:'rgba(30,40,60,.22)',lit:.45},
 dusk:{sky:['#3E3A6E','#C8607A','#F4B26B'],grass:'#5E8F5A',grass2:'#6A9A62',park:'#55854F',walk:'#B9AFA6',walkSide:'#968A80',plaza:'#C7BCB0',road:'#454752',road2:'#4C4E59',line:'rgba(255,226,170,.6)',water:['#5A6FA8','#46568C'],earth:['#6E5040','#55402F'],light:.82,win:'rgba(255,214,140,.92)',winOff:'rgba(48,52,78,.6)',lamp:.6,shadow:'rgba(40,20,50,.28)',lit:.9},
 night:{sky:['#04060E','#0B1020','#18203A'],grass:'#1D3326',grass2:'#21392A',park:'#1A2F22',walk:'#3A3D47',walkSide:'#2A2D35',plaza:'#41444E',road:'#1E222B',road2:'#23272F',line:'rgba(242,200,90,.45)',water:['#13233F','#0D1A30'],earth:['#2B2219','#201912'],light:.5,win:'rgba(255,208,120,.95)',winOff:'rgba(16,20,34,.75)',lamp:1,shadow:'rgba(0,0,0,.35)',lit:1},
  dawn:{sky:['#3A4A7E','#E0899A','#FFCB8E'],grass:'#5F8F62',grass2:'#6B9A6A',park:'#578A58',walk:'#C2B8B0',walkSide:'#9C9088',plaza:'#CFC4B8',road:'#4A4D58',road2:'#51545F',line:'rgba(255,236,200,.6)',water:['#6A80B8','#56689C'],earth:['#73554A','#5A4236'],light:.88,win:'rgba(255,222,165,.85)',winOff:'rgba(70,80,110,.55)',lamp:.3,shadow:'rgba(60,40,80,.32)',lit:.5},
  evening:{sky:['#0B0E2A','#23285A','#4A3F7A'],grass:'#2A4532',grass2:'#304C37',park:'#27412D',walk:'#555463',walkSide:'#3E3E4B',plaza:'#5C5B69',road:'#2A2C38',road2:'#30323E',line:'rgba(250,210,120,.5)',water:['#24335E','#1B284C'],earth:['#3E3028','#2E241D'],light:.62,win:'rgba(255,210,130,.95)',winOff:'rgba(22,26,44,.7)',lamp:.9,shadow:'rgba(0,0,0,.32)',lit:1}};
PAL.grid=PAL.night;var P=PAL.night,phase='night',palKey='';
// Auto: keyframes over the day (minutes after midnight), smoothly blended; the drawing details follow the nearest phase
var DAYKEYS=[[0,'night'],[300,'night'],[390,'dawn'],[510,'day'],[990,'day'],[1095,'dusk'],[1185,'evening'],[1290,'night'],[1440,'night']];
var BASE={night:'night',evening:'night',dawn:'dusk',dusk:'dusk',day:'day'};
var MODES=['auto','grid','dawn','day','dusk','evening','night'],SKYMODE='auto';
try{var sv=localStorage.getItem('caldera-sky');if(sv&&MODES.indexOf(sv)>=0)SKYMODE=sv}catch(err){}
var hm0=location.hash.match(/[#&]sky=([a-z]+)/);if(hm0&&MODES.indexOf(hm0[1])>=0)SKYMODE=hm0[1];
var at0=location.hash.match(/[#&]at=(\d{1,2}):(\d{2})/);   // #at=18:40 shows Auto at that time (for checking the phases)
function rgba(c){if(c.charAt(0)==='#'){var n=parseInt(c.slice(1),16);return [n>>16,n>>8&255,n&255,1]}var m=c.match(/[\d.]+/g)||[0,0,0,1];return [+m[0],+m[1],+m[2],m[3]==null?1:+m[3]]}
function hex2(v){var x=Math.max(0,Math.min(255,Math.round(v))).toString(16);return x.length<2?'0'+x:x}
function lerpCol(a,b,f){var A=rgba(a),B=rgba(b),o=[0,1,2,3].map(function(k){return A[k]+(B[k]-A[k])*f});return o[3]>=.999?'#'+hex2(o[0])+hex2(o[1])+hex2(o[2]):'rgba('+Math.round(o[0])+','+Math.round(o[1])+','+Math.round(o[2])+','+o[3].toFixed(3)+')'}
function blendPal(a,b,f){var o={};for(var k in a){var x=a[k],y=b[k];o[k]=typeof x==='number'?x+(y-x)*f:Array.isArray(x)?x.map(function(v,i){return lerpCol(v,y[i],f)}):lerpCol(x,y,f)}return o}
function phaseNow(){var d=new Date(),m=at0?(+at0[1])*60+(+at0[2]):d.getHours()*60+d.getMinutes()+d.getSeconds()/60;
  for(var i=0;i<DAYKEYS.length-1;i++){var a=DAYKEYS[i],b=DAYKEYS[i+1];if(m>=a[0]&&m<=b[0]){var f=(m-a[0])/((b[0]-a[0])||1);return {a:a[1],b:b[1],f:f*f*(3-2*f)}}}return {a:'night',b:'night',f:0}}
function applySky(){var was=sky,k0=palKey;
  if(SKYMODE==='auto'){var ph=phaseNow();P=ph.a===ph.b?PAL[ph.a]:blendPal(PAL[ph.a],PAL[ph.b],ph.f);phase=ph.f<.5?ph.a:ph.b;sky=BASE[phase];palKey=ph.a+ph.b+Math.round(ph.f*40)}
  else if(SKYMODE==='grid'){sky='grid';P=PAL.night;phase='grid';palKey='grid'}
  else{sky=BASE[SKYMODE];P=PAL[SKYMODE];phase=SKYMODE;palKey=SKYMODE}
  night=sky==='night'||sky==='grid';if(sky!==was&&cars)cars.forEach(function(c){c.trail=[]});if(palKey!==k0){dirty=true;UDIRTY=true}}
applySky();
// ---- Tron mode: black glass, neon edges, a glowing grid floor and light cycles
var NEON={TypeScript:'#3AA8FF',JavaScript:'#FFD23A',Python:'#2BFFC0',HTML:'#FF8A2B',Swift:'#FF3D7F',CSS:'#B07CFF',Shell:'#9BFF4A',Go:'#3DF2FF',Rust:'#FF9F5A',Private:'#CFEFFF'};
var CYAN='#3DF2FF',ORANGE='#FF8A2B',DNEON=['#3DF2FF','#FF8A2B','#C77DFF','#FFD23A','#2BFFC0','#FF3D7F'];
function neon(r){return NEON[r.language]||'#9FB4FF'}
function glowLine(c,pts,col,w,blur,close){c.save();c.strokeStyle=col;c.lineWidth=w;c.shadowColor=col;c.shadowBlur=blur;c.lineJoin='round';c.beginPath();c.moveTo(pts[0][0],pts[0][1]);for(var k=1;k<pts.length;k++)c.lineTo(pts[k][0],pts[k][1]);if(close)c.closePath();c.stroke();c.restore()}
function tronGround(){var c=c1;c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,L1.width,L1.height);c.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);
  var A=corner(-.5,-.5),B=corner(W+.5,-.5),C=corner(W+.5,H+.5),Dd=corner(-.5,H+.5),th=22;
  poly(c,[Dd,C,[C[0],C[1]+th],[Dd[0],Dd[1]+th]],'#03060B');poly(c,[C,B,[B[0],B[1]+th],[C[0],C[1]+th]],'#020409');poly(c,[A,B,C,Dd],'#05080F');
  // floor grid: one line per tile edge, every fourth brighter
  c.save();c.lineWidth=.6;for(var pass=0;pass<2;pass++){c.beginPath();for(var i=0;i<=W+1;i++){if((i%4===0)!==(pass===1))continue;var a=corner(i-.5,-.5),b=corner(i-.5,H+.5);c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1])}
    for(var j=0;j<=H+1;j++){if((j%4===0)!==(pass===1))continue;var a2=corner(-.5,j-.5),b2=corner(W+.5,j-.5);c.moveTo(a2[0],a2[1]);c.lineTo(b2[0],b2[1])}
    c.strokeStyle=pass?'rgba(61,242,255,.45)':'rgba(61,242,255,.14)';c.shadowColor=CYAN;c.shadowBlur=pass?6:0;c.stroke()}c.restore();
  for(var j3=0;j3<=H;j3++)for(var i3=0;i3<=W;i3++){var tt=tiles[i3+','+j3];
    if(water(i3,j3)){poly(c,dia(i3,j3,1.02),'#020D16');var q=iso(i3,j3);c.save();c.globalCompositeOperation='lighter';c.strokeStyle='rgba(61,242,255,.35)';c.lineWidth=1;for(var w=0;w<2;w++){var ox=(rnd(i3*13+j3*7+w)-.5)*TW*.5,oy=(rnd(i3*5+j3*11+w)-.5)*TH*.4;c.beginPath();c.moveTo(q.x+ox-7,q.y+oy);c.lineTo(q.x+ox+7,q.y+oy);c.stroke()}c.restore();continue}
    if(tt.t==='r'){poly(c,dia(i3,j3,1.02),'#070A12');var ri=isRoad(i3-1,j3)||isRoad(i3+1,j3),rj=isRoad(i3,j3-1)||isRoad(i3,j3+1),q2=iso(i3,j3);
      if(ri&&!rj)glowLine(c,[[q2.x-TW*.5,q2.y-TH*.5],[q2.x+TW*.5,q2.y+TH*.5]],'rgba(61,242,255,.75)',1,5);
      else if(rj&&!ri)glowLine(c,[[q2.x+TW*.5,q2.y-TH*.5],[q2.x-TW*.5,q2.y+TH*.5]],'rgba(61,242,255,.75)',1,5);
      else if(ri&&rj){c.fillStyle='rgba(61,242,255,.08)';poly(c,dia(i3,j3,.7));c.fill()}}}
  // the island rim
  glowLine(c,[A,B,C,Dd],'rgba(61,242,255,.9)',1.4,10,true);glowLine(c,[[Dd[0],Dd[1]+th],[C[0],C[1]+th],[B[0],B[1]+th]],'rgba(61,242,255,.35)',1,6);
  // district pads with neon rims in the district's color
  blocks.forEach(function(b,bi){var col=(b.d.label||b.d.name)==='Private'?'#CFEFFF':DNEON[bi%DNEON.length],x0=b.x-.5-.08,y0=b.y-.5-.08,x1=b.x+b.k-.5+.08,y1=b.y+b.k-.5+.08,a=corner(x0,y0),bb=corner(x1,y0),cc=corner(x1,y1),dd=corner(x0,y1);
    poly(c,[a,bb,cc,dd],'#0A1120');glowLine(c,[a,bb,cc,dd],col,1.2,9,true);b.neon=col});
  for(var key in tiles){var t2=tiles[key];if(t2.t!=='h'&&t2.t!=='p')continue;var ij=key.split(','),q3=iso(+ij[0],+ij[1]);c.fillStyle=t2.t==='h'?'#0B1626':'#061510';poly(c,dia(+ij[0],+ij[1],.86));c.fill()}
  // glossy floor: each tower's glow reflected under it
  c.save();c.globalCompositeOperation='lighter';for(var k2 in tiles){var t3=tiles[k2];if(t3.t!=='b')continue;var ij2=k2.split(','),pp=iso(+ij2[0],+ij2[1]),col=t3.r.locked?'#CFEFFF':neon(t3.r);
    var g=c.createRadialGradient(pp.x,pp.y+6,1,pp.x,pp.y+6,TW*.7);g.addColorStop(0,col+'40');g.addColorStop(1,col+'00');c.fillStyle=g;c.beginPath();c.ellipse(pp.x,pp.y+6,TW*.7,TH*.6,0,0,7);c.fill()}c.restore();
}
function tronPrism(c,px,py,w,h,col,litp,seed,locked){var hw=TW/2*w,hh=TH/2*w,L=[[px-hw,py],[px,py+hh],[px,py+hh-h],[px-hw,py-h]],R=[[px,py+hh],[px+hw,py],[px+hw,py-h],[px,py+hh-h]],Tp=[[px,py-hh-h],[px+hw,py-h],[px,py+hh-h],[px-hw,py-h]];
  var g=c.createLinearGradient(0,py-h,0,py+hh);g.addColorStop(0,'#101A2C');g.addColorStop(1,'#060A12');poly(c,L,g);var g2=c.createLinearGradient(0,py-h,0,py+hh);g2.addColorStop(0,'#0A1220');g2.addColorStop(1,'#04070D');poly(c,R,g2);poly(c,Tp,'#0E1A2E');
  // window light strips, floor by floor
  var rows=Math.max(0,Math.floor((h-8)/7));for(var side=0;side<2;side++){var ax=side?px:px-hw,ay=side?py+hh:py,bx=side?px+hw:px,by=side?py:py+hh;
    for(var r=0;r<rows;r++){var on=rnd(seed+r*7.3+side*31.7)<litp,v=6+r*7,u0=.14+rnd(seed+r)*.1,u1=.86-rnd(seed+r*3)*.1;
      c.strokeStyle=on?col:'rgba(160,200,255,.07)';c.globalAlpha=on?(side?.75:.95):1;c.lineWidth=1.3;c.beginPath();c.moveTo(ax+(bx-ax)*u0,ay+(by-ay)*u0-v);c.lineTo(ax+(bx-ax)*u1,ay+(by-ay)*u1-v);c.stroke();c.globalAlpha=1}}
  // neon edges
  glowLine(c,[[px-hw,py],[px,py+hh],[px+hw,py]],col,1,6);glowLine(c,[[px,py+hh],[px,py+hh-h]],col,1.4,10);glowLine(c,[[px-hw,py],[px-hw,py-h]],col,.8,5);glowLine(c,[[px+hw,py],[px+hw,py-h]],col,.8,5);
  glowLine(c,Tp,col,1.2,10,true)}
function tronObjects(){SIGNS=[];var c=c2;c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,L2.width,L2.height);c.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);hits=[];tagHits=[];lamps=[];cranes=[];beacons=[];var tags=[];
  for(var sum=0;sum<=W+H;sum++)for(var i=0;i<=W;i++){var j=sum-i;if(j<0||j>H)continue;var t=tiles[i+','+j],p=iso(i,j);
    if((t.t==='g'&&!water(i,j)&&rnd(i*17+j*29)<.22)||t.t==='p'){// data crystals
      var n=t.t==='p'?3:1;for(var q=0;q<n;q++){var cx0=p.x+(rnd(i*3+q)-.5)*24,cy0=p.y+(rnd(j*5+q)-.5)*10,s=.6+rnd(i+j+q)*.5,col=rnd(i*7+j+q)<.5?'#2BFFC0':CYAN;
        c.fillStyle='rgba(10,30,40,.9)';poly(c,[[cx0,cy0-14*s],[cx0+4*s,cy0-4*s],[cx0,cy0],[cx0-4*s,cy0-4*s]]);c.fill();glowLine(c,[[cx0,cy0-14*s],[cx0+4*s,cy0-4*s],[cx0,cy0],[cx0-4*s,cy0-4*s]],col,.8,6,true)}}
    if(t.t==='h'&&(!BUILDING||buildF(t,i,j)>=1)){var spots=[[-11,-3],[11,-3],[0,-9],[0,4]],blk=null;blocks.forEach(function(b){if(b.d===t.d)blk=b});var hc=blk&&blk.neon||CYAN;
      for(var q2=0;q2<t.n;q2++){var hx=p.x+spots[q2][0],hy=p.y+spots[q2][1],hw=TW/2*.24,hh=TH/2*.24;c.fillStyle='#0A1220';poly(c,[[hx-hw,hy],[hx,hy+hh],[hx+hw,hy],[hx+hw,hy-6],[hx,hy-14],[hx-hw,hy-6]]);c.fill();
        glowLine(c,[[hx-hw,hy-6],[hx,hy-14],[hx+hw,hy-6]],hc,1,6);c.fillStyle=hc;c.globalAlpha=.8;c.fillRect(hx-1,hy-4,2,2);c.globalAlpha=1}}
    if(t.t==='b'){var r=t.r,h=bh(r),dm=dormant(r),seed=hash(r.name||(i+'_'+j)),col=r.kind?(LCOL[r.kind]||'#9FB4FF'):r.locked?'#CFEFFF':dm?'#5A6A80':neon(r);
      var wk=r.weeks&&r.weeks.length?Math.max.apply(null,r.weeks):0,litp=dm?.03:r.locked?(t.d&&t.d.apart?0:r.week?.45:.12):Math.min(.95,.25+(r.week/Math.max(wk,1))*.7);
      var tiers=h>110?[[.78,h*.6],[.62,h*.26],[.46,h*.14]]:h>70?[[.78,h*.72],[.6,h*.28]]:[[.78,h]],base=p.y+4,top=base;
      for(var k=0;k<tiers.length;k++){tronPrism(c,p.x,top,tiers[k][0],tiers[k][1],col,litp,seed+k*101,r.locked);top-=tiers[k][1]}
      if(r.locked){glowLine(c,[[p.x-3,top-6],[p.x-3,top-8],[p.x,top-11],[p.x+3,top-8],[p.x+3,top-6]],col,1.2,6);c.fillStyle=col;c.fillRect(p.x-4,top-6,8,6)}
      if(r===tallest){c.save();c.globalCompositeOperation='lighter';var g=c.createLinearGradient(0,top-260,0,top);g.addColorStop(0,col+'00');g.addColorStop(1,col+'90');c.fillStyle=g;c.fillRect(p.x-2.5,top-260,5,260);c.restore();beacons.push({x:p.x,y:top-4})}
      if(r.week>0&&!dm)cranes.push({x:p.x+4,y:top,seed:seed,col:col});
      var SLt=SFA.get(r);if(SLt&&(!BUILDING||buildF(t,i,j)>=1))SIGNS.push({c:c,x:p.x,base:base,top:top,tiers:tiers,list:SLt,d:t.d,tron:true,LOD:false});
      if(sel===r){var hw2=TW/2*.78,hh2=TH/2*.78;glowLine(c,[[p.x-hw2,base],[p.x,base+hh2],[p.x+hw2,base],[p.x+hw2,top],[p.x,top-TH/2*.46],[p.x-hw2,top]],'#FFFFFF',2/cam.z+.6,16,true)}
      hits.push({r:r,d:t.d,x0:p.x-TW*.42,x1:p.x+TW*.42,y0:top-14,y1:p.y+TH*.45});
      if(labels&&!r.locked&&!r.kind&&(cam.z>1.05||sel===r||(!WORLD&&topSet.indexOf(r)>=0))&&!(t.d&&sel!==r&&String(t.d.name).toLowerCase().replace(/[^a-z0-9]/g,'')===String(r.name).toLowerCase().replace(/[^a-z0-9]/g,'')))tags.push({x:p.x,y:top-(r===tallest?12:8),text:r.name.length>18?r.name.slice(0,17)+'\u2026':r.name,col:col,url:repoUrl(r),r:r})}}
  drawSigns();
  if(SHOPLBL){pill(c,SHOPLBL.x,SHOPLBL.y,SHOPLBL.text,SHOPLBL.bg,'#fff','700 11px IBM Plex Sans,Arial,sans-serif');hits.push({shop:1,x0:SHOPLBL.x-80,x1:SHOPLBL.x+80,y0:SHOPLBL.y-12,y1:SHOPLBL.y+8});SHOPLBL=null}
  if(WORLD){worldLabels(tags);return}
  if(labels){var fT='600 10.5px IBM Plex Mono,monospace',fB='700 10.5px IBM Plex Mono,monospace';fitLabels(c,tags,fT,function(b){return {x:b.x,y:b.y,text:b.d.name.toUpperCase()}},fB,
    function(g){tronPill(c,g.x,g.y,g.text,g.col,fT);tagHit(c,g,fT)},function(b,q){tronPill(c,q.x,q.y,q.text,b.neon||CYAN,fB)})}}
// labels never sit on top of each other: district names and the live counts are placed first, then the selected repo,
// then repo names by size; a repo name that would overlap one already placed waits until you zoom in far enough to fit
function fitLabels(c,tags,fT,blk,fB,drawTag,drawBlk){var placed=[],box=function(x,y,t,f){c.font=f;var w=c.measureText(t).width+14;return [x-w/2-2,y-19,x+w/2+2,y+5]},
  hit=function(q){for(var i=0;i<placed.length;i++){var o=placed[i];if(q[0]<o[2]&&q[2]>o[0]&&q[1]<o[3]&&q[3]>o[1])return true}return false};
  if(LV.mode==='private')Object.keys(LV.d).forEach(function(k){var b=byName[k],x=LV.d[k];if(b&&x&&x.now>0){var f=iso(b.x+b.k,b.y+b.k);placed.push(box(f.x,f.y+18,'\u25CF '+x.now+' live','600 10px ui-monospace,monospace'))}});
  blocks.forEach(function(b){var p2=corner(b.x+b.k-.5+.05,b.y+b.k-.5+.05),q=blk({x:p2[0],y:p2[1]+22,d:b.d});placed.push(box(q.x,q.y,q.text,fB));drawBlk(b,q)});
  tags.slice().sort(function(a,b){return (b.r===sel)-(a.r===sel)||((b.r&&+b.r.commits)||0)-((a.r&&+a.r.commits)||0)}).forEach(function(g){var q=box(g.x,g.y,g.text,fT);if(g.r!==sel&&hit(q))return;placed.push(q);drawTag(g)})}
function tronPill(c,x,y,text,col,font){c.font=font;var tw=c.measureText(text).width,w=tw+14,h=17;c.fillStyle='rgba(2,6,12,.88)';poly(c,[[x-w/2,y-h],[x+w/2,y-h],[x+w/2,y],[x+3,y],[x,y+4],[x-3,y],[x-w/2,y]]);c.fill();
  glowLine(c,[[x-w/2,y-h],[x+w/2,y-h],[x+w/2,y],[x+3,y],[x,y+4],[x-3,y],[x-w/2,y]],col,1,6,true);c.fillStyle=col;c.textAlign='center';c.textBaseline='middle';c.fillText(text,x,y-h/2+.5);c.textBaseline='alphabetic'}
function rgb(hex){var n=parseInt(hex.slice(1),16);return [n>>16,n>>8&255,n&255]}
function hex(c){return '#'+c.map(function(v){v=Math.max(0,Math.min(255,Math.round(v)));return (v<16?'0':'')+v.toString(16)}).join('')}
function mix(h,f,toward){var c=rgb(h);if(toward){var t=rgb(toward);return hex(c.map(function(v,i){return v+(t[i]-v)*f}))}
  if(f>=1)return hex(c.map(function(v){return v+(255-v)*(f-1)}));return hex(c.map(function(v){return v*f}))}
function lit(hex,f){return mix(hex,f*P.light+(f>=1?0:0))}
var tallest=null,second=null;(function(){var all=[];D.districts.forEach(function(d){d.repos.forEach(function(r){all.push(r)})});all.sort(function(a,b){return bh(b)-bh(a)});tallest=all[0];second=all[1]})();
// ---- layers: ground (L1) and objects (L2) are cached; cars, cranes and lights animate on top
var L1=document.createElement('canvas'),L2=document.createElement('canvas'),L3=document.createElement('canvas'),c1=L1.getContext('2d'),c2=L2.getContext('2d'),c3=L3.getContext('2d'),dirty=true,hits=[],sel=null,T=0;
function isRoad(i,j){var t=tiles[i+','+j];return t&&t.t==='r'}
function poly(ctx,pts,fill){ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(var k=1;k<pts.length;k++)ctx.lineTo(pts[k][0],pts[k][1]);ctx.closePath();if(fill){ctx.fillStyle=fill;ctx.fill()}}
function dia(i,j,s){var p=iso(i,j),hw=TW/2*s,hh=TH/2*s;return [[p.x,p.y-hh],[p.x+hw,p.y],[p.x,p.y+hh],[p.x-hw,p.y]]}
function corner(i,j){var p=iso(i,j);return [p.x,p.y]}
function water(i,j){return i===W||j===H}
function drawGround(){var c=c1;c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,L1.width,L1.height);c.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);
  // the island: a diorama slab with earth sides
  var A=corner(-.5,-.5),B=corner(W+.5,-.5),C=corner(W+.5,H+.5),Dd=corner(-.5,H+.5),th=22;
  poly(c,[Dd,C,[C[0],C[1]+th],[Dd[0],Dd[1]+th]],P.earth[0]);poly(c,[C,B,[B[0],B[1]+th],[C[0],C[1]+th]],P.earth[1]);
  poly(c,[A,B,C,Dd],P.grass);
  for(var j=0;j<=H;j++)for(var i=0;i<=W;i++){var t=tiles[i+','+j];
    if(water(i,j)){var g=c.createLinearGradient(0,iso(i,j).y-TH/2,0,iso(i,j).y+TH/2);g.addColorStop(0,P.water[0]);g.addColorStop(1,P.water[1]);poly(c,dia(i,j,1.02),g);
      var q=iso(i,j);c.strokeStyle=sky==='night'?'rgba(140,170,230,.25)':'rgba(255,255,255,.35)';c.lineWidth=1;for(var w=0;w<2;w++){var ox=(rnd(i*13+j*7+w)-.5)*TW*.5,oy=(rnd(i*5+j*11+w)-.5)*TH*.4;c.beginPath();c.moveTo(q.x+ox-6,q.y+oy);c.quadraticCurveTo(q.x+ox,q.y+oy-2,q.x+ox+6,q.y+oy);c.stroke()}continue}
    if(t.t==='w'||t.t==='wp'){poly(c,dia(i,j,1.02),sky==='night'||sky==='evening'?'#6E6556':'#D9CBB0');poly(c,dia(i,j,.8),sky==='night'||sky==='evening'?'#7A7060':'#E6DAC2');continue}
    if(t.t==='g'){if((i*7+j*3)%5===0)poly(c,dia(i,j,.9),P.grass2);continue}
    if(t.t==='r'){poly(c,dia(i,j,1.02),(i+j)%2?P.road:P.road2);
      var ri=isRoad(i-1,j)||isRoad(i+1,j),rj=isRoad(i,j-1)||isRoad(i,j+1),q2=iso(i,j);c.strokeStyle=P.line;c.lineWidth=1.2;c.setLineDash([5,5]);
      if(ri&&!rj){c.beginPath();c.moveTo(q2.x-TW*.25,q2.y-TH*.25);c.lineTo(q2.x+TW*.25,q2.y+TH*.25);c.stroke()}
      else if(rj&&!ri){c.beginPath();c.moveTo(q2.x+TW*.25,q2.y-TH*.25);c.lineTo(q2.x-TW*.25,q2.y+TH*.25);c.stroke()}
      c.setLineDash([]);
      if(ri&&rj){c.fillStyle=sky==='night'?'rgba(255,255,255,.12)':'rgba(255,255,255,.5)';for(var z=-2;z<=2;z++){c.save();c.translate(q2.x,q2.y);c.transform(1,.5,-1,.5,0,0);c.fillRect(-10+z*4,-12,2,5);c.fillRect(-10+z*4,7,2,5);c.restore()}}}
  }
  // blocks: raised sidewalk slabs, then lots
  blocks.forEach(function(b){var x0=b.x-.5-.08,y0=b.y-.5-.08,x1=b.x+b.k-.5+.08,y1=b.y+b.k-.5+.08,a=corner(x0,y0),bb=corner(x1,y0),cc=corner(x1,y1),dd=corner(x0,y1),h=3;
    poly(c,[dd,cc,[cc[0],cc[1]+h],[dd[0],dd[1]+h]],P.walkSide);poly(c,[cc,bb,[bb[0],bb[1]+h],[cc[0],cc[1]+h]],mix(P.walkSide.charAt(0)==='#'?P.walkSide:'#999999',.85));poly(c,[a,bb,cc,dd],P.walk)});
  for(var key in tiles){var t2=tiles[key];if(t2.t!=='b'&&t2.t!=='h'&&t2.t!=='p')continue;var ij=key.split(','),ii=+ij[0],jj=+ij[1];
    if(t2.t==='b')poly(c,dia(ii,jj,.9),P.plaza);
    else if(t2.t==='h'){poly(c,dia(ii,jj,.9),P.grass2);}
    else{poly(c,dia(ii,jj,.9),P.park);var q3=iso(ii,jj);c.strokeStyle=sky==='night'?'rgba(200,190,170,.18)':'rgba(240,232,210,.8)';c.lineWidth=2;c.beginPath();c.moveTo(q3.x-TW*.3,q3.y);c.quadraticCurveTo(q3.x,q3.y-4,q3.x+TW*.3,q3.y);c.stroke()}}
  // soft building shadows, unioned into one path so overlaps don't double-darken (sun from the upper left)
  c.beginPath();for(var k2 in tiles){var t3=tiles[k2];if(t3.t!=='b')continue;var ij2=k2.split(','),pp=iso(+ij2[0],+ij2[1]),hgt=bh(t3.r),hw=TW/2*.78,hh=TH/2*.78,vx=hgt*.62,vy=hgt*.3;
    var pts=[[pp.x-hw,pp.y+4],[pp.x,pp.y+4-hh],[pp.x+vx,pp.y+4-hh+vy],[pp.x+hw+vx,pp.y+4+vy],[pp.x+vx,pp.y+4+hh+vy],[pp.x,pp.y+4+hh]];c.moveTo(pts[0][0],pts[0][1]);for(var m=1;m<pts.length;m++)c.lineTo(pts[m][0],pts[m][1]);c.closePath()}
  c.fillStyle=P.shadow;c.fill('nonzero');
}
// ---- world mode (caldera.social/world): every member is a neighborhood; friendships are highways between them
var WORLD=D.world||null,WFOCUS=null,WHOVER=null;
function blockMid(b){var n=b.nbo;return n?iso(n.ox+n.w/2-.5,n.oy+n.h/2-.5):iso(b.x+b.k/2-.5,b.y+b.k/2-.5)}
function worldCard(b){var key=b.d.nb||b.d.name,m=WORLD.m[key]||{},nn=NBM[key],nrep=nn?nn.ds.reduce(function(s,d){return s+d.repos.length},0):b.d.repos.length;sel=null;
  card.classList.remove('is-dir');card.innerHTML='<button class="x" aria-label="Close">&times;</button><h3>'+e(m.name||key)+'</h3><div class="k">'+e(key)+(m.isNew?' &middot; new this week':'')+(m.groups&&m.groups.length?' &middot; '+m.groups.map(function(g){return e(g)}).join(', '):'')+'</div>'
    +(m.headline?'<p style="margin:6px 0 0">'+e(m.headline)+'</p>':'')
    +'<div class="row"><span>Buildings</span><b>'+nrep+'</b></div>'+(nn&&nn.ds.length>1?'<div class="row"><span>Districts</span><b>'+nn.ds.length+'</b></div>':'')+(m.friends?'<div class="row"><span>Friends</span><b>'+m.friends+'</b></div>':'')
    +'<p style="margin:8px 0 0"><a href="'+e(m.city||'#')+'">Walk into their city &rarr;</a> &middot; <a href="'+e(m.page||'#')+'">Profile</a></p><div class="k" style="margin-top:4px">Click the name again to go in.</div>'+giftHtml(key,'');
  card.hidden=false;card.querySelector('.x').onclick=function(){WFOCUS=null;show(null)};giftWire(function(){worldCard(b)})}
// ---- light-ups: one gift a day to celebrate someone's city (or one of its public repos). It shines on the world map for 24
// hours as searchlights from the gifted building; every extra gift adds a beam, so friends rally to light each other up.
var GC=window.CALDERA_GIFTS||null,GME=null,LIT={};
if(D.world&&GC){fetch(GC.url+'/me',{credentials:'same-origin',cache:'no-store'}).then(function(r){return r.ok?r.json():null}).then(function(j){GME=j}).catch(function(){});
  fetch(GC.url+'/lit',{cache:'no-store'}).then(function(r){return r.ok?r.json():null}).then(function(j){if(j&&j.lit)LIT=j.lit}).catch(function(){})}
function giftHtml(key,repo){if(!D.world||!GC)return'';var L=LIT[key],h=key.replace(/^@/,''),out='<div class="c-gift">';
  if(L&&L.n)out+='<div class="k">&#10022; Lit up today by '+L.by.slice(0,4).map(function(x){return '@'+e(x)}).join(', ')+(L.n>4?' and '+(L.n-4)+' more':'')+'</div>';
  if(!GME)out+='';else if(!GME.member)out+='<a class="c-gift-b" href="/auth/github?back=%2Fworld">&#10022; Sign in to light up '+(repo?'this repo':'their city')+'</a>';
  else if(!GME.listed)out+='<div class="k">List your page in People to light up cities.</div>';
  else if(GME.handle===h)out+=L&&L.n?'':'<div class="k">Friends can light up your city. It glows here for 24 hours.</div>';
  else if((GME.today||[]).indexOf(h)>=0)out+='<div class="k">&#10022; You lit this city up today.</div>';
  else if(GME.left<=0)out+='<div class="k">You\u2019ve given today\u2019s gift'+(GME.max>1?'s':'')+'. New '+(GME.max>1?'ones':'one')+' at midnight Pacific.</div>';
  else out+='<button type="button" class="c-gift-b" data-gift="'+e(key)+'" data-repo="'+e(repo||'')+'">&#10022; Light up '+(repo?'this repo':'their city')+'</button><div class="k">'+GME.left+' gift'+(GME.left===1?'':'s')+' left today &middot; it glows for 24 hours</div>';
  return out+'</div>'}
function giftWire(again){var bt=card.querySelector('[data-gift]');if(!bt)return;bt.onclick=function(){bt.disabled=true;var key=bt.getAttribute('data-gift'),repo=bt.getAttribute('data-repo');
  fetch(GC.url,{method:'POST',credentials:'same-origin',headers:{'content-type':'application/json'},body:JSON.stringify({to:key.replace(/^@/,''),repo:repo})}).then(function(r){return r.json().then(function(j){return{ok:r.ok,j:j}})},function(){return{ok:false,j:{error:'Could not reach Caldera.'}}}).then(function(x){
    if(!x.ok){bt.disabled=false;giftToast(x.j.error||'Could not light it up.');return}GME=x.j;LIT[key]=x.j.lit;giftToast('\u2726 You lit up '+key+'\u2019s city'+(repo?' for '+repo:'')+'. It glows for 24 hours.');again();dirty=true;draw()})}}
function giftToast(m){if(!toasts)return;var t=document.createElement('div');t.className='c-toast';t.textContent=m;toasts.insertBefore(t,toasts.firstChild);setTimeout(function(){if(t.parentNode)t.parentNode.removeChild(t)},5200)}
/** searchlights: one per gift, up to 3, from the gifted buildings (else the tallest), sweeping and crossing */
function drawLit(){if(!D.world)return;var ks=Object.keys(LIT);if(!ks.length)return;var c=cx,tn=performance.now(),amb={day:.55,dawn:.75,dusk:.85,evening:1,night:1.1,grid:1}[sky]||.9;
  c.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);c.save();c.globalCompositeOperation='lighter';
  ks.forEach(function(key){var L=LIT[key],list=BDIST[key];if(!L||!L.n||!list||!list.length)return;var src=[];Object.keys(L.repos||{}).forEach(function(nm){var b=list.filter(function(o){return o.r.name===nm})[0];if(b)src.push(b)});
    if(!src.length)src.push(list.slice().sort(function(a,b2){return bh(b2.r)-bh(a.r)})[0]);var nb=Math.min(3,L.n),sd=hash(key)%97;
    for(var k=0;k<nb;k++){var b=src[k%src.length],p=iso(b.i,b.j),top=p.y-bh(b.r),ang=Math.sin(tn/2600+k*2.1+sd)*.3+(k-(nb-1)/2)*.22,len=340,tx=p.x+Math.sin(ang)*len,ty=top-Math.cos(ang)*len,w=34,nx=Math.cos(ang)*w,ny=Math.sin(ang)*w;
      var g=c.createLinearGradient(p.x,top,tx,ty);g.addColorStop(0,'rgba(255,238,196,'+(.5*amb)+')');g.addColorStop(.6,'rgba(255,226,170,'+(.16*amb)+')');g.addColorStop(1,'rgba(255,226,170,0)');
      c.fillStyle=g;c.beginPath();c.moveTo(p.x-2.5,top);c.lineTo(p.x+2.5,top);c.lineTo(tx+nx,ty+ny);c.lineTo(tx-nx,ty-ny);c.closePath();c.fill();
      var hs=c.createRadialGradient(p.x,top,0,p.x,top,10);hs.addColorStop(0,'rgba(255,248,225,'+(.9*amb)+')');hs.addColorStop(1,'rgba(255,238,196,0)');c.fillStyle=hs;c.beginPath();c.arc(p.x,top,10,0,7);c.fill()}});
  c.restore()}
function worldFocus(b){b=(b.d.nb&&byName[b.d.nb])||b;var m=WORLD.m[b.d.nb||b.d.name]||{};if(WFOCUS===b&&m.city){location.href=m.city;return}WFOCUS=b;
  var c=blockMid(b),z0=cam.z,z1=Math.max(cam.z,Math.min(1.5,vw<600?.75:.9)),x0=cam.x,y0=cam.y,x1=vw/2-c.x*z1,y1=vh/2-c.y*z1+40*z1,t0=performance.now();
  (function anim(){var f=Math.min(1,(performance.now()-t0)/450),k=f<.5?2*f*f:1-Math.pow(-2*f+2,2)/2;cam.z=z0+(z1-z0)*k;cam.x=x0+(x1-x0)*k;cam.y=y0+(y1-y0)*k;draw();if(f<1)requestAnimationFrame(anim)})();
  worldCard(b)}
// ---- new lands: members who joined since this browser last looked at the world get their city built in front of you.
// The camera flies to each new neighborhood and its buildings rise one by one from a foundation, in scaffolding with a
// crane, then light up. Joining while you watch: the live poll sees the member count go up and reloads in place (same
// camera), and the newcomer is built. First visit: this week's newcomers are built so there's always something to see.
var BUILD={},BUILDING=false,BTIMERS=[];
function buildF(t,i,j){var B=BUILD[t.d&&(t.d.nb||t.d.name)];if(!B)return 1;var k=i+','+j,d=B.st[k]||0,du=(B.du&&B.du[k])||1900,f=(T-B.t0-d)/du;return f<=0?0:f>=1?1:f}
// a build is only redrawn every frame while something is actually moving (pending lands sit still as baseplates)
function bActive(){if(INTRO&&T>INTRO)introFinish(false);if(INTRO||SHIM||DUST.length)return true;for(var k in BUILD){var B=BUILD[k];if(T>=B.t0&&T<=B.t0+B.end+600)return true}return false}
// ---- LEGO build: buildings assemble brick by brick (stud-topped bricks drop in with a bounce, dust puffs, a click if
// sound is on), then windows click on and the roof piece snaps on. Used for the first-load city intro and for new lands
// on the world map. Bricks are drawn procedurally; a building is capped at LEGO_MAX courses (big cities use fewer,
// taller courses) so a phone stays smooth.
var INTRO=false,GINTRO=null,SHIM=null,DUST=[],LEGOST={},FOREMAN={},LEGO_MAX=14,lastTick=0;
function ease3(x){return 1-Math.pow(1-x,3)}
function gf(i,j){if(!GINTRO)return 1;var f=(T-GINTRO.t0-(i+j)*GINTRO.step)/260;return f<=0?0:f>=1?1:f}
function gpop(i,j){if(!GINTRO)return 1;var f=(T-GINTRO.t0-(i+j)*GINTRO.step-240)/260;return f<=0?0:f>=1?1:f}
// the island starts as a bare studded baseplate; plates snap down along a diagonal sweep and the roads draw on under them
function groundIntro(c){if(!GINTRO)return;var pc=sky==='night'||sky==='evening'?'#2E5A3A':'#4FA35E';
  for(var j=0;j<=H;j++)for(var i=0;i<=W;i++){if(water(i,j))continue;var f=gf(i,j);if(f>=1)continue;var p=iso(i,j),e=ease3(f),dy=f>0?-(1-e)*9:0,a=f>0?1-e:1;
    c.save();c.globalAlpha=a;poly(c,dia(i,j,1.02),pc);c.translate(0,dy);poly(c,dia(i,j,.96),mix(pc,1.08));studs(c,p.x,p.y,.9,pc);c.restore()}}
function bounce(x){var n=7.5625,d=2.75;if(x<1/d)return n*x*x;if(x<2/d)return n*(x-=1.5/d)*x+.75;if(x<2.5/d)return n*(x-=2.25/d)*x+.9375;return n*(x-=2.625/d)*x+.984375}
function backOut(x){var c1=1.9,c3=c1+1;return 1+c3*Math.pow(x-1,3)+c1*Math.pow(x-1,2)}
function legoN(h){return Math.max(3,Math.min(LEGO_MAX,Math.round(h/7)))}
function clickTick(){var tn=performance.now();if(!sound||tn-lastTick<70)return;lastTick=tn;tone([1700+Math.random()*500],.012)}
function studs(c,px,y,w,col,a){var hw=TW/2*w,hh=TH/2*w,g=w>.66?[-.6,0,.6]:[-.45,.45],rs=hw*(w>.66?.13:.17),sh=Math.max(1.3,rs*.7),top=mix(col,1.25*P.light+(P.light<1?.12:0)),side=mix(col,.8);
  c.save();if(a!=null)c.globalAlpha=a;for(var m=0;m<g.length;m++)for(var n=0;n<g.length;n++){var x=px+(g[m]-g[n])*hw/2,yy=y+(g[m]+g[n])*hh/2;
    c.fillStyle=side;c.beginPath();c.ellipse(x,yy,rs,rs*.5,0,0,Math.PI);c.lineTo(x-rs,yy-sh);c.ellipse(x,yy-sh,rs,rs*.5,0,Math.PI,0,true);c.closePath();c.fill();
    c.fillStyle=top;c.beginPath();c.ellipse(x,yy-sh,rs,rs*.5,0,0,7);c.fill();c.fillStyle='rgba(255,255,255,.35)';c.beginPath();c.ellipse(x-rs*.3,yy-sh-rs*.12,rs*.35,rs*.18,0,0,7);c.fill()}c.restore()}
function seams(c,px,top,w,h,bh,h0){var hw=TW/2*w,hh=TH/2*w;c.save();c.lineWidth=.7;
  for(var b=Math.ceil((h0+.01)/bh);b*bh<h0+h-.01;b++){var y=top-(b*bh-h0);c.strokeStyle='rgba(0,0,0,.22)';c.beginPath();c.moveTo(px-hw,y);c.lineTo(px,y+hh);c.lineTo(px+hw,y);c.stroke();
    c.strokeStyle='rgba(255,255,255,.13)';c.beginPath();c.moveTo(px-hw,y-.8);c.lineTo(px,y+hh-.8);c.lineTo(px+hw,y-.8);c.stroke()}
  c.strokeStyle='rgba(0,0,0,.16)';for(var b2=Math.floor(h0/bh);b2*bh<h0+h;b2++){var y0=top-Math.max(0,b2*bh-h0),y1=top-Math.min(h,(b2+1)*bh-h0);if(y0-y1<1.5)continue;var u=b2%2?.5:.25,u2=b2%2?null:.75;
    [u,u2].forEach(function(uu){if(uu==null)return;c.beginPath();c.moveTo(px-hw+hw*uu,y0+hh*uu);c.lineTo(px-hw+hw*uu,y1+hh*uu);c.moveTo(px+hw*uu,y0+hh-hh*uu);c.lineTo(px+hw*uu,y1+hh-hh*uu);c.stroke()})}c.restore()}
function plate(c,px,y,w,col,a){var hw=TW/2*w,hh=TH/2*w;c.save();c.globalAlpha=a==null?1:a;poly(c,[[px,y-hh],[px+hw,y],[px,y+hh],[px-hw,y]],mix(col,.55,P.grass||'#5a7'));studs(c,px,y,w,mix(col,.55,P.grass||'#5a7'));c.restore()}
function minifig(c,x,y,col,seed){var s=1.3,bob=Math.sin(T/160+seed)*1.2,arm=Math.sin(T/120+seed)*.9;c.save();c.lineCap='round';
  c.fillStyle='#2B3242';c.fillRect(x-2.2*s,y-5*s,1.9*s,5*s);c.fillRect(x+.3*s,y-5*s,1.9*s,5*s);
  c.fillStyle=col;c.beginPath();c.moveTo(x-3*s,y-5*s);c.lineTo(x+3*s,y-5*s);c.lineTo(x+2.4*s,y-10.5*s+bob*.2);c.lineTo(x-2.4*s,y-10.5*s+bob*.2);c.closePath();c.fill();
  c.strokeStyle='#F4C430';c.lineWidth=1.3*s;c.beginPath();c.moveTo(x+2.6*s,y-9.5*s);c.lineTo(x+5.5*s,y-12.5*s-arm*3);c.stroke();
  c.fillStyle='#F4C430';c.fillRect(x-1.9*s,y-14.6*s+bob*.2,3.8*s,4*s);c.fillRect(x-.9*s,y-15.6*s+bob*.2,1.8*s,1.2*s);
  c.fillStyle='#E9A92C';c.beginPath();c.ellipse(x,y-14.8*s+bob*.2,2.6*s,1*s,0,0,7);c.fill();c.fillRect(x-1.8*s,y-16.4*s+bob*.2,3.6*s,1.8*s);
  c.fillStyle=col;c.fillRect(x+4.4*s,y-15*s-arm*3,3*s,2*s);c.restore()}
function drawDust(c){if(!DUST.length)return;var tn=performance.now();DUST=DUST.filter(function(d){return tn-d.born<480});c.save();
  DUST.forEach(function(d){var f=(tn-d.born)/480;c.fillStyle='rgba(235,228,212,'+(.55*(1-f))+')';for(var k=0;k<5;k++){var a=k*1.26+d.s,r=d.w*(.5+f*.9);c.beginPath();c.arc(d.x+Math.cos(a)*r,d.y+Math.sin(a)*r*.5-f*3,1.2+f*2.2,0,7);c.fill()}});c.restore()}
// draws a building that is mid-build and returns the y of its current top
function lego(c,px,base,tiers,h,col,glass,litp,seed,r,f,key,dkey,LOD){var w0=tiers[0][0];
  if(f<=0){plate(c,px,base,w0,col,.9);return base}
  var n=legoN(h),bh=h/n,bf=Math.min(1,f/.8),pl=bf*n,placed=Math.min(n,Math.floor(pl)),q=pl-placed,hc=placed*bh,top=base,acc=0,curW=w0,wf=f<.8?0:Math.min(1,(f-.8)/.14);
  if(!placed)plate(c,px,base,w0,col,1);
  for(var k=0;k<tiers.length;k++){var tw=tiers[k][0],full=tiers[k][1],th=Math.min(full,hc-acc);if(th<=.01)break;prism(c,px,top,tw,th,col);
    if(!LOD){seams(c,px,top,tw,th,bh,acc);if(wf>0)facadeWindows(c,px,top,tw,th,glass,litp*wf,seed+k*101,base,0)}top-=th;acc+=th;curW=tw;if(th<full-.01)break}
  var nw=tiers[tiers.length-1][0],a2=0;for(var k2=0;k2<tiers.length;k2++){if(hc<a2+tiers[k2][1]-.01){nw=tiers[k2][0];break}a2+=tiers[k2][1]}
  if(placed<n){if(!LOD)studs(c,px,top,curW,col);
    var e=bounce(Math.min(1,q*1.15)),dy=-(1-e)*42,sq=q>.55&&q<.8?1-.18*Math.sin((q-.55)/.25*Math.PI):1,hw=TW/2*nw,hh=TH/2*nw;
    c.save();c.fillStyle='rgba(0,0,0,'+(.22*Math.min(1,q*1.4))+')';c.beginPath();c.ellipse(px,top,hw*.85*(.6+.4*q),hh*.85*(.6+.4*q),0,0,7);c.fill();c.restore();
    prism(c,px,top+dy,nw,bh*sq,col);if(!LOD)studs(c,px,top+dy-bh*sq,nw,col)}
  else if(f<.94&&!LOD)studs(c,px,top,curW,col,1-wf*.9);
  var st=LEGOST[key]||(LEGOST[key]={n:0});if(placed>st.n){st.n=placed;if(!LOD&&DUST.length<60)DUST.push({x:px,y:top,born:performance.now(),w:TW/2*nw*.9,s:seed%6});clickTick()}
  if(!LOD&&f<.8&&!FOREMAN[dkey]){FOREMAN[dkey]=1;minifig(c,px-TW/2*w0-5,base+TH/2*w0*.55,col,seed)}
  if(!LOD&&wf>0&&wf<1){var sx=px+((seed%7)/7-.5)*TW/2*nw,sy=top+(base-top)*(.2+((seed>>3)%5)/8),tw2=Math.sin(wf*Math.PI);c.save();c.globalAlpha=tw2;c.fillStyle='#FFF6C8';c.beginPath();c.moveTo(sx,sy-5);c.lineTo(sx+1.2,sy-1.2);c.lineTo(sx+5,sy);c.lineTo(sx+1.2,sy+1.2);c.lineTo(sx,sy+5);c.lineTo(sx-1.2,sy+1.2);c.lineTo(sx-5,sy);c.lineTo(sx-1.2,sy-1.2);c.closePath();c.fill();c.restore()}
  if(!LOD&&f>=.94){var rf=Math.min(1,(f-.94)/.06);c.save();c.translate(0,-(1-backOut(rf))*12);roofProps(c,px,top,curW,r,seed);c.restore()}
  return top}
function scaffold(c,x,base,top,tw,f){var hw=TW/2*tw*.92,hh=TH/2*tw*.92;c.save();c.globalAlpha=Math.min(1,(1-f)*3);c.strokeStyle='rgba(255,196,92,.9)';c.lineWidth=1.1/Math.max(cam.z,.3);
  c.beginPath();for(var y=base;y>top-6;y-=9){c.moveTo(x-hw,y);c.lineTo(x,y+hh);c.lineTo(x+hw,y)}c.moveTo(x-hw,base);c.lineTo(x-hw,top-6);c.moveTo(x+hw,base);c.lineTo(x+hw,top-6);c.moveTo(x,base+hh);c.lineTo(x,top+hh-6);c.stroke();
  c.fillStyle='rgba(255,236,170,'+(.9*(1-f))+')';for(var k=0;k<3;k++){var a=(T/180+k*2.1)%6.28;c.beginPath();c.arc(x+Math.cos(a)*hw*.8,top-4+Math.sin(a*1.3)*3,1.6,0,7);c.fill()}c.restore()}
function nbTiles(key){var out=[];for(var k in tiles){var t=tiles[k];if((t.t==='b'||t.t==='h')&&t.d&&(t.d.nb||t.d.name)===key)out.push(k)}return out}
function legoDur(t){return t&&t.t==='b'&&t.r&&!t.r.kind?Math.min(1500,620+legoN(bh(t.r))*62):700}
function buildStart(key,now){var ks=nbTiles(key),mn=1e9;ks.forEach(function(k){var a=k.split(',');mn=Math.min(mn,+a[0]+ +a[1])});var st={},du={},end=0;
  ks.forEach(function(k,n){var a=k.split(','),d=400+(+a[0]+ +a[1]-mn)*200+rnd(n*7+3)*220,u=legoDur(tiles[k]);st[k]=d;du[k]=u;end=Math.max(end,d+u)});LEGOST={};BUILD[key]={t0:now,st:st,du:du,end:end};BUILDING=true;draw();return end}
// first load of a city page: baseplate, then every district assembles brick by brick (busiest district first), windows
// click on, roofs snap on, a shimmer sweeps the skyline. About 3.5-4.5s; any click, drag, scroll or key skips it.
function cityIntro(){if(reduce||D.world||sky==='grid'||!blocks.length)return;var t0=performance.now()+150,nb=0;
  for(var k in tiles)if(tiles[k].t==='b')nb++;LEGO_MAX=nb>80?5:nb>45?7:nb>25?10:14;
  GINTRO={t0:t0,step:Math.min(28,620/Math.max(1,W+H))};var gEnd=620+260;
  var ds=blocks.map(function(b){var sc=0;(b.d.repos||[]).forEach(function(r){sc+=(+r.week||0)*20+(+r.commits||0)});return {key:b.d.nb||b.d.name,sc:sc}}).sort(function(a,b){return b.sc-a.sc});
  var stag=Math.min(300,1300/Math.max(1,ds.length)),plan=[],raw=0;
  ds.forEach(function(x,di){var ks=nbTiles(x.key).filter(function(k){return tiles[k].t==='b'});ks.sort(function(a,b){var p=a.split(','),q=b.split(',');return (+p[0]+ +p[1])-(+q[0]+ +q[1])});
    var gap=Math.min(150,900/Math.max(1,ks.length)),pl={key:x.key,st:{},du:{}};ks.forEach(function(k,n){var d=di*stag+n*gap,u=legoDur(tiles[k]);pl.st[k]=d;pl.du[k]=u;raw=Math.max(raw,d+u)});plan.push(pl)});
  var sc=Math.min(1,3300/Math.max(1,raw)),bStart=t0+gEnd-200,endAll=0;
  plan.forEach(function(pl){var end=0;for(var k in pl.st){pl.st[k]*=sc;pl.du[k]=Math.max(420,pl.du[k]*Math.max(sc,.6));end=Math.max(end,pl.st[k]+pl.du[k])}BUILD[pl.key]={t0:bStart,st:pl.st,du:pl.du,end:end};endAll=Math.max(endAll,end)});
  INTRO=bStart+endAll+80;BUILDING=true;LEGOST={}}
function introFinish(skipped){if(!INTRO)return;INTRO=false;GINTRO=null;LEGO_MAX=14;BTIMERS.forEach(clearTimeout);BTIMERS=[];BUILD={};BUILDING=false;LEGOST={};DUST=[];if(!skipped)SHIM={t0:performance.now()};dirty=true;draw()}
['pointerdown','wheel','keydown'].forEach(function(ev){(ev==='keydown'?window:cv).addEventListener(ev,function(){if(INTRO)introFinish(true)},{passive:true})});
function drawShimmer(){if(!SHIM)return;var f=(performance.now()-SHIM.t0)/900;if(f>=1){SHIM=null;return}var w=cv.width,h=cv.height;
  c3.setTransform(1,0,0,1,0,0);c3.globalCompositeOperation='source-over';c3.clearRect(0,0,w,h);c3.drawImage(L2,0,0);c3.globalCompositeOperation='source-atop';
  var x=(f*1.5-.25)*w,g=c3.createLinearGradient(x-w*.07,h*.1,x+w*.07,h*.3);g.addColorStop(0,'rgba(255,255,255,0)');g.addColorStop(.5,'rgba(255,250,225,.6)');g.addColorStop(1,'rgba(255,255,255,0)');
  c3.fillStyle=g;c3.fillRect(0,0,w,h);c3.globalCompositeOperation='source-over';cx.save();cx.setTransform(1,0,0,1,0,0);cx.globalCompositeOperation='lighter';cx.globalAlpha=.32*Math.sin(f*Math.PI);cx.drawImage(L3,0,0);cx.restore()}
function flyTo(x1,y1,z1,ms,done){var z0=cam.z,x0=cam.x,y0=cam.y,t0=performance.now();(function anim(){var f=Math.min(1,(performance.now()-t0)/ms),k=f<.5?2*f*f:1-Math.pow(-2*f+2,2)/2;
  cam.z=z0+(z1-z0)*k;cam.x=x0+(x1-x0)*k;cam.y=y0+(y1-y0)*k;draw();if(f<1)requestAnimationFrame(anim);else if(done)done()})()}
var buildBar=null;function buildNote(html){if(!buildBar){buildBar=document.createElement('div');buildBar.setAttribute('role','status');
  buildBar.style.cssText='position:absolute;left:50%;'+(vw<600?'top:52px;width:calc(100% - 24px);justify-content:space-between;':'bottom:18px;')+'transform:translateX(-50%);z-index:6;display:flex;gap:10px;align-items:center;max-width:calc(100% - 24px);padding:9px 10px 9px 14px;border-radius:12px;background:rgba(10,12,22,.9);border:1px solid #8B6CF6;box-shadow:0 0 22px rgba(139,108,246,.45);color:#fff;font:600 12.5px/1.35 IBM Plex Sans,Arial,sans-serif';
  st.appendChild(buildBar)}buildBar.innerHTML=html;var sk=buildBar.querySelector('button');if(sk)sk.onclick=buildSkip}
function buildDone(){BTIMERS.forEach(clearTimeout);BTIMERS=[];for(var k in BUILD)BUILD[k].t0=-1e9;BUILDING=false;BUILD={};LEGOST={};DUST=[];draw();if(buildBar){buildBar.remove();buildBar=null}}
function buildSkip(){var h=BHOME;buildDone();if(h)flyTo(h.x,h.y,h.z,500)}
var BHOME=null;
function buildLands(keys){keys=keys.filter(function(k){return byName[k]&&nbTiles(k).length});if(!keys.length)return;
  if(reduce){keys.forEach(function(k){var b=byName[k];if(b)pulse(b,SCOL,true)});return}
  BHOME={x:cam.x,y:cam.y,z:cam.z};var n=keys.length,i=0,e=function(v){return String(v).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})};
  function next(){if(i>=n){var h=BHOME;BTIMERS.push(setTimeout(function(){buildDone();if(h)flyTo(h.x,h.y,h.z,900)},600));return}
    var k=keys[i++],b=byName[k],m=WORLD.m[k]||{},c=blockMid(b),z=Math.min(1.4,vw<600?.85:1.05);
    buildNote('<span style="color:#C4B5FF">✦</span><span>'+(n>1?(vw<600?'New land '+i+'/'+n+': ':'New land '+i+' of '+n+': '):'New land: ')+'<b>'+e(m.name||k)+'</b> joined. Building their city…</span><button type="button" style="all:unset;cursor:pointer;padding:4px 10px;border-radius:8px;border:1px solid rgba(255,255,255,.25);font-weight:600">Skip</button>');
    flyTo(vw/2-c.x*z,vh/2-c.y*z+40*z,z,1100,function(){var dur=buildStart(k,performance.now());pulse(b,'#8B6CF6',true);
      BTIMERS.push(setTimeout(function(){pulse(b,SCOL,true);BTIMERS.push(setTimeout(next,900))},dur))})}
  next()}
(function(){if(!WORLD)return;var KEY='caldera.world.seen',all=Object.keys(WORLD.m),seen=null;
  try{var v=JSON.parse(localStorage.getItem(KEY)||'null');if(v&&Array.isArray(v.k))seen=v.k}catch(e){}
  var fresh=seen?all.filter(function(k){return seen.indexOf(k)<0}):all.filter(function(k){return WORLD.m[k].isNew}).slice(-6);
  try{localStorage.setItem(KEY,JSON.stringify({k:all,at:Date.now()}))}catch(e){}
  if(!reduce)fresh.slice(-12).forEach(function(k){if(byName[k]&&nbTiles(k).length){BUILD[k]={t0:Infinity,st:{},du:{},end:0};BUILDING=true}});
  var cam0=null;try{cam0=JSON.parse(sessionStorage.getItem('caldera.world.cam')||'null');sessionStorage.removeItem('caldera.world.cam')}catch(e){}
  setTimeout(function(){if(cam0&&isFinite(cam0.z)){cam.x=cam0.x;cam.y=cam0.y;cam.z=cam0.z;draw()}if(fresh.length)setTimeout(function(){buildLands(fresh.slice(-12))},cam0?300:1400)},60)})();
// someone joined while you're watching: reload in place (same camera) so their land is built (at most once a minute)
function worldGrew(n){if(!WORLD||!(n>Object.keys(WORLD.m).length)||BUILDING)return;try{var last=+sessionStorage.getItem('caldera.world.reload')||0;if(Date.now()-last<60000)return;
  sessionStorage.setItem('caldera.world.reload',String(Date.now()));sessionStorage.setItem('caldera.world.cam',JSON.stringify(cam))}catch(e){return}location.reload()}
// world labels: drawn last, in screen space, so they stay readable at any zoom. Level of detail, not "everything at once":
// every candidate gets a rank (the focused or hovered neighborhood, then you, then your friends, then the liveliest:
// lit today, agents working, commits this week, new), and labels are placed greedily by rank. One that would overlap a
// placed label is dropped (only the focused/hovered/your own name may slide a little to find room), and "smart" mode
// caps the count by stage area, so a phone shows a handful and zooming in reveals more as neighborhoods spread apart.
// Districts, agent pads and repo names join from mid zoom and compete for the same budget.
var LMODES=['smart','all','off'],LMODE='smart';try{var lm0=localStorage.getItem('caldera-world-labels');if(LMODES.indexOf(lm0)>=0)LMODE=lm0}catch(err){}
if(WORLD&&!MINI)labels=LMODE!=='off';
var WME=null,WFR=null,WSCORE=null,WSCORE_T=0;
function worldMe(){if(WME!==null)return WME;WME='';try{var a=document.querySelector('#caldera-bar .ch-acct');var m=a&&/@([a-z0-9-]+)/i.exec(a.getAttribute('aria-label')||'');if(m)WME='@'+m[1].toLowerCase()}catch(err){}return WME}
function worldFriends(){if(WFR)return WFR;WFR={};var me=worldMe();if(me)(WORLD.links||[]).forEach(function(l){if(l[2]===1||l[2]===4)return;if(l[0]===me)WFR[l[1]]=1;else if(l[1]===me)WFR[l[0]]=1});return WFR}
// liveliness, recomputed at most every 5s (light-ups and agents change while the page is open)
function worldScores(){var t=performance.now();if(WSCORE&&t-WSCORE_T<5000)return WSCORE;WSCORE_T=t;WSCORE={};var ag={};
  Object.keys(AG).forEach(function(id){var a=AG[id].a;if(a&&a.d&&!AG[id].gone&&(a.state==='working'||a.state==='thinking'))ag[a.d]=(ag[a.d]||0)+1});
  NBS.forEach(function(n){var wk=0,cm=0;n.ds.forEach(function(d){(d.repos||[]).forEach(function(r){wk+=+r.week||0;cm+=+r.commits||0})});var wm=WORLD.m[n.key]||{};
    WSCORE[n.key]=(LIT[n.key]&&LIT[n.key].n?40+5*LIT[n.key].n:0)+(ag[n.key]?30+5*ag[n.key]:0)+Math.min(30,6*Math.log(1+wk))+Math.min(10,Math.log(1+cm))+(wm.isNew?8:0)+Math.min(6,+wm.friends||0)});return WSCORE}
function nbTop(n){if(n._ty==null){var ty=Infinity;n.ds.forEach(function(d){(BDIST[d.name]||[]).forEach(function(o){ty=Math.min(ty,iso(o.i,o.j).y-bh(o.r))})});
  var m=iso(n.ox+n.w/2-.5,n.oy+n.h/2-.5);n._tx=m.x;n._ty=isFinite(ty)?ty-10:iso(n.ox-.5,n.oy-.5).y-10}return {x:n._tx,y:n._ty}}
function worldLabels(tags){var c=c3;c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,L3.width,L3.height);if(!labels){WLAB=[];return}c.setTransform(dpr,0,0,dpr,0,0);
  var z=cam.z,S=function(x,y){return [x*z+cam.x,y*z+cam.y]},foc=WFOCUS?(WFOCUS.d.nb||WFOCUS.d.name):null,cand=[],placed=[],me=worldMe(),fr=worldFriends(),sc=worldScores(),phone=vw<600;
  NBS.forEach(function(n){var wm=WORLD.m[n.key]||{},t=nbTop(n),sp=S(t.x,t.y),k=n.key,pr=k===foc?0:k===WHOVER?.3:k===me?.6:fr[k]?.8:1;
    cand.push({pr:pr,sc:sc[k]||0,x:sp[0],y:sp[1],text:(phone&&k.length>22?k.slice(0,21)+'…':k)+(wm.isNew?(phone?' ✦':' ✦ new'):'')+(LIT[k]&&LIT[k].n?'  ✦ lit'+(LIT[k].n>1?' ×'+LIT[k].n:''):''),bg:wm.isNew?'rgba(46,170,120,.95)':k===me?'rgba(109,74,232,.98)':'rgba(139,108,246,.96)',fg:'#fff',font:phone?'700 11.5px IBM Plex Sans,Arial,sans-serif':'700 13px IBM Plex Sans,Arial,sans-serif',block:n.rep})});
  if(z>=.55)blocks.forEach(function(b){var p2=corner(b.x+b.k-.5+.05,b.y+b.k-.5+.05),sp=S(p2[0],p2[1]);cand.push({pr:(b.d.nb===foc?1.5:2),sc:0,x:sp[0],y:sp[1]+20,text:b.d.label||b.d.name,bg:'rgba(26,22,44,.9)',fg:'#E6DEFF',font:'600 11px IBM Plex Sans,Arial,sans-serif',block:byName[b.d.nb]||b})});
  if(z>=.55){var per={};Object.keys(AG).forEach(function(id){var a=AG[id].a;if(!a||!a.d||AG[id].gone)return;var q=per[a.d]=per[a.d]||{w:0,p:0};if(a.state==='working'||a.state==='thinking')q.w++;else q.p++});
    Object.keys(per).forEach(function(k){if(!NBM[k])return;var hb=dockAt({d:k}),sp=S(hb.x,hb.y),q=per[k];
      cand.push({pr:1.9,sc:0,x:sp[0],y:sp[1]+18,text:k+'’s agents'+(q.w?' · '+q.w+' working':'')+(q.p?' · '+q.p+' parked':''),bg:'rgba(48,34,6,.9)',fg:'#FFC24A',font:'600 10px IBM Plex Mono,ui-monospace,monospace'})})}
  if(SHOP&&SHOP.big){var mq=iso(SHOP.i+1,SHOP.j+1),msp=S(mq.x,mq.y-30);cand.push({pr:.5,sc:0,x:msp[0],y:msp[1],text:'\u2726 Free tools market \u00b7 '+TOOLS.length,bg:'rgba(201,139,78,.97)',fg:'#fff',font:phone?'700 11.5px IBM Plex Sans,Arial,sans-serif':'700 13px IBM Plex Sans,Arial,sans-serif',shop:1})}
  tags.forEach(function(g){var sp=S(g.x,g.y);cand.push({pr:3,sc:0,x:sp[0],y:sp[1],text:g.text,bg:'rgba(17,20,32,.88)',fg:'#F2F2F5',font:'600 10.5px IBM Plex Sans,Arial,sans-serif',url:g.url})});
  cand.sort(function(a,b){return a.pr-b.pr||b.sc-a.sc});WLAB=placed;
  // budget: one label per ~40,000px² of stage in smart mode (about 6 on a phone, 20 on a laptop); the must-shows never count
  // zooming in spreads neighborhoods apart, so the budget grows with zoom (up to 4x) and collisions decide the rest
  var cap=LMODE==='all'?Infinity:Math.round(Math.max(4,vw*vh/40000)*Math.max(1,Math.min(4,FITZ?z/FITZ:1))),used=0,M=5;
  var hitAny=function(q){for(var i=0;i<placed.length;i++){var o=placed[i];if(q.x0<o.x1+M&&q.x1+M>o.x0&&q.y0<o.y1+M&&q.y1+M>o.y0)return true}return false};
  cand.forEach(function(g){var must=g.pr<.7;if(!must&&used>=cap)return;c.font=g.font;var w=c.measureText(g.text).width+12,bx={x0:g.x-w/2-3,x1:g.x+w/2+3,y0:g.y-20,y1:g.y+5};
    if(bx.x1<0||bx.x0>vw||bx.y1<0||bx.y0>vh)return;
    {var sh=Math.max(0,6-bx.x0)-Math.max(0,bx.x1-(vw-6));if(sh){bx.x0+=sh;bx.x1+=sh;g.x+=sh}}   // a name near the edge slides in instead of vanishing
    if(hitAny(bx)){if(!must)return;var offs=[],ok=false;[26,52].forEach(function(dy){[0,-.5,.5].forEach(function(fx){offs.push([w*fx,-dy]);offs.push([w*fx,dy])})});
      for(var oi=0;oi<offs.length&&!ok;oi++){var ox=offs[oi][0],q={x0:bx.x0+ox,x1:bx.x1+ox,y0:bx.y0+offs[oi][1],y1:bx.y1+offs[oi][1]};var s2=Math.max(0,6-q.x0)-Math.max(0,q.x1-(vw-6));q.x0+=s2;q.x1+=s2;ox+=s2;   // stay inside the stage
        if(q.y0<4||q.y1>vh-4)continue;if(!hitAny(q)){bx=q;g.x+=ox;g.y+=offs[oi][1];ok=true}}if(!ok)return}
    if(!must)used++;bx.text=g.text;bx.pr=g.pr;placed.push(bx);
    pill(c,g.x,g.y,g.text,g.bg,g.fg,g.font);
    if(g.url||g.block||g.shop)tagHits.push({x0:(bx.x0-cam.x)/z,x1:(bx.x1-cam.x)/z,y0:(bx.y0-cam.y)/z,y1:(bx.y1-cam.y)/z,url:g.url,block:g.block,shop:g.shop})})}
// friendships as rays of light: soft glowing arcs in the sky between two neighborhoods, light motes travelling along
// them. Real friendships glow warm violet, people who work on the same repo glow code-teal, GitHub follows sky-blue; the
// founder's welcome links are faint and thin. Dimmer by day. Links are [a, b, kind, why]: 0 request/invite, 1 founder,
// 2 shared repo, 3 GitHub follow, 4 same stack (not a friendship: dashed coral, their public repos share uncommon packages).
var WLAB=[],RAYS=true;try{RAYS=localStorage.getItem('caldera-world-rays')!=='0'}catch(err){}
// Color by topic: tint each neighborhood's ground by its member's top "what they're building" tag; the legend names every
// color, so the tint is never the only cue
var TOPICS=false,TCOL={};try{TOPICS=localStorage.getItem('caldera-world-topics')==='1'}catch(err){}
if(WORLD)(WORLD.topics||[]).forEach(function(x){TCOL[x.t]=x.c});
function drawTopics(){if(!WORLD||!TOPICS)return;var c=cx;c.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);
  NBS.forEach(function(n){var m=WORLD.m[n.key]||{},col=m.tag?(TCOL[m.tag]||'#94A3B8'):null;if(!col)return;
    var a=iso(n.ox-.9,n.oy-.9),b=iso(n.ox+n.w+.1,n.oy-.9),d=iso(n.ox+n.w+.1,n.oy+n.h+.1),e=iso(n.ox-.9,n.oy+n.h+.1);
    c.beginPath();c.moveTo(a.x,a.y+TH/2);c.lineTo(b.x,b.y+TH/2);c.lineTo(d.x,d.y+TH/2);c.lineTo(e.x,e.y+TH/2);c.closePath();
    c.globalAlpha=.32;c.fillStyle=col;c.fill();c.globalAlpha=.85;c.lineWidth=2/cam.z;c.strokeStyle=col;c.stroke();c.globalAlpha=1})}
function topicLegend(){var L=document.getElementById('w-topics');if(!WORLD)return;if(!L){L=document.createElement('div');L.id='w-topics';L.className='w-topics';L.setAttribute('role','note');L.setAttribute('aria-label','Color by topic');st.appendChild(L)}
  L.hidden=!TOPICS;if(!TOPICS)return;var ts=WORLD.topics||[];L.innerHTML='';var h=document.createElement('b');h.textContent=ts.length?'What they\u2019re building':'No topics yet';L.appendChild(h);
  ts.forEach(function(x){var r=document.createElement('span');var sw=document.createElement('i');sw.style.background=x.c;r.appendChild(sw);r.appendChild(document.createTextNode(x.t+' \u00b7 '+x.n));L.appendChild(r)});
  var o=document.createElement('span');var so=document.createElement('i');so.style.background='#94A3B8';o.appendChild(so);o.appendChild(document.createTextNode('Other'));if(ts.length)L.appendChild(o)}
function drawRays(){if(!WORLD||!RAYS)return;var ls=WORLD.links||[];if(!ls.length)return;var c=cx,tn=performance.now(),foc=WFOCUS?(WFOCUS.d.nb||WFOCUS.d.name):WHOVER;
  var amb={day:.5,dawn:.75,dusk:.8,evening:1,night:1.1,grid:1}[sky]||.9;c.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
  ls.forEach(function(l,ix){var na=NBM[l[0]],nb=NBM[l[1]];if(!na||!nb)return;var p=nbTop(na),q=nbTop(nb),d=Math.hypot(q.x-p.x,q.y-p.y),mx=(p.x+q.x)/2,my=Math.min(p.y,q.y)-40-d*.28;
    var fd=l[2]===1,rp=l[2]===2,gf=l[2]===3,sk=l[2]===4,hit=foc&&(l[0]===foc||l[1]===foc),k=amb*(foc?(hit?1.7:.22):1)*(fd?.35:1);if(k<=.02)return;
    var col=fd?'159,180,255':rp?'90,230,200':gf?'110,180,255':sk?'255,122,150':'200,160,255',col2=fd?'159,180,255':rp?'150,255,220':gf?'170,215,255':sk?'255,170,185':'255,196,107';
    var path=function(){c.beginPath();c.moveTo(p.x,p.y);c.quadraticCurveTo(mx,my,q.x,q.y)};
    var gr=c.createLinearGradient(p.x,p.y,q.x,q.y);gr.addColorStop(0,'rgba('+col+','+(.16*k)+')');gr.addColorStop(.5,'rgba('+col2+','+(.2*k)+')');gr.addColorStop(1,'rgba('+col+','+(.16*k)+')');
    path();c.strokeStyle=gr;c.lineWidth=fd?5:sk?6:11;c.stroke();
    if(sk)c.setLineDash([5,7]);path();c.strokeStyle='rgba('+col2+','+Math.min(.9,.55*k)+')';c.lineWidth=fd?.8:sk?1.3:1.6;c.stroke();if(sk)c.setLineDash([]);
    var nm=fd||sk?1:3;for(var m=0;m<nm;m++){var t=((tn/(fd?5200:2600))+m/nm+rnd(ix+1))%1,u=1-t,x=u*u*p.x+2*u*t*mx+t*t*q.x,y=u*u*p.y+2*u*t*my+t*t*q.y,rr=fd?3:5,g=c.createRadialGradient(x,y,0,x,y,rr);
      g.addColorStop(0,'rgba(255,245,225,'+Math.min(1,.9*k)+')');g.addColorStop(1,'rgba('+col2+',0)');c.fillStyle=g;c.beginPath();c.arc(x,y,rr,0,7);c.fill()}});
  c.restore()}
// ---- objects
var GLASS={TypeScript:1,Swift:1,Go:1,Rust:1,Private:1};
function face(c,pts,col,f,y0,y1){var g=c.createLinearGradient(0,y0,0,y1);g.addColorStop(0,mix(col,f*P.light*1.04));g.addColorStop(1,mix(col,f*P.light*.78));poly(c,pts,g)}
function awning(c,x,y,w,cols){var hw=TW/2*w,hh=TH/2*w,n=6;for(var k=0;k<n;k++){var a=k/n,b=(k+1)/n;c.fillStyle=cols[k%2];c.beginPath();
  c.moveTo(x-hw+hw*a,y+hh*a);c.lineTo(x-hw+hw*b,y+hh*b);c.lineTo(x-hw+hw*b-3,y+hh*b+5);c.lineTo(x-hw+hw*a-3,y+hh*a+5);c.closePath();c.fill()}}
// ---- listings: apps and websites the owner listed hang signs on the city's buildings (sfPlace picks which and how):
// rooftop billboards on struts, vertical blade signs on tall towers, wall billboards and street-level fascia signs over
// an awning. Each sign shows the listing's real icon and short name, in a metal frame, lit in the listing's colour
// (neon at night, soft by day), skewed onto the face it hangs on so it sits in the city's projection.
var LCOL={app:'#6C63FF',site:'#1FA39A'},LIMG={},LTEX={},SHOPC=['#D9C7AE','#C7CED6','#E0CDB5','#BFC9B8','#D6BFB4'];
function limg(u){if(!u||!/^https?:\/\/[^\s"<>]+\/v1\/listings\/img\/[A-Za-z0-9._%-]+$/.test(u))return null;var im=LIMG[u];if(im)return im.complete&&im.naturalWidth?im:null;
  im=new Image();im.onload=function(){draw()};im.src=u;LIMG[u]=im;return null}
function rrect(c,x,y,w,h,r){c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath()}
// the icon as a texture: drawn once per icon onto a 128px white tile with rounded corners (no per-frame clipping)
function ltex(r){var m=r.meta||{},im=limg(m.icon),app=r.kind==='app',k=(im?m.icon:'#'+(r.name||'?').charAt(0))+'|'+(app?'a':'s')+'|'+r.kind,t=LTEX[k];if(t)return t;
  t=document.createElement('canvas');t.width=t.height=128;var g=t.getContext('2d');g.fillStyle='#FFFFFF';rrect(g,0,0,128,128,app?28:24);g.fill();
  if(im){var pad=app?0:14;g.save();rrect(g,pad,pad,128-pad*2,128-pad*2,app?28:14);g.clip();g.drawImage(im,pad,pad,128-pad*2,128-pad*2);g.restore()}
  else{g.fillStyle=LCOL[r.kind]||'#8A8A93';g.font='700 76px IBM Plex Sans,Arial,sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText(String(r.name||'?').charAt(0).toUpperCase(),64,68)}
  if(im)LTEX[k]=t;else if(!m.icon||!/^https?:/.test(m.icon))LTEX[k]=t;return t}   // a letter tile for a loading icon isn't kept
function fitText(c,txt,maxW,fs,min,wt){txt=String(txt||'');c.font=wt+' '+fs+'px IBM Plex Sans,Arial,sans-serif';var w=c.measureText(txt).width;
  if(w>maxW&&fs>min){fs=Math.max(min,fs*maxW/w*.96);c.font=wt+' '+fs.toFixed(2)+'px IBM Plex Sans,Arial,sans-serif';w=c.measureText(txt).width}
  while(w>maxW*1.03&&txt.length>2){txt=txt.slice(0,-2)+'…';w=c.measureText(txt).width}return {t:txt,fs:fs}}
var SIGNS=[];
// one sign panel in local (face) coordinates: x0,y0 top-left, w x h. vert = a blade (icon on top, letters stacked)
function signPanel(c,r,x0,y0,w,h,col,dark,tron,LOD,vert){
  if(LOD){c.fillStyle=col;c.globalAlpha=dark?1:.85;c.fillRect(x0,y0,w,h);c.globalAlpha=1;return}
  c.save();c.shadowColor=col;c.shadowBlur=dark?14:3;c.fillStyle=tron?'#02060C':'#2B2F3A';rrect(c,x0-1.3,y0-1.3,w+2.6,h+2.6,1.8);c.fill();c.restore();   // frame + glow
  var g=c.createLinearGradient(0,y0,0,y0+h);g.addColorStop(0,tron?'#06121C':mix(col,dark?1.18:1.1));g.addColorStop(1,tron?'#02060C':mix(col,dark?.78:.72));c.fillStyle=g;c.fillRect(x0,y0,w,h);
  c.strokeStyle=dark||tron?mix(col,1.45):'rgba(255,255,255,.55)';c.lineWidth=.6;c.strokeRect(x0+.3,y0+.3,w-.6,h-.6);   // neon tube / bright rim
  var tx=ltex(r),is,ix,iy;
  if(vert){is=Math.min(w-2.4,h*.4);ix=x0+(w-is)/2;iy=y0+1.2;c.drawImage(tx,ix,iy,is,is);
    var name=String(r.name||'').replace(/\s+/g,'').toUpperCase(),fs=Math.min(w*.66,7.5),step=fs*1.02,room=y0+h-(iy+is+1.5),n=Math.max(0,Math.min(name.length,Math.floor(room/step)));
    if(n<name.length&&n>1)name=name.slice(0,n-1)+'·';c.fillStyle=dark?'#FFFFFF':'#FFFDF6';c.font='800 '+fs.toFixed(2)+'px IBM Plex Sans,Arial,sans-serif';c.textAlign='center';c.textBaseline='top';
    if(dark){c.save();c.shadowColor='#FFFFFF';c.shadowBlur=4}for(var q=0;q<Math.min(n,name.length);q++)c.fillText(name.charAt(q),x0+w/2,iy+is+1.5+q*step+(room-n*step)/2);if(dark)c.restore();
    if(dark)for(var b=y0+1.5;b<y0+h-1;b+=2.6){c.fillStyle=(Math.floor((b-y0)/2.6)%2)?'#FFE9B0':'#FFF6DC';c.fillRect(x0-1.6,b,.9,.9);c.fillRect(x0+w+.7,b,.9,.9)}}   // marquee bulbs
  else{is=Math.min(h-2.4,w*.42);ix=x0+1.4;iy=y0+(h-is)/2;c.drawImage(tx,ix,iy,is,is);var tw=w-is-4.2;
    if(tw>5){var f=fitText(c,r.name,tw,Math.min(h*.46,9),2.6,'700');c.fillStyle='#FFFFFF';c.textAlign='left';c.textBaseline='middle';if(dark){c.save();c.shadowColor='#FFFFFF';c.shadowBlur=3}
      c.fillText(f.t,ix+is+1.6,y0+h/2+.3);if(dark)c.restore()}}
  c.textBaseline='alphabetic';c.textAlign='center';
  if(!tron&&!dark){c.fillStyle='rgba(255,255,255,.16)';c.fillRect(x0,y0,w,h*.38)}   // daylight sheen
  if(sel===r){c.save();c.strokeStyle=tron?'#FFFFFF':'#C4B5FF';c.lineWidth=2/cam.z;c.shadowColor='#8B6CF6';c.shadowBlur=12;rrect(c,x0-3,y0-3,w+6,h+6,2.5);c.stroke();c.restore()}}
// a sign's screen bounds for tapping: the transformed corners of its local box
function signHit(s,g,ox,oy,uy,x0,y0,w,h){var xs=[],ys=[];[[x0,y0],[x0+w,y0],[x0,y0+h],[x0+w,y0+h]].forEach(function(q){xs.push(ox+q[0]);ys.push(oy+uy*q[0]+q[1])});
  var a=Math.min.apply(null,xs),b=Math.max.apply(null,xs),u=Math.min.apply(null,ys),v=Math.max.apply(null,ys),px=Math.max(0,(14-(b-a))/2),py=Math.max(0,(14-(v-u))/2);
  hits.push({r:s.r,d:g.d,x0:a-3-px,x1:b+3+px,y0:u-3-py,y1:v+3+py})}
function drawSigns(){SIGNS.forEach(function(g){var c=g.c,x=g.x,k=D.world?.8:1,w0=g.tiers[0][0],th0=g.tiers[0][1],hw=TW/2*w0,hh=TH/2*w0,dark=g.tron||sky==='night'||sky==='evening';
  g.list.forEach(function(s){var r=s.r,col=LCOL[r.kind]||'#8A8A93',L=s.side!=='R',uy,ox,oy;
    if(s.v==='roof'){var wT=g.tiers[g.tiers.length-1][0],hwT=TW/2*wT,pw=hwT*1.3,ph=Math.max(8,pw*.42),sh=5*k,bx=L?1:-1;   // billboard on struts across the roof, facing the viewer
      uy=L?.5:-.5;var cx0=x+bx*hwT*.2,cy0=g.top-hwT*.1;ox=cx0-pw/2;oy=cy0-uy*pw/2;
      c.save();c.transform(1,uy,0,1,ox,oy);
      if(!g.LOD){c.fillStyle='rgba(0,0,0,'+(dark?.3:.2)+')';c.beginPath();c.moveTo(0,0);c.lineTo(pw,0);c.lineTo(pw+bx*2.5,-1.6);c.lineTo(bx*2.5,-1.6);c.closePath();c.fill();   // shadow on the roof
        c.strokeStyle=g.tron?col:'#4A4F5C';c.lineWidth=.9;c.beginPath();[.12,.5,.88].forEach(function(f){c.moveTo(pw*f,0);c.lineTo(pw*f,-sh)});c.moveTo(pw*.12,0);c.lineTo(pw*.5,-sh);c.moveTo(pw*.88,0);c.lineTo(pw*.5,-sh);c.stroke();   // struts + braces
        c.fillStyle=g.tron?'#0A1422':'#5A606E';c.fillRect(-1,-sh-1.2,pw+2,1.2)}   // catwalk
      signPanel(c,r,0,-sh-1.2-ph,pw,ph,col,dark,g.tron,g.LOD,false);
      if(!g.LOD)[.18,.5,.82].forEach(function(f){var lx=pw*f,ly=-sh-.6;c.fillStyle='#3A3F4A';c.fillRect(lx-.9,ly-1.1,1.8,1.6);   // spotlights on the catwalk
        if(dark){c.fillStyle='rgba(255,246,214,.16)';c.beginPath();c.moveTo(lx,ly-1);c.lineTo(lx-pw*.17,-sh-1.2-ph);c.lineTo(lx+pw*.17,-sh-1.2-ph);c.closePath();c.fill();c.fillStyle='#FFF4D0';c.fillRect(lx-.6,ly-1.3,1.2,.8)}});
      c.restore();signHit(s,g,ox,oy,uy,0,-sh-1.2-ph,pw,ph+sh);return}
    // the face it hangs on: left face runs (x-hw,base) -> (x,base+hh), right face (x,base+hh) -> (x+hw,base)
    uy=L?.5:-.5;var ax=L?x-hw:x,ay=L?g.base:g.base+hh;
    if(s.v==='blade'){var dp=11*k,bl=Math.min(th0*.62,62*k),v0=Math.max(10*k,th0*.2),u=L?.8:.2,pxA=ax+hw*u,pyA=ay+uy*hw*u,buy=L?-.5:.5;   // vertical, sticking out from the wall
      ox=L?pxA-dp:pxA;oy=L?pyA+dp*.5:pyA;c.save();c.transform(1,buy,0,1,ox,oy);var x0=L?0:1.6,bw=dp-1.6,wx=L?dp:0;
      if(!g.LOD){c.strokeStyle=g.tron?col:'#3E434E';c.lineWidth=.9;c.beginPath();c.moveTo(wx,-v0-bl*.12);c.lineTo(L?bw:x0,-v0-bl*.12);c.moveTo(wx,-v0-bl*.88);c.lineTo(L?bw:x0,-v0-bl*.88);c.stroke()}   // brackets
      signPanel(c,r,x0,-v0-bl,bw,bl,col,dark,g.tron,g.LOD,true);c.restore();
      if(!g.LOD&&!g.tron){c.save();c.transform(1,uy,0,1,ax,ay);var su=hw*u;c.fillStyle='rgba(0,0,0,'+(dark?.25:.16)+')';c.fillRect(L?su-3:su,-v0-bl,3,bl);c.restore()}   // its shadow on the wall
      signHit(s,g,ox,oy,buy,x0,-v0-bl,bw,bl);return}
    c.save();c.transform(1,uy,0,1,ax,ay);
    if(s.v==='wall'){var pw2=hw*.8,ph2=Math.min(pw2*.6,th0*.42),lx0=(hw-pw2)/2,vb=Math.min(th0-ph2-3,Math.max(9*k,th0*.52-ph2/2));   // a framed billboard on the face
      if(!g.LOD){c.fillStyle='rgba(0,0,0,'+(dark?.3:.18)+')';c.fillRect(lx0+1.4,-vb-ph2+1.6,pw2,ph2);
        c.strokeStyle=g.tron?col:'#3E434E';c.lineWidth=.7;c.beginPath();[.2,.5,.8].forEach(function(f){var lx=lx0+pw2*f;c.moveTo(lx,-vb-ph2-.5);c.lineTo(lx,-vb-ph2-3);c.lineTo(lx+(L?-1.4:1.4),-vb-ph2-3.6)});c.stroke()}   // gooseneck lamps
      signPanel(c,r,lx0,-vb-ph2,pw2,ph2,col,dark,g.tron,g.LOD,false);
      if(!g.LOD&&dark)[.2,.5,.8].forEach(function(f){var lx=lx0+pw2*f+(L?-1.4:1.4);c.fillStyle='rgba(255,246,214,.14)';c.beginPath();c.moveTo(lx,-vb-ph2-3.4);c.lineTo(lx-4,-vb-ph2*.3);c.lineTo(lx+4,-vb-ph2*.3);c.closePath();c.fill();c.fillStyle='#FFF4D0';c.fillRect(lx-.6,-vb-ph2-3.9,1.2,.8)});
      c.restore();signHit(s,g,ax,ay,uy,lx0,-vb-ph2,pw2,ph2);return}
    // fascia: shop window, striped awning, and the name board above it, at street level
    var fw=hw*.9,fx0=(hw-fw)/2,wnd=7*k,aw=3*k,bd=Math.max(6,7.5*k);
    if(!g.LOD){c.fillStyle=dark?'rgba(255,214,140,.95)':'rgba(40,52,72,.62)';c.fillRect(fx0+1,-wnd,fw-2,wnd-.6);
      c.fillStyle=dark?'rgba(120,70,30,.6)':'rgba(255,255,255,.35)';c.fillRect(fx0+fw*.45,-wnd+1,fw*.1,wnd-1.6);   // door
      if(dark){c.save();c.globalAlpha=.35;c.shadowColor='#FFD98A';c.shadowBlur=8;c.fillStyle='#FFD98A';c.fillRect(fx0+1,-wnd,fw-2,wnd-.6);c.restore()}}
    signPanel(c,r,fx0,-wnd-aw-bd,fw,bd,col,dark,g.tron,g.LOD,false);
    c.restore();
    if(!g.LOD){var n=6,ox2=L?-2.2:2.2;for(var q=0;q<n;q++){var a0=fx0+fw*q/n,a1=fx0+fw*(q+1)/n,P0={x:ax+a0,y:ay+uy*a0-wnd-aw},P1={x:ax+a1,y:ay+uy*a1-wnd-aw};   // awning, leaning out over the street
      c.fillStyle=q%2?'#FFF4E8':mix(col,dark?.95:1.15);c.beginPath();c.moveTo(P0.x,P0.y);c.lineTo(P1.x,P1.y);c.lineTo(P1.x+ox2,P1.y+aw+1.4);c.lineTo(P0.x+ox2,P0.y+aw+1.4);c.closePath();c.fill()}
      if(dark){c.save();c.transform(1,uy,0,1,ax,ay);[fx0+1,fx0+fw-1].forEach(function(lx){c.fillStyle='#FFF4D0';c.beginPath();c.arc(lx,-wnd-aw-bd-1.2,.8,0,7);c.fill()});c.restore()}}   // sconces
    signHit(s,g,ax,ay,uy,fx0,-wnd-aw-bd,fw,bd+aw+wnd)})});SIGNS=[]}   // pushed last: tapping a sign wins over the tower in front of it
// ---- the store directory: tapping any storefront (or "Stores" in the toolbar) lists every storefront in that city in one menu
function storeList(key){var out=[];for(var k in tiles){var t=tiles[k];if(t.t!=='b'||!t.r||!(!key||(t.d&&(t.d.nb||t.d.name))===key))continue;var L=SFA.get(t.r);if(!L)continue;var a=k.split(',');
    L.forEach(function(s){out.push({r:s.r,d:t.d,i:+a[0],j:+a[1]})})}
  out.sort(function(a,b){return String(a.r.name).localeCompare(String(b.r.name),undefined,{sensitivity:'base'})||placeOf(a).localeCompare(placeOf(b))});return out}
function placeOf(s){if(!s.d)return '';if(D.world){var key=s.d.nb||s.d.name,m=WORLD&&WORLD.m&&WORLD.m[key]||{};return m.name||key}return s.d.name||''}
function storeAddr(r){var m=r.meta||{},s=r.sites&&r.sites[0];return typeof s==='string'&&s.indexOf(m.host||'\u0000')===0?s:(m.host||'')}
function storeKind(r){return r.kind==='app'?((r.meta||{}).store==='play'?'App · Google Play':'App · App Store'):'Website'+(storeAddr(r)?' · '+storeAddr(r):'')}
function storeIcon(r,px){var m=r.meta||{},im=limg(m.icon),col=LCOL[r.kind]||'#8A8A93';return im?'<img src="'+e(m.icon)+'" alt="" width="'+px+'" height="'+px+'" style="width:'+px+'px;height:'+px+'px;border-radius:'+(r.kind==='app'?Math.round(px*.22):Math.round(px*.18))+'px;flex:none;object-fit:cover;background:#fff">'
  :'<span aria-hidden="true" style="width:'+px+'px;height:'+px+'px;flex:none;border-radius:'+Math.round(px*.22)+'px;display:inline-flex;align-items:center;justify-content:center;font-weight:700;background:#fff;color:'+col+';box-shadow:0 0 0 2px '+col+'">'+e(String(r.name||'?').charAt(0).toUpperCase())+'</span>'}
function flyToStore(s){var q=iso(s.i,s.j),z=Math.max(cam.z,D.world?.9:1.05),sheet=vw<600,ty=sheet?vh*.24:vh/2,tx=sheet?vw/2:Math.min(vw-60,(vw+Math.min(card.offsetWidth+20,vw*.5))/2);flyTo(tx-q.x*z,ty-(q.y-40)*z,z,reduce?1:450)}
var DIRKEY=null;
function storeDir(r0,key,focus){var all=storeList(key),cur=null;all.forEach(function(s){if(s.r===r0)cur=s});if(!cur&&all.length&&r0)cur=null;
  DIRKEY=key;sel=cur?cur.r:null;
  function render(){var r=cur&&cur.r,m=r&&r.meta||{},u=r?repoUrl(r):'',app=r&&r.kind==='app';
    var top=r?'<div class="d-sel">'+'<div style="display:flex;gap:10px;align-items:center">'+storeIcon(r,44)+'<div style="min-width:0"><h3 style="margin:0">'+e(r.name)+'</h3><div class="k">'+e(storeKind(r))+(placeOf(cur)?' &middot; '+e(placeOf(cur))+(D.world?'':' district'):'')+'</div></div></div>'
      +(m.desc?'<p style="margin:8px 0 0">'+e(m.desc)+'</p>':'')
      +(m.genre?'<div class="row"><span>Category</span><b>'+e(m.genre)+'</b></div>':'')
      +(+m.rating>0?'<div class="row"><span>Rating</span><b>&#9733; '+(+m.rating).toFixed(1)+(+m.ratings>0?' ('+(+m.ratings).toLocaleString('en-US')+')':'')+'</b></div>':'')
      +(u?'<p style="margin:8px 0 0"><a class="d-visit" href="'+e(u)+'" target="_blank" rel="noopener">'+(app?(m.store==='play'?'Open on Google Play':'Open on the App Store'):'Visit '+e(storeAddr(r)||'the site'))+' &#8599;</a></p>':'')+'</div>':'';
    card.innerHTML='<button class="x" aria-label="Close">&times;</button><div class="d-head"><b>Stores</b> <span class="k">'+all.length+' in '+(key&&D.world?e(placeOf(all[0]||{d:null})||'this city'):D.world?'the world':'this city')+'</span></div>'+top
      +'<ul class="d-list" role="list">'+all.map(function(s,ix){var on=s===cur;return '<li><button type="button" class="d-row'+(on?' is-on':'')+'" data-ix="'+ix+'" aria-current="'+(on?'true':'false')+'">'+storeIcon(s.r,28)+'<span class="d-txt"><span class="d-name">'+e(s.r.name)+'</span><span class="d-meta">'+e(storeKind(s.r))+(placeOf(s)?' &middot; '+e(placeOf(s)):'')+'</span></span></button></li>'}).join('')+'</ul>';
    card.querySelector('.x').onclick=function(){show(null)};
    card.querySelectorAll('.d-row').forEach(function(b){b.onclick=function(){var s=all[+b.getAttribute('data-ix')];cur=s;sel=s.r;render();flyToStore(s);var nb=card.querySelector('.d-row[data-ix="'+b.getAttribute('data-ix')+'"]');if(nb)nb.focus();card.scrollTop=0}});
    draw()}
  card.classList.add('is-dir');card.setAttribute('role','dialog');card.setAttribute('aria-label','Stores');render();card.hidden=false;
  if(focus){var f=card.querySelector('.d-row.is-on')||card.querySelector('.d-row');if(f)f.focus()}}
function listingCard(h){var key=D.world&&h.d?(h.d.nb||h.d.name):null;storeDir(h.r,key,false)}
var SHOPLBL=null;
function drawShop(c,p,LOD){if(!SHOP)return;var x=p.x,y=p.y+4,night=sky==='night'||sky==='evening';
  if(SHOP.big){var q=iso(SHOP.i+1,SHOP.j+1);x=q.x;y=q.y+4;var n=Math.min(8,Math.max(4,TOOLS.length)),pal=[['#E85D75','#FFF4E8'],['#4FB89A','#FFF4E8'],['#7AA7FF','#FFF4E8'],['#E8C547','#FFF4E8'],['#8B6CF6','#FFF4E8'],['#F28C38','#FFF4E8']];
    for(var k=0;k<n;k++){var a=k/n*Math.PI*2,sx=x+Math.cos(a)*TW*.95,sy=y+Math.sin(a)*TH*.95;prism(c,sx,sy,.42,10,'#B98A5A');awning(c,sx,sy-10,.5,pal[k%pal.length])}
    prism(c,x,y,.22,22,'#A07850');c.save();if(night){c.shadowColor='#FFD98A';c.shadowBlur=14}c.fillStyle=night?'#FFE6A8':'#FFF6DE';c.beginPath();c.arc(x,y-27,5,0,7);c.fill();c.restore();
    hits.push({shop:1,x0:x-TW*1.4,x1:x+TW*1.4,y0:y-40,y1:y+TH*1.4});return}
  prism(c,x,y,.8,24,'#C98B4E');prism(c,x,y-24,.56,6,'#A86F3C');awning(c,x,y-19,.88,['#E85D75','#FFF4E8']);
  c.save();if(night){c.shadowColor='#FFD98A';c.shadowBlur=12}c.fillStyle=night?'#FFE6A8':'#FFF2D6';c.fillRect(x-9,y-36,18,7);c.restore();
  SHOPLBL={x:x,y:y-48,text:'\u2726 Workshop \u00b7 '+TOOLS.length+' free tool'+(TOOLS.length===1?'':'s'),bg:'rgba(201,139,78,.97)'};
  hits.push({shop:1,x0:x-TW*.5,x1:x+TW*.5,y0:y-58,y1:y+TH*.45})}
function shopCard(){var base=(window.CALDERA_TOOLS_HUB||'').replace(/\/$/,'');sel=null;
  card.classList.remove('is-dir');card.innerHTML='<button class="x" aria-label="Close">&times;</button><h3>'+(D.world?'Free tools market':'Workshop')+'</h3><div class="k">'+(D.world?'Free software made by Caldera members':'Free software this person made')+'</div>'
   +TOOLS.slice(0,8).map(function(t){return '<div style="margin-top:10px"><b>'+e(t.name)+'</b>'+(D.world&&t.handle?' <a href="#" data-maker="'+e(t.handle)+'" style="font-size:12px">@'+e(t.handle)+'</a>':'')+'<div style="font-size:12.5px;opacity:.85">'+e(t.pitch||'')+'</div>'
     +'<div style="font-size:12px;margin-top:3px"><a href="'+e(base+'/tools/go/'+t.id)+'" target="_blank" rel="noopener nofollow">Get it \u2197</a>'+(t.platform?' &middot; '+e(t.platform):'')+(t.repo?' &middot; open source':'')+'</div></div>'}).join('')
   +'<div class="row" style="margin-top:12px"><a href="'+e(base+'/tools')+'" target="_blank" rel="noopener">All free tools \u2192</a></div>';
  card.hidden=false;card.querySelector('.x').onclick=function(){show(null)};
  card.querySelectorAll('[data-maker]').forEach(function(a){a.onclick=function(ev){ev.preventDefault();var b=byName['@'+a.getAttribute('data-maker')];if(b&&typeof worldFocus==='function')worldFocus(b)}});draw()}
function prism(c,px,py,w,h,col){var hw=TW/2*w,hh=TH/2*w;
  face(c,[[px-hw,py],[px,py+hh],[px,py+hh-h],[px-hw,py-h]],col,.98,py-h,py+hh);
  face(c,[[px,py+hh],[px+hw,py],[px+hw,py-h],[px,py+hh-h]],col,.72,py-h,py+hh);
  poly(c,[[px,py-hh-h],[px+hw,py-h],[px,py+hh-h],[px-hw,py-h]],mix(col,1.12*P.light+(P.light<1?.1:0)));
  c.strokeStyle='rgba(255,255,255,'+(sky==='night'?.06:.16)+')';c.lineWidth=.8;c.beginPath();c.moveTo(px,py+hh);c.lineTo(px,py+hh-h);c.stroke();
  c.strokeStyle='rgba(0,0,0,.22)';c.beginPath();c.moveTo(px-hw,py-h);c.lineTo(px,py+hh-h);c.lineTo(px+hw,py-h);c.stroke();return {hw:hw,hh:hh}}
// windows: parallelograms that follow each face; u runs along the face, v up from the base
function facadeWindows(c,px,py,w,h,glass,litp,seed,base,people){people=people||0;var hw=TW/2*w,hh=TH/2*w,cols=w>.6?4:3,rows=Math.max(0,Math.floor((h-9)/(glass?7:8)));
  for(var side=0;side<2;side++){var ax=side?px:px-hw,ay=side?py+hh:py,bx=side?px+hw:px,by=side?py:py+hh;
    if(glass){c.strokeStyle='rgba(255,255,255,'+(sky==='night'?.05:.18)+')';c.lineWidth=.7;for(var m=1;m<cols+1;m++){var u=m/(cols+1);c.beginPath();c.moveTo(ax+(bx-ax)*u,ay+(by-ay)*u-3);c.lineTo(ax+(bx-ax)*u,ay+(by-ay)*u-h+2);c.stroke()}
      if(!side&&sky!=='night'){c.save();poly(c,[[ax,ay],[bx,by],[bx,by-h],[ax,ay-h]]);c.clip();var gx=c.createLinearGradient(ax,ay-h,bx,by);gx.addColorStop(.3,'rgba(255,255,255,0)');gx.addColorStop(.45,'rgba(255,255,255,.22)');gx.addColorStop(.55,'rgba(255,255,255,0)');c.fillStyle=gx;c.fillRect(ax-2,ay-h-hh-2,hw+4,h+hh*2+4);c.restore()}}
    for(var r=0;r<rows;r++)for(var k=0;k<cols;k++){var on=rnd(seed+r*7.3+k*13.1+side*31.7)<litp;if(glass&&!on&&sky!=='night')continue;
      var u0=(k+.22)/cols,u1=(k+.78)/cols,v0=6+r*(glass?7:8),v1=v0+(glass?4:5);
      c.fillStyle=on?P.win:P.winOff;poly(c,[[ax+(bx-ax)*u0,ay+(by-ay)*u0-v0],[ax+(bx-ax)*u1,ay+(by-ay)*u1-v0],[ax+(bx-ax)*u1,ay+(by-ay)*u1-v1],[ax+(bx-ax)*u0,ay+(by-ay)*u0-v1]]);c.fill();
      // someone on the site right now: a silhouette in some of the lit windows (more of them when the site is busy)
      if(on&&people>0&&rnd(seed*1.7+r*11.9+k*5.3+side*17.3)<people){var um=(u0+u1)/2,wx=ax+(bx-ax)*um,wy=ay+(by-ay)*um,wh=v1-v0,ww=Math.abs((bx-ax)*(u1-u0));
        c.fillStyle=sky==='night'||sky==='evening'?'rgba(40,24,14,.82)':'rgba(30,26,22,.7)';
        c.beginPath();c.arc(wx+(rnd(seed+r+k)-.5)*ww*.25,wy-v1+wh*.36,Math.max(.55,wh*.2),0,7);c.fill();   // head
        c.beginPath();c.ellipse(wx,wy-v0-.1,Math.max(.8,ww*.34),Math.max(.6,wh*.3),0,Math.PI,0);c.fill()}}   // shoulders
    // ground floor: storefront band
    c.fillStyle=sky==='night'?'rgba(255,200,120,.35)':'rgba(30,36,48,.35)';poly(c,[[ax,ay-1],[bx,by-1],[bx,by-5],[ax,ay-5]]);c.fill()}}
function roofProps(c,px,ty,w,r,seed){var hw=TW/2*w,hh=TH/2*w,s=rnd(seed);
  if(r.locked){c.fillStyle=sky==='night'?'#AFC0E0':'#E8EDF6';c.strokeStyle=c.fillStyle;c.lineWidth=1.6;c.beginPath();c.arc(px,ty-6,3,Math.PI,0);c.stroke();c.fillRect(px-4,ty-6,8,6);c.fillStyle='#5C6B86';c.fillRect(px-.7,ty-4.5,1.4,2.5);return}
  if(r===tallest){c.strokeStyle='#B8BCC6';c.lineWidth=1.2;c.beginPath();c.moveTo(px,ty);c.lineTo(px,ty-26);c.stroke();return}
  if(r===second&&w>.5){c.fillStyle='rgba(40,44,56,.85)';c.beginPath();c.ellipse(px,ty,hw*.55,hh*.55,0,0,7);c.fill();c.fillStyle='#F2D24A';c.font='bold 7px sans-serif';c.textAlign='center';c.fillText('H',px,ty+2.5);return}
  if(s<.3&&!GLASS[r.language]){// water tower
    c.fillStyle='#6B5137';c.fillRect(px-5,ty-8,1.2,8);c.fillRect(px+4,ty-8,1.2,8);c.fillStyle='#8B6A48';c.fillRect(px-6,ty-17,12,9);c.beginPath();c.moveTo(px-7,ty-17);c.lineTo(px,ty-22);c.lineTo(px+7,ty-17);c.closePath();c.fillStyle='#5E4630';c.fill();return}
  if(s<.55){// AC units
    for(var q=0;q<3;q++){var ox=(rnd(seed+q)-.5)*hw*.9,oy=(rnd(seed+q*3)-.5)*hh*.7;prism(c,px+ox,ty+oy,.12,4,'#9AA1AD')}return}
  if(s<.72&&GLASS[r.language]){// solar panels
    c.fillStyle=sky==='night'?'#18233E':'#2B4C86';for(var q2=-1;q2<=1;q2++){poly(c,[[px-8+q2*5,ty-1+q2*2.5],[px-2+q2*5,ty-4+q2*2.5],[px+2+q2*5,ty-2+q2*2.5],[px-4+q2*5,ty+1+q2*2.5]]);c.fill()}return}
  if(s<.85){// roof garden
    poly(c,[[px,ty-hh*.8],[px+hw*.8,ty],[px,ty+hh*.8],[px-hw*.8,ty]],sky==='night'?'#1F3A28':'#5DA14E');tree2(c,px-4,ty+1,.55);tree2(c,px+5,ty-1,.45)}}
function tree2(c,px,py,s){c.fillStyle='rgba(0,0,0,.18)';c.beginPath();c.ellipse(px+4*s,py+1,7*s,3*s,0,0,7);c.fill();c.fillStyle='#6B4B2E';c.fillRect(px-.8*s,py-6*s,1.6*s,6*s);
  var g=c.createRadialGradient(px-2*s,py-13*s,1,px,py-10*s,9*s);g.addColorStop(0,sky==='night'?'#2E5A3C':'#8CCF6E');g.addColorStop(1,sky==='night'?'#15301F':'#3F8A47');c.fillStyle=g;c.beginPath();c.arc(px,py-10*s,7.5*s,0,7);c.fill()}
function pine(c,px,py,s){c.fillStyle='rgba(0,0,0,.18)';c.beginPath();c.ellipse(px+3*s,py+1,6*s,2.5*s,0,0,7);c.fill();c.fillStyle=sky==='night'?'#173126':'#2F7A4A';for(var k=0;k<3;k++){c.beginPath();c.moveTo(px,py-18*s+k*4*s);c.lineTo(px+6*s-k*.5,py-6*s+k*2*s);c.lineTo(px-6*s+k*.5,py-6*s+k*2*s);c.closePath();c.fill()}}
function houseAt(c,px,py,col,seed){var w=.26,hw=TW/2*w,hh=TH/2*w,h=8;prism(c,px,py,w,h,col);
  var rt=py-h,rc=sky==='night'?'#4A2A2A':['#B4554F','#8E5A3C','#5B6B8A','#A0503A'][seed%4];
  poly(c,[[px-hw,rt],[px-hw*.15,rt-9],[px+hw*.85,rt-9+hh*.9],[px,rt+hh]],mix(rc,1));poly(c,[[px,rt+hh],[px+hw*.85,rt-9+hh*.9],[px+hw,rt],],mix(rc,.7));
  poly(c,[[px-hw*.15,rt-9],[px+hw,rt],[px+hw*.85,rt-9+hh*.9]],mix(rc,.85));
  c.fillStyle=mix('#8A7A6A',.9);c.fillRect(px+hw*.3,rt-10,2.2,5);
  c.fillStyle=sky==='night'?'rgba(255,208,120,.95)':'rgba(70,90,120,.7)';poly(c,[[px-hw*.6,py-3+hh*.4-3],[px-hw*.3,py-3+hh*.7-3],[px-hw*.3,py-3+hh*.7-6],[px-hw*.6,py-3+hh*.4-6]]);c.fill()}
function lamp(c,px,py){c.strokeStyle=sky==='night'?'#555B66':'#4A4F58';c.lineWidth=1;c.beginPath();c.moveTo(px,py);c.lineTo(px,py-14);c.lineTo(px+3,py-15);c.stroke();c.fillStyle=sky==='night'?'#FFE3A0':'#C9CDD4';c.fillRect(px+2,py-16,3,2)}
// a public repo's name label is a link to it (private and locked buildings never link)
var tagHits=[];function repoUrl(r){return !r.locked&&r.public!==false&&(/^https:\/\/[^\s"<>]+$/.test(r.url||'')||(r.kind==='site'&&/^http:\/\/[^\s"<>]+$/.test(r.url||'')))?r.url:''}
function tagHit(c,g,font){if(!g.url)return;c.font=font;var w=c.measureText(g.text).width+12;tagHits.push({x0:g.x-w/2,x1:g.x+w/2,y0:g.y-17,y1:g.y+2,url:g.url})}
function openRepo(u){if(u)window.open(u,'_blank','noopener')}
function pill(c,x,y,text,bg,fg,font){c.font=font;var tw=c.measureText(text).width,w=tw+12,h=17,r=8.5;c.save();c.shadowColor='rgba(0,0,0,.3)';c.shadowBlur=6;c.shadowOffsetY=2;c.fillStyle=bg;c.beginPath();
  c.moveTo(x-w/2+r,y-h);c.arcTo(x+w/2,y-h,x+w/2,y,r);c.arcTo(x+w/2,y,x-w/2,y,r);c.lineTo(x+3,y);c.lineTo(x,y+4);c.lineTo(x-3,y);c.arcTo(x-w/2,y,x-w/2,y-h,r);c.arcTo(x-w/2,y-h,x+w/2,y-h,r);c.closePath();c.fill();c.restore();
  c.fillStyle=fg;c.textAlign='center';c.textBaseline='middle';c.fillText(text,x,y-h/2+.5);c.textBaseline='alphabetic'}
var lamps=[],cranes=[],beacons=[];
function drawObjects(){SIGNS=[];var LOD=WORLD&&cam.z<.5;var c=c2;c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,L2.width,L2.height);c.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);hits=[];tagHits=[];lamps=[];cranes=[];beacons=[];var tags=[];
  FOREMAN={};for(var sum=0;sum<=W+H;sum++)for(var i=0;i<=W;i++){var j=sum-i;if(j<0||j>H)continue;var t=tiles[i+','+j],p=iso(i,j),gp=gpop(i,j);if(gp<=0&&t.t!=='b')continue;if(gp<1&&t.t!=='b'){c.save();var gk=backOut(gp);c.translate(p.x,p.y);c.scale(gk,gk);c.translate(-p.x,-p.y)}
    var hf=t.t==='h'&&BUILDING?buildF(t,i,j):1;if(hf<.55){if(gp<1&&t.t!=='b')c.restore();continue}if(hf<1){c.save();var hk=backOut(Math.min(1,(hf-.55)/.45));c.translate(p.x,p.y);c.scale(hk,hk);c.translate(-p.x,-p.y)}
    if(t.t==='g'&&!water(i,j)&&rnd(i*17+j*29)<(i===0||j===0?.55:.8)){var s=.7+rnd(i+j*3)*.5;if(rnd(i*3+j)<.5)tree2(c,p.x+(rnd(i)-.5)*20,p.y+(rnd(j)-.5)*8,s);else pine(c,p.x+(rnd(j)-.5)*20,p.y+(rnd(i)-.5)*8,s)}
    if(t.t==='r'&&(isRoad(i-1,j)||isRoad(i+1,j))&&(isRoad(i,j-1)||isRoad(i,j+1))&&(i+j)%2===0){var lp={x:p.x-TW*.32,y:p.y};lamp(c,lp.x,lp.y);lamps.push(lp)}
    if(t.t==='w')drawShop(c,p,LOD);
    if(t.t==='p'){tree2(c,p.x-10,p.y+1,.9);pine(c,p.x+11,p.y-2,.8);tree2(c,p.x+2,p.y+7,.6)}
    if(t.t==='h'){var spots=[[-11,-3],[11,-3],[0,-9],[0,4]],sd=hash(t.d.name);for(var q=0;q<t.n;q++)houseAt(c,p.x+spots[q][0],p.y+spots[q][1],['#E8DCC8','#CFD8E6','#EAD2B8','#D2E0CC'][(sd+q)%4],sd+q)}
    if(hf<1)c.restore();if(gp<1&&t.t!=='b')c.restore();
    if(t.t==='b'){var r=t.r,SL=SFA.get(r),h=bh(r),dm=dormant(r),seed=hash(r.name||(i+'_'+j)),glass=!!GLASS[r.language]||r.locked,bf=BUILDING?buildF(t,i,j):1;
      var col=r.kind?SHOPC[seed%SHOPC.length]:r.locked?'#5F6F8E':dm?mix(LANG[r.language]||'#8A8A93',.55,'#8A8E96'):(LANG[r.language]||'#8A8A93');
      var wk=r.weeks&&r.weeks.length?Math.max.apply(null,r.weeks):0,litp=r.kind?.6:dm?0:r.locked?(t.d&&t.d.apart?0:r.week?.4:.08):Math.min(.95,.15+(r.week/Math.max(wk,1))*.8);
      litp=Math.min(litp,P.lit==null?1:P.lit);   // fewer lit windows by day, more as evening comes
      var gw=glowOf(t.d),sg=gw>0?siteGlowOf(t):0,lw=Math.max(sg,gw*.3);if(lw>0)litp=Math.max(litp,Math.min(.97,lw*(.55+.45*(P.lit==null?1:P.lit))));   // people on the site right now light up its building (the rest of the district a little)
      var tiers=h>110?[[.78,h*.6],[.62,h*.26],[.46,h*.14]]:h>70?[[.78,h*.72],[.6,h*.28]]:[[.78,h]],base=p.y+4,top=base;
      if(bf<1){top=lego(c,p.x,base,tiers,h,col,glass,litp,seed,r,bf,i+','+j,t.d&&(t.d.nb||t.d.name),LOD);if(bf>0&&bf<.8&&!LOD)cranes.push({x:p.x+4,y:top,seed:seed})}
      else{for(var k=0;k<tiers.length;k++){var tw=tiers[k][0],th=tiers[k][1];var sh=prism(c,p.x,top,tw,th,col);if(!LOD)facadeWindows(c,p.x,top,tw,th,glass,litp,seed+k*101,base,sg>0?Math.min(.55,sg*.75):0);top-=th}
      if(!LOD&&!(SL&&SL.some(function(s){return s.v==='roof'})))roofProps(c,p.x,top,tiers[tiers.length-1][0],r,seed)}
      if(r===tallest)beacons.push({x:p.x,y:top-26});
      if(r.week>0&&!dm&&bf>=1)cranes.push({x:p.x+4,y:top,seed:seed});
      if(SL&&bf>=1)SIGNS.push({c:c,x:p.x,base:base,top:top,tiers:tiers,list:SL,d:t.d,tron:false,LOD:LOD});
      if(sel===r){c.save();c.strokeStyle='#C4B5FF';c.lineWidth=2.4/cam.z;c.shadowColor='#8B6CF6';c.shadowBlur=12;var hw=TW/2*.78,hh=TH/2*.78;c.beginPath();c.moveTo(p.x-hw,base);c.lineTo(p.x,base+hh);c.lineTo(p.x+hw,base);c.lineTo(p.x+hw,top+ (base-top>0?0:0));c.lineTo(p.x,top-TH/2*.46);c.lineTo(p.x-hw,top);c.closePath();c.stroke();c.restore()}
      hits.push({r:r,d:t.d,x0:p.x-TW*.42,x1:p.x+TW*.42,y0:top-14,y1:p.y+TH*.45});
      if(labels&&bf>=1&&!INTRO&&!r.locked&&!r.kind&&(cam.z>1.05||sel===r||(!WORLD&&topSet.indexOf(r)>=0))&&!(t.d&&sel!==r&&String(t.d.name).toLowerCase().replace(/[^a-z0-9]/g,'')===String(r.name).toLowerCase().replace(/[^a-z0-9]/g,'')))tags.push({x:p.x,y:top-(r===tallest?32:8),text:r.name.length>18?r.name.slice(0,17)+'…':r.name,url:repoUrl(r),r:r})}}
  drawDust(c);drawSigns();
  if(SHOPLBL){pill(c,SHOPLBL.x,SHOPLBL.y,SHOPLBL.text,SHOPLBL.bg,'#fff','700 11px IBM Plex Sans,Arial,sans-serif');hits.push({shop:1,x0:SHOPLBL.x-80,x1:SHOPLBL.x+80,y0:SHOPLBL.y-12,y1:SHOPLBL.y+8});SHOPLBL=null}
  if(WORLD){worldLabels(tags);return}
  if(labels&&!INTRO){var fT='600 10.5px IBM Plex Sans,Arial,sans-serif',fB='700 11.5px IBM Plex Sans,Arial,sans-serif';fitLabels(c,tags,fT,function(b){return {x:b.x,y:b.y,text:b.d.name}},fB,
    function(g){pill(c,g.x,g.y,g.text,'rgba(17,20,32,.86)','#F2F2F5',fT);tagHit(c,g,fT)},function(b,q){pill(c,q.x,q.y,q.text,'rgba(139,108,246,.95)','#fff',fB)})}
}
function drawSky(){var c=cx;c.setTransform(dpr,0,0,dpr,0,0);
  if(sky==='grid'){c.fillStyle='#010207';c.fillRect(0,0,vw,vh);var g0=c.createRadialGradient(vw/2,vh*.38,10,vw/2,vh*.38,Math.max(vw,vh)*.7);g0.addColorStop(0,'rgba(30,70,140,.45)');g0.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=g0;c.fillRect(0,0,vw,vh);
    c.strokeStyle='rgba(61,242,255,.07)';c.lineWidth=1;for(var y=vh*.12;y<vh;y+=26){c.beginPath();c.moveTo(0,y);c.lineTo(vw,y);c.stroke()}return}var g=c.createLinearGradient(0,0,0,vh);g.addColorStop(0,P.sky[0]);g.addColorStop(.6,P.sky[1]);g.addColorStop(1,P.sky[2]);c.fillStyle=g;c.fillRect(0,0,vw,vh);
  var cc=wxCloud(),wk=wxKind(),tint={partly:.06,overcast:.4,fog:.42,drizzle:.32,rain:.46,storm:.62,snow:.36}[wk]||0;
  if(tint){c.fillStyle=sky==='night'?'rgba(18,22,32,'+tint+')':sky==='dusk'?'rgba(110,100,120,'+tint+')':'rgba(140,148,160,'+tint+')';c.fillRect(0,0,vw,vh)}
  if(sky==='night'&&cc<60){c.globalAlpha=1-cc/60;for(var s=0;s<90;s++){c.fillStyle='rgba(255,255,255,'+(.25+rnd(s)*.6)+')';var sz=rnd(s*5)<.1?1.8:1.1;c.fillRect(rnd(s*3)*vw,rnd(s*7)*vh*.5,sz,sz)}
    c.fillStyle='#F4F1E4';c.beginPath();c.arc(vw*.86,vh*.13,13,0,7);c.fill();c.fillStyle=P.sky[0];c.beginPath();c.arc(vw*.86+5,vh*.13-3,12,0,7);c.fill();c.globalAlpha=1}
  drawClouds(c)}
function carPos(car){var a=iso(car.i,car.j),b=iso(car.ti,car.tj),dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy)||1,ux=dx/len,uy=dy/len,nx=-uy,ny=ux*.5;return {x:a.x+dx*car.t+nx*4,y:a.y+dy*car.t+ny*4,ux:ux,uy:uy}}
function drawCycles(){var c=cx;c.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);c.save();c.globalCompositeOperation='lighter';c.lineCap='round';c.lineJoin='round';
  var tn=performance.now();cars.forEach(function(car,k){var f=fa(car,tn),col=k%2?ORANGE:CYAN,tr=car.trail||[];if(tr.length>1){c.strokeStyle=col;c.globalAlpha=.35*f;c.lineWidth=4;c.beginPath();c.moveTo(tr[0][0],tr[0][1]);for(var m=1;m<tr.length;m++)c.lineTo(tr[m][0],tr[m][1]);c.stroke();
      c.globalAlpha=.95*f;c.lineWidth=1.3;c.stroke();c.strokeStyle='#FFFFFF';c.globalAlpha=.6*f;c.lineWidth=.5;c.stroke()}
    c.globalAlpha=f;var p=carPos(car);c.fillStyle=col;c.beginPath();c.arc(p.x,p.y-1,2.2,0,7);c.fill();c.fillStyle='#FFFFFF';c.beginPath();c.arc(p.x+p.ux*1.5,p.y+p.uy*1.5-1,1,0,7);c.fill()});c.restore()}
function drawVis(){if(INTRO)return;if(!vis.length)return;var c=cx,tn=performance.now();c.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);c.save();c.globalCompositeOperation='lighter';c.lineCap='round';c.lineJoin='round';
  vis.forEach(function(v){var age=tn-v.born,a=Math.min(1,age/600,(v.life-age)/1500);if(a<=0)return;var tr=v.trail||[];
    if(tr.length>1){c.strokeStyle=v.col;c.globalAlpha=.3*a;c.lineWidth=4;c.beginPath();c.moveTo(tr[0][0],tr[0][1]);for(var m=1;m<tr.length;m++)c.lineTo(tr[m][0],tr[m][1]);c.stroke();c.globalAlpha=.9*a;c.lineWidth=1.2;c.stroke()}
    var p=carPos(v);c.globalAlpha=a;var g=c.createRadialGradient(p.x,p.y-1,0,p.x,p.y-1,7);g.addColorStop(0,v.col);g.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=g;c.beginPath();c.arc(p.x,p.y-1,7,0,7);c.fill();c.fillStyle='#FFFFFF';c.beginPath();c.arc(p.x,p.y-1,1.6,0,7);c.fill()});
  c.restore()}
function drawCars(){if(INTRO)return;if(sky==='grid')return drawCycles();var c=cx;c.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);
  var tn=performance.now();cars.forEach(function(car){c.globalAlpha=fa(car,tn);var a=iso(car.i,car.j),b=iso(car.ti,car.tj),dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy)||1,ux=dx/len,uy=dy/len,nx=-uy,ny=ux*.5;
    var px=a.x+dx*car.t+nx*4,py=a.y+dy*car.t+ny*4;
    if(sky!=='day'){var g=c.createRadialGradient(px+ux*10,py+uy*10,0,px+ux*10,py+uy*10,14);g.addColorStop(0,'rgba(255,240,190,.55)');g.addColorStop(1,'rgba(255,240,190,0)');c.fillStyle=g;c.beginPath();c.arc(px+ux*10,py+uy*10,14,0,7);c.fill()}
    c.fillStyle='rgba(0,0,0,.25)';poly(c,[[px-ux*5-nx*2.5+1,py-uy*5-ny*2.5+1.5],[px+ux*5-nx*2.5+1,py+uy*5-ny*2.5+1.5],[px+ux*5+nx*2.5+1,py+uy*5+ny*2.5+1.5],[px-ux*5+nx*2.5+1,py-uy*5+ny*2.5+1.5]]);c.fill();
    poly(c,[[px-ux*5-nx*2.5,py-uy*5-ny*2.5-2],[px+ux*5-nx*2.5,py+uy*5-ny*2.5-2],[px+ux*5+nx*2.5,py+uy*5+ny*2.5-2],[px-ux*5+nx*2.5,py-uy*5+ny*2.5-2]],mix(car.col,P.light<1?.75:1));
    poly(c,[[px-ux*2-nx*2,py-uy*2-ny*2-4],[px+ux*2.5-nx*2,py+uy*2.5-ny*2-4],[px+ux*2.5+nx*2,py+uy*2.5+ny*2-4],[px-ux*2+nx*2,py-uy*2+ny*2-4]],mix(car.col,1.15));
    if(sky!=='day'){c.fillStyle='#FF4A4A';c.fillRect(px-ux*5-1,py-uy*5-3,2,1.5)}});c.globalAlpha=1}
function drawLive(){var c=cx;c.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);
  var tn=performance.now();pulses=pulses.filter(function(p){return tn-p.born<3200});
  if(pulses.length){c.save();c.globalCompositeOperation='lighter';pulses.forEach(function(p){var pr=(tn-p.born)/3200,r=12+pr*(p.big?90:60);c.strokeStyle=p.col;c.globalAlpha=1-pr;c.lineWidth=2.5;c.shadowColor=p.col;c.shadowBlur=12;c.beginPath();c.ellipse(p.x,p.y,r,r*.5,0,0,7);c.stroke();
    if(p.big){var g=c.createLinearGradient(0,p.y-260,0,p.y);g.addColorStop(0,'rgba(255,210,63,0)');g.addColorStop(1,'rgba(255,210,63,.85)');c.fillStyle=g;c.globalAlpha=(1-pr)*.9;c.fillRect(p.x-3,p.y-260,6,260)}});c.restore()}
  Object.keys(LV.d).forEach(function(k){var b=byName[k],x=LV.d[k];if(!b||!(x.level>0))return;var p=iso(b.x+b.k/2-.5,b.y+b.k/2-.5),pr=(tn%2000)/2000;
    c.save();c.globalCompositeOperation='lighter';c.strokeStyle='rgba(255,255,255,'+(.35*(1-pr))+')';c.lineWidth=1.5;c.beginPath();c.ellipse(p.x,p.y,(b.k*TW/2)*(.6+pr*.5),(b.k*TH/2)*(.6+pr*.5),0,0,7);c.stroke();c.restore();
    if(LV.mode==='private'&&x.now>0){var f=iso(b.x+b.k,b.y+b.k);tronPill(c,f.x,f.y+18,'\u25CF '+x.now+' live','#FFFFFF','600 10px ui-monospace,monospace')}});
  // cranes slowly rotate their jibs
  cranes.forEach(function(k){var mx=k.x,my=k.y,mh=30,a=T/2400+k.seed%6;if(sky==='grid'){c.save();c.shadowColor=k.col;c.shadowBlur=6}c.strokeStyle=sky==='grid'?k.col:'#E9A92C';c.lineWidth=1.2;c.beginPath();c.moveTo(mx-1.5,my);c.lineTo(mx-1.5,my-mh);c.moveTo(mx+1.5,my);c.lineTo(mx+1.5,my-mh);for(var z=0;z<mh;z+=5){c.moveTo(mx-1.5,my-z);c.lineTo(mx+1.5,my-z-5)}c.stroke();
    var jx=Math.cos(a)*30,jy=Math.sin(a)*15;c.lineWidth=1.6;c.beginPath();c.moveTo(mx-jx*.35,my-mh-jy*.35);c.lineTo(mx+jx,my-mh+jy);c.stroke();c.fillStyle='#7A7F8A';c.fillRect(mx-jx*.35-2,my-mh-jy*.35-1,4,4);
    var hx=mx+jx*.7,hy=my-mh+jy*.7;c.strokeStyle='rgba(60,60,60,.8)';c.lineWidth=.6;c.beginPath();c.moveTo(hx,hy);c.lineTo(hx,hy+12+Math.sin(T/700+k.seed)*3);c.stroke();c.fillStyle=sky==='grid'?k.col:'#E9A92C';c.fillRect(hx-2,hy+12+Math.sin(T/700+k.seed)*3,4,3);
    if((sky==='night'||sky==='grid')&&Math.floor(T/700+k.seed)%2){c.fillStyle='#FF5040';c.beginPath();c.arc(mx,my-mh-2,1.6,0,7);c.fill()}if(sky==='grid')c.restore()});
  if(P.lamp){c.globalCompositeOperation='lighter';lamps.forEach(function(l){var g=c.createRadialGradient(l.x+3,l.y-15,0,l.x+3,l.y-6,26);g.addColorStop(0,'rgba(255,214,140,'+(.35*P.lamp)+')');g.addColorStop(1,'rgba(255,214,140,0)');c.fillStyle=g;c.beginPath();c.arc(l.x+3,l.y-8,26,0,7);c.fill()});c.globalCompositeOperation='source-over'}
  if(sky==='grid'){c.globalCompositeOperation='lighter';beacons.forEach(function(b){var pr=(T%2400)/2400,g=c.createRadialGradient(b.x,b.y,0,b.x,b.y,30*pr+4);g.addColorStop(0,'rgba(255,255,255,.0)');g.addColorStop(.8,'rgba(61,242,255,'+(.5*(1-pr))+')');g.addColorStop(1,'rgba(61,242,255,0)');c.fillStyle=g;c.beginPath();c.ellipse(b.x,b.y,30*pr+4,(30*pr+4)*.5,0,0,7);c.fill()});c.globalCompositeOperation='source-over';return}
  beacons.forEach(function(b){if(Math.floor(T/900)%2){c.fillStyle='#FF3B30';c.beginPath();c.arc(b.x,b.y,2,0,7);c.fill();if(sky!=='day'){c.globalCompositeOperation='lighter';var g=c.createRadialGradient(b.x,b.y,0,b.x,b.y,10);g.addColorStop(0,'rgba(255,60,48,.6)');g.addColorStop(1,'rgba(255,60,48,0)');c.fillStyle=g;c.beginPath();c.arc(b.x,b.y,10,0,7);c.fill();c.globalCompositeOperation='source-over'}}})}
// ---- window glow from live visitors: the hub sends each district's glow (visitors in the last 30 minutes, each fading
// over 30 minutes), and lit windows ease toward it: a busy site lights up, then dims to dark as people leave
var GT={},GL={},GS={},glowAt=0,glowDraw=0;
  // which building a visit belongs to. The hub sends each district's visited sites (hostnames). A repo that lists the site
  // (its website on GitHub, or "sites" in city.json) owns it; otherwise the one repo named like the site ("relay" for
  // relay.example.com). A site no repo owns puts nobody anywhere: people only ever stand where the visitors really are.
  function sNorm(x){return String(x||'').toLowerCase().replace(/[^a-z0-9]/g,'')}
  // a site is a host ("kitse.co", also owning its subdomains) or a page ("mjonesone.com/dictate", owning only visits the hub
  // reports for that path). A path site never takes a whole host's visitors: nobody stands where they weren't.
  function sHostOwns(sites,h){if(!sites||!h||h.indexOf('.')<0)return false;var hh=h.split('/')[0];for(var i=0;i<sites.length;i++){var s=String(sites[i]);
    if(s.indexOf('/')>=0){if(h===s||h.indexOf(s+'/')===0)return true;continue}if(hh===s||hh.slice(-s.length-1)==='.'+s)return true}return false}
  function sWord(h){var l=String(h).split('.');while(l.length>2&&/^(www|app|m|my|go|get|beta|staging)$/.test(l[0]))l.shift();return sNorm(l[0])}
  var SBK=null,SBT=null,SBG=null,SBAt=0;
  // a building's sites, plus those of the websites whose signs hang on it (their visitors walk into this building)
  function tSites(t){var L=SFA.get(t.r);if(!L)return t.r.sites;if(t._st)return t._st;var o=(t.r.sites||[]).slice();L.forEach(function(s){if(s.r!==t.r)(s.r.sites||[]).forEach(function(x){if(o.indexOf(x)<0)o.push(x)})});return t._st=o}
  function siteBook(){if(SBK&&SBT===tiles&&SBG===GS&&(!BUILDING||T-SBAt<1000))return SBK;SBT=tiles;SBG=GS;SBAt=T;SBK=new Map();var by={},k,dn;   // rebuilt when the layout or the live data changes
    var stores=[];for(k in tiles){var t=tiles[k];if(!t||t.t!=='b'||!t.d||!t.r||!t.r.name)continue;(by[t.d.name]||(by[t.d.name]=[])).push(t);if((SFA.get(t.r)||[]).some(function(s){return s.r.kind==='site'}))stores.push(t)}
    for(dn in by){var ts=by[dn],d=ts[0].d,ds=GS[d.name]||(d.nb&&GS[d.nb])||null;if(!ds)continue;var mx=0;for(k in ds)mx=Math.max(mx,ds[k]);
      for(k in ds){var share=ds[k]/(mx||1),own=ts.filter(function(t){return sHostOwns(tSites(t),k)}),kk=k;
        var pth=own.filter(function(t){return (tSites(t)||[]).some(function(x){x=String(x);return x.indexOf('/')>=0&&(kk===x||kk.indexOf(x+'/')===0)})});if(pth.length)own=pth;   // a page (host/path) beats its bare host
        if(!own.length){var w=k.indexOf('.')<0?sNorm(k):sWord(k),best=null,bs=0;
          if(w.length>=3)ts.forEach(function(t){var rn=sNorm(t.r.name),sc=rn===w?1000:(w.length>=4&&rn.indexOf(w)>=0)||(rn.length>=4&&w.indexOf(rn)>=0)?100-Math.abs(rn.length-w.length):0;
            if(sc>bs&&!(tSites(t)&&tSites(t).length&&sc<1000)){bs=sc;best=t}});   // a repo that names its own sites isn't guessed into another
          if(best)own=[best];else own=stores.filter(function(t){return t.d!==d&&sHostOwns(tSites(t),k)})}   // a listed website standing in another district
        own.forEach(function(t){SBK.set(t.r,Math.max(SBK.get(t.r)||0,share))})}}
    return SBK}
  function siteGlowOf(t){var gw=glowOf(t.d);if(!(gw>0)||!t.r)return 0;return gw*(siteBook().get(t.r)||0)}
function stepGlow(tn){var dt=Math.min(1000,tn-(glowAt||tn));glowAt=tn;var moving=false,ks={},k;for(k in GT)ks[k]=1;for(k in GL)ks[k]=1;
  for(k in ks){var g=GL[k]||0,t=GT[k]||0;if(Math.abs(t-g)<.003){if(t)GL[k]=t;else delete GL[k];continue}GL[k]=g+(t-g)*Math.min(1,dt/2200);moving=true}
  if(moving&&tn-glowDraw>220){glowDraw=tn;dirty=true}}
function glowOf(d){return d?(GL[d.name]||(d.nb&&GL[d.nb])||0):0}
var lastPT=0;function frame(){T=performance.now();if(BUILDING&&bActive())dirty=true;stepGlow(T);if(L1.width!==cv.width||L1.height!==cv.height){L1.width=L2.width=L3.width=cv.width;L1.height=L2.height=L3.height=cv.height;dirty=true}
  if(under){if(UL.width!==cv.width||UL.height!==cv.height){UL.width=cv.width;UL.height=cv.height;UDIRTY=true}
    if(dirty){if(sky==='grid'){tronGround();tronObjects()}else{drawGround();drawObjects()}dirty=false;UDIRTY=true}if(UDIRTY){drawUnder();UDIRTY=false}
    cx.setTransform(1,0,0,1,0,0);cx.fillStyle='#03020A';cx.fillRect(0,0,cv.width,cv.height);
    cx.globalAlpha=.32;cx.drawImage(L1,0,0);cx.globalAlpha=.22;cx.drawImage(L2,0,0);cx.globalAlpha=1;cx.drawImage(UL,0,0);
    cx.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);drawUnderLive(cx,performance.now());return}
  if(dirty){if(sky==='grid'){tronGround();tronObjects()}else{drawGround();groundIntro(c1);drawObjects()}dirty=false}
  var tn0=performance.now(),dts=lastPT?Math.min(200,tn0-lastPT)/1000:0;lastPT=tn0;if(sky!=='grid'){stepClouds(tn0);stepPrecip(dts)}stepWalks(tn0);
  drawSky();cx.setTransform(1,0,0,1,0,0);cx.drawImage(L1,0,0);drawTopics();drawTraces();drawCars();drawWalks();drawVis();cx.setTransform(1,0,0,1,0,0);cx.drawImage(L2,0,0);drawShimmer();drawRays();drawLit();drawWeather();drawLive();drawFx();cx.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);drawAgents(cx,performance.now());drawHelis(cx,performance.now());if(WORLD){cx.setTransform(1,0,0,1,0,0);cx.drawImage(L3,0,0)}
  cx.setTransform(dpr,0,0,dpr,0,0);var v=cx.createRadialGradient(vw/2,vh/2,Math.min(vw,vh)*.35,vw/2,vh/2,Math.max(vw,vh)*.75);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(0,0,0,'+(sky==='day'?.12:sky==='grid'?.5:.3)+')');cx.fillStyle=v;cx.fillRect(0,0,vw,vh)}
function draw(){dirty=true;UDIRTY=true;if(reduce)frame()}
var last=0,FPS_MS=MINI?50:30;function tick(ts){if(!document.hidden&&ts-last>FPS_MS){last=ts;cars.forEach(function(c){c.t+=sky==='grid'?0.035:0.02;if(c.t>=1)step(c);var p=carPos(c);(c.trail=c.trail||[]).push([p.x,p.y-1]);if(c.trail.length>34)c.trail.shift()});
  if(LV.on){var tg=performance.now();cars=cars.filter(function(c){return !c.gone||tg-c.gone<1500})}
  if(vis.length){var tn=performance.now();vis=vis.filter(function(v){return tn-v.born<v.life});vis.forEach(function(v){v.t+=v.sp;if(v.t>=1)step(v);var p=carPos(v);(v.trail=v.trail||[]).push([p.x,p.y-1]);if(v.trail.length>26)v.trail.shift()})}frame()}requestAnimationFrame(tick)}
// ---- interaction
function ago(iso){if(!iso)return '';var d=Math.round((now-Date.parse(iso))/DAY);return d<=0?'today':d===1?'yesterday':d+' days ago'}
function e(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function agentCard(id){var g=AG[id];if(!g)return show(null);var a=g.a,st={working:'working',thinking:'thinking',waiting:'waiting for you',idle:'idle',done:'done'}[a.state]||a.state;sel={agent:id};
  var where=a.d?e(a.d)+' district':'not in a district';
  card.classList.remove('is-dir');card.innerHTML='<button class="x" aria-label="Close">&times;</button>'+(a.label||a.task!=null?'<h3>'+e(a.label||'Agent')+'</h3><div class="k">'+e(a.machine||'')+(a.machine?' &middot; ':'')+st+(a.ago!=null?' &middot; '+(a.ago<60?a.ago+'s':Math.round(a.ago/60)+' min')+' ago':'')+'</div>'
     +(a.task?'<p style="margin:6px 0 0">'+e(a.task)+'</p>':'')+(a.did?'<div class="row"><span>Last step</span><b style="text-align:right">'+e(a.did)+'</b></div>':'')
     +'<div class="row"><span>Where</span><b>'+(a.repo?e(a.repo)+' &middot; ':'')+where+'</b></div>'+(a.tokens?'<div class="row"><span>Tokens today</span><b>'+(+a.tokens).toLocaleString('en-US')+'</b></div>':'')
    :'<h3>AI agent</h3><p style="margin:6px 0 0">An agent is '+st+(a.d?' in the '+where:'')+'. What it is working on is private.</p>');
  card.hidden=false;card.querySelector('.x').onclick=function(){show(null)};draw()}
function show(h){if(h&&h.note!=null)return noteCard(h.note);if(under&&!h){usel=null;UDIRTY=true;card.hidden=true;return}if(h&&h.agent)return agentCard(h.agent);sel=h?h.r:null;if(!h){card.hidden=true;draw();return}if(h.r&&h.r.kind)return listingCard(h);var r=h.r,d=h.d,mx=Math.max.apply(null,(r.weeks||[0]).concat([1]));
  var notes=(d.notePaths||[]).map(function(p){var n=p.split('/').pop().replace(/\.md$/,'');return D.openBase?'<a href="'+e(D.openBase+encodeURIComponent(p))+'" target="_blank" rel="noopener">'+e(n)+'</a>':'<a href="#" data-open="'+e(p)+'">'+e(n)+'</a>'}).join(', ');
  if(r.locked){card.classList.remove('is-dir');card.innerHTML='<button class="x" aria-label="Close">&times;</button><h3>&#128274; Private '+(D.kind==='vault'?'folder':'repo')+'</h3><div class="k">'+e(d.name)+' district</div><p style="margin:8px 0 0">'+(d.apart?'This person keeps private work anonymous: these padlocks don\'t show how many repos there are, how big they are, which projects they belong to or when they were busy.':'The details of this building are private. Its size and lights show roughly how much work goes on inside.')+'</p>';card.hidden=false;card.querySelector('.x').onclick=function(){show(null)};draw();return}
  card.classList.remove('is-dir');card.innerHTML='<button class="x" aria-label="Close">&times;</button><h3>'+e(r.name)+'</h3><div class="k">'+e(d.name)+' district &middot; '+e(r.language)+(r.public?' &middot; public':r.priv?' &middot; &#128274; private repo, code not shared':'')+'</div>'
   +(r.description?'<p style="margin:6px 0 0">'+e(r.description)+'</p>':'')
   +'<div class="sp" title="Commits, last 12 weeks">'+(r.weeks||[]).map(function(w){return '<i style="height:'+Math.max(4,Math.round(w/mx*100))+'%"></i>'}).join('')+'</div><div class="k">Commits, last 12 weeks</div>'
   +'<div class="row"><span>Commits this year</span><b>'+r.commits.toLocaleString('en-US')+'</b></div><div class="row"><span>This week</span><b>'+r.week+'</b></div>'
   +(r.pushed?'<div class="row"><span>Last push</span><b>'+ago(r.pushed)+'</b></div>':'')
   +'<div class="row"><span>Notes about '+e(d.name)+'</span><b>'+d.notes+'</b></div>'+(notes?'<div class="k" style="margin-top:6px">'+notes+'</div>':'')
   +(r.url?'<p style="margin:8px 0 0"><a href="'+e(r.url)+'" target="_blank" rel="noopener">Open on GitHub &#8599;</a></p>':'')
   +(D.world&&d.nb&&r.public&&!r.locked?giftHtml(d.nb,r.name):'');
  card.hidden=false;card.querySelector('.x').onclick=function(){show(null)};giftWire(function(){show(h)});draw()}
function at(px,py){if(under){var wx0=(px-cam.x)/cam.z,wy0=(py-cam.y)/cam.z,best=null,bd=1e9;UP.forEach(function(p,ix){var d=Math.hypot(p.x-wx0,p.y-wy0);if(d<Math.max(p.r+3,7/cam.z)&&d<bd){bd=d;best=ix}});return best==null?null:{note:best}}
  if(labels){var tx=(px-cam.x)/cam.z,ty=(py-cam.y)/cam.z;for(var ti=tagHits.length-1;ti>=0;ti--){var th=tagHits[ti];if(tx>=th.x0&&tx<=th.x1&&ty>=th.y0&&ty<=th.y1)return th.shop?{shop:1}:th.block?{block:th.block}:{url:th.url}}}
  for(var aid in AG){var g=AG[aid];if(!g.gone&&g.sx!=null&&Math.hypot(px-g.sx,py-g.sy)<Math.max(12,14*cam.z))return {agent:aid}}var wx=(px-cam.x)/cam.z,wy=(py-cam.y)/cam.z;for(var i=hits.length-1;i>=0;i--){var h=hits[i];if(wx>=h.x0&&wx<=h.x1&&wy>=h.y0&&wy<=h.y1)return h}return null}
var ptr={},moved=false,pinch=0;
cv.addEventListener('pointerdown',function(ev){cv.setPointerCapture(ev.pointerId);ptr[ev.pointerId]={x:ev.clientX,y:ev.clientY};moved=false;cv.classList.add('drag');var ks=Object.keys(ptr);if(ks.length===2){var a=ptr[ks[0]],b=ptr[ks[1]];pinch=Math.hypot(a.x-b.x,a.y-b.y)}});
cv.addEventListener('pointermove',function(ev){var p=ptr[ev.pointerId];if(!p)return;var ks=Object.keys(ptr);
  if(ks.length===2){var o=ptr[ks[0]===String(ev.pointerId)?ks[1]:ks[0]];var dist=Math.hypot(ev.clientX-o.x,ev.clientY-o.y);if(pinch){var r=st.getBoundingClientRect();zoom(dist/pinch,(ev.clientX+o.x)/2-r.left,(ev.clientY+o.y)/2-r.top)}pinch=dist;moved=true}
  else{var dx=ev.clientX-p.x,dy=ev.clientY-p.y;if(Math.abs(dx)+Math.abs(dy)>3)moved=true;cam.x+=dx;cam.y+=dy}
  p.x=ev.clientX;p.y=ev.clientY;draw()});
function up(ev){var was=ptr[ev.pointerId];delete ptr[ev.pointerId];cv.classList.remove('drag');pinch=0;if(was&&!moved){var r=st.getBoundingClientRect(),h=at(ev.clientX-r.left,ev.clientY-r.top);
  if(h&&h.shop)return shopCard();
  if(h&&h.block)return worldFocus(h.block);
  if(h&&h.url)return openRepo(h.url);
  if(MINI&&h&&h.r)return openRepo(repoUrl(h.r));   // the pop-out has no room for cards: a public building opens its repo
  show(h)}}
if(/[#&]test\b/.test(location.hash))window.calderaTest={   // #test: hit boxes in page coordinates, for automated checks
  buildings:function(){var b=st.getBoundingClientRect();return hits.filter(function(h){return h.r}).map(function(h){return {name:h.r.locked?'':h.r.name,locked:!!h.r.locked,url:repoUrl(h.r),x:b.left+cam.x+(h.x0+h.x1)/2*cam.z,y:b.top+cam.y+(h.y0*.35+h.y1*.65)*cam.z}})},
  world:function(){return WLAB.map(function(l){return {text:l.text,pr:l.pr,x0:l.x0,x1:l.x1,y0:l.y0,y1:l.y1}})},
  zoomTo:function(k,z){var n=NBM[k];if(!n)return false;var c=iso(n.ox+n.w/2-.5,n.oy+n.h/2-.5);cam.z=z;cam.x=vw/2-c.x*z;cam.y=vh/2-c.y*z;draw();return true},
  rays:function(on){RAYS=on;return RAYS},
  wlabels:function(){var b=st.getBoundingClientRect();return (WLAB||[]).map(function(q){return {text:q.text,pr:q.pr,x0:b.left+q.x0,x1:b.left+q.x1,y0:b.top+q.y0,y1:b.top+q.y1}})},   // world labels as placed (screen rects)
  labels:function(){var b=st.getBoundingClientRect();return tagHits.map(function(t){return {url:t.url,b:t.block?t.block.d.name:'',x:b.left+cam.x+(t.x0+t.x1)/2*cam.z,y:b.top+cam.y+(t.y0+t.y1)/2*cam.z}})},
  walks:function(){var b=st.getBoundingClientRect(),tn=performance.now();return WALKS.filter(function(w){return tn>=w.born}).map(function(w){var p=walkAt(w);return {id:w.id,ghost:w.ghost,f:w.d/w.len,x:b.left+cam.x+p.x*cam.z,y:b.top+cam.y+p.y*cam.z}})},
  traces:function(){var r=st.getBoundingClientRect();return TRACES.map(function(t){var m=t.pts[Math.floor(t.pts.length/2)];return {a:t.a,x:r.left+cam.x+m.x*cam.z,y:r.top+cam.y+m.y*cam.z}})},
  clouds:function(){return CLOUDS.map(function(c){return {x:c.x,y:c.y,gone:c.gone}})},
  weather:function(){return {kind:wxKind(),mode:WXMODE,wx:WX,phase:phase,keys:DAYKEYS}},
  fx:function(){return {drops:FX.drops.length,queue:FX.queue.length,parts:FX.parts.length,beams:FX.beams.length,more:Object.keys(FX.more).length,z:cam.z}},
  point:function(locked){var b=st.getBoundingClientRect();for(var i=0;i<hits.length;i++){var h=hits[i];if(!h.r||!!h.r.locked!==locked||(!locked&&!repoUrl(h.r)))continue;
    for(var fy=.2;fy<.95;fy+=.1)for(var fx=.2;fx<.85;fx+=.15){var wx=h.x0+(h.x1-h.x0)*fx,wy=h.y0+(h.y1-h.y0)*fy,sx=cam.x+wx*cam.z,sy=cam.y+wy*cam.z,g=at(sx,sy);
      if(g&&g.r===h.r)return {x:b.left+sx,y:b.top+sy,url:repoUrl(h.r)}}}return null}};
cv.addEventListener('dblclick',function(ev){var r=st.getBoundingClientRect(),h=at(ev.clientX-r.left,ev.clientY-r.top);if(h&&h.r&&!MINI)openRepo(repoUrl(h.r))});
cv.addEventListener('pointermove',function(ev){if(Object.keys(ptr).length)return;var r=st.getBoundingClientRect(),h=at(ev.clientX-r.left,ev.clientY-r.top);
  cv.classList.toggle('c-link',!!(h&&(h.url||h.block||(h.r&&repoUrl(h.r)))));
  if(WORLD){var hk=h&&h.block?(h.block.d.nb||h.block.d.name):h&&h.d?(h.d.nb||h.d.name):null;if(hk!==WHOVER){WHOVER=hk;cv.title=hk?rayWhy(hk):'';if(reduce)frame()}}});
cv.addEventListener('pointerleave',function(){if(WHOVER){WHOVER=null;cv.title='';if(reduce)frame()}});
// /world?focus=<handle> (the World link on a profile): fly straight to that person's neighborhood
if(D.world){try{var FQ=(new URLSearchParams(location.search).get('focus')||'').toLowerCase().replace(/^@/,'');if(FQ&&byName['@'+FQ])setTimeout(function(){worldFocus(byName['@'+FQ])},700)}catch(err){}}
function rayWhy(k){var out=[];((WORLD&&WORLD.links)||[]).forEach(function(l){if(l[0]!==k&&l[1]!==k)return;var o=l[0]===k?l[1]:l[0];out.push(o+(l[2]===2&&l[3]?': both work on '+l[3]:l[2]===3&&l[3]?': '+l[3]:l[2]===4?': similar stack'+(l[3]?' ('+l[3]+')':''):l[2]===1?': welcome link':': friends'))});return out.length?k+' is connected to '+out.slice(0,8).join(', ')+(out.length>8?' and '+(out.length-8)+' more':''):''}
cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up);
function zoom(f,ox,oy){var z=Math.min(3,Math.max(D.world?.08:.25,cam.z*f));f=z/cam.z;cam.x=ox-(ox-cam.x)*f;cam.y=oy-(oy-cam.y)*f;cam.z=z;draw()}
cv.addEventListener('wheel',function(ev){ev.preventDefault();var r=st.getBoundingClientRect();zoom(Math.exp(-ev.deltaY*0.0015),ev.clientX-r.left,ev.clientY-r.top)},{passive:false});
var bl=document.getElementById('t-labels'),bs=document.getElementById('t-sky');
var btp=document.getElementById('t-topics');if(btp){btp.setAttribute('aria-pressed',String(TOPICS));topicLegend();btp.onclick=function(){TOPICS=!TOPICS;btp.setAttribute('aria-pressed',String(TOPICS));try{localStorage.setItem('caldera-world-topics',TOPICS?'1':'0')}catch(err){}topicLegend();if(reduce)frame()}}
var bfr=document.getElementById('t-fr');if(bfr){bfr.setAttribute('aria-pressed',String(RAYS));bfr.onclick=function(){RAYS=!RAYS;bfr.setAttribute('aria-pressed',String(RAYS));try{localStorage.setItem('caldera-world-rays',RAYS?'1':'0')}catch(err){}if(reduce)frame()}}
var LTXT={smart:'Labels',all:'All labels',off:'Labels off'},LTIP={smart:'Labels: the most relevant names that fit. Zoom in for more. Tap for all',all:'All labels that fit. Tap to hide labels',off:'Labels hidden. Tap for smart labels'};
function lblBtn(){bl.setAttribute('aria-pressed',String(labels));if(WORLD&&!MINI){bl.textContent=LTXT[LMODE];bl.title=LTIP[LMODE]}}
lblBtn();bl.onclick=function(){if(WORLD&&!MINI){LMODE=LMODES[(LMODES.indexOf(LMODE)+1)%LMODES.length];labels=LMODE!=='off';try{localStorage.setItem('caldera-world-labels',LMODE)}catch(err){}}else labels=!labels;lblBtn();draw()};
var MN={auto:'Auto',grid:'Grid',dawn:'Dawn',day:'Day',dusk:'Dusk',evening:'Evening',night:'Night'};
var SKYIC={auto:'',grid:'\u25A6',dawn:'\uD83C\uDF05',day:'\u2600\uFE0F',dusk:'\uD83C\uDF07',evening:'\uD83C\uDF06',night:'\uD83C\uDF19'};
function skyLabel(){var m=SKYMODE==='auto'?phase:SKYMODE;bs.innerHTML=(SKYIC[m]||'')+'<span class="t-txt"> '+(SKYMODE==='auto'?'Auto \u00b7 '+MN[phase]:MN[SKYMODE])+'</span>';bs.title='Lighting: '+(SKYMODE==='auto'?'follows your clock (now '+MN[phase].toLowerCase()+')':MN[SKYMODE].toLowerCase())+'. Click for the next one.'}
skyLabel();bs.onclick=function(){SKYMODE=MODES[(MODES.indexOf(SKYMODE)+1)%MODES.length];try{localStorage.setItem('caldera-sky',SKYMODE)}catch(err){}applySky();skyLabel();draw()};
setInterval(function(){if(SKYMODE!=='auto')return;var k=palKey;applySky();skyLabel();if(palKey!==k)draw()},60000);
setInterval(function(){if(TODAY){buildTraces();todayLine()}},5*60000);   // footprints fade through the day and reset at local midnight
var bw=document.getElementById('t-wx');function wxLabel(){if(!bw)return;var k=wxKind(),ic={clear:'\u2600\uFE0F',partly:'\u26C5',overcast:'\u2601\uFE0F',fog:'\uD83C\uDF2B\uFE0F',drizzle:'\uD83C\uDF26\uFE0F',rain:'\uD83C\uDF27\uFE0F',storm:'\u26C8\uFE0F',snow:'\uD83C\uDF28\uFE0F'}[k]||'';
  bw.innerHTML=ic+'<span class="t-txt"> '+(WXMODE==='auto'?'Auto':WXN[WXMODE]||k)+'</span>';bw.title='Weather: '+(WXMODE==='auto'?(WX&&WX.c?'your local weather'+(WX.place?' in '+WX.place:'')+' ('+k+')':'clear (no local weather yet)'):WXN[WXMODE]||k)+'. Click for the next one.'}
if(bw){wxLabel();bw.onclick=function(){WXMODE=WXMODES[(WXMODES.indexOf(WXMODE)+1)%WXMODES.length];try{localStorage.setItem('caldera-weather',WXMODE)}catch(err){}PRECIP.length=0;wxLabel();draw()}}   // an all-day window drifts through the day
document.getElementById('t-reset').onclick=function(){WFOCUS=null;fit();show(null)};
var bsnd=document.getElementById('t-snd');function sndLabel(){bsnd.innerHTML=sound?'&#x1F50A;':'&#x1F507;';bsnd.setAttribute('aria-pressed',String(sound));bsnd.title='Sound for arrivals, signups and sales ('+(sound?'on':'off')+')'}
if(bsnd){sndLabel();bsnd.onclick=function(){sound=!sound;try{localStorage.setItem('caldera-sound',sound?'1':'0')}catch(err){}sndLabel();if(sound)tone([660,880],.06)}}
var bu=document.getElementById('t-under');if(bu)bu.onclick=function(){under=!under;bu.setAttribute('aria-pressed',String(under));bu.innerHTML=under?'&#x2B06;<span class="t-txt"> City</span>':'&#x2B07;<span class="t-txt"> Underground</span>';
  st.classList.toggle('c-dig',under);if(liveEl)liveEl.hidden=under;usel=null;card.hidden=true;underPanel();fit();draw()};
if(U&&/[#&]underground\b/.test(location.hash))setTimeout(function(){bu&&bu.onclick()},50);
// full screen: the real Fullscreen API where the page is allowed it, otherwise the stage fills the window (Esc exits)
var bf=document.getElementById('t-full');function fsLabel(){var on=!!document.fullscreenElement||st.classList.contains('c-full');bf.innerHTML=on?'&#x2715;<span class="t-txt"> Exit</span>':'&#x26F6;<span class="t-txt"> Full screen</span>';bf.setAttribute('aria-label',on?'Exit full screen':'Full screen')}
function cssFull(on){st.classList.toggle('c-full',on);document.body.style.overflow=on?'hidden':'';setTimeout(function(){fit();draw()},30);fsLabel()}
bf.onclick=function(){if(document.fullscreenElement){document.exitFullscreen();return}if(st.classList.contains('c-full'))return cssFull(false);
  var r=st.requestFullscreen&&document.fullscreenEnabled?st.requestFullscreen():null;if(r&&r.catch)r.catch(function(){cssFull(true)});else cssFull(true)};
// pop out: inside Obsidian the plugin opens an always-on-top window; on the web a small window opens the watch page
// (the hub's own page, which can float the city on top in Chrome/Edge); elsewhere this page in mini mode
var bp=document.getElementById('t-pop');if(bp){if(MINI)bp.hidden=true;bp.onclick=function(){
  if(window.parent!==window){parent.postMessage({caldera:'popout'},'*');return}
  var m=location.pathname.match(/^\/@([a-z0-9-]+)\//),u=m?'/watch/@'+m[1]+location.search:location.href.split('#')[0]+'#mini';
  var w=window.open(u,'caldera-city','popup,width=440,height=290');if(!w)location.href=u}}
document.addEventListener('fullscreenchange',function(){setTimeout(function(){fit();draw()},30);fsLabel()});
document.addEventListener('keydown',function(ev){if(ev.key==='Escape'&&st.classList.contains('c-full'))cssFull(false)});
document.addEventListener('keydown',function(ev){if(ev.key==='Escape'&&!card.hidden&&card.classList.contains('is-dir')){ev.preventDefault();show(null);var b=document.getElementById('t-stores');if(b)b.focus()}});
(function(){var n=storeList(null).length,tb=st.querySelector('.c-tools');if(!n||!tb||MINI)return;var b=document.createElement('button');b.id='t-stores';b.type='button';b.title='Every storefront in this '+(D.world?'world':'city');
  b.innerHTML='&#x1F3EA;<span class="t-txt"> Stores ('+n+')</span>';b.setAttribute('aria-label','Stores ('+n+')');b.onclick=function(){if(!card.hidden&&card.classList.contains('is-dir')){show(null);return}storeDir(null,null,true)};
  var ref=tb.querySelector('#t-reset');tb.insertBefore(b,ref||null)})();
window.addEventListener('resize',function(){fit();draw()});
fit();
if(reduce)frame();else{cityIntro();requestAnimationFrame(tick)}
})();`;

// src/gitlines.ts
var PROTECTED = /* @__PURE__ */ new Set(["Library", "Desktop", "Documents", "Downloads", "Pictures", "Movies", "Music", "Public", "Applications", "Dropbox", "Google Drive", "OneDrive", "Creative Cloud Files", "node_modules"]);
var CODE_DIRS = ["code", "Code", "src", "dev", "Dev", "projects", "Projects", "repos", "git", "GitHub", "github", "work", "Developer", "Sites", "workspace"];
var GENERATED = /(^|\/)(node_modules|dist|build|out|vendor|third_party|\.next|coverage|__pycache__)\/|(^|\/)(package-lock\.json|npm-shrinkwrap\.json|yarn\.lock|pnpm-lock\.yaml|bun\.lockb?|Cargo\.lock|poetry\.lock|Pipfile\.lock|uv\.lock|Gemfile\.lock|composer\.lock|go\.sum)$|\.min\.(js|css)$|\.(map|snap)$/;
var MAX_FILE_LINES = 5e3;
var MAX_REPOS = 80;
function parseNumstat(out, into = {}) {
  for (const rec of out.split("")) {
    const lines = rec.split("\n"), head2 = (lines[0] || "").split(""), day = (head2[0] || "").trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) continue;
    for (const l of lines.slice(1)) {
      const m = /^(\d+)\t(\d+)\t(.+)$/.exec(l.trim());
      if (!m) continue;
      const a = Number(m[1]), d = Number(m[2]), file = m[3].replace(/^.*=> /, "").replace(/[{}]/g, "");
      if (GENERATED.test(file) || a > MAX_FILE_LINES || d > MAX_FILE_LINES) continue;
      const e = into[day] || (into[day] = { added: 0, removed: 0 });
      e.added += a;
      e.removed += d;
    }
  }
  return into;
}
var run = (m, args, cwd) => new Promise((res, rej) => m.cp.execFile("git", args, { cwd, timeout: 15e3, maxBuffer: 32 * 1024 * 1024, windowsHide: true, env: { ...process.env, GIT_TERMINAL_PROMPT: "0", LC_ALL: "C" } }, (err, stdout) => err ? rej(err) : res(String(stdout))));
async function findRepos(m, days, extra = []) {
  const { fs, path, os } = m, home = os.homedir(), since = Date.now() - (days + 1) * 864e5;
  const kids = async (dir) => {
    try {
      return (await fs.promises.readdir(dir, { withFileTypes: true })).filter((e) => e.isDirectory() && !e.name.startsWith(".") && !PROTECTED.has(e.name)).map((e) => path.join(dir, e.name));
    } catch {
      return [];
    }
  };
  const roots = [home, ...CODE_DIRS.map((d) => path.join(home, d)), ...extra.map((x) => x.trim().replace(/^~(?=$|\/)/, home)).filter(Boolean)];
  const cand = [];
  for (const r of roots) {
    if (r !== home) cand.push(r);
    cand.push(...await kids(r));
  }
  const out = [], seen = /* @__PURE__ */ new Set();
  for (const c of cand) {
    if (out.length >= MAX_REPOS) break;
    try {
      const g = path.join(c, ".git");
      const st = await fs.promises.stat(g);
      let t = st.mtimeMs;
      if (st.isDirectory()) {
        try {
          t = Math.max(t, (await fs.promises.stat(path.join(g, "index"))).mtimeMs, (await fs.promises.stat(path.join(g, "logs", "HEAD"))).mtimeMs);
        } catch {
        }
      }
      if (t < since) continue;
      const real = await fs.promises.realpath(c);
      if (seen.has(real)) continue;
      seen.add(real);
      out.push(c);
    } catch {
    }
  }
  return out;
}
var memo = null;
async function gitLines(m, days = 14, extra = []) {
  const key = days + "|" + extra.join(",");
  if (memo && memo.key === key && memo.at > Date.now() - 15 * 6e4) return memo.v;
  const repos = await findRepos(m, days, extra);
  let v;
  if (repos.length) {
    v = {};
    const one = async (r) => {
      let email = "";
      try {
        email = (await run(m, ["config", "user.email"], r)).trim();
      } catch {
      }
      try {
        const out = await run(m, ["log", `--since=${days}.days`, "--no-merges", "--numstat", "--date=format-local:%Y-%m-%d", "--pretty=format:%x1e%ad%x1f%ae", ...email ? [`--author=<${email.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}>`] : []], r);
        parseNumstat(out, v);
      } catch {
      }
    };
    for (let i = 0; i < repos.length; i += 4) await Promise.all(repos.slice(i, i + 4).map(one));
  }
  memo = { key, at: Date.now(), v };
  return v;
}

// src/auto.ts
async function localGitLines(days = 14, extra = []) {
  if (!import_obsidian.Platform.isDesktopApp) return void 0;
  let mods;
  try {
    const r = window.require;
    mods = { fs: r("fs"), path: r("path"), os: r("os"), cp: r("child_process") };
  } catch {
    return void 0;
  }
  return gitLines(mods, days, extra);
}
var isoLocal = (t) => {
  const d = new Date(t);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
function prettyModel(model) {
  const m = model.trim().replace(/-\d{8}$/, "").split("/").pop().replace(/\./g, "-");
  const c = m.match(/^claude-([a-z]+)-(\d+)(?:-(\d+))?/);
  if (c) return `Claude ${c[1][0].toUpperCase()}${c[1].slice(1)} ${c[2]}${c[3] ? "." + c[3] : ""}`;
  const g = m.match(/^gpt-(\d+)(?:-(\d+))?(.*)$/);
  if (g) return `GPT-${g[1]}${g[2] ? "." + g[2] : ""}${g[3] ? " " + g[3].replace(/^-/, "").replace(/-/g, " ").replace(/\b\w/g, (x) => x.toUpperCase()) : ""}`;
  return m;
}
function providerOf(name) {
  const m = name.toLowerCase();
  if (m.includes("claude")) return "Anthropic";
  if (/^(gpt|o\d|codex)/.test(m)) return "OpenAI";
  if (m.includes("gemini")) return "Google";
  if (m.includes("deepseek")) return "DeepSeek";
  if (m.includes("grok")) return "xAI";
  if (m.includes("llama")) return "Meta";
  if (m.includes("mistral")) return "Mistral";
  return "Other";
}
async function aiUsage(cachePath, windowDays = 45) {
  if (!import_obsidian.Platform.isDesktopApp) return void 0;
  let fs, path, os;
  try {
    fs = window.require("fs");
    path = window.require("path");
    os = window.require("os");
  } catch {
    return void 0;
  }
  const home = os.homedir(), since = Date.now() - (windowDays + 2) * 864e5;
  let cache = {};
  try {
    cache = JSON.parse(await fs.promises.readFile(cachePath, "utf8"));
  } catch {
  }
  const files = [];
  const walk = async (dir, kind, depth) => {
    let ents = [];
    try {
      ents = await fs.promises.readdir(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of ents) {
      const p = path.join(dir, e.name);
      if (e.isDirectory() && depth > 0) await walk(p, kind, depth - 1);
      else if (e.isFile() && e.name.endsWith(".jsonl")) files.push([p, kind]);
    }
  };
  await walk(path.join(home, ".claude", "projects"), "claude", 2);
  await walk(path.join(home, ".codex", "sessions"), "codex", 4);
  if (!files.length) return void 0;
  const next = {};
  for (const [p, kind] of files) {
    let st;
    try {
      st = await fs.promises.stat(p);
    } catch {
      continue;
    }
    if (st.mtimeMs < since) continue;
    const c = cache[p];
    if (c && c.m === st.mtimeMs && c.s === st.size) {
      next[p] = c;
      continue;
    }
    const t = {}, seen = /* @__PURE__ */ new Set();
    let text = "";
    try {
      text = await fs.promises.readFile(p, "utf8");
    } catch {
      continue;
    }
    let model = "gpt-5";
    for (const line of text.split("\n")) {
      if (kind === "claude") {
        if (!line.includes('"usage"') || !line.includes('"assistant"')) continue;
        try {
          const o = JSON.parse(line), msg = o.message || {}, u = msg.usage;
          if (!u || !msg.model || String(msg.model).startsWith("<") || !o.timestamp || seen.has(msg.id)) continue;
          seen.add(msg.id);
          const n = (u.input_tokens || 0) + (u.output_tokens || 0) + (u.cache_creation_input_tokens || 0) + (u.cache_read_input_tokens || 0);
          const d = isoLocal(Date.parse(o.timestamp));
          (t[d] || (t[d] = {}))[msg.model] = (t[d][msg.model] || 0) + n;
        } catch {
        }
      } else {
        if (!line.includes('"turn_context"') && !line.includes('"token_count"')) continue;
        try {
          const o = JSON.parse(line), pl = o.payload || {};
          if (o.type === "turn_context" && pl.model) model = pl.model;
          else if (pl.type === "token_count" && o.timestamp) {
            const n = pl.info?.last_token_usage?.total_tokens || 0;
            if (n) {
              const d = isoLocal(Date.parse(o.timestamp));
              (t[d] || (t[d] = {}))[model] = (t[d][model] || 0) + n;
            }
          }
        } catch {
        }
      }
    }
    next[p] = { m: st.mtimeMs, s: st.size, t };
    await new Promise((r) => window.setTimeout(r, 0));
  }
  try {
    await fs.promises.writeFile(cachePath, JSON.stringify(next));
  } catch {
  }
  const first = isoLocal(Date.now() - (windowDays - 1) * 864e5);
  const days = {}, models = /* @__PURE__ */ new Map();
  for (const f of Object.values(next)) for (const [d, ms] of Object.entries(f.t)) {
    if (d < first) continue;
    for (const [m, n] of Object.entries(ms)) {
      days[d] = (days[d] || 0) + n;
      const k = prettyModel(m);
      models.set(k, (models.get(k) || 0) + n);
    }
  }
  const total = Object.values(days).reduce((a, b) => a + b, 0);
  if (!total) return void 0;
  const prov = /* @__PURE__ */ new Map();
  for (const [m, n] of models) prov.set(providerOf(m), (prov.get(providerOf(m)) || 0) + n);
  return {
    total,
    window_days: windowDays,
    days,
    models: [...models].sort((a, b) => b[1] - a[1]).slice(0, 8),
    providers: [...prov].sort((a, b) => b[1] - a[1]),
    note: "Tokens processed by my AI coding agents (Claude Code, Codex) on this computer, including cached context. Counts only."
  };
}
async function githubCode(links) {
  const gh = links.map((l) => l[1]).map((u) => u.match(/^https?:\/\/(?:www\.)?github\.com\/([A-Za-z0-9-]{1,39})\/?$/)).find(Boolean);
  if (!gh) return void 0;
  const user = gh[1];
  try {
    const r = await (0, import_obsidian.requestUrl)({ url: `https://github.com/users/${user}/contributions`, throw: false });
    if (r.status !== 200) return void 0;
    const html = r.text, byId = /* @__PURE__ */ new Map(), counts = /* @__PURE__ */ new Map();
    for (const m of html.matchAll(/data-date="(\d{4}-\d{2}-\d{2})"[^>]*id="([^"]+)"|id="([^"]+)"[^>]*data-date="(\d{4}-\d{2}-\d{2})"/g)) byId.set(m[2] || m[3], m[1] || m[4]);
    for (const m of html.matchAll(/<tool-tip[^>]*for="([^"]+)"[^>]*>\s*(No|\d[\d,]*) contributions?/g)) {
      const d = byId.get(m[1]);
      if (d) counts.set(d, m[2] === "No" ? 0 : Number(m[2].replace(/,/g, "")));
    }
    if (!counts.size) return void 0;
    const dates = [...counts.keys()].sort(), weekly = [];
    for (let i = 0; i < dates.length; i += 7) weekly.push(dates.slice(i, i + 7).reduce((a, d) => a + (counts.get(d) || 0), 0));
    const commits = [...counts.values()].reduce((a, b) => a + b, 0);
    let repos = 0;
    try {
      const u = await (0, import_obsidian.requestUrl)({ url: `https://api.github.com/users/${user}`, throw: false });
      repos = u.json?.public_repos || 0;
    } catch {
    }
    const start = (/* @__PURE__ */ new Date(dates[0] + "T12:00:00")).toLocaleDateString("en-US", { month: "short", year: "numeric" });
    return commits ? { commits, repos, weekly, url: `https://github.com/${user}`, start } : void 0;
  } catch {
    return void 0;
  }
}
function githubUser(links) {
  return links.map((l) => l[1]).map((u) => u.match(/^https?:\/\/(?:www\.)?github\.com\/([A-Za-z0-9-]{1,39})\/?$/)).find(Boolean)?.[1];
}
async function githubRepoSig(user) {
  const u = await (0, import_obsidian.requestUrl)({ url: `https://api.github.com/users/${user}`, throw: false });
  const r = await (0, import_obsidian.requestUrl)({ url: `https://api.github.com/users/${user}/repos?type=owner&sort=created&direction=desc&per_page=1`, throw: false });
  if (u.status !== 200 || r.status !== 200 || !Array.isArray(r.json)) return void 0;
  return `${u.json?.public_repos ?? "?"}|${r.json[0]?.full_name || ""}`;
}
async function githubCity(user, prev) {
  const own = [];
  for (let pg = 1; pg <= 2; pg++) {
    const r = await (0, import_obsidian.requestUrl)({ url: `https://api.github.com/users/${user}/repos?type=owner&sort=pushed&per_page=100&page=${pg}`, throw: false });
    if (r.status !== 200 || !Array.isArray(r.json)) return void 0;
    own.push(...r.json);
    if (r.json.length < 100) break;
  }
  const old = new Map((Array.isArray(prev?.repos) ? prev.repos : []).map((r) => [r.name, r]));
  const repos = own.filter((r) => !r.fork && !r.private && !r.archived).slice(0, 120).map((r) => {
    const o = old.get(r.name);
    return {
      name: r.name,
      project: r.language || "Other",
      public: true,
      language: r.language || "Other",
      size: r.size,
      pushed: r.pushed_at,
      created: r.created_at,
      url: r.html_url,
      description: (r.description || "").slice(0, 200),
      commits: o?.commits || (r.size ? 1 : 0),
      weeks: o?.weeks || [],
      week: o?.week || 0,
      today: 0,
      sites: cleanSites(r.homepage || r.website)
    };
  });
  for (const r of repos.slice(0, 20)) {
    try {
      const w = await (0, import_obsidian.requestUrl)({ url: `https://api.github.com/repos/${user}/${r.name}/stats/commit_activity`, throw: false });
      if (w.status === 200 && Array.isArray(w.json) && w.json.length) {
        const t = w.json.slice(-52).map((x) => x.total || 0);
        r.weeks = t.slice(-12);
        r.commits = Math.max(1, t.reduce((a, b) => a + b, 0));
        r.week = t[t.length - 1];
      }
    } catch {
    }
  }
  return repos.length ? { generated: (/* @__PURE__ */ new Date()).toISOString(), source: `caldera github ${user}`, repos } : void 0;
}
function forgeOf(links) {
  const gh = githubUser(links);
  if (gh) return { kind: "github", host: "github.com", user: gh, url: `https://github.com/${gh}` };
  for (const [label, url] of links) {
    const m = url.match(/^(https?:\/\/[^/\s]+)\/([A-Za-z0-9._-]{1,40})\/?$/);
    if (m && (/forgejo|gitea|codeberg/i.test(label) || /^https?:\/\/(www\.)?codeberg\.org$/i.test(m[1]))) return { kind: "forgejo", host: m[1].replace(/^http:/, "https:"), user: m[2], url: `${m[1]}/${m[2]}` };
  }
  return void 0;
}
var forgeSource = (f) => f.kind === "github" ? `caldera github ${f.user}` : `caldera forgejo ${f.url}`;
var fj = async (f, path) => {
  const r = await (0, import_obsidian.requestUrl)({ url: `${f.host}/api/v1${path}`, headers: { Accept: "application/json" }, throw: false });
  return r.status === 200 ? r : void 0;
};
async function forgejoCode(f) {
  try {
    const h = await fj(f, `/users/${encodeURIComponent(f.user)}/heatmap`);
    if (!h || !Array.isArray(h.json)) return void 0;
    const now = Date.now(), WEEK = 7 * 864e5, weekly = Array(53).fill(0);
    for (const x of h.json) {
      const age = now - Number(x.timestamp) * 1e3;
      if (age >= 0 && age < 53 * WEEK) weekly[52 - Math.floor(age / WEEK)] += Number(x.contributions) || 0;
    }
    const commits = weekly.reduce((a, b) => a + b, 0);
    if (!commits) return void 0;
    const u = await fj(f, `/users/${encodeURIComponent(f.user)}/repos?limit=50`);
    const repos = Array.isArray(u?.json) ? u.json.filter((r) => !r.fork && !r.private).length : 0;
    const start = new Date(now - 52 * WEEK).toLocaleDateString("en-US", { month: "short", year: "numeric" });
    return { commits, repos, weekly, url: f.url, start };
  } catch {
    return void 0;
  }
}
async function forgejoCity(f, prev) {
  const own = [];
  for (let pg = 1; pg <= 4; pg++) {
    const r = await fj(f, `/users/${encodeURIComponent(f.user)}/repos?limit=50&page=${pg}`);
    if (!r || !Array.isArray(r.json)) {
      if (pg === 1) return void 0;
      break;
    }
    own.push(...r.json);
    if (r.json.length < 50) break;
  }
  const old = new Map((Array.isArray(prev?.repos) ? prev.repos : []).map((r) => [r.name, r]));
  const live = own.filter((r) => !r.fork && !r.private && !r.archived && !r.mirror).sort((a, b) => String(b.updated_at).localeCompare(String(a.updated_at)));
  const repos = live.slice(0, 120).map((r) => {
    const o = old.get(r.name);
    return {
      name: r.name,
      owner: r.owner?.login || f.user,
      project: r.language || "Other",
      public: true,
      language: r.language || "Other",
      size: r.size,
      pushed: r.updated_at,
      created: r.created_at,
      url: r.html_url,
      description: (r.description || "").slice(0, 200),
      commits: o?.commits || (r.size ? 1 : 0),
      weeks: o?.weeks || [],
      week: o?.week || 0,
      today: 0,
      sites: cleanSites(r.homepage || r.website)
    };
  });
  const now = Date.now(), WEEK = 7 * 864e5, YEAR = 365 * 864e5, q2 = "&stat=false&verification=false&files=false";
  for (const r of repos.slice(0, 20)) {
    try {
      const base = `/repos/${encodeURIComponent(r.owner)}/${encodeURIComponent(r.name)}/commits?limit=50${q2}`;
      const weeks = Array(12).fill(0);
      let year = 0, ok = false;
      for (let pg = 1; pg <= 10; pg++) {
        const w = await fj(f, `${base}&page=${pg}`);
        if (!w || !Array.isArray(w.json)) break;
        ok = true;
        let older = false;
        for (const c of w.json) {
          const age = now - Date.parse(c.commit?.author?.date || c.created);
          if (!(age >= 0)) continue;
          if (age >= YEAR) {
            older = true;
            continue;
          }
          year++;
          if (age < 12 * WEEK) weeks[11 - Math.floor(age / WEEK)]++;
        }
        if (older || w.json.length < 50) break;
      }
      if (!ok) continue;
      r.weeks = weeks;
      r.week = weeks[11];
      r.commits = Math.max(1, year);
    } catch {
    }
  }
  for (const r of repos) delete r.owner;
  return repos.length ? { generated: (/* @__PURE__ */ new Date()).toISOString(), source: forgeSource(f), repos } : void 0;
}
var KINDS = [
  [/^(person|people|contact|contacts)$/, "People"],
  [/^(company|companies|organization|organisation|org|orgs|organizations)$/, "Companies"],
  [/^(project|projects)$/, "Projects"],
  [/^(source|sources|article|articles|clipping|clippings|paper|papers|reference|references)$/, "Sources"],
  [/^(concept|concepts|idea|ideas|zettel|zettelkasten|permanent)$/, "Ideas & concepts"],
  [/^(book|books|reading)$/, "Books"],
  [/^(meeting|meetings)$/, "Meetings"],
  [/^(daily|dailies|journal|journals|daily-notes|daily notes|daily-digest|diary)$/, "Daily notes"],
  [/^(recipe|recipes)$/, "Recipes"],
  [/^(research)$/, "Research"],
  [/^(course|courses|class|classes|lecture|lectures)$/, "Learning"],
  [/^(podcast|podcasts|video|videos)$/, "Media notes"],
  [/^(tool|tools|software)$/, "Tools"],
  [/^(place|places|travel)$/, "Places"]
];
var kindOf = (v) => {
  const k = String(v ?? "").trim().toLowerCase();
  return (KINDS.find(([rx]) => rx.test(k)) || [])[1];
};
function vaultKinds(app, md) {
  const n = /* @__PURE__ */ new Map();
  for (const f of md) {
    if (f.path.startsWith("Caldera/")) continue;
    const fm = app.metadataCache.getFileCache(f)?.frontmatter || {};
    const label = kindOf(fm.type) || kindOf(fm.category) || (/^\d{4}-\d{2}-\d{2}$/.test(f.basename) ? "Daily notes" : void 0) || f.path.split("/").slice(0, -1).map(kindOf).find(Boolean);
    if (label) n.set(label, (n.get(label) || 0) + 1);
  }
  return [...n].filter(([, c]) => c >= 3).sort((a, b) => b[1] - a[1]).slice(0, 7);
}

// src/settings.ts
var import_obsidian3 = require("obsidian");

// src/listings.ts
var MAX_LISTINGS = 12;
var LISTING_DISTRICT = "Apps & sites";
var REPO_RX = /^[A-Za-z0-9._-]{1,100}$/;
var PKG_RX = /^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+$/;
var clean = (v, n) => String(v ?? "").replace(/[\u0000-\u001f\u007f<>]/g, " ").replace(/\s+/g, " ").trim().slice(0, n);
function shortHash(s) {
  let a = 2166136261, b = 16777619 ^ 1540483477;
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    a = Math.imul(a ^ c, 16777619) >>> 0;
    b = Math.imul(b ^ c, 1540483477) >>> 0;
  }
  return (a.toString(16).padStart(8, "0") + b.toString(16).padStart(8, "0")).slice(0, 14);
}
function parseAppUrl(raw) {
  let u;
  try {
    u = new URL(String(raw || "").trim());
  } catch {
    return null;
  }
  if (u.protocol !== "https:" || u.username || u.password || u.port && u.port !== "443") return null;
  if (u.hostname === "apps.apple.com") {
    const m = u.pathname.match(/\/id(\d{5,12})(?:\/|$)/);
    if (!m) return null;
    return { kind: "app", store: "apple", id: m[1], key: `apple-${m[1]}`, url: `https://apps.apple.com/app/id${m[1]}` };
  }
  if (u.hostname === "play.google.com" && /^\/store\/apps\/details\/?$/.test(u.pathname)) {
    const id = u.searchParams.get("id") || "";
    if (!PKG_RX.test(id) || id.length > 150) return null;
    return { kind: "app", store: "play", id, key: `play-${id}`, url: `https://play.google.com/store/apps/details?id=${id}` };
  }
  return null;
}
function parseSiteUrl(raw) {
  let s = String(raw || "").trim();
  if (!s) return null;
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) s = "https://" + s;
  let u;
  try {
    u = new URL(s);
  } catch {
    return null;
  }
  if (u.protocol !== "https:" && u.protocol !== "http:" || u.username || u.password) return null;
  if (u.port && u.port !== "80" && u.port !== "443") return null;
  const h = u.hostname.toLowerCase();
  if (!/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(h) || /^\d+(\.\d+){3}$/.test(h) || h.length > 253) return null;
  if (/(^|\.)(localhost|local|internal|intranet|lan|home|corp|localdomain|test|invalid|example)$/.test(h)) return null;
  if (h === "apps.apple.com" || h === "play.google.com") return null;
  const url = `${u.protocol}//${h}${u.pathname === "/" ? "/" : u.pathname.replace(/\/+$/, "")}`.slice(0, 300);
  return { kind: "site", key: `site-${shortHash(url)}`, url, host: cleanSites(h)?.[0] || h.replace(/^www\./, "") };
}
var NO_STOREFRONT = "no-storefront";
var MAX_LABEL = 40;
var isFlag = (v) => /^no-?storefront$/i.test(v);
var NAME_RX = /^name\s*:\s*/i;
var cleanLabel = (v) => clean(v, MAX_LABEL);
function parseListingLine(line, kind) {
  const [a = "", ...rest] = String(line ?? "").split("|").map((x) => x.trim());
  const ref = kind === "app" ? parseAppUrl(a) : parseSiteUrl(a);
  if (!ref) return null;
  for (const v of rest) {
    if (!v) continue;
    if (NAME_RX.test(v)) {
      const n = cleanLabel(v.replace(NAME_RX, ""));
      if (n && !ref.label) ref.label = n;
    } else if (isFlag(v)) ref.storefront = false;
    else if (!ref.repo && REPO_RX.test(v)) ref.repo = v;
  }
  return ref;
}
function listingLine(r) {
  const label = cleanLabel(r.label);
  const base = r.storefront === false ? `${r.url} | ${r.repo || ""} | ${NO_STOREFRONT}` : r.repo ? `${r.url} | ${r.repo}` : r.url;
  return label ? `${base}${r.storefront === false || r.repo ? "" : " |"} | name: ${label}` : base;
}
function storefrontOn(l, hideStorefronts = []) {
  if (l.storefront === false) return false;
  return !(l.repo && hideStorefronts.some((h) => h.trim().toLowerCase() === l.repo.toLowerCase()));
}
function parseListings(raw, kind) {
  const lines = Array.isArray(raw) ? raw : typeof raw === "string" ? raw.split(/\r?\n/) : [];
  const out = [], seen = /* @__PURE__ */ new Set();
  for (const l of lines) {
    const r = parseListingLine(l, kind);
    if (!r || seen.has(r.key)) continue;
    seen.add(r.key);
    out.push(r);
    if (out.length >= MAX_LISTINGS) break;
  }
  return out;
}
function fallbackName(r) {
  if (r.kind === "site") return r.host || "Website";
  if (r.store === "play" && r.id) {
    const last = r.id.split(".").pop() || r.id;
    return last.charAt(0).toUpperCase() + last.slice(1);
  }
  return "App";
}
function toListing(r, m, hub) {
  const base = hub.replace(/\/$/, "");
  const rating = Number(m?.rating), ratings = Number(m?.ratings);
  const img = m?.img && /^[a-z0-9._-]{3,170}$/i.test(m.img) ? `${base}/v1/listings/img/${encodeURIComponent(m.img)}` : void 0;
  return {
    kind: r.kind,
    key: r.key,
    url: r.url,
    store: r.store,
    host: r.host,
    repo: r.repo,
    ...r.storefront === false ? { storefront: false } : {},
    name: cleanLabel(r.label) || clean(m?.name, 80) || fallbackName(r),
    icon: img,
    genre: clean(m?.genre, 40) || void 0,
    seller: clean(m?.seller, 80) || void 0,
    desc: clean(m?.desc, 200) || void 0,
    rating: rating > 0 && rating <= 5 ? Math.round(rating * 10) / 10 : void 0,
    ratings: ratings > 0 ? Math.round(ratings) : void 0
  };
}
function listingBuilding(l, project, besidePrivate = false, on) {
  const site = l.kind === "site" ? siteKey(l) : "";
  return {
    ...besidePrivate ? { pv: true } : {},
    name: clean(l.name, 60) || "App",
    project,
    public: true,
    language: l.kind === "app" ? "App" : "Web",
    commits: 0,
    weeks: [],
    week: 0,
    today: 0,
    url: l.url,
    kind: l.kind,
    ...site ? { sites: [site] } : {},
    meta: { store: l.store, icon: l.icon, genre: l.genre, rating: l.rating, ratings: l.ratings, desc: l.desc, host: l.host, ...on ? { on } : {} }
  };
}
function siteKey(l) {
  let path = "";
  try {
    path = new URL(l.url).pathname.toLowerCase().replace(/\/+$/, "");
  } catch {
  }
  return (l.host || "") + (/^\/[a-z0-9._~%\/-]{1,120}$/.test(path) ? path : "");
}
var lc = (v) => v.trim().toLowerCase();
var findRepo = (c, name) => {
  const n = lc(name);
  for (const d of c?.districts || []) for (const r of d.repos) if (!r.kind && r.name && lc(r.name) === n) return { d, r };
  return null;
};
var general = (ds) => {
  let g = ds.find((d) => d.name === LISTING_DISTRICT);
  if (!g) {
    g = { name: LISTING_DISTRICT, notes: 0, repos: [] };
    ds.push(g);
  }
  return g;
};
var copy = (c) => ({ ...c, districts: c.districts.map((d) => ({ ...d, repos: d.repos.map((r) => ({ ...r })) })) });
var addSite = (r, host) => {
  if (host) r.sites = cleanSites([...r.sites || [], host]);
};
var dropEmptyGeneral = (c) => {
  if (!c.districts.find((d) => d.name === LISTING_DISTRICT)?.repos.length) c.districts = c.districts.filter((d) => d.name !== LISTING_DISTRICT);
  return c;
};
function withListingsPrivate(city, items, hideStorefronts = []) {
  if (!items.length) return city;
  const c = city ? copy(city) : { districts: [], private: true };
  for (const l of items) {
    const hit = l.repo ? findRepo(c, l.repo) : null;
    if (!storefrontOn(l, hideStorefronts)) {
      if (hit && l.kind === "site" && l.storefront === false) addSite(hit.r, l.host);
      continue;
    }
    (hit ? hit.d : general(c.districts)).repos.push(listingBuilding(l, hit ? hit.d.name : LISTING_DISTRICT, false, hit?.r.name));
  }
  return dropEmptyGeneral(c);
}
function withListingsPublic(pub, priv, items, mode = "show", hideRepos = [], hideStorefronts = []) {
  const hs = new Set(hideStorefronts.map(lc).filter(Boolean));
  if (!items.length && !hs.size) return pub;
  const c = pub ? copy(pub) : { districts: [], private: false };
  const owned = new Set(items.filter((l) => l.kind === "site" && l.repo && storefrontOn(l, hideStorefronts)).map((l) => lc(l.repo)));
  for (const d of c.districts) for (const r of d.repos) if (!r.kind && r.name && (hs.has(lc(r.name)) || owned.has(lc(r.name)))) delete r.sites;
  const hide = new Set(hideRepos.map(lc).filter(Boolean));
  for (const l of items) {
    const hit = l.repo ? findRepo(priv, l.repo) : null;
    let district = null, named = null, pv = false;
    if (hit) {
      const pd = c.districts.find((d2) => d2.name === hit.d.name && !d2.apart) || null;
      const shownByName = hit.r.public || mode === "named" && !hide.has(lc(hit.r.name));
      const placeOk = hit.r.public || mode === "named" || mode === "show";
      if (pd && placeOk) {
        district = pd;
        pv = !hit.r.public;
        if (shownByName) named = pd.repos.find((r) => !r.kind && !r.locked && lc(r.name) === lc(hit.r.name)) || null;
      }
    }
    if (!storefrontOn(l, [...hs])) {
      if (l.kind === "site" && l.storefront === false && named && !hs.has(lc(named.name))) addSite(named, l.host);
      continue;
    }
    const d = district || general(c.districts);
    d.repos.push(listingBuilding(l, d.name, pv && !!district, district && named ? named.name : void 0));
  }
  return dropEmptyGeneral(c);
}
var esc2 = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var httpsOk = (u) => /^https?:\/\/[^\s"<>]+$/.test(u);
var imgOk = (u) => !!u && /^https:\/\/[^\s"<>]+\/v1\/listings\/img\/[A-Za-z0-9._%-]+$/.test(u);
var stars = (r) => r ? `<span class="ls-rate" title="${r} out of 5">&#9733; ${r.toFixed(1)}</span>` : "";
function appsCards(apps) {
  return `<div class="ls-grid">${apps.filter((a) => a.kind === "app" && httpsOk(a.url)).map((a) => `<a class="ls-card" href="${esc2(a.url)}" target="_blank" rel="noopener">${imgOk(a.icon) ? `<img class="ls-icon app" src="${esc2(a.icon)}" alt="" loading="lazy" width="56" height="56">` : `<span class="ls-icon app ls-ph" aria-hidden="true">${esc2((a.name || "A").charAt(0))}</span>`}<span class="ls-body"><span class="ls-name">${esc2(a.name)}</span><span class="ls-sub">${[a.genre ? esc2(a.genre) : "", stars(a.rating)].filter(Boolean).join(" &middot; ")}</span><span class="ls-store">${a.store === "play" ? "Google Play" : "App Store"} &#8599;</span></span></a>`).join("")}</div>`;
}
function siteCards(sites) {
  return `<div class="ls-grid">${sites.filter((s) => s.kind === "site" && httpsOk(s.url)).map((s) => `<a class="ls-card" href="${esc2(s.url)}" target="_blank" rel="noopener">${imgOk(s.icon) ? `<img class="ls-icon site" src="${esc2(s.icon)}" alt="" loading="lazy" width="40" height="40">` : `<span class="ls-icon site ls-ph" aria-hidden="true">${esc2((s.host || "W").charAt(0).toUpperCase())}</span>`}<span class="ls-body"><span class="ls-name">${esc2(s.name)}</span><span class="ls-host">${esc2(s.host || "")} &#8599;</span>${s.desc ? `<span class="ls-desc">${esc2(s.desc)}</span>` : ""}</span></a>`).join("")}</div>`;
}
var LISTINGS_CSS = `
.ls-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(230px, 1fr)); gap: var(--space-3); margin: var(--space-2) 0 var(--space-6); }
.ls-card { display: flex; gap: 12px; align-items: flex-start; padding: 12px; border: 1px solid var(--line); border-radius: var(--radius-md); background: var(--bg-raised); color: var(--text); text-decoration: none; min-width: 0; }
.ls-card:hover { border-color: var(--line-strong); }
.ls-icon { flex: none; object-fit: cover; background: var(--bg-sunken); }
.ls-icon.app { width: 56px; height: 56px; border-radius: 13px; }
.ls-icon.site { width: 40px; height: 40px; border-radius: 9px; }
.ls-ph { display: inline-flex; align-items: center; justify-content: center; font-weight: 600; color: var(--accent-text); font-size: var(--text-lg); }
.ls-body { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
.ls-name { font-weight: 600; color: var(--text-strong); overflow-wrap: anywhere; }
.ls-sub, .ls-host, .ls-store { font-size: var(--text-sm); color: var(--text-muted); overflow-wrap: anywhere; }
.ls-store { color: var(--accent-text); }
.ls-desc { font-size: var(--text-sm); color: var(--text); display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
.ls-rate { white-space: nowrap; }
`;

// src/profile-file.ts
var import_obsidian2 = require("obsidian");
var PROFILE_FILE = "Caldera/profile.md";
var pair = (v) => {
  const [a, ...b] = String(v ?? "").split("|");
  const k = a.trim(), val = b.join("|").trim();
  return k && val ? [k, val] : null;
};
var pairs = (v) => Array.isArray(v) ? v.map(pair).filter(Boolean) : null;
function effectiveSettings(app, s) {
  const f = app.vault.getAbstractFileByPath(PROFILE_FILE);
  const fm = f instanceof import_obsidian2.TFile ? app.metadataCache.getFileCache(f)?.frontmatter : null;
  if (!fm) return s;
  const e = { ...s, sections: { ...s.sections } };
  if (typeof fm.name === "string" && fm.name.trim()) e.name = fm.name.trim();
  if (typeof fm.headline === "string") e.headline = fm.headline.trim();
  if (typeof fm.photo === "string") e.avatarPath = fm.photo.trim();
  if (typeof fm.banner === "string") e.bannerPath = fm.banner.trim();
  e.links = pairs(fm.links) ?? e.links;
  e.properties = pairs(fm.properties) ?? e.properties;
  const topics = pairs(fm.topics);
  if (topics) e.publicTopics = topics.map(([tag, label]) => [tag.replace(/^#/, ""), label]);
  if (fm.sections && typeof fm.sections === "object") for (const [k, v] of Object.entries(fm.sections)) e.sections[k] = v !== false;
  if (typeof fm.listed === "boolean") e.listed = fm.listed;
  if (typeof fm.autoConnectRepos === "boolean") e.autoConnectRepos = fm.autoConnectRepos;
  if (typeof fm.autoConnectGithub === "boolean") e.autoConnectRepos = fm.autoConnectGithub;
  const list = (v) => Array.isArray(v) ? v.map((x) => String(x ?? "").trim()).filter(Boolean) : typeof v === "string" ? v.split(",").map((x) => x.trim()).filter(Boolean) : null;
  {
    const t = list(fm.tags);
    if (t) e.tags = t.slice(0, 12);
    const h = list(fm.hideTags);
    if (h) e.hideTags = h.slice(0, 40);
    const hr = list(fm.hideRepos);
    if (hr) e.hideRepos = hr.slice(0, 200);
  }
  {
    const hs = Array.isArray(fm.hideStorefronts) ? fm.hideStorefronts.map((x) => String(x ?? "").trim()).filter(Boolean) : typeof fm.hideStorefronts === "string" ? fm.hideStorefronts.split(",").map((x) => x.trim()).filter(Boolean) : null;
    if (hs) e.hideStorefronts = hs.slice(0, 300);
  }
  if (typeof fm.autoTags === "boolean") e.autoTags = fm.autoTags;
  if (["show", "anonymous", "hidden", "named"].includes(String(fm.privateRepos))) e.privateRepos = fm.privateRepos;
  if (Array.isArray(fm.sidebar)) e.tree = fm.sidebar.map((x) => {
    const [g = "", items = "", folder = ""] = String(x ?? "").split("|").map((v) => v.trim());
    return [g, items, folder || void 0];
  }).filter(([g]) => g);
  if (Array.isArray(fm.graph)) e.graph = fm.graph.map((x) => String(x).trim()).filter(Boolean).slice(0, 20);
  e.backlinks = pairs(fm.backlinks) ?? e.backlinks;
  if (typeof fm.summary === "string") e.summary = fm.summary.trim();
  if (Array.isArray(fm.now)) e.now = fm.now.map((x) => String(x).trim()).filter(Boolean).slice(0, 8);
  if (String(fm.now ?? "").trim().toLowerCase() === "auto") {
    e.now = [];
    e.nowAuto = true;
  }
  e.timeline = pairs(fm.timeline) ?? e.timeline;
  e.projects = pairs(fm.projects) ?? e.projects;
  e.knows = pairs(fm.knows) ?? e.knows;
  if (typeof fm.garden === "string") e.gardenFolder = fm.garden.trim().replace(/^\/+|\/+$/g, "");
  if (typeof fm.garden_journal === "boolean") e.gardenJournal = fm.garden_journal;
  if (typeof fm.garden_url === "string") e.gardenUrl = /^https:\/\//.test(fm.garden_url.trim()) ? fm.garden_url.trim() : "";
  for (const k of ["apps", "websites"]) {
    const v = fm[k];
    if (Array.isArray(v)) e[k] = v.map((x) => String(x ?? "").trim()).filter(Boolean).slice(0, 24);
    else if (typeof v === "string") e[k] = v.split(/\r?\n/).map((x) => x.trim()).filter(Boolean).slice(0, 24);
  }
  if (Array.isArray(fm.tabs)) e.tabs = fm.tabs.map((x) => String(x).trim()).filter(Boolean).slice(0, 5);
  return e;
}
var q = (v) => JSON.stringify(v);
function profileFileText(s, hubUrl) {
  const list = (rows) => rows.length ? rows.map((r) => `  - ${q(r)}`).join("\n") : "  []";
  return `---
name: ${q(s.name)}
headline: ${q(s.headline)}
photo: ${q(s.avatarPath)}
banner: ${q(s.bannerPath)}
links:
${list(s.links.map(([a, b]) => `${a} | ${b}`))}
properties:
${list(s.properties.map(([a, b]) => `${a} | ${b}`))}
topics:
${list(s.publicTopics.map(([a, b]) => `${a} | ${b}`))}
sections:
${Object.entries(s.sections).map(([k, v]) => `  ${k}: ${v}`).join("\n")}
listed: ${s.listed !== false}
summary: ${q(s.summary || "")}
now:${s.nowAuto ? " auto" : "\n" + list(s.now || [])}
timeline:
${list((s.timeline || []).map(([a, b]) => `${a} | ${b}`))}
projects:
${list((s.projects || []).map(([a, b]) => `${a} | ${b}`))}
apps:
${list(s.apps || [])}
websites:
${list(s.websites || [])}
hideStorefronts:
${list(s.hideStorefronts || [])}
knows:
${list((s.knows || []).map(([a, b]) => `${a} | ${b}`))}
tabs:
${list(s.tabs || [])}
${gardenEnabled() ? `garden: ${q(s.gardenFolder ?? "Garden")}
garden_url: ${q(s.gardenUrl || "")}
garden_journal: ${s.gardenJournal !== false}
` : ""}sidebar:
${list((s.tree || []).map(([a, b, c]) => `${a} | ${b}${c ? ` | ${c}` : ""}`))}
graph:
${list(s.graph || [])}
backlinks:
${list((s.backlinks || []).map(([a, b]) => `${a} | ${b}`))}
---
# My Caldera profile

This note controls your public page at ${hubUrl.replace(/\/$/, "")}/@${s.handle}/ . Edit the properties above, or ask your AI agent to, and the page republishes itself about a minute after you save. **Everything above is public.**

- **name, headline** - shown at the top of your page.
- **photo, banner** - paths to images in this vault, e.g. \`Attachments/me.jpg\`.
- **links** - \`Label | https://...\`, one per line.
- **properties** - short facts, \`Label | value\` (e.g. \`Based in | Lisbon\`).
- **topics** - which of your tags may be counted publicly, \`tag | Label\`. Tags not listed are never shown.
- **sections** - switch parts of the page on or off: ${Object.keys(s.sections).join(", ")}.
- **listed** - \`true\` shows your card on the People page; \`false\` keeps the page link-only.
- **autoConnectGithub** (or autoConnectRepos) - \`false\` stops Caldera making you friends with members you follow, who follow you, or who work on the same public GitHub repos (on by default).
- **tags** - what you're building, shown as chips on your page and searchable in People (e.g. \`[Social features, Next.js]\`). **hideTags** hides tags Caldera worked out from your public GitHub; **autoTags** \`false\` turns those off entirely.
- **privateRepos** - how private repos show on your public city: \`named\` (like your private view: names, language colours and activity in their real projects, but no links or code), \`show\` (padlocked buildings in place: no names, but size, activity and the project they sit beside are visible), \`anonymous\` (one separate padlocked district, no sizes, activity or projects) or \`hidden\` (no trace). Your private view always shows everything. **hideRepos** - with \`named\`, private repos to keep as nameless padlocks anyway (e.g. \`[client-project, secret-launch]\`).
- **summary** - a short intro box. Links: \`[[Label|https://...]]\`, bold: \`**text**\`.
- **now** - what you're doing now, one line each. Or \`now: auto\` (and when there's no list): your last week of journal wins, updated on every publish.
- **timeline** - \`Year | what happened | optional one-line detail\`. Start a chapter with \`era | Name | 1995-2006\`.
- **projects** - \`Name | status | https://link\`.
- **apps** - your apps in the App Store or Google Play, one store link each (e.g. \`https://apps.apple.com/us/app/name/id123456789\`). Add \` | repo-name\` to stand the app beside that repo in your city; a private repo's name is never shown. Name, icon, category and rating come from the store. Up to 12.
- **websites** - sites you run, one link each (http or https). Add \` | repo-name\` to tie a site to the repo that builds it, so its live visitors walk into that building. Title, icon and description come from the site. Up to 12.
- **Storefronts** - every app and website you list stands as a storefront building in your city (its profile card shows either way). Turn one off with a third field: \`link | repo-name | no-storefront\` (no repo: \`link | | no-storefront\`). A website with its storefront off, tied to a repo shown by name, lights up that repo's building instead.
- **Short names** - add \`name: Short name\` to any app or website line to use your own name (up to 40 characters) on its card and storefront instead of the store's or site's title, e.g. \`https://example.com | repo-name | name: Example\`. It can go before or after \`no-storefront\`.
- **hideStorefronts** - repos whose apps and websites get no storefront, e.g. \`[old-site, client-work]\`. Those repos' own websites (GitHub homepage or city.json) are also left off your public city.
- **knows** - \`Label | vault folder\`; shows how many notes are in each folder (counts only).
- **tabs** - extra tab labels in the top bar, like \`Now.md\`.
${gardenEnabled() ? `- **garden** - a folder whose notes are published as full pages (your digital garden). Default \`Garden\`. Any note can also opt in with \`caldera: garden\`; \`caldera: private\` keeps a note out. In a garden note, \`stage: seedling | budding | evergreen\` and \`license: all-rights | cc-by | cc-by-nc | cc0 | ai-licensable\`. Email addresses and phone numbers are removed automatically. Link a friend's note with \`[[@handle/Their note]]\`.
- **garden_journal** - \`true\` (default) grows garden pages from your daily journal: one per public project it keeps mentioning and one per recurring theme. Only journal text that is already public is used. \`false\` turns it off.
- **garden_url** - an existing garden elsewhere (Quartz, Obsidian Publish...), linked from your page.
` : ""}- **sidebar** - the left column, \`Group | item, item | folder\` (e.g. \`Projects | Caldera, Newsletter | Projects\`). Items that match a project, public note or section on your page become links. The optional folder shows how many notes it holds (a count only). Empty: your topics and public notes.
- **graph** - note names for the graph on the right, sized by how many of your notes link to each (only the count is published). Empty: your topics.
- **backlinks** - the list under the graph, \`Title | short context\`. Empty: your public notes.
- **Your own sections (modules)** - add a note to \`Caldera/modules/\` (e.g. \`Caldera/modules/Reading list.md\`) and it becomes a section on your page, titled with the file name. Write ordinary Markdown: lists, tables, quotes, links, images from the vault. Optional frontmatter: \`place: side\` (right-hand column), \`order: 10\`, \`publish: false\` (draft). Or ask your AI agent: "add a Talks module with my last five talks".

Your handle and identity key live in Settings -> Caldera, never here. Guide: ${hubUrl.replace(/\/$/, "")}/guide.html
`;
}
async function ensureProfileFile(app, s, hubUrl) {
  const existing = app.vault.getAbstractFileByPath(PROFILE_FILE);
  if (existing instanceof import_obsidian2.TFile) return existing;
  if (!app.vault.getAbstractFileByPath("Caldera")) await app.vault.createFolder("Caldera").catch(() => {
  });
  return app.vault.create(PROFILE_FILE, profileFileText(s, hubUrl));
}

// src/settings.ts
var DEFAULT_SETTINGS = {
  hubUrl: "https://caldera.social",
  identity: null,
  handle: "",
  name: "",
  headline: "",
  theme: "dark",
  avatarPath: "",
  bannerPath: "",
  links: [],
  properties: [],
  sections: { journal: true, scoreboard: true, properties: true, numbers: true, topics: true, notes: true, links: true, sidebar: true, rail: true, modules: true },
  publicTopics: [["ai", "AI"], ["design", "Design"], ["startups", "Startups"], ["investing", "Investing"], ["writing", "Writing"]],
  activityFile: "Caldera/activity.json",
  historyDays: 45,
  inboxFolder: "Caldera/Inbox",
  lastInboxSync: "1970-01-01T00:00:00.000Z",
  asks: [],
  offers: [],
  autoPublishHours: 6,
  welcomed: false,
  listed: true,
  lastSeenRelease: "",
  lastPublished: 0,
  tree: [],
  graph: [],
  backlinks: [],
  summary: "",
  now: [],
  timeline: [],
  projects: [],
  knows: [],
  tabs: [],
  gardenFolder: "Garden",
  gardenUrl: "",
  gardenJournal: true,
  groups: []
};
var WELCOME_NOTE = "Welcome to Caldera - I built it. Glad you're here. If anything breaks or feels confusing, tell me and I'll fix it.";
var groupsFrom = (v) => [...new Set(String(v || "").toLowerCase().split(/[\s,]+/).map((g) => g.replace(/^#/, "")).filter((g) => /^[a-z0-9][a-z0-9-]{1,29}$/.test(g)))].slice(0, 8);
var SECTION_LABELS = {
  journal: "Daily journal (flip through days)",
  scoreboard: "Scoreboard (streak, rank, 30-day bars)",
  properties: "Properties",
  numbers: "Vault numbers (notes, words, links, active days)",
  topics: "Topics (allow-listed tags only)",
  notes: "Notes marked caldera: public",
  links: "Links elsewhere",
  garden: "Garden (full pages for notes you plant: Garden folder or caldera: garden)",
  city: "City (your GitHub as a little city: add GitHub | https://github.com/you to Links, or write Caldera/city.json yourself)"
};
var CalderaSettingTab = class extends import_obsidian3.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    const s = this.plugin.settings;
    containerEl.empty();
    containerEl.createEl("p", { text: "Your vault stays private. Only the sections you switch on below, notes you mark caldera: public, and counts are published. Use 'Preview profile' before publishing.", cls: "setting-item-description" });
    new import_obsidian3.Setting(containerEl).setName("Connections").setHeading();
    const lights = containerEl.createDiv({ cls: "caldera-conn" });
    lights.createEl("p", { text: s.identity && s.handle ? "Checking..." : "Publish your page to see your connections.", cls: "setting-item-description" });
    if (s.identity && s.handle) void this.plugin.ownerActivity(new Date(Date.now() - 864e5).toISOString()).then((a) => {
      const c = a?.connections;
      lights.empty();
      if (!c) {
        lights.createEl("p", { text: "Update the hub to see connections.", cls: "setting-item-description" });
        return;
      }
      const rows = [
        ["GitHub", !!c.github?.on, c.github?.on ? `Connected as @${c.github.login}` : c.github?.listed ? `Listed (github.com/${c.github.listed}), sign in with GitHub once to link it` : "Not connected"],
        ["Obsidian", true, "Connected (this vault)"],
        ["Live visitors on your city", !!c.live, c.live ? "Visits in the last 7 days" : "No visits in the last 7 days"],
        ["AI agents on the map", !!c.agents, c.agents ? "Agents in the last 7 days" : "No agents in the last 7 days"],
        ["Private view", !!c.private, c.private ? "Up to date" : "Not turned on"],
        ["Daily summary email", !!c.email, c.email ? "On" : "Off"]
      ];
      for (const [name, on, status] of rows) {
        const r = lights.createDiv({ cls: "caldera-conn-row" });
        r.createSpan({ cls: "caldera-conn-dot" + (on ? " is-on" : ""), attr: { "aria-label": on ? "Connected" : "Not connected" } });
        r.createSpan({ text: name, cls: "caldera-conn-name" });
        r.createSpan({ text: status, cls: "caldera-conn-status" });
      }
    }).catch(() => {
      lights.empty();
      lights.createEl("p", { text: "Couldn't reach the hub.", cls: "setting-item-description" });
    });
    new import_obsidian3.Setting(containerEl).setName("Set them up on caldera.social").setDesc("Opens your settings page, already signed in, with a step-by-step for anything that's grey.").addButton((b) => b.setButtonText("Open settings").setDisabled(!s.identity || !s.handle).onClick(() => void this.plugin.openProfile("settings")));
    new import_obsidian3.Setting(containerEl).setName("Identity").setHeading();
    new import_obsidian3.Setting(containerEl).setName("Your Caldera ID").setDesc(s.identity ? s.identity.id : "Not created yet").addButton((b) => b.setButtonText(s.identity ? "Copy ID" : "Create identity").onClick(async () => {
      if (!s.identity) {
        await this.plugin.ensureIdentity();
        this.display();
      } else {
        await navigator.clipboard.writeText(s.identity.id);
        new import_obsidian3.Notice("ID copied");
      }
    })).addButton((b) => b.setButtonText("Export recovery key").setDisabled(!s.identity).onClick(async () => {
      await navigator.clipboard.writeText(btoa(JSON.stringify(s.identity)));
      new import_obsidian3.Notice("Recovery key copied. Store it somewhere safe; anyone with it can act as you.");
    }));
    this.text("Handle", "Your address on the hub: hub/@handle", "handle", (v) => v.toLowerCase().replace(/[^a-z0-9-]/g, ""));
    let claim = "";
    new import_obsidian3.Setting(containerEl).setName("Import a sign-up").setDesc("Started your Caldera profile on the website, with GitHub, Google or email? Get a code on your settings page (caldera.social/settings, Connections > Obsidian) and paste it here: your vault takes over that profile (same handle and page) and the hub deletes its copy of the key.").addText((t) => t.setPlaceholder("CAL-...").onChange((v) => {
      claim = v.trim();
    })).addButton((b) => b.setButtonText("Import").onClick(() => this.plugin.importGithub(claim).then((ok) => {
      if (ok) this.display();
    })));
    this.text("Hub", "Where your profile is hosted and friends connect. Self-hosters can point this at their own hub.", "hubUrl");
    new import_obsidian3.Setting(containerEl).setName("List me in the directory").setDesc("Show your profile card on the public People page. Off: your page still works for anyone with the link, but isn't browsable.").addToggle((t) => t.setValue(s.listed !== false).onChange(async (v) => {
      s.listed = v;
      await this.plugin.saveSettings();
    }));
    new import_obsidian3.Setting(containerEl).setName("Connect me with my GitHub people").setDesc("Become friends automatically with Caldera members you follow or who follow you on GitHub, or who work on the same public repos, including people who join later. Remove one like any friend and it never comes back.").addToggle((t) => t.setValue(s.autoConnectRepos !== false).onChange(async (v) => {
      s.autoConnectRepos = v;
      await this.plugin.saveSettings();
      this.plugin.queuePublish("profile");
    }));
    new import_obsidian3.Setting(containerEl).setName("Tag me from my public GitHub").setDesc("Shows what you're building (like AI agents or Next.js) on your page and in People, worked out from your public repos' topics, descriptions, READMEs and dependencies. Private repos only ever add a language. Add or hide tags with tags / hideTags in Caldera/profile.md, or on caldera.social/me/building.").addToggle((t) => t.setValue(s.autoTags !== false).onChange(async (v) => {
      s.autoTags = v;
      await this.plugin.saveSettings();
      this.plugin.queuePublish("profile");
    }));
    new import_obsidian3.Setting(containerEl).setName("Private repos on my city").setDesc("How your private repos appear on your public city, the World and your share card. With names: they look exactly like your private view (names, language colours, activity, real projects) but nobody can open the code. Padlocked: nameless locked buildings in place, which still show roughly how big and how busy private work is, and which project it sits beside. Anonymous: one separate padlocked district with no sizes, activity or projects. Hidden: no trace at all. Your private view always shows everything. Also: privateRepos in Caldera/profile.md.").addDropdown((d) => d.addOption("", "Caldera's default (Anonymous for new members)").addOption("named", "Show with names (code stays private)").addOption("show", "Show as padlocked").addOption("anonymous", "Anonymous").addOption("hidden", "Hidden").setValue(s.privateRepos || "").onChange(async (v) => {
      s.privateRepos = v || void 0;
      s.privateReposTs = (/* @__PURE__ */ new Date()).toISOString();
      await this.plugin.saveSettings();
      this.plugin.queuePublish("profile");
    }));
    new import_obsidian3.Setting(containerEl).setName("Show my view count").setDesc("Your page shows how many people have viewed it (one per visitor per day). Off: only you see the count, in the bar when you're signed in and in your private view.").addToggle((t) => t.setValue(s.showViews !== false).onChange(async (v) => {
      s.showViews = v;
      await this.plugin.saveSettings();
      this.plugin.queuePublish("profile");
    }));
    new import_obsidian3.Setting(containerEl).setName("Friends and sharing").setHeading();
    new import_obsidian3.Setting(containerEl).setName("Share my page").setDesc("Your link, the picture people see when you post it, and your invite link (you get 25 help credits for each person who joins from it).").addButton((b) => b.setButtonText("Share my page").setCta().setDisabled(!s.handle).onClick(() => this.plugin.openShare()));
    new import_obsidian3.Setting(containerEl).setName("Groups").setDesc(`Comma separated, like producthunt. Each group is a town of everyone's cities at ${s.hubUrl.replace(/^https?:\/\//, "").replace(/\/$/, "")}/g/name, and people in your groups are suggested to you as friends.`).addText((t) => t.setPlaceholder("producthunt, obsidian-pkm").setValue((s.groups || []).join(", ")).onChange(async (v) => {
      s.groups = groupsFrom(v);
      await this.plugin.saveSettings();
      this.plugin.queuePublish("profile");
    }));
    let email = s.summaryEmail || "";
    new import_obsidian3.Setting(containerEl).setName("Email me a daily summary").setDesc("One short email on days something happens: who visited your page, kudos and new followers, people to meet. We send a confirmation link first; every email has a one-click unsubscribe. Leave empty and save to turn it off.").addText((t) => t.setPlaceholder("you@example.com").setValue(email).onChange((v) => email = v.trim())).addButton((b) => b.setButtonText("Save").onClick(() => this.plugin.setSummaryEmail(email)));
    new import_obsidian3.Setting(containerEl).setName("Welcome new members").setDesc("For community hosts: follow each person who joins Caldera from now on, with the note below (up to 10 a day). Off by default.").addToggle((t) => t.setValue(!!s.welcomeNew).onChange(async (v) => {
      s.welcomeNew = v;
      if (v && !s.welcomeSince) s.welcomeSince = (/* @__PURE__ */ new Date()).toISOString();
      await this.plugin.saveSettings();
    }));
    new import_obsidian3.Setting(containerEl).setName("Welcome note").addTextArea((t) => {
      t.setValue(s.welcomeNote || WELCOME_NOTE);
      t.inputEl.rows = 2;
      t.onChange(async (v) => {
        s.welcomeNote = v.trim().slice(0, 200);
        await this.plugin.saveSettings();
      });
    });
    new import_obsidian3.Setting(containerEl).setName("Profile").setHeading();
    new import_obsidian3.Setting(containerEl).setName("Edit your page as a note").setDesc("Name, headline, photo, links, topics and sections also live in Caldera/profile.md. Edit it (or ask your AI agent to) and the page republishes itself. Values there win over the fields below.").addButton((b) => b.setButtonText("Open profile file").onClick(() => this.plugin.openProfileFile()));
    this.text("Name", "", "name");
    this.text("Headline", "One line under your name", "headline");
    this.text("Avatar image", "Path in your vault, e.g. Attachments/me.jpg", "avatarPath");
    this.text("Banner image", "Path in your vault", "bannerPath");
    new import_obsidian3.Setting(containerEl).setName("Theme").addDropdown((d) => d.addOptions({ dark: "Dark", light: "Light" }).setValue(s.theme).onChange(async (v) => {
      s.theme = v;
      await this.plugin.saveSettings();
    }));
    this.pairs("Links", "One per line: Label | https://url", "links");
    this.listing("Apps", "Your apps in the App Store or Google Play (up to 12). Each one gets a card on your page and, with Storefront on, a storefront building in your city. Repo: the repo it's built from, so it stands beside that repo (a private repo's name is never shown). Short name: what your page and storefront call it, instead of the store's title.", "apps", "app");
    this.listing("Websites", "Sites you run (up to 12), a whole site or one page like example.com/tool. Each one gets a card on your page and, with Storefront on, a storefront building in your city that its live visitors walk into. Repo: the repo that builds it. Storefront off: the site lights up that repo's building instead. Short name: what your page and storefront call it, instead of the site's title.", "websites", "site");
    new import_obsidian3.Setting(containerEl).setName("Repos without storefronts").setDesc("Comma separated repo names. Their apps and websites get no storefront, and their own websites (GitHub homepage) are left off your public city. Also hideStorefronts in Caldera/profile.md.").addText((t) => {
      void this.listValue("hideStorefronts").then((v) => t.setValue(v.join(", ")));
      t.setPlaceholder("old-site, client-work").onChange((v) => this.saveList("hideStorefronts", v.split(",").map((x) => x.trim()).filter((x) => /^[A-Za-z0-9._-]{1,100}$/.test(x))));
    });
    new import_obsidian3.Setting(containerEl).setName("GitHub username").setDesc("Your public repos become your city, and your contributions your code chart. Refreshed every 6 hours. Same as a GitHub line in Links.").addText((t) => t.setPlaceholder("octocat").setValue(githubUser(s.links || []) || "").onChange(async (v) => {
      const u = v.trim().replace(/^@/, "").replace(/^https?:\/\/(www\.)?github\.com\//, "").replace(/\/.*$/, "");
      s.links = (s.links || []).filter((l) => !/^https?:\/\/(?:www\.)?github\.com\/[A-Za-z0-9-]{1,39}\/?$/.test(l[1]));
      if (/^[A-Za-z0-9-]{1,39}$/.test(u)) s.links.push(["GitHub", `https://github.com/${u}`]);
      await this.plugin.saveSettings();
    }));
    new import_obsidian3.Setting(containerEl).setName("Forgejo or Codeberg profile").setDesc("Code on Codeberg or your own Forgejo / Gitea server instead? Paste your profile address. Your public repos become your city, and your contributions your code chart. Used when no GitHub username is set.").addText((t) => t.setPlaceholder("https://codeberg.org/you").setValue((s.links || []).find((l) => l[0] === "Forgejo")?.[1] || "").onChange(async (v) => {
      const m = v.trim().replace(/^http:/, "https:").replace(/\/+$/, "").match(/^(https:\/\/[^/\s]+)\/([A-Za-z0-9._-]{1,40})$/);
      s.links = (s.links || []).filter((l) => l[0] !== "Forgejo");
      if (m) s.links.push(["Forgejo", `${m[1]}/${m[2]}`]);
      await this.plugin.saveSettings();
    }));
    this.pairs("Properties", "One per line: key | value (shown as a properties block)", "properties");
    new import_obsidian3.Setting(containerEl).setName("What is public").setHeading();
    for (const [k, label] of Object.entries(SECTION_LABELS)) {
      if (k === "garden" && !gardenEnabled()) continue;
      new import_obsidian3.Setting(containerEl).setName(label).addToggle((t) => t.setValue(s.sections[k] !== void 0 ? !!s.sections[k] : k === "garden" || k === "city").onChange(async (v) => {
        s.sections[k] = v;
        await this.plugin.saveSettings();
      }));
    }
    if (gardenEnabled()) {
      this.text("Garden folder", "Notes in this folder are published as full pages, with stage and license from their properties. Empty = only notes marked caldera: garden.", "gardenFolder", (v) => v.replace(/^\/+|\/+$/g, ""));
      new import_obsidian3.Setting(containerEl).setName("Grow my garden from my journal").setDesc("Each public project and recurring theme in your daily journal gets a garden page that adds a dated entry whenever it comes up. Uses only journal text that is already public.").addToggle((t) => t.setValue(s.gardenJournal !== false).onChange(async (v) => {
        s.gardenJournal = v;
        await this.plugin.saveSettings();
      }));
      this.text("Existing garden URL", "Optional: a garden you already publish elsewhere (Quartz, Obsidian Publish...). Linked from your page.", "gardenUrl", (v) => /^https:\/\//.test(v) ? v : "");
    }
    this.pairs("Public topics", "Only these tags are counted. One per line: tag | Label", "publicTopics");
    this.text("Activity file", "Optional JSON of daily counts from outside tools (calendar, email, git)", "activityFile");
    new import_obsidian3.Setting(containerEl).setName("Count lines of code").setDesc("Desktop: lines you added and removed each day in the git repos on this computer (your own commits). Only the two totals per day leave this device: never repo names, files or code. Shown in your daily email, not part of your score.").addToggle((t) => t.setValue(s.gitLines !== false).onChange(async (v) => {
      s.gitLines = v;
      await this.plugin.saveSettings();
    }));
    this.text("Code folders", "Optional: more folders that hold your repos, comma-separated (folders right under your home folder and ~/code, ~/src, ~/projects are found on their own)", "gitFolders");
    new import_obsidian3.Setting(containerEl).setName("My profile tab").setHeading();
    new import_obsidian3.Setting(containerEl).setName("Open my profile when Obsidian starts").setDesc("The My profile tab shows your page built from your vault, plus private sections only you can see (visits, today, on this day, patterns, goals). Switch to Public view to see the live page.").addToggle((t) => t.setValue(!!s.openProfileOnStartup).onChange(async (v) => {
      s.openProfileOnStartup = v;
      await this.plugin.saveSettings();
    })).addButton((b) => b.setButtonText("Open now").onClick(() => this.plugin.openProfileTab()));
    new import_obsidian3.Setting(containerEl).setName("Private web address (Tailscale)").setDesc(createFragment((f) => {
      f.appendText("See your private sections in a browser, on any of your Tailscale devices. Every 10 minutes Obsidian pushes them to your hub, which stores them encrypted and shows them only to your own Tailscale account, never on your public page. Needs a hub with a private address set up for you (self-hosted, or the operator's own profile).");
      if (s.privateUrl) {
        f.createEl("br");
        f.appendText("Your private address: ");
        f.createEl("a", { text: s.privateUrl, href: s.privateUrl });
      }
    })).addToggle((t) => t.setValue(!!s.privateWeb).onChange(async (v) => {
      s.privateWeb = v;
      await this.plugin.saveSettings();
      this.plugin.schedulePrivatePush();
      if (v && !await this.plugin.pushPrivate(true)) {
        s.privateWeb = false;
        await this.plugin.saveSettings();
        this.plugin.schedulePrivatePush();
      }
      this.display();
    }));
    new import_obsidian3.Setting(containerEl).setName("Live traffic on your city").setHeading();
    const sites = s.traffic || [], hub = s.hubUrl.replace(/\/$/, "");
    new import_obsidian3.Setting(containerEl).setName("Show visitors to your own sites in your city").setDesc(sites.length ? "Paste a project's snippet into that site's pages (before </body>). Each visit then rides out of its district as a light, live. Call caldera('signup') or caldera('buy') on the page to mark conversions. Your public city shows only how busy each district is; the numbers stay in your private view and private address." : "Each city district gets a tracking snippet after your next publish (you need a city: add GitHub | https://github.com/you to Links above).");
    for (const site of sites) {
      const snippet = trackTag(hub, site.key);
      new import_obsidian3.Setting(containerEl).setName(site.project).setDesc(snippet + (site.public ? "" : "  (unlisted project: shown as Private on your public city)")).addButton((b) => b.setButtonText("Copy snippet").onClick(async () => {
        await navigator.clipboard.writeText(snippet);
        new import_obsidian3.Notice(`Snippet for ${site.project} copied`);
      })).addExtraButton((b) => b.setIcon("key-round").setTooltip("Copy server key (for sending events from your own server: POST " + hub + "/v1/t/" + site.key + "/events)").onClick(async () => {
        if (!site.secret) return void new import_obsidian3.Notice("Publish once to get the server key");
        await navigator.clipboard.writeText(site.secret);
        new import_obsidian3.Notice("Server key copied. Keep it secret: it lets a server send events for this site.");
      }));
    }
    new import_obsidian3.Setting(containerEl).setName("AI agents on your city").setHeading();
    new import_obsidian3.Setting(containerEl).setName("Show your AI agents working in your city").setDesc(s.agentKey ? "Each Claude Code agent you run becomes a drone over the repo it's working in: a beam while it edits, circling while it thinks, parked at Agent HQ blinking amber when it's waiting on you. Copy the setup prompt and paste it into Claude Code on each computer you use. What an agent is working on stays private (your private view and private address); your public city only shows anonymous drones." : "Publish once (with a city) to get your agent key.").addButton((b) => b.setButtonText("Copy setup prompt").setDisabled(!s.agentKey).onClick(async () => {
      await navigator.clipboard.writeText(agentSetupPrompt(hub, s.agentKey));
      new import_obsidian3.Notice("Setup prompt copied. Paste it into Claude Code on each computer you use.");
    }));
    new import_obsidian3.Setting(containerEl).setName("Publishing").setHeading();
    new import_obsidian3.Setting(containerEl).setName("Auto-publish interval (hours)").setDesc("0 = only when you publish manually").addText((t) => t.setValue(String(s.autoPublishHours)).onChange(async (v) => {
      s.autoPublishHours = Math.max(0, Number(v) || 0);
      await this.plugin.saveSettings();
      this.plugin.scheduleAutoPublish();
    }));
  }
  text(name, desc, key, clean2 = (v) => v) {
    new import_obsidian3.Setting(this.containerEl).setName(name).setDesc(desc).addText((t) => t.setValue(String(this.plugin.settings[key] ?? "")).onChange(async (v) => {
      this.plugin.settings[key] = clean2(v.trim());
      await this.plugin.saveSettings();
    }));
  }
  /** The current list: from Caldera/profile.md when the note sets it (it wins there), else from settings. */
  async listValue(key) {
    const f = this.app.vault.getAbstractFileByPath(PROFILE_FILE), fm = f instanceof import_obsidian3.TFile ? this.app.metadataCache.getFileCache(f)?.frontmatter : null;
    const v = fm && key in fm ? fm[key] : this.plugin.settings[key];
    return Array.isArray(v) ? v.map((x) => String(x ?? "").trim()).filter(Boolean) : typeof v === "string" ? v.split(/\r?\n/).map((x) => x.trim()).filter(Boolean) : [];
  }
  /** Saved where it came from: into Caldera/profile.md when the note sets this list (so the note stays the source), else settings. */
  async saveList(key, lines) {
    const f = this.app.vault.getAbstractFileByPath(PROFILE_FILE), fm = f instanceof import_obsidian3.TFile ? this.app.metadataCache.getFileCache(f)?.frontmatter : null;
    if (f instanceof import_obsidian3.TFile && fm && key in fm) await this.app.fileManager.processFrontMatter(f, (m) => {
      m[key] = lines;
    });
    else {
      this.plugin.settings[key] = lines;
      await this.plugin.saveSettings();
      this.plugin.queuePublish("profile");
    }
  }
  /** One row per app or website: its link, the repo it's tied to (editable), a Storefront toggle and Remove; then Add. */
  listing(name, desc, key, kind) {
    new import_obsidian3.Setting(this.containerEl).setName(name).setDesc(desc);
    const box = this.containerEl.createDiv({ cls: "caldera-listings" });
    let refs = [];
    const save = () => this.saveList(key, refs.map(listingLine));
    const draw = () => {
      box.empty();
      refs.forEach((r, i) => {
        const label = r.kind === "site" ? r.url.replace(/^https?:\/\//, "").replace(/\/$/, "") : r.store === "play" ? `Google Play: ${r.id}` : `App Store: id${r.id}`;
        new import_obsidian3.Setting(box).setName(label).setClass("caldera-listing-row").addText((t) => t.setPlaceholder("repo (optional)").setValue(r.repo || "").onChange((v) => {
          const x = v.trim();
          if (x && !/^[A-Za-z0-9._-]{1,100}$/.test(x)) return;
          r.repo = x || void 0;
          void save();
        })).addText((t) => {
          t.setPlaceholder("short name (optional)").setValue(r.label || "").onChange((v) => {
            const x = cleanLabel(v);
            if (x) r.label = x;
            else delete r.label;
            void save();
          });
          t.inputEl.maxLength = MAX_LABEL;
          t.inputEl.setAttribute("aria-label", "Short name shown on your page and storefront");
        }).addToggle((t) => t.setTooltip("Storefront in my city").setValue(r.storefront !== false).onChange((v) => {
          if (v) delete r.storefront;
          else r.storefront = false;
          void save();
        })).addExtraButton((b) => b.setIcon("trash").setTooltip("Remove").onClick(() => {
          refs.splice(i, 1);
          void save();
          draw();
        }));
      });
      let add = "";
      const row = new import_obsidian3.Setting(box).setName(refs.length ? "" : `No ${kind === "app" ? "apps" : "websites"} yet`).addText((t) => t.setPlaceholder(kind === "app" ? "https://apps.apple.com/us/app/name/id123456789" : "https://example.com").onChange((v) => {
        add = v.trim();
      })).addButton((b) => b.setButtonText("Add").onClick(() => {
        const r = parseListingLine(add, kind);
        if (!r) {
          row.setDesc(kind === "app" ? "That isn't an App Store (apps.apple.com) or Google Play link." : "That isn't a website link (http or https, no IP addresses).");
          return;
        }
        if (refs.some((x) => x.key === r.key)) {
          row.setDesc("Already listed.");
          return;
        }
        if (refs.length >= MAX_LISTINGS) {
          row.setDesc(`Up to ${MAX_LISTINGS}.`);
          return;
        }
        refs.push(r);
        void save();
        draw();
      }));
    };
    void this.listValue(key).then((lines) => {
      refs = lines.map((l) => parseListingLine(l, kind)).filter((x) => !!x).slice(0, MAX_LISTINGS);
      draw();
    });
  }
  pairs(name, desc, key) {
    new import_obsidian3.Setting(this.containerEl).setName(name).setDesc(desc).addTextArea((t) => {
      t.setValue(this.plugin.settings[key].map((p) => p.join(" | ")).join("\n"));
      t.inputEl.rows = 4;
      t.onChange(async (v) => {
        this.plugin.settings[key] = v.split("\n").map((l) => l.split("|").map((x) => x.trim())).filter((p) => p[0] && p[1]).map((p) => [p[0], p.slice(1).join("|")]);
        await this.plugin.saveSettings();
      });
    });
  }
};
var TRACK_SRI = "sha384-UCnwKWu6Be2g87+ZI1+h367D6yOXEuXFQL2U2Z7PuSoH3oSCsu/cmZMbj4s70JlC";
var trackTag = (hub, key) => `<script async src="${hub.replace(/\/$/, "")}/t/1.js" integrity="${TRACK_SRI}" crossorigin="anonymous" data-site="${key}"><\/script>`;
var AGENT_HOOK_SHA256 = "bfe8dbde26fdc5e8b2e33805cdd4cadb98020ecaf34fe3f7c2e491ed636aedae";
function agentSetupPrompt(hub, k) {
  return `Set up the Caldera agent hook on this computer, so my Caldera city shows what my AI agents are working on.

1. Download ${hub}/agent-hook.mjs to ~/.caldera/agent-hook.mjs (create the folder). Read it first: it reads the hook event from stdin, works out the repo (git remote name) and a short task title, and posts only that to my Caldera hub, with a 1.5 second timeout. It never blocks or changes anything.
   Before using it, check its SHA-256 is ${AGENT_HOOK_SHA256} (shasum -a 256 ~/.caldera/agent-hook.mjs). If it doesn't match, delete it, stop and tell me.
2. Write ~/.caldera/agent.json (chmod 600): {"hub": "${hub}", "key": "${k.key}", "secret": "${k.secret}", "machine": "<a short name for this computer>"}
3. In ~/.claude/settings.json, add hooks (keep any existing ones) that run \`node ~/.caldera/agent-hook.mjs\` for UserPromptSubmit, PostToolUse, Stop, Notification and SessionEnd.
4. Test it: echo '{"hook_event_name":"UserPromptSubmit","session_id":"caldera-test-1","cwd":"'$PWD'","prompt":"Testing the Caldera agent hook"}' | node ~/.caldera/agent-hook.mjs and confirm it exits quietly, then send SessionEnd for the same session to clear the test drone.

Keep the key and secret out of any repo. If I'd rather not send task titles at all, add "tasks": false to agent.json (drones still fly, without words).`;
}

// src/collect.ts
var import_obsidian5 = require("obsidian");

// src/assets/theme.css
var theme_default = `/* ============================================================================
   LIVING PROFILE - DESIGN TOKENS
   This is the ONLY file you need to edit to restyle the whole page.
   Every color, font, size, radius and spacing used anywhere comes from here.
   profile.css uses these variables only; it never hard-codes a color.

   Quick recipes:
   - Switch to the light theme:  <html data-theme="light"> in index template,
     or set "theme": "light" in config/profile.json.
   - New accent color:           change --accent (and --accent-soft).
   - Different fonts:            change --font-body / --font-display / --font-mono
                                 (and the Google Fonts link in the template).
   - Tighter / looser layout:    change --space-unit.
   ========================================================================== */

:root {
  /* --- Typography ------------------------------------------------------- */
  --font-body: 'IBM Plex Sans', 'Helvetica Neue', Arial, sans-serif;
  --font-display: 'Source Serif 4', Georgia, serif;
  --font-mono: 'IBM Plex Mono', ui-monospace, Menlo, monospace;

  --text-xs: 11.5px;
  --text-sm: 13.5px;
  --text-md: 15px;
  --text-lg: 18px;
  --text-h2: 26px;
  --text-h1: clamp(34px, 5vw, 46px);
  --leading: 1.65;

  /* --- Spacing & shape -------------------------------------------------- */
  --space-unit: 8px;                       /* everything scales off this */
  --space-1: calc(var(--space-unit) * 0.5);
  --space-2: var(--space-unit);
  --space-3: calc(var(--space-unit) * 1.5);
  --space-4: calc(var(--space-unit) * 2);
  --space-6: calc(var(--space-unit) * 3);
  --space-8: calc(var(--space-unit) * 4);
  --radius-sm: 6px;
  --radius-md: 8px;
  --radius-lg: 14px;
  --radius-round: 999px;

  /* --- Layout ----------------------------------------------------------- */
  --sidebar-width: 250px;
  --rail-width: 300px;
  --content-width: 760px;
  --banner-height: 260px;
  --avatar-size: 112px;
  --banner-focus: 62% 14%;   /* which part of the banner photo stays in view (x y) */

  /* --- Color: dark theme (default) -------------------------------------- */
  --bg: #1C1C1F;           /* page */
  --bg-sunken: #17171A;    /* sidebars */
  --bg-raised: #232327;    /* cards, buttons */
  --bg-tab: #141416;       /* top tab bar */
  --line: #2A2A2E;         /* hairlines */
  --line-strong: #3A3A40;
  --text: #DADADF;
  --text-strong: #F2F2F5;
  --text-muted: #8A8A93;
  --accent: #8B6CF6;       /* links, highlights, graph center */
  --accent-text: #B39DFA;  /* link text on dark */
  --accent-soft: rgba(139, 108, 246, .10);
  --accent-2: #4FB89A;     /* secondary accent (help exchange, gravity) */
  --on-accent: #FFFFFF;
  --chart-bar: var(--accent);
  --chart-bar-quiet: rgba(139, 108, 246, .55);
  --graph-node: #6E6E78;
  --graph-node-hot: var(--accent-text);
  --graph-edge: var(--line-strong);
  /* activity heatmap, empty -> busiest */
  --heat-0: #232327;
  --heat-1: #3A2F66;
  --heat-2: #5B47B0;
  --heat-3: #8B6CF6;
  --heat-4: #C7B8FF;
  --chart-alt: var(--accent-2);  /* second chart color */
  --chart-github: var(--text-strong);  /* scoreboard: GitHub commits */
  --chart-ai: #E0A458;               /* scoreboard + tags: AI sessions */
  --chart-work: #5B8DEF;             /* scoreboard: meetings and email */
}

/* --- Color: light theme ------------------------------------------------- */
:root[data-theme="light"] {
  --bg: #FFFFFF;
  --bg-sunken: #F6F6F7;
  --bg-raised: #F0F0F2;
  --bg-tab: #EDEDF0;
  --line: #E4E4E7;
  --line-strong: #D0D0D6;
  --text: #2B2B30;
  --text-strong: #0D0D10;
  --text-muted: #6E6E78;
  --accent: #6D4AE8;
  --accent-text: #5A38D6;
  --accent-soft: rgba(109, 74, 232, .08);
  --accent-2: #138A6A;
  --graph-node: #A8A8B3;
  --heat-0: #EDEDF0;
  --heat-1: #D9D0FB;
  --heat-2: #B3A1F6;
  --heat-3: #8B6CF6;
  --heat-4: #5A38D6;
}
`;

// src/profile.css.ts
var PROFILE_CSS = '/* ============================================================================\n   LIVING PROFILE - COMPONENTS\n   Layout and components only. No raw colors, fonts or sizes here:\n   everything comes from theme.css. To restyle, edit theme.css.\n   ========================================================================== */\n\n* { box-sizing: border-box; }\nhtml, body { margin: 0; }\nbody {\n  background: var(--bg);\n  color: var(--text);\n  font-family: var(--font-body);\n  font-size: var(--text-md);\n  line-height: var(--leading);\n  -webkit-font-smoothing: antialiased;\n}\na { color: var(--accent-text); text-decoration: none; }\na:hover { text-decoration: underline; }\n.mono { font-family: var(--font-mono); }\n.muted { color: var(--text-muted); }\n\n/* --- Top tab bar ------------------------------------------------------- */\n.tabs {\n  display: flex; align-items: center; gap: var(--space-1);\n  background: var(--bg-tab); border-bottom: 1px solid var(--line);\n  padding: 0 var(--space-3); overflow-x: auto;\n}\n.tab { padding: 10px 14px; font-size: var(--text-sm); color: var(--text-muted); white-space: nowrap; }\n.tab.is-active {\n  color: var(--text); background: var(--bg);\n  border: 1px solid var(--line); border-bottom: 0;\n  border-radius: var(--radius-md) var(--radius-md) 0 0;\n}\n.tabs .spacer { flex: 1; }\n.sync { font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); white-space: nowrap; padding-right: var(--space-2); }\n.sync .dot { display: inline-block; width: 7px; height: 7px; border-radius: 50%; background: var(--accent-2); margin-right: 6px; animation: pulse 2.4s ease-in-out infinite; }\n\n/* --- Three-column shell ------------------------------------------------ */\n.shell { display: flex; flex-wrap: wrap; align-items: stretch; }\n.sidebar {\n  flex: 0 1 var(--sidebar-width); min-width: 200px;\n  background: var(--bg-sunken); border-right: 1px solid var(--line);\n  padding: var(--space-3) var(--space-2); font-size: var(--text-sm);\n}\n.note { flex: 999 1 560px; min-width: 0; padding-bottom: var(--space-8); }\n.rail {\n  flex: 0 1 var(--rail-width); min-width: 240px;\n  background: var(--bg-sunken); border-left: 1px solid var(--line);\n  padding: var(--space-3); display: flex; flex-direction: column; gap: var(--space-4);\n}\n@media (max-width: 900px) {\n  .sidebar { display: none; }\n  .rail { border-left: 0; border-top: 1px solid var(--line); flex-basis: 100%; }\n}\n\n/* --- File tree --------------------------------------------------------- */\n.label { font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); letter-spacing: .04em; text-transform: uppercase; }\n.tree .label { padding: 0 var(--space-2) var(--space-2); display: block; }\n.side-inner { position: sticky; top: 0; max-height: 100vh; overflow-y: auto; padding-bottom: var(--space-4); scrollbar-width: none; } .side-inner::-webkit-scrollbar { display: none; }\n.tree .label + .toc, .tree .label + .tree-group, .tree .label + .tree-row { margin-top: 0; }\n.toc { margin-bottom: var(--space-4); border-left: 1px solid var(--line); margin-left: var(--space-2); }\n.tree-row { display: flex; align-items: center; gap: 6px; padding: 4px var(--space-2); border-radius: var(--radius-sm); color: var(--text); line-height: 1.35; }\na.tree-row { text-decoration: none; }\na.tree-row:hover, summary.tree-row:hover { background: var(--bg-raised); color: var(--text-strong); text-decoration: none; }\n.tree-row.child { padding-left: calc(var(--space-2) + 18px); color: var(--text-muted); }\n.tree-row.child.is-link { color: var(--text); }\n.tree-row.is-current { background: var(--bg-raised); color: var(--text-strong); box-shadow: inset 2px 0 0 var(--accent); }\n.tree-row > span:first-child { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\n.tree-row .ext { flex: 0 0 auto; font-size: 11px; color: var(--text-muted); opacity: 0; transition: opacity .15s; }\n.tree-row:hover .ext, .tree-row:focus-visible .ext { opacity: 1; }\n.tree-row .count { flex: 0 0 auto; font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); font-variant-numeric: tabular-nums; }\n.tree-row:focus-visible { outline: 2px solid var(--accent); outline-offset: -2px; }\n.toc-row { margin-left: -1px; border-left: 2px solid transparent; border-radius: 0 var(--radius-sm) var(--radius-sm) 0; color: var(--text-muted); padding-left: var(--space-3); }\n.toc-row.is-active { color: var(--text-strong); border-left-color: var(--accent); background: var(--accent-soft); }\n.tree-group > summary { list-style: none; cursor: pointer; user-select: none; }\n.tree-group > summary::-webkit-details-marker { display: none; }\n.tree-row.group .g-name { flex: 1; font-weight: 500; }\n.tree-row.group .caret { flex: 0 0 12px; width: 12px; height: 12px; display: inline-block; }\n.tree-group > summary .caret::before { content: ""; display: block; width: 0; height: 0; margin: 2px 0 0 2px; border-left: 4px solid transparent; border-right: 4px solid transparent; border-top: 6px solid var(--text-muted); transform: rotate(-90deg); transition: transform .15s; }\n.tree-group[open] > summary .caret::before { transform: none; }\n.tree-row.group.leaf .caret::before { content: ""; display: block; width: 5px; height: 5px; margin: 3px 0 0 3px; border-radius: 50%; background: var(--line-strong); }\nhtml { scroll-behavior: smooth; } h2[id], section[id], .pnote[id] { scroll-margin-top: var(--space-4); }\n@media (prefers-reduced-motion: reduce) { html { scroll-behavior: auto; } }\n@media (max-width: 900px) {\n  .sidebar.tree { display: block; flex-basis: 100%; min-width: 0; position: sticky; top: 0; z-index: 5; padding: 0; border-right: 0; border-bottom: 1px solid var(--line); }\n  .side-inner { position: static; max-height: none; overflow: visible; padding: 0; }\n  .side-inner > .label, .side-inner > .tree-group, .side-inner > .tree-row { display: none; }\n  .toc { display: flex; overflow-x: auto; gap: 2px; margin: 0; border: 0; padding: 6px var(--space-3); scrollbar-width: none; }\n  .toc-row { white-space: nowrap; border: 0; border-radius: var(--radius-round); padding: 4px 12px; margin: 0; }\n  .side-inner:not(:has(.toc)) { display: none; }\n}\n\n/* --- Banner & title ---------------------------------------------------- */\n.banner { position: relative; height: var(--banner-height); }   /* no overflow:hidden, so the avatar can hang below */\n.banner::after { z-index: 1; }\n.banner img.cover { width: 100%; height: 100%; object-fit: cover; object-position: var(--banner-focus); opacity: .92; display: block; }\n.banner::after { content: ""; position: absolute; inset: 0; background: linear-gradient(180deg, transparent 40%, var(--bg) 100%); }\n.banner img.avatar {\n  position: absolute; left: 48px; bottom: calc(var(--avatar-size) * -0.32); z-index: 2;\n  width: var(--avatar-size); height: var(--avatar-size); border-radius: 50%;\n  object-fit: cover; object-position: center 25%; border: 4px solid var(--bg);\n}\n/* No cover photo: the avatar sits above the name instead of hanging off an empty banner */\n.page img.avatar.solo { display: block; width: calc(var(--avatar-size) * .8); height: calc(var(--avatar-size) * .8); border-radius: 50%; object-fit: cover; object-position: center 25%; margin-bottom: var(--space-4);}\n.page { max-width: var(--content-width); margin: 0 auto; padding: calc(var(--space-8) + var(--space-4)) var(--space-8) 0; }\n.crumb { font-family: var(--font-mono); font-size: 12px; color: var(--text-muted); }\nh1.title { margin: 6px 0 var(--space-4); font-family: var(--font-display); font-weight: 600; font-size: var(--text-h1); color: var(--text-strong); line-height: 1.1; }\nh1.title .caret { color: var(--accent); animation: blink 1s step-end infinite; }\nh2 { font-family: var(--font-display); font-weight: 600; font-size: var(--text-h2); color: var(--text-strong); margin: var(--space-8) 0 var(--space-2); }\n\n/* --- Properties -------------------------------------------------------- */\n.props {\n  display: grid; grid-template-columns: 150px 1fr; gap: 6px 14px;\n  border-top: 1px solid var(--line); border-bottom: 1px solid var(--line);\n  padding: 10px 0; margin-bottom: var(--space-6); font-size: var(--text-sm);\n}\n.props dt { font-family: var(--font-mono); font-size: 12.5px; color: var(--text-muted); margin: 0; }\n.props dd { margin: 0; }\n@media (max-width: 560px) { .props { grid-template-columns: 1fr; } .props dd { margin-bottom: 6px; } }\n\n/* --- Callout ----------------------------------------------------------- */\n.callout { border-left: 3px solid var(--accent); background: var(--accent-soft); border-radius: 0 var(--radius-md) var(--radius-md) 0; padding: 12px 16px; margin-bottom: var(--space-6); }\n.callout-title { font-weight: 600; color: var(--accent-text); font-size: var(--text-sm); }\n\n/* --- Lists, tables ----------------------------------------------------- */\nul.bullets { margin: 0; padding-left: 20px; }\nul.bullets li { margin: 4px 0; }\n.query { font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); margin-bottom: 6px; }\n.table-wrap { overflow-x: auto; }\ntable.data { width: 100%; border-collapse: collapse; font-size: 14px; }\ntable.data th { text-align: left; padding: 8px; border-bottom: 1px solid var(--line-strong); color: var(--text-muted); font-weight: 500; }\ntable.data td { padding: 8px; border-bottom: 1px solid var(--line); }\ntable.data .num { text-align: right; font-family: var(--font-mono); }\n\n/* --- Commit chart ------------------------------------------------------ */\n.bars { height: 110px; display: flex; gap: 3px; align-items: flex-end; border-bottom: 1px solid var(--line-strong); }\n.bars span { flex: 1; max-width: 28px; background: var(--chart-bar); border-radius: 2px 2px 0 0; transform-origin: bottom; animation: rise 1.1s cubic-bezier(.2,.8,.2,1) both; }\n.bars span.quiet { background: var(--chart-bar-quiet); }\n.bars-legend { display: flex; justify-content: space-between; font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); margin-top: 4px; }\n\n/* --- Timeline ---------------------------------------------------------- */\n.timeline { position: relative; }\n.timeline .row { display: grid; grid-template-columns: 64px 14px 1fr; gap: 0 12px; padding: 7px 0; position: relative; }\n.timeline .row::before { content: ""; position: absolute; left: calc(64px + 12px + 6px); top: 0; bottom: 0; width: 2px; background: var(--line); }\n.timeline .year { font-family: var(--font-mono); font-size: var(--text-sm); color: var(--text-muted); padding-top: 2px; font-variant-numeric: tabular-nums; }\n.timeline .dot { position: relative; z-index: 1; width: 10px; height: 10px; margin: 7px 0 0 2px; border-radius: 50%; background: var(--bg); border: 2px solid var(--accent); }\n.timeline .row.same .dot { width: 6px; height: 6px; margin: 9px 0 0 4px; border: 0; background: var(--line-strong); }\n.timeline .what { min-width: 0; }\n.timeline .detail { color: var(--text-muted); font-size: var(--text-sm); margin-top: 2px; }\n.timeline .era { display: flex; align-items: baseline; gap: 10px; margin: var(--space-4) 0 2px; padding-left: calc(64px + 12px + 14px + 12px); }\n.timeline .era:first-child { margin-top: 0; }\n.timeline .era-name { font-family: var(--font-mono); font-size: var(--text-xs); letter-spacing: .06em; text-transform: uppercase; color: var(--accent-text); }\n.timeline .era-range { font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); }\n@media (max-width: 560px) { .timeline .row { grid-template-columns: 44px 14px 1fr; gap: 0 8px; } .timeline .row::before { left: calc(44px + 8px + 6px); } .timeline .era { padding-left: calc(44px + 8px + 14px + 8px); } }\n\n/* --- Right rail -------------------------------------------------------- */\n.graph svg { width: 100%; height: 240px; display: block; }\n.graph .edge { stroke: var(--graph-edge); stroke-width: 1; }\n.graph .node { fill: var(--graph-node); }\n.graph .node.hot { fill: var(--graph-node-hot); }\n.graph .center { fill: var(--accent); }\n.graph text { fill: var(--text-muted); font-family: var(--font-body); font-size: 8.5px; }\n.graph .float { animation: float 4s ease-in-out infinite; }\n.backlink { padding: 6px 0; border-bottom: 1px solid var(--line); font-size: var(--text-sm); }\n.backlink .ctx { color: var(--text-muted); font-size: 12px; }\n.pulse-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: var(--space-2); }\n.pulse-cell { background: var(--bg-raised); border-radius: var(--radius-sm); padding: var(--space-2); }\n.pulse-cell .v { font-size: 20px; color: var(--text-strong); }\n.pulse-cell .l { font-size: var(--text-xs); color: var(--text-muted); }\n\n/* --- Help exchange (off by default in config) -------------------------- */\n.hx-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: var(--space-3); }\n.hx-card { background: var(--bg-raised); border: 1px solid var(--line); border-radius: var(--radius-md); padding: var(--space-4); }\n.hx-row { display: flex; justify-content: space-between; gap: var(--space-2); padding: 6px 0; border-bottom: 1px solid var(--line); font-size: var(--text-sm); }\n.hx-row .bounty { color: var(--accent-2); font-family: var(--font-mono); }\n\n\n/* --- Stat strip -------------------------------------------------------- */\n.stat-strip { display: grid; grid-template-columns: repeat(auto-fit, minmax(110px, 1fr)); gap: 1px; background: var(--line); border: 1px solid var(--line); border-radius: var(--radius-md); overflow: hidden; margin-bottom: var(--space-6); }\n.stat { background: var(--bg); padding: var(--space-3) var(--space-2); }\n.stat .v { font-size: 22px; color: var(--text-strong); font-variant-numeric: tabular-nums; }\n.stat .l { font-size: var(--text-xs); color: var(--text-muted); }\n.small { font-size: var(--text-sm); margin: 0 0 var(--space-2); }\n\n/* --- Activity heatmap -------------------------------------------------- */\n.heat-box { position: relative; }\n.heat-frame { display: flex; gap: 6px; }\n.heat-days { display: grid; grid-template-rows: repeat(7, 12px); gap: 3px; padding-top: 18px; font-family: var(--font-mono); font-size: 10px; line-height: 12px; color: var(--text-muted); }\n.heat-wrap { overflow-x: auto; min-width: 0; }\n.heat-months { position: relative; height: 18px; font-family: var(--font-mono); font-size: 10px; color: var(--text-muted); }\n.heat-months span { position: absolute; top: 0; white-space: nowrap; }\n.heat { outline: none; border-radius: 3px; width: max-content; }\n.heat:focus-visible { box-shadow: 0 0 0 2px var(--accent); }\n.heat i[data-d] { cursor: pointer; transition: transform .12s ease; }\n.heat i[data-d]:hover, .heat i.is-sel { transform: scale(1.25); box-shadow: 0 0 0 1.5px var(--text-strong); position: relative; z-index: 1; }\n.heat i.is-today { box-shadow: inset 0 0 0 1.5px var(--accent-2); }\n.heat i.is-pin { box-shadow: 0 0 0 1.5px var(--accent); }\n.heat-tip { position: absolute; z-index: 5; transform: translate(-50%, calc(-100% - 8px)); pointer-events: none; white-space: nowrap; background: var(--text-strong); color: var(--bg); font-size: var(--text-xs); font-family: var(--font-mono); padding: 4px 8px; border-radius: var(--radius-sm); box-shadow: 0 4px 14px rgba(0,0,0,.25); }\n.heat-tip::after { content: ""; position: absolute; left: calc(50% + var(--ax, 0px)); bottom: -4px; margin-left: -4px; border: 4px solid transparent; border-bottom: 0; border-top-color: var(--text-strong); }\n.heat-foot { display: flex; flex-wrap: wrap; gap: 6px 16px; justify-content: space-between; align-items: center; margin-top: 8px; }\n.heat-read { font-size: var(--text-sm); color: var(--text-muted); min-height: 1.4em; font-variant-numeric: tabular-nums; }\n.heat-read b { color: var(--text-strong); font-weight: 500; }\n.heat-foot .heat-legend { margin-top: 0; }\n@media (prefers-reduced-motion: reduce) { .heat i[data-d] { transition: none; } }\n.heat { display: grid; grid-template-rows: repeat(7, 12px); grid-auto-flow: column; grid-auto-columns: 12px; gap: 3px; }\n.heat i, .heat-legend i { width: 12px; height: 12px; border-radius: 2px; display: block; background: var(--heat-0); }\n.heat i.l1, .heat-legend i.l1 { background: var(--heat-1); }\n.heat i.l2, .heat-legend i.l2 { background: var(--heat-2); }\n.heat i.l3, .heat-legend i.l3 { background: var(--heat-3); }\n.heat i.l4, .heat-legend i.l4 { background: var(--heat-4); }\n.heat-legend { display: flex; gap: 4px; align-items: center; justify-content: flex-end; font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); margin-top: 6px; }\n\n/* --- Two columns, growth line, horizontal bars ------------------------- */\n.two-col { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: var(--space-6); }\n.growth { width: 100%; height: auto; display: block; }\n.growth .axis { stroke: var(--line-strong); }\n.growth .area { fill: var(--accent-soft); }\n.growth .line { fill: none; stroke: var(--accent); stroke-width: 2.5; stroke-linejoin: round; stroke-dasharray: 2000; animation: draw 2.6s ease-out both; }\n.growth .now { fill: var(--accent); animation: pulse 2s ease-in-out infinite; }\n.growth text { fill: var(--text-muted); font-family: var(--font-mono); font-size: 11px; }\n.hbar { display: grid; grid-template-columns: 130px 1fr 52px; gap: 10px; align-items: center; font-size: var(--text-sm); padding: 4px 0; }\n.hbar .track { height: 8px; background: var(--bg-raised); border-radius: 4px; overflow: hidden; }\n.hbar .fill { display: block; height: 100%; background: var(--accent); border-radius: 4px; transform-origin: left; animation: grow 1.2s cubic-bezier(.2,.8,.2,1) both; }\n.hbar .fill.alt { background: var(--chart-alt); }\n.hbar .num { text-align: right; font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); }\n.cols { height: 120px; display: flex; gap: 4px; align-items: flex-end; border-bottom: 1px solid var(--line-strong); margin-top: var(--space-2); }\n.cols span { flex: 1; height: 100%; display: flex; flex-direction: column-reverse; align-items: center; }\n.cols b { display: block; width: 100%; background: var(--chart-alt); border-radius: 2px 2px 0 0; transform-origin: bottom; animation: rise 1s cubic-bezier(.2,.8,.2,1) both; }\n.cols em { font-style: normal; font-family: var(--font-mono); font-size: 10px; color: var(--text-muted); }\n\n/* --- Topic cloud ------------------------------------------------------- */\n.cloud { display: flex; flex-wrap: wrap; gap: 6px 16px; align-items: baseline; }\n.cloud span { color: var(--text-strong); line-height: 1.3; }\n.cloud sup { font-family: var(--font-mono); font-size: 10px; color: var(--text-muted); margin-left: 2px; }\n\n@keyframes draw { from { stroke-dashoffset: 2000; } to { stroke-dashoffset: 0; } }\n@keyframes grow { from { transform: scaleX(0); } to { transform: scaleX(1); } }\n\n\n/* --- Daily journal ----------------------------------------------------- */\n.journal { background: var(--bg-raised); border: 1px solid var(--line); border-radius: var(--radius-lg); padding: var(--space-4); margin-bottom: var(--space-6); overflow: hidden; }\n.j-head { display: flex; align-items: center; gap: var(--space-3); margin-bottom: var(--space-3); }\n.j-title { flex: 1; text-align: center; }\n.j-date { font-family: var(--font-display); font-size: 22px; color: var(--text-strong); }\n.j-nav { width: 44px; height: 44px; border-radius: 50%; border: 1px solid var(--line-strong); background: var(--bg); color: var(--text); font-size: 22px; cursor: pointer; }\n.j-nav:disabled { opacity: .3; cursor: default; }\n.j-top { display: flex; flex-wrap: wrap; gap: var(--space-4); align-items: center; }\n.ring-wrap { position: relative; width: 96px; height: 96px; flex: 0 0 96px; }\n.ring { width: 96px; height: 96px; transform: rotate(-90deg); display: block; }\n.ring .trk { fill: none; stroke: var(--line); stroke-width: 9; }\n.ring .val { fill: none; stroke: var(--accent); stroke-width: 9; stroke-linecap: round; transition: stroke-dashoffset .8s cubic-bezier(.2,.8,.2,1); }\n.j-score { position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; }\n.j-score .v { font-size: 26px; color: var(--text-strong); line-height: 1; }\n.j-score .l { font-size: 10px; color: var(--text-muted); }\n.j-delta { font-family: var(--font-mono); font-size: var(--text-xs); margin-bottom: 4px; }\n.j-headline { flex: 1 1 260px; font-family: var(--font-display); font-size: 21px; color: var(--text-strong); line-height: 1.3; }\n.j-themes { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 8px; font-family: var(--font-body); }\n.j-themes span { font-size: var(--text-xs); color: var(--accent-text); background: var(--accent-soft); border-radius: var(--radius-round); padding: 2px 10px; }\n.j-chips { display: grid; grid-template-columns: repeat(auto-fit, minmax(96px, 1fr)); gap: 1px; background: var(--line); border: 1px solid var(--line); border-radius: var(--radius-md); overflow: hidden; margin: var(--space-4) 0; }\n.chip { background: var(--bg); padding: var(--space-2); }\n.chip .v { font-size: 20px; color: var(--text-strong); font-variant-numeric: tabular-nums; }\n.chip .l { font-size: var(--text-xs); color: var(--text-muted); }\n.chip .dd { font-family: var(--font-mono); font-size: var(--text-xs); min-height: 1em; }\n.up { color: var(--accent-2); } .down { color: var(--text-muted); } .flat { color: var(--text-muted); }\n.j-lists ul { margin-top: 4px; }\n.flip-l { animation: flipL .45s ease both; } .flip-r { animation: flipR .45s ease both; }\n@keyframes flipL { from { opacity: 0; transform: translateX(-24px) rotateY(8deg); } to { opacity: 1; transform: none; } }\n@keyframes flipR { from { opacity: 0; transform: translateX(24px) rotateY(-8deg); } to { opacity: 1; transform: none; } }\n\n/* --- Scoreboard -------------------------------------------------------- */\n.scoreboard { margin-bottom: var(--space-6); }\n.sb-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: var(--space-3); margin-bottom: var(--space-3); }\n.sb-stat .v { font-size: 30px; color: var(--text-strong); line-height: 1.1; }\n.sb-stat .v small { font-size: 14px; color: var(--text-muted); }\n.sb-stat .l { font-size: var(--text-xs); color: var(--text-muted); }\n.sb-bars { height: 90px; display: flex; gap: 3px; align-items: flex-end; border-bottom: 1px solid var(--line-strong); }\n.sb-bars span { flex: 1; background: var(--chart-bar-quiet); border-radius: 2px 2px 0 0; transform-origin: bottom; animation: rise 1s cubic-bezier(.2,.8,.2,1) both; }\n.sb-bars span.yday { background: var(--accent); }\n.sb-bars span.today { background: repeating-linear-gradient(45deg, var(--chart-bar-quiet), var(--chart-bar-quiet) 3px, transparent 3px, transparent 6px); }\n.sb-lower { margin-top: var(--space-4); }\n.lb-row { display: grid; grid-template-columns: 26px 1fr auto; gap: 10px; align-items: center; padding: 7px 0; border-bottom: 1px solid var(--line); font-size: var(--text-sm); }\n.lb-row .rank { font-family: var(--font-mono); color: var(--text-muted); }\n.lb-row .num { font-family: var(--font-mono); }\n.lb-row.me .who { color: var(--text-strong); font-weight: 600; }\n.lb-row.empty .who { color: var(--text-muted); border: 1px dashed var(--line-strong); border-radius: var(--radius-sm); padding: 2px 8px; justify-self: start; }\n.sb-how { margin-top: var(--space-3); font-size: var(--text-sm); color: var(--text-muted); }\n.sb-how summary { cursor: pointer; color: var(--accent-text); }\n\n/* --- Footer ------------------------------------------------------------ */\n.foot { margin-top: var(--space-8); padding-top: var(--space-3); border-top: 1px solid var(--line); font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); }\n\n/* --- Motion (respects reduced-motion) ---------------------------------- */\n@keyframes pulse { 0%,100% { opacity: .35; } 50% { opacity: 1; } }\n@keyframes blink { 50% { opacity: 0; } }\n@keyframes rise { from { transform: scaleY(0); } to { transform: scaleY(1); } }\n@keyframes float { 0%,100% { transform: translate(0,0); } 50% { transform: translate(3px,-4px); } }\n@media (prefers-reduced-motion: reduce) { * { animation: none !important; } }\n\n.note { max-width: 100%; }\n.lede { font-size: var(--text-lg); color: var(--text-muted); margin: -8px 0 var(--space-6); }\n.pnote { padding: var(--space-3) 0; border-bottom: 1px solid var(--line); }\n.pn-title { font-family: var(--font-display); font-size: 19px; color: var(--text-strong); }\n.pn-ex { color: var(--text); font-size: var(--text-sm); }\n.pn-date { font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); }\n\n.lb-wrap { position: relative; }\n.lb-row.empty .invite-btn { font: inherit; font-size: var(--text-sm); cursor: pointer; background: transparent; color: var(--accent-text); border: 1px dashed var(--accent); border-radius: var(--radius-sm); padding: 2px 10px; justify-self: start; text-decoration: none; display: inline-flex; align-items: center; gap: 6px; }\n.lb-row.empty .invite-btn::before { content: "+"; font-family: var(--font-mono); }\n.lb-row.empty .invite-btn:hover, .lb-row.empty .invite-btn[aria-expanded="true"] { background: var(--accent-soft); border-style: solid; text-decoration: none; }\n.lb-row.empty .invite-btn:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }\n.invite-pop { position: absolute; z-index: 20; width: min(340px, 100%); background: var(--bg-raised); border: 1px solid var(--line-strong); border-radius: var(--radius-md); padding: 14px; box-shadow: 0 12px 32px rgba(0,0,0,.35); }\n.invite-pop .inv-head { display: flex; justify-content: space-between; align-items: start; gap: 8px; }\n.invite-pop .inv-title { font-weight: 600; color: var(--text-strong); font-size: var(--text-sm); }\n.invite-pop .inv-sub { color: var(--text-muted); font-size: var(--text-xs); margin: 2px 0 10px; line-height: 1.45; }\n.invite-pop .inv-close { background: none; border: 0; color: var(--text-muted); font-size: 18px; line-height: 1; cursor: pointer; padding: 0 2px; }\n.invite-pop .inv-link { display: flex; gap: 6px; }\n.invite-pop .inv-url { flex: 1; min-width: 0; font-family: var(--font-mono); font-size: 12px; color: var(--text); background: var(--bg); border: 1px solid var(--line); border-radius: var(--radius-sm); padding: 6px 8px; }\n.invite-pop button.inv-copy { background: var(--accent); color: var(--bg); border: 0; border-radius: var(--radius-sm); padding: 6px 12px; font: inherit; font-size: var(--text-sm); font-weight: 600; cursor: pointer; }\n.invite-pop .inv-ways { display: flex; gap: 6px; margin-top: 8px; }\n.invite-pop .inv-ways a, .invite-pop .inv-ways button { flex: 1; text-align: center; font: inherit; font-size: var(--text-sm); color: var(--text); background: var(--bg); border: 1px solid var(--line); border-radius: var(--radius-sm); padding: 6px 0; cursor: pointer; text-decoration: none; }\n.invite-pop .inv-ways a:hover, .invite-pop .inv-ways button:hover { border-color: var(--accent); color: var(--text-strong); text-decoration: none; }\n.invite-pop .inv-status { min-height: 1.2em; margin-top: 6px; font-size: var(--text-xs); color: var(--accent-2); }\n.invite-pop button:focus-visible, .invite-pop a:focus-visible, .invite-pop input:focus-visible { outline: 2px solid var(--accent); outline-offset: 1px; }\n\n/* Heatmap sizing (2026-10-12): cells grow with the column (11-18px), room for the hover zoom, no stray scrollbar */\n.heat-box { container-type: inline-size; }\n.heat-frame { --gap: 3px; --cell: clamp(8px, calc((100cqw - 46px - 25 * var(--gap)) / 26), 18px); }\n@container (max-width: 460px) { .heat-frame { --gap: 2px; } }\n.heat, .heat-days { gap: var(--gap, 3px); }\n.heat-days { grid-template-rows: repeat(7, var(--cell, 12px)); line-height: var(--cell, 12px); }\n.heat-wrap { overflow-x: auto; overflow-y: hidden; padding: 4px; margin: -4px; scrollbar-width: none; }\n.heat-wrap::-webkit-scrollbar { display: none; }\n.heat { grid-template-rows: repeat(7, var(--cell, 12px)); grid-auto-columns: var(--cell, 12px); }\n.heat i { width: var(--cell, 12px); height: var(--cell, 12px); border-radius: 3px; }\n.heat i[data-d]:hover, .heat i.is-sel { transform: scale(1.18); }\n\n/* --- Standard nav: pages block + add-friend --------------------------- */\n.toc.pages .friend-row { color: var(--accent); }\n.toc.pages .friend-row:hover { color: var(--accent); background: var(--accent-soft); }\n.tree-row.group .g-link { color: inherit; text-decoration: none; }\n.tree-row.group .g-link:hover { color: var(--accent); text-decoration: underline; }\n\n/* custom modules (Caldera/modules/*.md) */\n.module .mod-body > :first-child { margin-top: 0; }\n.module .mod-body h3, .module .mod-body h4 { font-family: var(--font-display); color: var(--text-strong); margin: var(--space-4) 0 var(--space-2); }\n.module .mod-body p { margin: 0 0 var(--space-3); }\n.module .mod-body img { display: block; max-width: 100%; height: auto; border-radius: var(--radius-md); border: 1px solid var(--line); margin: var(--space-2) 0; }\n.module .mod-body blockquote { margin: 0 0 var(--space-3); padding: var(--space-2) var(--space-3); border-left: 3px solid var(--accent); background: var(--accent-soft); border-radius: 0 var(--radius-sm) var(--radius-sm) 0; color: var(--text); }\n.module .mod-body blockquote p:last-child { margin-bottom: 0; }\n.module .mod-body code { font-family: var(--font-mono); font-size: .92em; background: var(--bg-raised); border: 1px solid var(--line); border-radius: var(--radius-sm); padding: 0 4px; }\n.module .mod-body pre { overflow-x: auto; background: var(--bg-raised); border: 1px solid var(--line); border-radius: var(--radius-md); padding: var(--space-3); }\n.module .mod-body pre code { border: 0; padding: 0; background: none; }\n.module .mod-body hr { border: 0; border-top: 1px solid var(--line); margin: var(--space-4) 0; }\n.module .mod-body ol { padding-left: 1.4em; }\n.module .mod-body input[type=checkbox] { margin-right: 6px; }\n.module .mod-body li:has(> input[type=checkbox]) { list-style: none; margin-left: -1.2em; }\n.module.side .mod-body { font-size: var(--text-sm); }\n.module.side .mod-body ul.bullets, .module.side .mod-body ol { margin: 0; }\n.module.side .mod-body p { margin: 0 0 var(--space-2); }\n\n/* --- Section headers: where each part comes from ---------------------- */\n.sec-src { display: flex; flex-wrap: wrap; align-items: center; gap: 6px 8px; margin: 0 0 var(--space-3); font-size: var(--text-sm); color: var(--text-muted); line-height: 1.45; }\n.sec-what { flex: 1 1 240px; min-width: 0; }\n.src { display: inline-flex; align-items: center; gap: 6px; padding: 2px 9px; border: 1px solid var(--line); border-radius: 999px; font-family: var(--font-mono); font-size: var(--text-xs); letter-spacing: .02em; color: var(--text); white-space: nowrap; }\n.src::before { content: ""; width: 7px; height: 7px; border-radius: 50%; background: var(--text-muted); }\n.s-obsidian::before { background: var(--accent); }\n.s-github::before { background: var(--text-strong); }\n.s-caldera::before { background: var(--accent-2); }\n.s-agents::before { background: var(--accent-text); border-radius: 2px; }\n.s-profile::before, .s-module::before { background: transparent; border: 1.5px solid var(--accent); width: 5px; height: 5px; }\nh2.t { margin-top: 0; }\n.journal .sec-src { margin: calc(-1 * var(--space-2)) 0 var(--space-3); }\n\n/* --- Scoreboard bars split by source ---------------------------------- */\n.sb-bars span { display: flex; flex-direction: column-reverse; overflow: hidden; }\n.sb-bars span i { display: block; min-height: 1px; }\n.sb-bars span:not(.yday) i { opacity: .62; }\n.sb-bars span.today i { opacity: .3; }\n.sb-bars span:has(i) { background: none; }\n.g-obsidian { background: var(--accent); }\n.g-github { background: var(--chart-github); }\n.g-ai { background: var(--chart-ai); }\n.g-work { background: var(--chart-work); }\n.sb-split { display: flex; flex-wrap: wrap; align-items: center; gap: 6px 16px; margin-top: var(--space-3); font-size: var(--text-sm); color: var(--text-muted); }\n.sb-split .label { flex-basis: 100%; }\n.sb-key { display: inline-flex; align-items: center; gap: 6px; white-space: nowrap; }\n.sb-key i { width: 10px; height: 10px; border-radius: 2px; }\n.sb-key b { color: var(--text-strong); font-weight: 600; font-variant-numeric: tabular-nums; }\n.s-agents::before { background: var(--chart-ai); }\n.s-calendar::before { background: var(--chart-work); }\n';

// src/garden.ts
var STAGES = ["seedling", "budding", "evergreen"];
var LICENSES = {
  "all-rights": { label: "All rights reserved. Not licensed for AI training.", short: "All rights reserved", ai: false },
  "cc-by": { label: "Creative Commons Attribution 4.0. Reuse with credit.", short: "CC BY 4.0", ai: true, url: "https://creativecommons.org/licenses/by/4.0/" },
  "cc-by-nc": { label: "Creative Commons Attribution-NonCommercial 4.0. Reuse with credit, not commercially.", short: "CC BY-NC 4.0", ai: false, url: "https://creativecommons.org/licenses/by-nc/4.0/" },
  "cc0": { label: "Public domain (CC0). No rights reserved.", short: "CC0", ai: true, url: "https://creativecommons.org/publicdomain/zero/1.0/" },
  "ai-licensable": { label: "Available to license for AI training, with the author's permission and payment. Not free to use.", short: "AI-licensable", ai: false }
};
var STAGE_ICON = { seedling: "&#127793;", budding: "&#127807;", evergreen: "&#127795;" };
var STAGE_TIP = { seedling: "Seedling: a rough, early idea", budding: "Budding: taking shape", evergreen: "Evergreen: worked through and stable" };
var normStage = (v) => {
  const s = String(v ?? "").toLowerCase().trim();
  return STAGES.includes(s) ? s : "seedling";
};
var normLicense = (v) => {
  const s = String(v ?? "").toLowerCase().trim();
  return LICENSES[s] ? s : "all-rights";
};
function redact(md) {
  let removed = 0;
  const text = md.replace(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g, () => {
    removed++;
    return "[email removed]";
  }).replace(/(?<![\w/.=-])(\+?\d[\d .()-]{8,}\d)(?![\w/])/g, (m) => {
    if ((m.match(/\d/g) || []).length < 10) return m;
    removed++;
    return "[phone removed]";
  });
  return { text, removed };
}
var esc3 = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
function parseXLink(target) {
  const m = target.match(/^@([a-z0-9][a-z0-9-]{1,30})\/(.+)$/i);
  return m ? { handle: m[1].toLowerCase(), title: m[2].trim(), slug: slug(m[2]) } : null;
}
function mdToHtml(md, link, image = () => null) {
  const lines = md.replace(/\r\n?/g, "\n").split("\n");
  const out = [];
  let para = [];
  let list = null;
  let quote = [];
  const flushPara = () => {
    if (para.length) {
      out.push(`<p>${inl(para.join(" "))}</p>`);
      para = [];
    }
  };
  const flushList = () => {
    if (list) {
      out.push(`<${list.tag}>${list.items.map((i) => `<li>${i}</li>`).join("")}</${list.tag}>`);
      list = null;
    }
  };
  const flushQuote = () => {
    if (quote.length) {
      out.push(`<blockquote>${mdToHtml(quote.join("\n"), link, image)}</blockquote>`);
      quote = [];
    }
  };
  const flush = () => {
    flushPara();
    flushList();
    flushQuote();
  };
  function inl(t) {
    const tokens = [];
    const keep = (html) => {
      tokens.push(html);
      return `\uE000${tokens.length - 1}\uE000`;
    };
    t = t.replace(/`([^`]+)`/g, (_m, c) => keep(`<code>${esc3(c)}</code>`));
    t = t.replace(/!\[\[([^\]|]+)(\|[^\]]*)?\]\]/g, (_m, tgt) => {
      const src = image(tgt.trim());
      return src ? keep(`<img src="${esc3(src)}" alt="${esc3(tgt.trim())}" loading="lazy">`) : "";
    });
    t = t.replace(/\[\[([^\]|#]+)(#[^\]|]*)?(\|([^\]]+))?\]\]/g, (_m, tgt, _h, _p, label) => {
      const text = (label || tgt).trim(), x = parseXLink(tgt.trim());
      const href = link(tgt.trim());
      if (href) return keep(`<a class="${x ? "xlink" : "internal"}" href="${esc3(href)}">${esc3(text.replace(/^@[^/]+\//, ""))}${x ? `<span class="xl-who">@${esc3(x.handle)}</span>` : ""}</a>`);
      return keep(`<span class="unlinked">${esc3(text)}</span>`);
    });
    t = t.replace(/!\[([^\]]*)\]\((https:\/\/[^)\s]+)\)/g, (_m, alt, u) => keep(`<a href="${esc3(u)}" rel="noopener nofollow" target="_blank">${esc3(alt || "image")}</a>`));
    t = t.replace(/\[([^\]]+)\]\(((?:https?:\/\/|mailto:)[^)\s]+)\)/g, (_m, label, u) => keep(`<a href="${esc3(u)}" rel="noopener nofollow" target="_blank">${esc3(label)}</a>`));
    t = t.replace(/(^|[\s(])(https?:\/\/[^\s)<]+)/g, (_m, pre, u) => pre + keep(`<a href="${esc3(u)}" rel="noopener nofollow" target="_blank">${esc3(u)}</a>`));
    let h = esc3(t);
    h = h.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>").replace(/__([^_]+)__/g, "<strong>$1</strong>").replace(/(^|[^*\w])\*([^*\s][^*]*)\*/g, "$1<em>$2</em>").replace(/(^|[^_\w])_([^_\s][^_]*)_/g, "$1<em>$2</em>").replace(/~~([^~]+)~~/g, "<del>$1</del>").replace(/==([^=]+)==/g, "<mark>$1</mark>");
    return h.replace(/\uE000(\d+)\uE000/g, (_m, i) => tokens[Number(i)]);
  }
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const fence = line.match(/^\s*(```|~~~)(.*)$/);
    if (fence) {
      flush();
      const body = [];
      for (i++; i < lines.length && !lines[i].trim().startsWith(fence[1]); i++) body.push(lines[i]);
      out.push(`<pre><code>${esc3(body.join("\n"))}</code></pre>`);
      continue;
    }
    if (/^\s*%%/.test(line)) {
      flush();
      if (!/%%.*%%/.test(line)) for (i++; i < lines.length && !lines[i].includes("%%"); i++) ;
      continue;
    }
    const q2 = line.match(/^\s*>\s?(.*)$/);
    if (q2) {
      flushPara();
      flushList();
      quote.push(q2[1].replace(/^\[!(\w+)\][+-]?\s*/, (_m, k) => `**${k.charAt(0).toUpperCase() + k.slice(1)}:** `));
      continue;
    } else flushQuote();
    if (/^\s*\|.*\|\s*$/.test(line) && i + 1 < lines.length && /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(lines[i + 1])) {
      flush();
      const cells = (l) => l.trim().replace(/^\|/, "").replace(/\|$/, "").replace(/\[\[[^\]]*\]\]/g, (w) => w.replace(/\|/g, "\uE001")).split(/(?<!\\)\|/).map((c) => inl(c.trim().replace(/\\\|/g, "|").replace(/\uE001/g, "|")));
      const head2 = cells(line);
      const rows = [];
      for (i += 2; i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i]); i++) rows.push(cells(lines[i]));
      i--;
      out.push(`<table><thead><tr>${head2.map((c) => `<th>${c}</th>`).join("")}</tr></thead><tbody>${rows.map((r) => `<tr>${head2.map((_c, k) => `<td>${r[k] ?? ""}</td>`).join("")}</tr>`).join("")}</tbody></table>`);
      continue;
    }
    const h = line.match(/^(#{1,6})\s+(.*)$/);
    if (h) {
      flush();
      const lvl = Math.min(6, h[1].length + 1);
      out.push(`<h${lvl}>${inl(h[2])}</h${lvl}>`);
      continue;
    }
    if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(line)) {
      flush();
      out.push("<hr>");
      continue;
    }
    const li = line.match(/^\s*([-*+]|\d+[.)])\s+(\[( |x|X)\]\s+)?(.*)$/);
    if (li) {
      flushPara();
      const tag = /\d/.test(li[1]) ? "ol" : "ul";
      if (!list || list.tag !== tag) {
        flushList();
        list = { tag, items: [] };
      }
      const box = li[2] ? `<input type="checkbox" disabled${/x/i.test(li[3]) ? " checked" : ""}> ` : "";
      list.items.push(box + inl(li[4]));
      continue;
    }
    if (!line.trim()) {
      flush();
      continue;
    }
    flushList();
    para.push(line.trim());
  }
  flush();
  return out.join("\n");
}
function excerptOf(md, n = 200) {
  const para = md.replace(/```[\s\S]*?```/g, "").split(/\n\s*\n/).map((x) => x.replace(/^#+\s.*$/gm, "").replace(/^\s*>\s?/gm, "").trim()).find((x) => x.length > 20) || "";
  return clip(para.replace(/!\[\[[^\]]*\]\]/g, "").replace(/\[\[(?:@[^/\]]+\/)?([^\]|]+)(\|([^\]]+))?\]\]/g, (_m, t, _p, l) => l || t).replace(/\[([^\]]+)\]\([^)]+\)/g, "$1").replace(/[*_`=~]/g, "").replace(/\s+/g, " ").trim(), n);
}
function page(site, title, body, depth, extraHead = "") {
  const up = depth ? "../".repeat(depth) : "";
  const icon = site.icon ? `<link rel="icon" href="${up}${esc3(site.icon)}" type="image/png">` : `<link rel="icon" href="${up}assets/favicon.svg" type="image/svg+xml">`;
  return `<!doctype html><html lang="en"${site.theme === "light" ? ' data-theme="light"' : ""}><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc3(title)}</title>
<meta name="robots" content="noindex, nofollow"><meta name="generator" content="Caldera for Obsidian">${extraHead}
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400&display=swap">
${icon}<link rel="stylesheet" href="${up}assets/theme.css"><link rel="stylesheet" href="${up}assets/profile.css"><link rel="stylesheet" href="${up}assets/garden.css"></head><body>
${body}</body></html>`;
}
var clip = (t, n) => t.length <= n ? t : t.slice(0, n).replace(/\s+\S*$/, "").replace(/[,;:.\s]+$/, "") + "\u2026";
var fmtDate = (iso2) => new Date(iso2).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
var stageBadge = (s) => `<span class="g-stage g-${s}" title="${STAGE_TIP[s]}">${STAGE_ICON[s]} ${s}</span>`;
var licenseLine = (key) => {
  const L = LICENSES[key] || LICENSES["all-rights"];
  return L.url ? `<a href="${L.url}" rel="license noopener" target="_blank">${esc3(L.short)}</a>` : esc3(L.short);
};
function renderGarden(site, notes, images = {}) {
  if (!notes.length) return {};
  const hub = (site.hub || "https://caldera.social").replace(/\/$/, "");
  const bySlug = new Map(notes.map((n) => [n.slug, n]));
  const byTitle = new Map(notes.map((n) => [n.title.toLowerCase(), n]));
  const back = /* @__PURE__ */ new Map();
  for (const n of notes) for (const o of n.out) if (o !== n.slug && bySlug.has(o)) back.set(o, [...back.get(o) || [], n]);
  const who = site.handle ? `@${site.handle}` : site.name;
  const files = {};
  const tabs = (active) => `<div class="tabs"><a class="tab" href="${active === "index" ? "" : "../"}index.html">${esc3(site.name)}.md</a><a class="tab${active === "garden" ? " is-active" : ""}" href="${active === "note" ? "../" : ""}garden.html">Garden</a>${active === "note" ? `<span class="tab is-active">%%TITLE%%</span>` : ""}<span class="spacer"></span></div>`;
  for (const n of notes) {
    const link = (target) => {
      const x = parseXLink(target);
      if (x) return `${hub}/@${x.handle}/n/${x.slug}.html`;
      const hit = byTitle.get(target.split("/").pop().replace(/\.md$/i, "").toLowerCase());
      return hit ? `${hit.slug}.html` : null;
    };
    const img = (target) => images[target] ? `../${images[target]}` : null;
    const body = mdToHtml(n.markdown, link, img);
    const bl = back.get(n.slug) || [];
    const L = LICENSES[n.license] || LICENSES["all-rights"];
    const html = `${tabs("note").replace("%%TITLE%%", esc3(n.title))}
<div class="shell">${site.nav ? site.nav(1, `n/${n.slug}.html`) : ""}<main class="note"><div class="g-main"><article class="g-note">
<div class="g-crumbs"><a href="../index.html">${esc3(who)}</a> / <a href="../garden.html">Garden</a></div>
<h1 class="g-title">${esc3(n.title)}</h1>
<div class="g-meta">${stageBadge(n.stage)}<span>Planted ${fmtDate(n.created)}</span><span>Tended ${fmtDate(n.updated)}</span><span>${n.words.toLocaleString("en-US")} words</span></div>
<div class="g-body">${body}</div>
${bl.length ? `<section class="g-links"><h2>Links to this note</h2>${bl.map((b) => `<a class="g-card" href="${b.slug}.html"><span class="g-card-t">${esc3(b.title)}</span><span class="g-card-x">${esc3(clip(b.excerpt, 120))}</span></a>`).join("")}</section>` : ""}
<!--caldera:xlinks-->
<footer class="g-foot"><div><b>License:</b> ${licenseLine(n.license)}. ${esc3(L.label)}</div>
<div class="g-prov"><b>Provenance:</b> sha256 <code title="${n.sha256}">${n.sha256.slice(0, 16)}</code> of <a href="${n.slug}.md">the published text</a>, listed in <a href="../caldera.json">${esc3(who)}'s signed manifest</a>${site.id ? ` (key <code>${esc3(site.id.slice(0, 14))}&hellip;</code>)` : ""}. Anyone can check the author and date.</div></footer>
</article></div></main></div>`;
    files[`n/${n.slug}.html`] = page(
      site,
      `${n.title} - ${site.name}`,
      html,
      1,
      `
<meta name="description" content="${esc3(n.excerpt)}">${L.ai ? "" : `
<meta name="robots" content="noai, noimageai">`}${L.url ? `
<link rel="license" href="${L.url}">` : ""}`
    );
    files[`n/${n.slug}.md`] = n.markdown;
  }
  const counts = STAGES.map((s) => [s, notes.filter((n) => n.stage === s).length]);
  const sorted = [...notes].sort((a, b) => b.updated.localeCompare(a.updated));
  const idx = `${tabs("garden")}
<div class="shell">${site.nav ? site.nav(0, "garden.html") : ""}<main class="note"><div class="g-main"><div class="g-index">
<div class="g-crumbs"><a href="index.html">${esc3(who)}</a> / Garden</div>
<h1 class="g-title">${esc3(site.name)}'s garden</h1>
<p class="g-lede">Notes grown in public from an Obsidian vault. Some are seedlings, some are evergreen; all of them keep changing.${site.external ? ` More at <a href="${esc3(site.external)}" rel="noopener" target="_blank">${esc3(site.external.replace(/^https?:\/\//, "").replace(/\/$/, ""))}</a>.` : ""}</p>
<!--caldera:gardenhome--><div class="g-filter" role="toolbar" aria-label="Filter by stage"><button class="is-on" data-stage="all">All <span>${notes.length}</span></button>${counts.filter(([, c]) => c).map(([s, c]) => `<button data-stage="${s}">${STAGE_ICON[s]} ${s} <span>${c}</span></button>`).join("")}</div>
<div class="g-list">${sorted.map((n) => `<a class="g-card" data-stage="${n.stage}" href="n/${n.slug}.html"><span class="g-card-t">${esc3(n.title)}</span><span class="g-card-x">${esc3(n.excerpt)}</span><span class="g-card-m">${stageBadge(n.stage)}<span>Tended ${fmtDate(n.updated)}</span>${n.xlinks.length ? `<span>${n.xlinks.length} link${n.xlinks.length === 1 ? "" : "s"} to other gardens</span>` : ""}</span></a>`).join("")}</div>
</div></div></main></div>
<script>(function(){var b=[].slice.call(document.querySelectorAll('.g-filter button')),c=[].slice.call(document.querySelectorAll('.g-list .g-card'));b.forEach(function(x){x.onclick=function(){b.forEach(function(y){y.classList.toggle('is-on',y===x)});var s=x.getAttribute('data-stage');c.forEach(function(k){k.hidden=s!=='all'&&k.getAttribute('data-stage')!==s})}})})();<\/script>`;
  files["garden.html"] = page(site, `${site.name}'s garden`, idx, 0);
  files["garden.json"] = JSON.stringify({
    name: site.name,
    handle: site.handle,
    external: site.external,
    notes: sorted.map((n) => ({ slug: n.slug, title: n.title, stage: n.stage, license: n.license, created: n.created, updated: n.updated, sha256: n.sha256, words: n.words, xlinks: n.xlinks }))
  }, null, 1);
  files["assets/garden.css"] = GARDEN_CSS;
  return files;
}
function gardenManifest(notes) {
  return notes.map((n) => ({
    slug: n.slug,
    title: n.title,
    stage: n.stage,
    license: n.license,
    created: n.created,
    updated: n.updated,
    sha256: n.sha256,
    words: n.words,
    excerpt: n.excerpt.slice(0, 200),
    xlinks: n.xlinks.map((x) => `${x.handle}/${x.slug}`)
  }));
}
function gardenSection(notes, external) {
  if (!notes.length && !external) return "";
  const sorted = [...notes].sort((a, b) => b.updated.localeCompare(a.updated)).slice(0, 6);
  const counts = STAGES.map((s) => [s, notes.filter((n) => n.stage === s).length]).filter(([, c]) => c);
  return `<h2>Garden</h2><p class="small">${notes.length ? `${notes.length} note${notes.length === 1 ? "" : "s"} grown in public: ${counts.map(([s, c]) => `${STAGE_ICON[s]} ${c} ${s}`).join(" &middot; ")}. ` : ""}${notes.length ? `<a href="garden.html">Garden home: notes, gravity, help credits, asks and offers &rarr;</a>` : ""}${external ? ` ${notes.length ? "Also at" : "My garden:"} <a href="${esc3(external)}" rel="noopener" target="_blank">${esc3(external.replace(/^https?:\/\//, "").replace(/\/$/, ""))}</a>` : ""}</p>${sorted.length ? `<div class="g-list g-list-profile">${sorted.map((n) => `<a class="g-card" href="n/${n.slug}.html"><span class="g-card-t">${esc3(n.title)}</span><span class="g-card-x">${esc3(clip(n.excerpt, 140))}</span><span class="g-card-m">${stageBadge(n.stage)}<span>Tended ${fmtDate(n.updated)}</span></span></a>`).join("")}</div>` : ""}`;
}
var GARDEN_CSS = `/* Caldera garden: note pages + index. Tokens come from theme.css. */
.tabs a.tab { color: var(--text-muted); text-decoration: none; }
.tabs a.tab:hover { color: var(--text); }
.tree-row.group .g-link { color: inherit; text-decoration: none; }
.tree-row.group .g-link:hover { color: var(--accent); text-decoration: underline; }
.shell > .note > .g-main { width: 100%; }
.g-main { max-width: 760px; margin: 0 auto; padding: 32px 20px 64px; }
.g-crumbs { font-size: var(--text-sm); color: var(--text-muted); margin-bottom: 10px; }
.g-crumbs a { color: var(--text-muted); }
.g-title { font-family: var(--font-display); font-size: 2.1rem; line-height: 1.15; font-weight: 600; margin: 0 0 12px; color: var(--text-strong); }
.g-lede { color: var(--text-muted); margin: 0 0 18px; }
.g-meta { display: flex; flex-wrap: wrap; gap: 8px 16px; align-items: center; font-size: var(--text-sm); color: var(--text-muted); padding-bottom: 18px; border-bottom: 1px solid var(--line); margin-bottom: 22px; }
.g-stage { display: inline-flex; align-items: center; gap: 5px; padding: 2px 10px; border-radius: 999px; border: 1px solid var(--line-strong); font-size: var(--text-xs); text-transform: capitalize; color: var(--text); background: var(--bg-raised); white-space: nowrap; }
.g-evergreen { border-color: var(--accent); }
.g-body { font-family: var(--font-display); font-size: 1.12rem; line-height: 1.7; color: var(--text); overflow-wrap: anywhere; }
.g-body h2, .g-body h3, .g-body h4 { font-family: var(--font-display); color: var(--text-strong); margin: 1.6em 0 .5em; line-height: 1.25; }
.g-body p, .g-body ul, .g-body ol, .g-body blockquote, .g-body pre { margin: 0 0 1em; }
.g-body ul, .g-body ol { padding-left: 1.3em; }
.g-body blockquote { border-left: 3px solid var(--accent); padding: 2px 0 2px 16px; color: var(--text-muted); }
.g-body code { font-family: var(--font-mono); font-size: .85em; background: var(--bg-sunken); padding: 1px 5px; border-radius: 4px; }
.g-body pre { background: var(--bg-sunken); padding: 14px; border-radius: var(--radius-md); overflow-x: auto; }
.g-body pre code { background: none; padding: 0; }
.g-body img { max-width: 100%; height: auto; border-radius: var(--radius-md); }
.g-body a.internal { border-bottom: 1px dashed var(--accent-text); text-decoration: none; }
.g-body a.xlink { border-bottom: 1px dashed var(--accent-text); text-decoration: none; }
.g-body .xl-who { font-family: var(--font-body); font-size: .7em; margin-left: 4px; padding: 0 6px; border-radius: 999px; background: var(--accent-soft); color: var(--accent-text); vertical-align: 2px; }
.g-body .unlinked { color: var(--text); }
.g-body mark { background: var(--accent-soft); color: inherit; }
.g-body hr { border: 0; border-top: 1px solid var(--line); margin: 2em 0; }
.g-links, .g-xlinks { margin-top: 36px; }
.g-links h2, .g-xlinks h2 { font-size: var(--text-sm); text-transform: uppercase; letter-spacing: .06em; color: var(--text-muted); font-weight: 600; margin: 0 0 10px; }
.g-list { display: grid; gap: 10px; }
.g-list-profile { grid-template-columns: repeat(auto-fill, minmax(230px, 1fr)); margin-bottom: 8px; }
.g-card { display: flex; flex-direction: column; gap: 6px; padding: 14px 16px; border: 1px solid var(--line); border-radius: var(--radius-md); background: var(--bg-raised); color: var(--text); text-decoration: none; }
.g-card:hover { border-color: var(--accent); text-decoration: none; }
.g-card-t { font-family: var(--font-display); font-weight: 600; font-size: 1.05rem; color: var(--text-strong); }
.g-card-x { font-size: var(--text-sm); color: var(--text-muted); line-height: 1.5; }
.g-card-m { display: flex; flex-wrap: wrap; gap: 6px 12px; align-items: center; font-size: var(--text-xs); color: var(--text-muted); }
.g-card .g-who { color: var(--accent-text); }
.g-filter { display: flex; flex-wrap: wrap; gap: 8px; margin: 0 0 18px; }
.g-filter button { font: inherit; font-size: var(--text-sm); color: var(--text-muted); background: var(--bg-raised); border: 1px solid var(--line); border-radius: 999px; padding: 5px 12px; cursor: pointer; text-transform: capitalize; }
.g-filter button span { opacity: .7; margin-left: 2px; }
.g-filter button.is-on { color: var(--text); border-color: var(--accent); }
.g-foot { margin-top: 40px; padding-top: 16px; border-top: 1px solid var(--line); font-size: var(--text-xs); color: var(--text-muted); display: grid; gap: 6px; line-height: 1.5; }
.g-foot code { font-family: var(--font-mono); }
@media (max-width: 600px) { .g-main { padding: 22px 16px 48px; } .g-title { font-size: 1.7rem; } .g-body { font-size: 1.04rem; } }
`;
function journalGarden(days, projects, o = {}) {
  const minP = o.minProjectDays ?? 2, minT = o.minThemeDays ?? 5;
  const sorted = [...days].filter((d) => /^\d{4}-\d{2}-\d{2}$/.test(d.date)).sort((a, b) => b.date.localeCompare(a.date));
  const names = projects.map((p) => p.trim()).filter((p) => p.length >= 3);
  const rx = (n) => new RegExp(`(^|[^\\w])${n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?![\\w])`, "i");
  const linkify = (line, self2) => {
    let out2 = line;
    for (const n of names) {
      if (n.toLowerCase() === self2.toLowerCase()) continue;
      const m = out2.match(rx(n));
      if (!m || out2.includes("[[")) continue;
      const i = (m.index || 0) + m[1].length;
      out2 = out2.slice(0, i) + `[[${n}]]` + out2.slice(i + n.length);
    }
    return out2;
  };
  const label = (d) => (/* @__PURE__ */ new Date(d + "T12:00:00")).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" });
  const page2 = (title, hits) => {
    const body = hits.map((h) => `## ${label(h.date)}
${h.lines.map(([k, t]) => `- ${k ? `**${k}:** ` : ""}${linkify(t, title)}`).join("\n")}`).join("\n\n");
    const n = hits.length, stage = n >= 20 ? "evergreen" : n >= 5 ? "budding" : "seedling";
    return {
      title,
      days: n,
      stage,
      created: hits[n - 1].date + "T12:00:00.000Z",
      updated: hits[0].date + "T12:00:00.000Z",
      markdown: `*Grown automatically from my daily journal: each day ${title} comes up, it gets a new entry. Newest first.*

${body}
`
    };
  };
  const out = [];
  for (const p of names) {
    const r = rx(p), hits = [];
    for (const d of sorted) {
      const lines = [];
      if (d.headline && r.test(d.headline)) lines.push(["", d.headline]);
      for (const f of d.focus || []) if (r.test(f)) lines.push(["Focus", f]);
      for (const w of d.wins || []) if (r.test(w)) lines.push(["Win", w]);
      if (lines.length) hits.push({ date: d.date, lines });
    }
    if (hits.length >= minP) out.push(page2(p, hits));
  }
  const themes = /* @__PURE__ */ new Map();
  for (const d of sorted) for (const t of d.themes || []) {
    const k = String(t).trim();
    if (k) themes.set(k, [...themes.get(k) || [], d]);
  }
  const total = sorted.filter((d) => d.headline || d.focus?.length || d.wins?.length).length;
  const picked = [];
  for (const [t, ds] of [...themes].sort((a, b) => b[1].length - a[1].length)) {
    if (names.some((n) => n.toLowerCase() === t.toLowerCase())) continue;
    if (total >= 10 && ds.length > total * 0.7) continue;
    const set = new Set(ds.map((d) => d.date));
    if (picked.some((p) => {
      let both = 0;
      for (const x of set) if (p.has(x)) both++;
      return both / (set.size + p.size - both) >= 0.8;
    })) continue;
    const hits = ds.map((d) => ({ date: d.date, lines: [["", d.headline || ""], ...(d.wins || []).slice(0, 2).map((w) => ["Win", w])].filter(([, x]) => x) })).filter((h) => h.lines.length);
    if (hits.length >= minT) {
      out.push(page2(t, hits));
      picked.push(set);
    }
  }
  return out;
}
function moduleHtml(md, hub, image = () => null) {
  const base = hub.replace(/\/$/, "");
  const link = (t) => {
    const x = parseXLink(t);
    return x ? `${base}/@${x.handle}/` : null;
  };
  return mdToHtml(md, link, image).replace(/<(\/?)h([2-6])>/g, (_m, c, n) => `<${c}h${Math.min(6, Number(n) + 1)}>`).replace(/<table>/g, '<div class="table-wrap"><table class="data">').replace(/<\/table>/g, "</table></div>").replace(/<ul>/g, '<ul class="bullets">');
}

// src/render.ts
function inviteHref(p) {
  const hub = (p.hub || "https://caldera.social").replace(/\/$/, "");
  const who = p.handle ? `@${p.handle}` : p.name;
  const join = `${hub}/${p.handle ? `?invite=${encodeURIComponent(p.handle)}` : ""}#install`;
  const subject = `Join me on Caldera`;
  const body = `Hey,

I'm using Caldera, the social layer for Obsidian. It turns your notes into a living profile that updates itself, and lets our vaults connect: share notes, ask for help, and compare our daily scores.

My page: ${hub}/@${p.handle || ""}/

Set up takes about 5 minutes - copy one prompt into your AI and it installs everything:
${join}

Then add me as a friend (${who}) from the Caldera panel in Obsidian.

${p.name}`;
  return `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}
var INVITE_MSG = "I'm using Caldera, the social layer for Obsidian. It turns your notes into a living page that updates itself, and our vaults can connect and compare daily scores. Setup takes about 5 minutes: copy one prompt into your AI.";
function inviteUrl(p) {
  const hub = (p.hub || "https://caldera.social").replace(/\/$/, "");
  return `${hub}/${p.handle ? `?invite=${encodeURIComponent(p.handle)}` : ""}#install`;
}
function invitePop(p) {
  return `<div class="invite-pop" hidden role="dialog" aria-label="Invite a friend" data-url="${esc4(inviteUrl(p))}" data-msg="${esc4(INVITE_MSG)}" data-subject="Join me on Caldera"><div class="inv-head"><div><div class="inv-title">Invite a friend</div><div class="inv-sub">They get their own living page in about 5 minutes, and you compare daily scores here.</div></div><button class="inv-close" type="button" aria-label="Close">&times;</button></div><div class="inv-link"><input class="inv-url" readonly aria-label="Invite link" value="${esc4(inviteUrl(p))}"><button class="inv-copy" type="button">Copy link</button></div><div class="inv-ways"><a class="inv-email" href="#">Email</a><a class="inv-text" href="#">Text</a><button class="inv-share" type="button">Share</button></div><div class="inv-status" role="status" aria-live="polite"></div></div>`;
}
function slug(t) {
  return t.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "s";
}
var big = (n) => n >= 1e9 ? (n / 1e9).toFixed(2).replace(/\.?0+$/, "") + "B" : n >= 1e6 ? (n / 1e6).toFixed(1).replace(/\.0$/, "") + "M" : n >= 1e3 ? Math.round(n / 1e3) + "K" : String(n);
function inline(t) {
  const parts = [];
  let last = 0;
  const rx = /\[\[([^|\]]+)\|(https?:\/\/[^\]\s]+)\]\]|\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)|\*\*([^*]+)\*\*/g;
  for (let m; m = rx.exec(t); ) {
    parts.push(esc4(t.slice(last, m.index)));
    if (m[5]) parts.push(`<b>${esc4(m[5])}</b>`);
    else parts.push(`<a href="${esc4(m[2] || m[4])}" rel="noopener">${esc4(m[1] || m[3])}</a>`);
    last = m.index + m[0].length;
  }
  return parts.join("") + esc4(t.slice(last));
}
function graphSvg(nodes, name) {
  if (!nodes.length) return "";
  const top = Math.max(1, ...nodes.map((x) => x.n)), order = [...nodes].sort((a, b) => b.n - a.n);
  const out = order.map((nd, i) => {
    const a = i / order.length * Math.PI * 2, r = i % 2 === 0 ? 64 : 96;
    const x = 130 + Math.cos(a) * r, y = 120 + Math.sin(a) * r * 0.85, size = 2.5 + 6.5 * Math.sqrt(nd.n / top);
    return { ...nd, x: x.toFixed(1), y: y.toFixed(1), ty: (y + size + 9).toFixed(1), r: size.toFixed(1), hot: nd.n >= top * 0.35, d: (-i * 0.3).toFixed(1) };
  });
  return `<svg viewBox="0 0 260 240" role="img" aria-label="Notes connected to ${esc4(name)}">${out.map((n) => `<line class="edge" x1="130" y1="120" x2="${n.x}" y2="${n.y}"></line>`).join("")}${out.map((n) => `<g class="float" style="animation-delay:${n.d}s"><circle class="node${n.hot ? " hot" : ""}" cx="${n.x}" cy="${n.y}" r="${n.r}"><title>${esc4(n.t)}: ${n.n}</title></circle><text x="${n.x}" y="${n.ty}" text-anchor="middle">${esc4(n.t)}</text></g>`).join("")}<circle class="center" cx="130" cy="120" r="9"></circle></svg>`;
}
var esc4 = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var fmt = (n) => n.toLocaleString("en-US");
function scored(daily) {
  return daily.map((d, i) => {
    const score = activityScore(d.counts);
    const prev = i ? activityScore(daily[i - 1].counts) : null;
    return { ...d, score, delta: prev ? Math.round((score - prev) / prev * 100) : null };
  });
}
var SRC_LABEL = { obsidian: "Obsidian vault", github: "GitHub", caldera: "Caldera", agents: "AI agents", calendar: "Calendar and email", self: "In their words", profile: "Profile note", module: "Custom module", stores: "App Store and Google Play", web: "Their websites" };
var srcLine = (src, what) => `<p class="sec-src">${src.map((x) => `<span class="src s-${x}">${SRC_LABEL[x]}</span>`).join("")}<span class="sec-what">${what}</span></p>`;
var head = (title, src, what) => `<h2>${esc4(title)}</h2>${srcLine(src, what)}`;
function renderProfile(p) {
  const s = p.sections, gh = p.source === "GitHub", em = p.source === "Caldera";
  const days = scored(p.daily);
  const labels = { meetings: "Meetings", emails: "Emails sent", prompts: "AI sessions", commits: "Commits", notes: "Notes", docs: "Docs filed" };
  const present = Object.keys(labels).filter((k) => days.some((d) => d.counts[k]));
  const journal = days.map((d, i) => ({
    date: d.date,
    label: (/* @__PURE__ */ new Date(d.date + "T12:00:00")).toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" }),
    score: d.score,
    delta: d.delta,
    headline: d.headline || "",
    focus: d.focus || [],
    wins: d.wins || [],
    themes: d.themes || [],
    chips: present.map((k) => ({ k: labels[k], v: d.counts[k] || 0, d: i ? (d.counts[k] || 0) - (days[i - 1].counts[k] || 0) : null }))
  }));
  const scores = days.map((d) => d.score);
  const yday = days.length > 1 ? days[days.length - 2] : days[days.length - 1];
  let streak = 0;
  const thresh = Math.max(20, (scores.slice().sort((a, b) => a - b)[Math.floor(scores.length / 2)] || 0) * 0.6);
  for (const sc of scores.slice(0, -1).reverse()) {
    if (sc >= thresh) streak++;
    else break;
  }
  const ranked = days.slice(0, -1).slice().sort((a, b) => b.score - a.score);
  const yrank = yday ? ranked.findIndex((d) => d.date === yday.date) + 1 : 0;
  const smax = Math.max(1, ...scores);
  const last7 = scores.slice(-8, -1), prev7 = scores.slice(-15, -8);
  const avg = (a) => a.length ? Math.round(a.reduce((x, y) => x + y, 0) / a.length) : 0;
  const trend = avg(prev7) ? Math.round((avg(last7) - avg(prev7)) / avg(prev7) * 100) : 0;
  const tmax = Math.max(1, ...p.topics.map((t) => t[1]));
  const parts = [];
  parts.push(`<!doctype html><html lang="en"${p.theme === "light" ? ' data-theme="light"' : ""}><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc4(p.name)}</title>
<meta name="robots" content="noindex, nofollow"><meta name="generator" content="Caldera for Obsidian">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400&display=swap">
${p.icon ? `<link rel="icon" href="${esc4(p.icon)}" type="image/png"><link rel="apple-touch-icon" href="${esc4(p.icon)}">` : `<link rel="icon" href="assets/favicon.svg" type="image/svg+xml">`}
<link rel="stylesheet" href="assets/theme.css"><link rel="stylesheet" href="assets/profile.css">${gardenEnabled() && s.garden !== false && p.garden?.length ? '<link rel="stylesheet" href="assets/garden.css">' : ""}</head><body>
<div class="tabs"><span class="tab is-active">${esc4(p.name)}.md</span>${(p.tabs || []).map((t) => `<span class="tab">${esc4(t)}</span>`).join("")}<span class="spacer"></span><span class="sync"><span class="dot"></span>synced from ${esc4(p.source || "vault")} <span id="ago" data-ts="${esc4(p.updated)}">just now</span></span></div>
<div class="shell">`);
  const sideOn = s.sidebar !== false && !!p.tree?.length, modOn = s.modules !== false, mainMods = modOn ? (p.modules || []).filter((m) => m.place === "main") : [], sideMods = modOn ? (p.modules || []).filter((m) => m.place === "side") : [];
  const railOn = s.rail !== false && (!!p.graph?.length || !!p.backlinks?.length || sideMods.length > 0);
  const gardenOn = gardenEnabled() && s.garden !== false && !!p.garden?.length;
  const nav = (depth, current, toc2 = "") => s.sidebar === false ? "" : navSidebar(p, sideOn, gardenOn, depth, current, toc2);
  parts.push(nav(0, "index.html", "%%TOC%%"));
  parts.push(`<main class="note">`);
  if (p.banner) parts.push(`<div class="banner"><img class="cover" src="${esc4(p.banner)}" alt="">${p.avatar ? `<img class="avatar" src="${esc4(p.avatar)}" alt="${esc4(p.name)}">` : ""}</div>`);
  parts.push(`<div class="page">${!p.banner && p.avatar ? `<img class="avatar solo" src="${esc4(p.avatar)}" alt="${esc4(p.name)}">` : ""}<div class="crumb">People / ${esc4(p.name)}.md${p.handle ? " / @" + esc4(p.handle) : ""}</div>
<h1 class="title">${esc4(p.name)}<span class="caret">|</span></h1>${p.headline ? `<p class="lede">${esc4(p.headline)}</p>` : ""}<!--caldera:owner-->`);
  if (s.city !== false && p.city?.districts.length) parts.push(citySnapshot(p.city, { name: p.name }));
  if (s.journal && journal.length) parts.push(`<section class="journal" id="journal" aria-label="Daily journal"><div class="j-head"><button class="j-nav" id="jprev" aria-label="Previous day">&#8249;</button>
<div class="j-title"><div class="label">Daily journal</div><div class="j-date" id="jdate"></div></div><button class="j-nav" id="jnext" aria-label="Next day">&#8250;</button></div>${srcLine(["obsidian"], "Each day, summarized from the daily notes in the vault. Use the arrows to go back.")}
<div class="j-body" id="jbody" aria-live="polite"></div></section><script id="journal-data" type="application/json">${JSON.stringify(journal).replace(/</g, "\\u003c")}<\/script>`);
  const GROUPS = [["github", "GitHub commits", ["commits"]], ["ai", "AI sessions", ["prompts"]], ["work", "Meetings and email", ["meetings", "emails"]], ["obsidian", "Obsidian notes and docs", ["notes", "docs"]]];
  const pts = (c, ks) => ks.reduce((a, k) => a + ACTIVITY_WEIGHTS[k] * Math.min(c[k] ?? 0, ACTIVITY_CAPS[k] ?? Infinity), 0);
  const groupsOn = GROUPS.filter((g) => days.some((d) => pts(d.counts, g[2]) > 0));
  const weekPts = groupsOn.map((g) => [g, Math.round(days.slice(-8, -1).reduce((a, d) => a + pts(d.counts, g[2]), 0))]);
  const barOf = (d) => {
    if (groupsOn.length < 2) return "";
    const tot = groupsOn.reduce((a, g) => a + pts(d.counts, g[2]), 0) || 1;
    return groupsOn.map((g) => {
      const v = pts(d.counts, g[2]);
      return v > 0 ? `<i class="g-${g[0]}" style="flex-grow:${(v / tot * 100).toFixed(1)}"></i>` : "";
    }).join("");
  };
  const counted = present.map((k) => labels[k].toLowerCase().replace(/^ai /, "AI ")), countedTxt = counted.length > 1 ? counted.slice(0, -1).join(", ") + " and " + counted[counted.length - 1] : counted[0] || "activity";
  const sbSrc = [...groupsOn.map((g) => ({ github: "github", ai: "agents", work: "calendar", obsidian: "obsidian" })[g[0]]), "caldera"];
  if (s.scoreboard && days.length > 2) parts.push(`<section class="scoreboard" id="scoreboard"><h2 class="t">Scoreboard</h2>${srcLine(sbSrc, `Points for each day's ${esc4(countedTxt)}. The leaderboard compares this week with friends on Caldera.`)}<div class="sb-stats">
<div class="sb-stat"><div class="v">${streak}<small> days</small></div><div class="l">active streak</div></div>
<div class="sb-stat"><div class="v">#${yrank}</div><div class="l">yesterday's rank of ${days.length - 1} days</div></div>
<div class="sb-stat"><div class="v">${avg(last7)}</div><div class="l">7-day average, ${trend >= 0 ? `<span class="up">&#9650; ${trend}%</span>` : `<span class="down">&#9660; ${-trend}%</span>`} vs prior week</div></div></div>
<div class="sb-bars" role="img" aria-label="Daily activity score, by source">${days.slice(-30).map((d, i, a) => `<span class="${i === a.length - 2 ? "yday" : i === a.length - 1 ? "today" : ""}" style="height:${Math.max(2, Math.round(d.score / smax * 100))}%" title="${d.date}: ${d.score}${groupsOn.map((g) => {
    const v = Math.round(pts(d.counts, g[2]));
    return v ? `, ${g[1].toLowerCase()} ${v}` : "";
  }).join("")}">${barOf(d)}</span>`).join("")}</div><div class="bars-legend"><span>${Math.min(30, days.length)} days ago</span><span>yesterday highlighted / today in progress</span></div>
${groupsOn.length > 1 ? `<div class="sb-split"><span class="label">Points this week, by source</span>${weekPts.map(([g, v]) => `<span class="sb-key"><i class="g-${g[0]}"></i>${esc4(g[1])} <b>${fmt(v)}</b></span>`).join("")}</div>` : ""}
${(() => {
    const best = days.slice(0, -2).map((d, i) => ({ d, i })).sort((a, b) => b.d.score - a.d.score).slice(0, 5);
    const lb = [`<div class="lb-row me"><span class="rank">1</span><span class="who">You</span><span class="num">${fmt(days.slice(-8, -1).reduce((x, d) => x + d.score, 0))}</span></div>`].concat([2, 3, 4].map((r) => `<div class="lb-row empty"><span class="rank">${r}</span><a class="who invite-btn" data-invite href="${esc4(inviteHref(p))}" target="_blank" rel="noopener">Invite a friend</a><span class="num">-</span></div>`));
    return `<div class="two-col sb-lower"><div class="lb-wrap"><div class="label">Leaderboard / points this week</div>${lb.join("")}${invitePop(p)}</div><div><div class="label">Your best other days</div>${best.map((b, k) => `<div class="lb-row"><span class="rank">${k + 1}</span><span class="who">${esc4((/* @__PURE__ */ new Date(b.d.date + "T12:00:00Z")).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", timeZone: "UTC" }))}</span><span class="num">${b.d.score}</span></div>`).join("")}</div></div>`;
  })()}
<details class="sb-how"><summary>How the score works</summary>Weighted daily counts: ${Object.entries(ACTIVITY_WEIGHTS).map(([k, w]) => `${labels[k] || k} x${w}`).join(", ")}. Bulk imports are capped. Counts only.</details></section>`);
  if (s.properties && p.properties.length) parts.push(`${head("At a glance", [gh ? "github" : em ? "self" : "profile"], gh ? "From the GitHub profile." : em ? "A few facts." : "Facts from the profile note in the vault.")}<dl class="props">${p.properties.map(([k, v]) => `<dt>${esc4(k)}</dt><dd>${esc4(v)}</dd>`).join("")}</dl>`);
  if (s.numbers) parts.push(`${head("The vault in numbers", ["obsidian"], "Counts only. What the notes say stays private.")}<div class="stat-strip">${[[fmt(p.stats.notes), "notes"], [(p.stats.words / 1e6).toFixed(2) + "M", "words"], [fmt(p.stats.links), "links between notes"], [String(p.stats.activeDays), "active days, 26 weeks"], ...p.extraNumbers || []].map(([v, l]) => `<div class="stat"><div class="v">${v}</div><div class="l">${l}</div></div>`).join("")}</div>`);
  if (s.summary !== false && p.summary) parts.push(`<div class="callout"><div class="callout-title">Summary</div>${inline(p.summary)}</div>`);
  if (s.now !== false && p.now?.length) parts.push(`${head("Now", [gh ? "github" : em ? "self" : p.nowAuto ? "obsidian" : "profile"], gh ? "Public repos pushed in the last two weeks. Updates by itself." : p.nowAuto ? "What's been happening this week, from the daily journal. Updates by itself." : "What's in progress right now.")}<ul class="bullets">${p.now.map((x) => `<li>${inline(x)}</li>`).join("")}</ul>`);
  for (const m of mainMods) parts.push(`<section class="module" data-module="${esc4(m.slug)}">${head(m.title, ["module"], "A section written for this page in Obsidian.")}<div class="mod-body">${m.html}</div></section>`);
  if (s.activity !== false && p.heat?.length) {
    const lvl = (n) => n === 0 ? 0 : n < 5 ? 1 : n < 30 ? 2 : n < 200 ? 3 : 4;
    const pad = ((/* @__PURE__ */ new Date(p.heat[0].date + "T12:00:00Z")).getUTCDay() + 6) % 7;
    parts.push(`${head("Activity", ["obsidian"], `Every day the vault learned something in the last 26 weeks: notes written and changed${p.extraNumbers?.length ? ", documents filed" : ""}.`)}<div class="heat-box" data-unit="updates"><div class="heat-frame"><div class="heat-days" aria-hidden="true"><span>Mon</span><span></span><span>Wed</span><span></span><span>Fri</span><span></span><span></span></div><div class="heat-wrap"><div class="heat-months" aria-hidden="true"></div><div class="heat" tabindex="0" aria-label="Activity, last 26 weeks. Use arrow keys to move between days." aria-describedby="heat-read">${'<i style="visibility:hidden"></i>'.repeat(pad)}${p.heat.map((c) => `<i class="l${lvl(c.n)}" data-d="${esc4(c.date)}" data-n="${c.n}"></i>`).join("")}</div></div></div><div class="heat-tip" hidden></div><div class="heat-foot"><div class="heat-read" id="heat-read" aria-live="polite"></div><div class="heat-legend">less <i class="l1"></i><i class="l2"></i><i class="l3"></i><i class="l4"></i> more</div></div></div>`);
  }
  const growthOn = s.growth !== false && (p.growth?.length || 0) > 1, knowsOn = s.knows !== false && !!p.knows?.length;
  if (growthOn || knowsOn) {
    let g = "";
    if (growthOn) {
      const gp = p.growth, gmax = Math.max(1, gp[gp.length - 1].total), W2 = 600, H2 = 180;
      const gx = (i) => 30 + i * (W2 - 40) / Math.max(1, gp.length - 1), gy = (v) => 10 + (H2 - 30) * (1 - v / gmax);
      const line = gp.map((x, i) => `${gx(i).toFixed(1)},${gy(x.total).toFixed(1)}`).join(" ");
      const first = (/* @__PURE__ */ new Date(gp[0].week + "T12:00:00Z")).toLocaleDateString("en-US", { month: "short", year: "numeric", timeZone: "UTC" });
      g = `<div>${head("Growth", ["obsidian"], "Notes in the vault over time.")}<svg class="growth" viewBox="0 0 ${W2} ${H2}" role="img" aria-label="Notes over time, ${fmt(gmax)} now"><line class="axis" x1="30" y1="${H2 - 20}" x2="${W2 - 10}" y2="${H2 - 20}"></line><path class="area" d="M${gx(0).toFixed(1)},${H2 - 20} L${line.replace(/ /g, " L")} L${gx(gp.length - 1).toFixed(1)},${H2 - 20} Z"></path><polyline class="line" points="${line}"></polyline><circle class="now" cx="${gx(gp.length - 1).toFixed(1)}" cy="${gy(gmax).toFixed(1)}" r="5"></circle><text x="30" y="${H2 - 4}">${esc4(first)}</text><text x="${W2 - 10}" y="${H2 - 4}" text-anchor="end">${fmt(gmax)} notes</text></svg></div>`;
    }
    const kmax = Math.max(1, ...(p.knows || []).map((k2) => k2[1]));
    const k = knowsOn ? `<div>${head("What it knows", ["obsidian"], "Notes in the vault, by subject.")}${p.knows.map(([l, n]) => `<div class="hbar"><span>${esc4(l)}</span><span class="track"><span class="fill" style="width:${(n / kmax * 100).toFixed(1)}%"></span></span><span class="num">${fmt(n)}</span></div>`).join("")}</div>` : "";
    parts.push(`<div class="two-col">${g}${k}</div>`);
  }
  if (s.inbox !== false && p.inbox?.kinds?.length) {
    const ib = p.inbox, kmax = Math.max(1, ...ib.kinds.map((k) => k[1])), total = ib.total ?? ib.kinds.reduce((a, k) => a + k[1], 0);
    const se = ib.series, smax2 = Math.max(1, ...(se?.weeks || []).map((w) => w[1]));
    parts.push(`${head("Inbox to knowledge", ["obsidian"], esc4(ib.note || `Every email attachment is read, summarized and linked into the vault overnight. ${fmt(total)} documents so far, by kind. Contents stay private.`))}<div class="two-col"><div>${ib.kinds.map(([l, n]) => `<div class="hbar"><span>${esc4(l)}</span><span class="track"><span class="fill alt" style="width:${(n / kmax * 100).toFixed(1)}%"></span></span><span class="num">${fmt(n)}</span></div>`).join("")}</div>${se?.weeks?.length ? `<div><div class="label">${esc4(se.label)} / ${fmt(se.weeks.reduce((a, w) => a + w[1], 0))} in ${se.weeks.length} weeks</div><div class="cols">${se.weeks.map(([l, n]) => `<span title="${esc4(l)}: ${n}"><b style="height:${Math.max(3, n / smax2 * 100).toFixed(1)}%"></b><em>${n || ""}</em></span>`).join("")}</div><div class="bars-legend"><span>${esc4(se.weeks[0][0])}</span><span>this week</span></div></div>` : ""}</div>`);
  }
  if (s.topics && p.topics.length) parts.push(`${gh ? head("Topics", ["github"], "Repo topics and languages, from public repos.") : em ? head("Topics", ["self"], "What they work on.") : head("Topics", ["obsidian"], "The tags used most in the vault.")}<div class="cloud">${p.topics.map(([t, n]) => `<span style="font-size:${(13 + n / tmax * 15).toFixed(1)}px">${esc4(t)}<sup>${n}</sup></span>`).join("")}</div>`);
  if (s.projects !== false && p.projects?.length) {
    const hasC = p.projects.some((x) => x.commits);
    parts.push(`${gh ? head("Projects", ["github"], "Public repositories with the most commits.") : em ? head("Projects", ["self"], "What they're building, with the number of updates on each.") : head("Projects", hasC ? ["obsidian", "github"] : ["obsidian"], `Notes in the vault's Projects folder${hasC ? ", with commit counts from GitHub" : ""}.`) + `<div class="query">TABLE status, ${hasC ? "commits, " : ""}link FROM "Projects" SORT ${hasC ? "commits DESC" : "file.name"}</div>`}<div class="table-wrap"><table class="data"><thead><tr><th>File</th><th>status</th>${hasC ? `<th class="num">${em ? "updates" : "commits"}</th>` : ""}<th>link</th></tr></thead><tbody>${p.projects.map((x) => `<tr><td>${/^https?:\/\//.test(x.url) ? `<a href="${esc4(x.url)}" rel="noopener">${esc4(x.name)}</a>` : esc4(x.name)}</td><td>${esc4(x.status)}</td>${hasC ? `<td class="num">${x.commits ? fmt(x.commits) : ""}</td>` : ""}<td>${/^https?:\/\//.test(x.url) ? `<a href="${esc4(x.url)}" rel="noopener">${esc4(x.url.replace(/^https?:\/\//, "").replace(/\/$/, ""))}</a>` : ""}</td></tr>`).join("")}</tbody></table></div>`);
  }
  const listSrc = gh ? "caldera" : em ? "self" : "profile";
  if (s.apps !== false && p.apps?.length) parts.push(`${head("Apps", [listSrc, "stores"], "Apps they made, with details from the store.")}${appsCards(p.apps)}`);
  if (s.websites !== false && p.websites?.length) parts.push(`${head("Websites", [listSrc, "web"], "Sites they run.")}${siteCards(p.websites)}`);
  if (s.code !== false && p.code && p.code.commits > 0) {
    const c = p.code, wk = c.weekly || [], f = Math.max(0, Math.min(wk.findIndex((x) => x > 0), wk.length - 26)), w2 = [...Array(Math.max(0, 26 - wk.length)).fill(0), ...wk.slice(f)], peak = Math.max(1, ...w2);
    parts.push(`${head("Code", ["github"], "Commits and languages, from GitHub.")}<p class="small"><b>${fmt(c.commits)}</b> commits across <b>${fmt(c.repos)}</b> repositories in the last year.${c.languages?.length ? ` Mostly ${esc4(c.languages.slice(0, -1).join(", "))}${c.languages.length > 1 ? " and " : ""}${esc4(c.languages[c.languages.length - 1])}.` : ""}${c.url && /^https?:\/\//.test(c.url) ? ` <a href="${esc4(c.url)}" rel="noopener">${esc4(c.url.replace(/^https?:\/\//, ""))}</a>` : ""}</p>${w2.length ? `<div class="bars" role="img" aria-label="Commits per week">${w2.map((x) => `<span class="${x >= peak * 0.5 ? "" : "quiet"}" style="height:${Math.max(2, x / peak * 100).toFixed(1)}%" title="${x}"></span>`).join("")}</div><div class="bars-legend"><span>${esc4(c.start || "")}</span><span>peak week: ${fmt(peak)}</span><span>this week</span></div>` : ""}`);
  }
  if (s.ai !== false && p.ai && p.ai.total > 0) {
    const a = p.ai, td = days.map((d) => ({ date: d.date, n: d.tokens || 0 })), tpeak = Math.max(1, ...td.map((x) => x.n));
    const share = (n) => a.total ? Math.round(n / a.total * 1e3) / 10 : 0;
    const bars = (rows, alt = false) => {
      const m = Math.max(1, ...rows.map((r) => r[1]));
      return rows.map(([l, n]) => `<div class="hbar"><span>${esc4(l)}</span><span class="track"><span class="fill${alt ? " alt" : ""}" style="width:${(n / m * 100).toFixed(1)}%"></span></span><span class="num" title="${fmt(n)} tokens">${share(n) >= 0.1 ? share(n) + "%" : "&lt;0.1%"}</span></div>`).join("");
    };
    parts.push(`${head("AI usage", ["agents"], "Tokens used by AI models and coding agents.")}<p class="small"><b>${big(a.total)}</b> tokens across <b>${a.models.length}</b> model${a.models.length === 1 ? "" : "s"} in the last ${a.window_days || td.length} days.${a.note ? ` <span class="muted">${esc4(a.note)}</span>` : ""}</p>${td.some((x) => x.n) ? `<div class="bars" role="img" aria-label="AI tokens per day">${td.map((x) => `<span class="${x.n >= tpeak * 0.5 ? "" : "quiet"}" style="height:${Math.max(2, x.n / tpeak * 100).toFixed(1)}%" title="${esc4(x.date)}: ${big(x.n)} tokens"></span>`).join("")}</div><div class="bars-legend"><span>${esc4(td[0]?.date || "")}</span><span>peak day: ${big(tpeak)}</span><span>today</span></div>` : ""}<div class="two-col" style="margin-top:var(--space-4)"><div><div class="label">Models / share of tokens</div>${bars(a.models)}</div>${a.providers?.length ? `<div><div class="label">Providers</div>${bars(a.providers, true)}</div>` : ""}</div>${a.sources && a.sources.length > 1 ? `<div style="margin-top:var(--space-4)"><div class="label">Where the tokens come from</div>${bars(a.sources, true)}</div>` : ""}`);
  }
  if (s.timeline !== false && p.timeline?.length) parts.push(`${gh ? head("Timeline", ["github"], "Milestones from public GitHub: joining, then the repos that stand out.") : em ? head("Timeline", ["self"], "Milestones.") : head("Timeline", ["profile"], "Milestones, from the profile note.")}<div class="timeline">${timelineRows(p.timeline)}</div>`);
  if (gardenEnabled() && s.garden !== false && (p.garden?.length || p.gardenExternal)) parts.push(gardenSection(p.garden || [], p.gardenExternal));
  if (s.notes && p.publicNotes.length) parts.push(`${head("Notes", ["obsidian"], "Notes published from the vault.")}${p.publicNotes.map((n) => `<div class="pnote" id="${slug("note-" + n.title)}"><div class="pn-title">${esc4(n.title)}</div><div class="pn-ex">${esc4(n.excerpt)}</div><div class="pn-date">${esc4(n.updated.slice(0, 10))}</div></div>`).join("")}`);
  if (s.links && p.links.length) parts.push(`${head("Elsewhere", [gh ? "github" : em ? "self" : "profile"], "Other places on the web.")}<ul class="bullets">${p.links.map(([l, u]) => `<li><a href="${esc4(u)}" rel="noopener">${esc4(l)}</a></li>`).join("")}</ul>`);
  parts.push(`<div class="foot">${gh ? "Built from GitHub" : em ? "Made" : "Grown from an Obsidian vault"} with Caldera. Updated ${esc4(p.updated.slice(0, 16).replace("T", " "))} UTC. <a href="${esc4((p.hub || "https://caldera.social").replace(/\/$/, ""))}/guide.html" target="_blank" rel="noopener">Your page? How to edit it</a></div></div></main>`);
  if (railOn) parts.push(`<aside class="rail">${p.graph?.length ? `<div class="graph"><div class="label">${esc4(p.graphLabel || "Graph")}</div>${graphSvg(p.graph, p.name)}</div>` : ""}${p.backlinks?.length ? `<div><div class="label">${esc4(p.backlinkLabel || "Backlinks")}</div>${p.backlinks.map(([t, c]) => `<div class="backlink"><span>${esc4(t)}</span><div class="ctx">${esc4(c)}</div></div>`).join("")}</div>` : ""}${sideMods.map((m) => `<div class="module side" data-module="${esc4(m.slug)}"><div class="label">${esc4(m.title)}</div><div class="mod-body">${m.html}</div></div>`).join("")}</aside>`);
  parts.push(`</div>`);
  parts.push(`<script>${CLIENT_JS}<\/script></body></html>`);
  const toc = [];
  if (s.journal && journal.length) toc.push(["journal", "Daily journal"]);
  if (s.scoreboard && days.length > 2) toc.push(["scoreboard", "Scoreboard"]);
  const seen = /* @__PURE__ */ new Set();
  let html = parts.join("\n").replace(/<h2>([^<]+)<\/h2>/g, (_m, t) => {
    let id = slug(t);
    while (seen.has(id)) id += "-2";
    seen.add(id);
    toc.push([id, t]);
    return `<h2 id="${id}">${t}</h2>`;
  });
  html = html.replace("%%TOC%%", toc.length > 2 ? `<span class="label">On this page</span><div class="toc">${toc.map(([id, t]) => `<a class="tree-row toc-row" href="#${id}">${t}</a>`).join("")}</div>` : "");
  const garden = gardenEnabled() && s.garden !== false && p.garden?.length ? renderGarden({ name: p.name, handle: p.handle, hub: p.hub, icon: p.icon, theme: p.theme, id: p.id, external: p.gardenExternal, nav: (d, cur) => nav(d, cur) }, p.garden, p.gardenImages) : {};
  const city = s.city !== false && p.city?.districts.length ? { "city.html": renderCity({ name: p.name, handle: p.handle, theme: p.theme, icon: p.icon, github: githubOf(p), nav: (d, cur) => nav(d, cur) }, p.city) } : {};
  const out = { ...garden, ...city, "index.html": html, "assets/theme.css": theme_default, "assets/profile.css": PROFILE_CSS + LISTINGS_CSS, "assets/favicon.svg": LOGO_SVG };
  let own = "caldera.social";
  try {
    own = new URL(p.hub || "https://caldera.social").host;
  } catch {
  }
  for (const k of Object.keys(out)) if (k.endsWith(".html")) out[k] = externalLinksNewWindow(out[k], [own]);
  return out;
}
function navSidebar(p, sideOn, gardenOn, depth, current, toc = "") {
  const up = "../".repeat(depth), onProfile = current === "index.html";
  const fix = (h) => /^https?:\/\//.test(h) ? h : h.startsWith("#") ? onProfile ? h : `${up}index.html${h}` : up + h;
  const pages = [["index.html", p.name || "Profile"]];
  if (gardenOn) pages.push(["garden.html", "Garden home"]);
  if (p.handle) pages.push([`${(p.hub || "https://caldera.social").replace(/\/$/, "")}/world?focus=${encodeURIComponent(p.handle)}`, "World"]);
  if (p.sections?.city !== false && p.city?.districts.length) pages.push(["city.html", "City"]);
  const pageRows = pages.map(([h, l]) => `<a class="tree-row toc-row page-row${h === current ? " is-active" : ""}" href="${/^https?:\/\//.test(h) ? h : onProfile && h === "index.html" ? "#top" : up + h}"${h === current ? ' aria-current="page"' : ""}>${esc4(l)}</a>`).join("");
  const hubBase = (p.hub || "https://caldera.social").replace(/\/$/, "");
  const friend = p.handle ? `<a class="tree-row toc-row page-row friend-row" href="${esc4(hubBase)}/kudos/${encodeURIComponent(p.handle)}" data-caldera-friend="${esc4(p.handle)}" target="_blank" rel="noopener" title="Send @${esc4(p.handle)} a friend request">+ Follow @${esc4(p.handle)}</a>` : "";
  const tree = sideOn && p.tree?.length ? `<span class="label">Vault</span>${sidebarTree(p.tree.map((r) => ({ ...r, current: r.href === "#top" && onProfile || !!r.href && r.href === current })), fix)}` : "";
  return `<nav class="sidebar tree" aria-label="Navigation"><div class="side-inner"><span class="label">Pages</span><div class="toc pages">${pageRows}${friend}</div>${toc}${tree}</div></nav>`;
}
function sidebarTree(rows, fix = (h) => h) {
  const out = [];
  let open3 = false;
  const ok = (h) => !!h && /^(https?:\/\/|#[\w-]+$|garden\.html$|n\/[a-z0-9-]+\.html$)/.test(h);
  const item = (r) => {
    const cls = `tree-row child${r.current ? " is-current" : ""}${r.href ? " is-link" : ""}`;
    if (!ok(r.href)) return `<div class="tree-row child${r.current ? " is-current" : ""}"><span>${esc4(r.name)}</span></div>`;
    const ext = /^https?:\/\//.test(r.href);
    return `<a class="${cls}" href="${esc4(fix(r.href))}"${ext ? ' target="_blank" rel="noopener"' : ""}${r.current ? ' aria-current="page"' : ""}><span>${esc4(r.name)}</span>${ext ? '<span class="ext" aria-hidden="true">&#8599;</span>' : ""}</a>`;
  };
  const gname = (r) => ok(r.href) && !/^https?:/.test(r.href) ? `<a class="g-name g-link" href="${esc4(fix(r.href))}">${esc4(r.name)}</a>` : `<span class="g-name">${esc4(r.name)}</span>`;
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    if (r.child) {
      out.push(item(r));
      continue;
    }
    if (open3) {
      out.push(`</details>`);
      open3 = false;
    }
    const kids = rows.slice(i + 1).findIndex((x) => !x.child), n = kids < 0 ? rows.length - i - 1 : kids;
    const count = r.count != null ? `<span class="count" title="${r.count} notes">${fmt(r.count)}</span>` : n ? `<span class="count">${n}</span>` : "";
    if (!n) {
      out.push(`<div class="tree-row group leaf"><span class="caret" aria-hidden="true"></span>${gname(r)}${count}</div>`);
      open3 = false;
      continue;
    }
    out.push(`<details class="tree-group" open><summary class="tree-row group"><span class="caret" aria-hidden="true"></span>${gname(r)}${count}</summary>`);
    open3 = true;
  }
  if (open3) out.push(`</details>`);
  return out.join("");
}
function splitDetail(t) {
  const masked = t.replace(/\[\[[^\]]*\]\]/g, (m) => "x".repeat(m.length)), i = masked.lastIndexOf(" | ");
  return i < 0 ? [t, ""] : [t.slice(0, i).trim(), t.slice(i + 3).trim()];
}
function timelineRows(rows) {
  let prev = "";
  return rows.map(([y, t]) => {
    const [main, detail] = splitDetail(t);
    if (y.trim().toLowerCase() === "era") {
      prev = "";
      return `<div class="era"><span class="era-name">${inline(main)}</span>${detail ? `<span class="era-range">${esc4(detail)}</span>` : ""}</div>`;
    }
    const same = y === prev;
    prev = y;
    return `<div class="row${same ? " same" : ""}"><span class="year">${same ? "" : esc4(y)}</span><span class="dot" aria-hidden="true"></span><div class="what"><div>${inline(main)}</div>${detail ? `<div class="detail">${inline(detail)}</div>` : ""}</div></div>`;
  }).join("");
}
var LOGO_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="7" fill="#1C1C1F"/><path d="M4 25 L12 10 L15 15 L18 8 L28 25 Z" fill="#8B6CF6"/><circle cx="16" cy="21" r="2.4" fill="#4FB89A"/></svg>';
var HEAT_JS = "(function(){var g=document.querySelector('.heat');if(!g)return;var box=g.closest('.heat-box');if(!box)return;\nvar tip=box.querySelector('.heat-tip'),rd=box.querySelector('.heat-read'),mo=box.querySelector('.heat-months');\nvar cells=[].slice.call(g.querySelectorAll('i[data-d]'));if(!cells.length)return;var unit=box.getAttribute('data-unit')||'updates';\nvar D=function(s){return new Date(s+'T12:00:00')};\nvar fd=function(s){return D(s).toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric',year:'numeric'})};\nvar amt=function(c){var n=+c.getAttribute('data-n');return n?n.toLocaleString('en-US')+' '+(n===1?unit.replace(/s$/,''):unit):'No activity'};\nvar today=cells[cells.length-1],cur=null,pin=null;today.classList.add('is-today');\nfunction months(){if(!mo)return;mo.innerHTML='';var last=-1,lm=-1;cells.forEach(function(c){var x=c.offsetLeft-g.offsetLeft;if(x===last)return;last=x;var m=D(c.getAttribute('data-d')).getMonth();if(m!==lm){if(x<=g.offsetWidth-26&&(lm>=0||D(c.getAttribute('data-d')).getDate()<=7)){var s=document.createElement('span');s.textContent=D(c.getAttribute('data-d')).toLocaleDateString('en-US',{month:'short'});s.style.left=x+'px';mo.appendChild(s)}lm=m}})}months();\nfunction sel(c,show){if(cur)cur.classList.remove('is-sel');cur=c;c.classList.add('is-sel');\nrd.textContent='';var b=document.createElement('b');b.textContent=(c===today?'Today, ':'')+fd(c.getAttribute('data-d'));rd.appendChild(b);rd.appendChild(document.createTextNode(' \xB7 '+amt(c)));\nif(!show){tip.hidden=true;return}tip.textContent=fd(c.getAttribute('data-d'))+' \xB7 '+amt(c);tip.hidden=false;\nvar r=c.getBoundingClientRect(),br=box.getBoundingClientRect(),w=tip.offsetWidth,x=r.left-br.left+r.width/2;var cx=x;x=Math.max(w/2,Math.min(br.width-w/2,x));tip.style.left=x+'px';tip.style.setProperty('--ax',(cx-x)+'px');tip.style.top=(r.top-br.top)+'px'}\nvar wr=g.parentNode;if(wr.scrollWidth>wr.clientWidth)wr.scrollLeft=wr.scrollWidth;\nsel(today,false);\nvar at=function(e){return e.target.closest?e.target.closest('i[data-d]'):null};\ng.addEventListener('mouseover',function(e){var c=at(e);if(c)sel(c,true)});\ng.addEventListener('mouseleave',function(){sel(pin||today,false)});\ng.addEventListener('click',function(e){var c=at(e);if(!c)return;pin=pin===c?null:c;g.querySelectorAll('.is-pin').forEach(function(x){x.classList.remove('is-pin')});if(pin)pin.classList.add('is-pin');sel(c,true)});\ng.addEventListener('keydown',function(e){var k={ArrowLeft:-7,ArrowRight:7,ArrowUp:-1,ArrowDown:1,Home:-1e6,End:1e6}[e.key];if(k==null){if(e.key==='Escape'){e.stopPropagation();pin=null;sel(today,false)}return}e.preventDefault();e.stopPropagation();var i=cells.indexOf(cur);sel(cells[Math.max(0,Math.min(cells.length-1,i+k))],true)});\ng.addEventListener('focus',function(){sel(cur||today,true)});g.addEventListener('blur',function(){tip.hidden=true});\nwindow.addEventListener('resize',function(){tip.hidden=true;months()})})();";
var INVITE_JS = "(function(){var pop=document.querySelector('.invite-pop');if(!pop)return;var btns=[].slice.call(document.querySelectorAll('[data-invite]'));if(!btns.length)return;\nvar url=pop.getAttribute('data-url'),msg=pop.getAttribute('data-msg'),subj=pop.getAttribute('data-subject')||'Join me on Caldera';\nvar inp=pop.querySelector('.inv-url'),cp=pop.querySelector('.inv-copy'),em=pop.querySelector('.inv-email'),tx=pop.querySelector('.inv-text'),sh=pop.querySelector('.inv-share'),st=pop.querySelector('.inv-status'),x=pop.querySelector('.inv-close');\ninp.value=url;var body=msg+'\\n\\n'+url;em.href='mailto:?subject='+encodeURIComponent(subj)+'&body='+encodeURIComponent(body);tx.href='sms:?&body='+encodeURIComponent(msg+' '+url);\nvar canShare=!!(navigator.share&&(!navigator.canShare||navigator.canShare({url:url})));if(!canShare)sh.hidden=true;\nvar host=pop.parentNode,from=null;\nfunction say(t){st.textContent=t;clearTimeout(say.t);say.t=setTimeout(function(){st.textContent=''},2600)}\nfunction open(b){from=b;pop.hidden=false;var hr=host.getBoundingClientRect(),r=b.getBoundingClientRect();pop.style.top=(r.bottom-hr.top+8)+'px';var l=r.left-hr.left;pop.style.left=Math.max(0,Math.min(hr.width-pop.offsetWidth,l))+'px';btns.forEach(function(x){x.setAttribute('aria-expanded',x===b?'true':'false')});cp.focus()}\nfunction close(back){if(pop.hidden)return;pop.hidden=true;btns.forEach(function(x){x.setAttribute('aria-expanded','false')});if(back&&from)from.focus()}\nbtns.forEach(function(b){b.setAttribute('aria-haspopup','dialog');b.setAttribute('aria-expanded','false');b.addEventListener('click',function(e){e.preventDefault();if(!pop.hidden&&from===b)close(true);else open(b)})});\nfunction fallback(){inp.focus();inp.select();var ok=false;try{ok=document.execCommand('copy')}catch(e){}say(ok?'Link copied':'Press Ctrl/Cmd+C to copy')}\ncp.addEventListener('click',function(){if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(url).then(function(){say('Link copied')},fallback)}else fallback()});\ninp.addEventListener('focus',function(){inp.select()});\nsh.addEventListener('click',function(){navigator.share({title:subj,text:msg,url:url}).catch(function(e){if(e&&e.name!=='AbortError'){sh.hidden=true;say('Sharing is not available here. Copy the link instead.')}})});\nx.addEventListener('click',function(){close(true)});\ndocument.addEventListener('keydown',function(e){if(e.key==='Escape'&&!pop.hidden){e.stopPropagation();close(true)}},true);\ndocument.addEventListener('click',function(e){if(!pop.hidden&&!pop.contains(e.target)&&!(e.target.closest&&e.target.closest('[data-invite]')))close(false)});\nwindow.addEventListener('resize',function(){close(false)})})();";
var CLIENT_JS = INVITE_JS + "\n" + HEAT_JS + `
(function(){var L=[].slice.call(document.querySelectorAll('.toc:not(.pages) a'));if(!L.length||!window.IntersectionObserver)return;var by={};L.forEach(function(a){by[a.getAttribute('href').slice(1)]=a});var cur;var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){if(cur)cur.classList.remove('is-active');cur=by[e.target.id];if(cur){cur.classList.add('is-active');var t=cur.parentNode;if(t.scrollWidth>t.clientWidth)t.scrollLeft=cur.offsetLeft-t.clientWidth/2+cur.offsetWidth/2}}})},{rootMargin:'0px 0px -70% 0px'});Object.keys(by).forEach(function(id){var el=document.getElementById(id);if(el)io.observe(el)})})();
(function(){var a=document.getElementById('ago');if(a){var t=Date.parse(a.dataset.ts);var f=function(){var m=Math.max(0,Math.round((Date.now()-t)/60000));a.textContent=m<60?m+'m ago':Math.floor(m/60)+'h '+(m%60)+'m ago'};f();setInterval(f,30000)}
var el=document.getElementById('journal-data');if(!el)return;var days=JSON.parse(el.textContent);if(!days.length)return;var i=Math.max(0,days.length-2);
var body=document.getElementById('jbody'),dt=document.getElementById('jdate'),pv=document.getElementById('jprev'),nx=document.getElementById('jnext');
var esc=function(s){return String(s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})};
var dl=function(d){return d==null?'':d>0?'<span class="up">&#9650; '+d+'</span>':d<0?'<span class="down">&#9660; '+(-d)+'</span>':'<span class="flat">=</span>'};
var mx=Math.max.apply(null,days.map(function(x){return x.score}).concat([1]));
function r(dir){var d=days[i],L=days.length;dt.textContent=(i===L-1?'Today so far / ':i===L-2?'Yesterday / ':'')+d.label;var C=2*Math.PI*42,p=Math.min(1,d.score/mx);
var sd=d.delta==null?'':(d.delta>=0?'<span class="up">&#9650; '+d.delta+'%</span>':'<span class="down">&#9660; '+(-d.delta)+'%</span>')+' vs day before';
var h='<div class="j-top"><div class="ring-wrap"><svg class="ring" viewBox="0 0 100 100" aria-hidden="true"><circle class="trk" cx="50" cy="50" r="42"></circle><circle class="val" cx="50" cy="50" r="42" style="stroke-dasharray:'+C+';stroke-dashoffset:'+(C*(1-p))+'"></circle></svg><div class="j-score"><div class="v">'+d.score+'</div><div class="l">score</div></div></div>'+
'<div class="j-headline">'+(sd?'<div class="j-delta">'+sd+'</div>':'')+(d.headline?esc(d.headline):'<span class="muted">No journal for this day. Activity only.</span>')+(d.themes.length?'<div class="j-themes">'+d.themes.map(function(t){return'<span>'+esc(t)+'</span>'}).join('')+'</div>':'')+'</div></div>';
if(d.chips.length)h+='<div class="j-chips">'+d.chips.map(function(c){return'<div class="chip"><div class="v">'+c.v+'</div><div class="l">'+esc(c.k)+'</div><div class="dd">'+dl(c.d)+'</div></div>'}).join('')+'</div>';
if(d.focus.length||d.wins.length){h+='<div class="two-col j-lists">';if(d.focus.length)h+='<div><div class="label">Focus</div><ul class="bullets">'+d.focus.map(function(x){return'<li>'+esc(x)+'</li>'}).join('')+'</ul></div>';if(d.wins.length)h+='<div><div class="label">Wins</div><ul class="bullets">'+d.wins.map(function(x){return'<li>'+esc(x)+'</li>'}).join('')+'</ul></div>';h+='</div>'}
body.innerHTML=h;body.classList.remove('flip-l','flip-r');void body.offsetWidth;if(dir)body.classList.add(dir<0?'flip-l':'flip-r');pv.disabled=i===0;nx.disabled=i===L-1}
pv.onclick=function(){if(i>0){i--;r(-1)}};nx.onclick=function(){if(i<days.length-1){i++;r(1)}};document.addEventListener('keydown',function(e){if(e.key==='ArrowLeft')pv.onclick();if(e.key==='ArrowRight')nx.onclick()});r(0)})();`;
function githubOf(p) {
  const ok = (u) => !!u && /^https:\/\/github\.com\/[\w.-]+\/?$/.test(u);
  const l = (p.links || []).find((x) => /github/i.test(x[0]) && ok(x[1]));
  return l ? l[1] : ok(p.code?.url) ? p.code.url : void 0;
}
function renderPrivateCity(p, city, openBase = "") {
  const q2 = { ...p, city: p.city?.districts.length ? p.city : city };
  const sideOn = p.sections.sidebar !== false && !!p.tree?.length, gardenOn = gardenEnabled() && p.sections.garden !== false && !!p.garden?.length;
  return renderCity({ name: p.name, handle: p.handle, theme: p.theme, icon: p.icon, openBase, github: githubOf(p), nav: (d, cur) => p.sections.sidebar === false ? "" : navSidebar(q2, sideOn, gardenOn, d, cur) }, city);
}

// src/collect.ts
var import_obsidian6 = require("obsidian");

// src/modules.ts
var import_obsidian4 = require("obsidian");
var MODULES_FOLDER = "Caldera/modules";
var MODULE_LIMITS = { count: 12, chars: 2e4, imgMax: 2e6, imgTotal: 6e6 };
var IMG_EXT = /* @__PURE__ */ new Set(["png", "jpg", "jpeg", "webp", "gif"]);
async function collectModules(app, hub) {
  const pre = MODULES_FOLDER + "/";
  const picked = app.vault.getMarkdownFiles().filter((f) => f.path.startsWith(pre) && !f.path.slice(pre.length).includes("/") && !/^_|^README$/i.test(f.basename)).sort((a, b) => a.basename.localeCompare(b.basename));
  const modules = [], files = {}, report = [];
  const used = /* @__PURE__ */ new Set();
  let imgTotal = 0;
  for (const f of picked) {
    const fm = app.metadataCache.getFileCache(f)?.frontmatter || {};
    const title = String(fm.title || f.basename).replace(/\s+/g, " ").trim().slice(0, 80) || f.basename;
    const place = /^(side|sidebar|rail|right)$/i.test(String(fm.place || "")) ? "side" : "main";
    const r = { path: f.path, title, place, published: false, removed: 0 };
    report.push(r);
    if (fm.publish === false || String(fm.publish).toLowerCase() === "false") {
      r.why = "draft (publish: false)";
      continue;
    }
    if (modules.length >= MODULE_LIMITS.count) {
      r.why = `only ${MODULE_LIMITS.count} modules show`;
      continue;
    }
    const raw = (await app.vault.cachedRead(f)).replace(/^---[\s\S]*?\n---\s*/, "").replace(/%%[\s\S]*?%%/g, "").trim();
    if (!raw) {
      r.why = "empty";
      continue;
    }
    const { text, removed } = redact(raw.slice(0, MODULE_LIMITS.chars));
    r.removed = removed;
    let sl = "m-" + slug(title), k = 2;
    while (used.has(sl)) sl = `m-${slug(title)}-${k++}`;
    used.add(sl);
    const images = {};
    for (const m of text.matchAll(/!\[\[([^\]|#]+)/g)) {
      const t = m[1].trim();
      if (images[t]) continue;
      const dest = app.metadataCache.getFirstLinkpathDest?.(t, f.path) ?? app.vault.getAbstractFileByPath(t);
      if (!(dest instanceof import_obsidian4.TFile) || !IMG_EXT.has(dest.extension.toLowerCase()) || dest.stat.size > MODULE_LIMITS.imgMax || imgTotal + dest.stat.size > MODULE_LIMITS.imgTotal) continue;
      const out = `m/img/${slug(dest.basename)}-${dest.stat.size}.${dest.extension.toLowerCase()}`;
      files[out] = await app.vault.readBinary(dest);
      imgTotal += dest.stat.size;
      images[t] = out;
    }
    const order = Number.isFinite(Number(fm.order)) ? Number(fm.order) : 50;
    modules.push({ title, slug: sl, place, order, html: moduleHtml(text, hub, (t) => images[t] || null) });
    r.published = true;
  }
  modules.sort((a, b) => a.order - b.order || a.title.localeCompare(b.title));
  return { modules, files, report };
}

// src/collect.ts
var DAY = 864e5;
var fmtN = (n) => n.toLocaleString("en-US");
var iso = (t) => {
  const d = new Date(t);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
async function collectProfile(app, s, social) {
  const md = app.vault.getMarkdownFiles();
  let words = 0, links = 0;
  const created = /* @__PURE__ */ new Map(), changed = /* @__PURE__ */ new Map();
  const tagCounts2 = /* @__PURE__ */ new Map();
  const allow = new Map(s.publicTopics.map(([tag, label]) => [tag.toLowerCase().replace(/^#/, ""), label]));
  const publicNotes = [];
  const journal = /* @__PURE__ */ new Map();
  for (const f of md) {
    created.set(iso(f.stat.ctime), (created.get(iso(f.stat.ctime)) || 0) + 1);
    changed.set(iso(f.stat.mtime), (changed.get(iso(f.stat.mtime)) || 0) + 1);
    const cache = app.metadataCache.getFileCache(f);
    links += (cache?.links?.length || 0) + (cache?.embeds?.length || 0) + (cache?.frontmatterLinks?.length || 0);
    words += Math.round(f.stat.size / 6);
    for (const t of cache ? (0, import_obsidian5.getAllTags)(cache) || [] : []) {
      const k = t.replace(/^#/, "").toLowerCase();
      if (allow.has(k)) tagCounts2.set(allow.get(k), (tagCounts2.get(allow.get(k)) || 0) + 1);
    }
    const fm = cache?.frontmatter || {};
    if (String(fm.caldera || "").toLowerCase() === "public") {
      const text = await app.vault.cachedRead(f);
      const body = text.replace(/^---[\s\S]*?---\s*/, "");
      const para = body.split(/\n\s*\n/).map((x) => x.replace(/^#+\s.*$/gm, "").trim()).find((x) => x.length > 20) || "";
      publicNotes.push({ title: f.basename, excerpt: para.replace(/\[\[([^\]|]+)(\|[^\]]+)?\]\]/g, "$1").slice(0, 280), updated: new Date(f.stat.mtime).toISOString() });
    }
    const dm = f.basename.match(/^(\d{4}-\d{2}-\d{2})$/);
    if (dm && (fm.caldera_headline || fm.caldera_focus || fm.caldera_wins)) {
      journal.set(dm[1], { headline: fm.caldera_headline, focus: asList(fm.caldera_focus), wins: asList(fm.caldera_wins), themes: asList(fm.caldera_themes) });
    }
  }
  const { garden, gardenImages, gardenFiles, gardenReport } = gardenEnabled() ? await collectGarden(app, s, md) : { garden: [], gardenImages: {}, gardenFiles: {}, gardenReport: [] };
  const external = /* @__PURE__ */ new Map();
  let extra = {};
  const actFile = app.vault.getAbstractFileByPath(s.activityFile);
  if (actFile instanceof import_obsidian5.TFile) {
    try {
      extra = JSON.parse(await app.vault.cachedRead(actFile)) || {};
      for (const d of extra.days || []) external.set(d.date, d);
    } catch {
    }
  }
  if (s.sections.ai !== false && !(extra.ai && typeof extra.ai.total === "number")) {
    const base = app.vault.adapter.getBasePath?.();
    const ai = base ? await aiUsage(`${base}/${app.vault.configDir}/plugins/caldera/ai-cache.json`).catch(() => void 0) : void 0;
    if (ai) {
      extra.ai = ai;
      for (const [d, n] of Object.entries(ai.days)) {
        const e = external.get(d) || { date: d };
        if (!e.tokens) e.tokens = n;
        external.set(d, e);
      }
    }
  }
  if (s.sections.code !== false && !(extra.code && typeof extra.code.commits === "number")) {
    const fg = forgeOf(s.links || []);
    const code = await (fg?.kind === "forgejo" ? forgejoCode(fg) : githubCode(s.links || [])).catch(() => void 0);
    if (code) extra.code = code;
  }
  const gitDays = s.gitLines === false ? void 0 : await localGitLines(14, String(s.gitFolders || "").split(/[\n,]+/).map((x) => x.trim()).filter(Boolean)).catch(() => void 0);
  const gitFrom = iso(Date.now() - 13 * DAY);
  const today = Date.now();
  const daily = [];
  const ownerPublic = [
    s.name,
    s.headline,
    ...(s.links || []).map((l) => l[0]),
    ...(s.properties || []).map((p) => p[1]),
    ...(s.publicTopics || []).map((t) => t[1]),
    ...(s.projects || []).map((p) => p[0]),
    ...(s.tree || []).flatMap((t) => [t[0], ...t[1].split(",")]),
    ...s.graph || [],
    ...(s.backlinks || []).map((b) => b[0]),
    ...s.tabs || []
  ].filter(Boolean).map((x) => String(x).trim());
  const safe = publicTextFilter(ownerPublic);
  const clean2 = (xs) => xs.filter((x) => safe(x));
  for (let i = s.historyDays - 1; i >= 0; i--) {
    const date = iso(today - i * DAY);
    const ext = external.get(date) || {};
    const j = journal.get(date) || {};
    daily.push({
      date,
      counts: {
        notes: Math.max(created.get(date) || 0, changed.get(date) || 0),
        meetings: ext.meetings,
        emails: ext.emails,
        prompts: ext.prompts,
        commits: ext.commits,
        docs: ext.docs,
        ...typeof ext.linesAdded === "number" ? { linesAdded: ext.linesAdded, linesRemoved: Number(ext.linesRemoved) || 0 } : gitDays && date >= gitFrom ? { linesAdded: gitDays[date]?.added || 0, linesRemoved: gitDays[date]?.removed || 0 } : {}
      },
      tokens: Number(ext.tokens) || void 0,
      headline: [j.headline || ext.headline].filter((h) => h && safe(String(h)))[0],
      focus: clean2(j.focus?.length ? j.focus : asList(ext.focus)),
      wins: clean2(j.wins?.length ? j.wins : asList(ext.wins)),
      themes: clean2(j.themes?.length ? j.themes : asList(ext.themes))
    });
  }
  if (s.gardenJournal !== false && s.sections.garden !== false) await growGardenFromJournal(app, s, daily, gardenEnabled() ? garden : [], gardenEnabled() ? gardenReport : []);
  let activeDays = 0;
  for (let i = 0; i < 182; i++) {
    const d = iso(today - i * DAY);
    if ((created.get(d) || 0) + (changed.get(d) || 0) > 0) activeDays++;
  }
  const files = {};
  const img = async (vaultPath, name) => {
    const f = vaultPath && app.vault.getAbstractFileByPath(vaultPath);
    if (f instanceof import_obsidian5.TFile && /^(png|jpe?g|gif|webp|avif|svg)$/i.test(f.extension) && f.stat.size <= 8 * 1024 * 1024) {
      const out = `img/${name}.${f.extension.toLowerCase()}`;
      files[out] = await app.vault.readBinary(f);
      return out;
    }
    return void 0;
  };
  const inbound = /* @__PURE__ */ new Map();
  const bump = (k) => inbound.set(k, (inbound.get(k) || 0) + 1);
  for (const targets of Object.values(app.metadataCache.resolvedLinks)) for (const t of Object.keys(targets)) bump(t.split("/").pop().replace(/\.md$/i, "").toLowerCase());
  for (const targets of Object.values(app.metadataCache.unresolvedLinks)) for (const t of Object.keys(targets)) bump(t.split("|")[0].split("/").pop().replace(/\.md$/i, "").toLowerCase());
  const linkCount = (name) => inbound.get(name.toLowerCase()) || 0;
  const topTopics = [...tagCounts2.entries()].sort((a, b) => b[1] - a[1]);
  const kinds = vaultKinds(app, md);
  const notesSorted = publicNotes.sort((a, b) => b.updated.localeCompare(a.updated)).slice(0, 12);
  const tree = [{ name: "People", child: false }, { name: s.name || "Me", child: true, current: true, href: "#top" }];
  const projUrl = new Map((s.projects || []).map(([n, rest]) => [n.toLowerCase(), (rest.split("|")[1] || "").trim()]));
  for (const [, t] of s.timeline || []) for (const m of String(t).matchAll(/\[\[([^|\]]+)\|(https?:\/\/[^\]\s]+)\]\]/g)) if (!projUrl.has(m[1].trim().toLowerCase())) projUrl.set(m[1].trim().toLowerCase(), m[2]);
  const noteIds = new Set(notesSorted.map((n) => n.title.toLowerCase()));
  const hrefFor = (it) => {
    const k = it.toLowerCase(), u = projUrl.get(k);
    if (u !== void 0) return /^https?:\/\//.test(u) ? u : "#projects";
    const g = garden.find((n) => n.title.toLowerCase() === k);
    if (g) return `n/${g.slug}.html`;
    if (noteIds.has(k)) return "#" + slug("note-" + it);
    if (topTopics.some((t) => t[0].toLowerCase() === k)) return "#topics";
    return void 0;
  };
  const folderCount = (folder) => {
    if (!folder) return void 0;
    const pre = folder.replace(/^\/+|\/+$/g, "") + "/";
    const n = md.filter((f) => f.path.startsWith(pre)).length;
    return n || void 0;
  };
  const groups = s.tree?.length ? s.tree.map(([g, items, folder]) => [g, items.split(",").map((x) => x.trim()).filter(Boolean), folder]) : [["Topics", topTopics.slice(0, 5).map((t) => t[0])], ["Notes", notesSorted.slice(0, 5).map((n) => n.title)]];
  if (!s.tree?.length && !topTopics.length && !notesSorted.length)
    for (const [label, n] of kinds) tree.push({ name: label, child: false, count: n });
  for (const [g, items, folder] of groups) {
    const count = items.length || folderCount(folder);
    if (!items.length && !count) continue;
    tree.push({ name: g, child: false, count });
    for (const it of items) tree.push({ name: it, child: true, href: hrefFor(it) });
  }
  if (garden.length && s.sections.garden !== false && !tree.some((t) => !t.child && t.name.toLowerCase() === "garden")) {
    tree.push({ name: "Garden", child: false, count: garden.length, href: "garden.html" });
    for (const n of [...garden].sort((a, b) => b.updated.localeCompare(a.updated)).slice(0, 6)) tree.push({ name: n.title, child: true, href: `n/${n.slug}.html` });
  }
  const graph = (s.graph?.length ? s.graph.map((n) => ({ t: n, n: linkCount(n) })) : (topTopics.length ? topTopics : kinds).slice(0, 12).map(([t, n]) => ({ t, n }))).slice(0, 16);
  const backlinks = s.backlinks?.length ? s.backlinks : notesSorted.slice(0, 6).map((n) => [n.title, n.excerpt.slice(0, 70)]);
  const DAYMS = 864e5, todayD = /* @__PURE__ */ new Date();
  todayD.setHours(12, 0, 0, 0);
  const startD = new Date(todayD.getTime() - ((todayD.getDay() + 6) % 7 + 7 * 25) * DAYMS);
  const heat = [];
  for (let t = startD.getTime(); t <= todayD.getTime(); t += DAYMS) {
    const d = iso(t), e = external.get(d) || {};
    heat.push({ date: d, n: (created.get(d) || 0) + (changed.get(d) || 0) + (Number(e.docs) || 0) });
  }
  const createdDays = [...created.keys()].sort();
  const growth = [];
  if (createdDays.length) {
    const first = /* @__PURE__ */ new Date(createdDays[0] + "T12:00:00");
    first.setDate(first.getDate() - (first.getDay() + 6) % 7);
    let total = 0;
    for (let w = first.getTime(); w <= todayD.getTime(); w += 7 * DAYMS) {
      for (let k = 0; k < 7; k++) total += created.get(iso(w + k * DAYMS)) || 0;
      growth.push({ week: iso(w), total });
    }
  }
  const knows = s.knows?.length ? s.knows.map(([label, folder]) => {
    const pre = folder.replace(/^\/+|\/+$/g, "") + "/";
    return [label, md.filter((f) => f.path.startsWith(pre)).length];
  }) : Array.isArray(extra.knows) ? extra.knows.filter((k) => Array.isArray(k) && typeof k[1] === "number").map((k) => [String(k[0]), k[1]]) : kinds;
  const pc = extra.projects && typeof extra.projects === "object" ? extra.projects : {};
  const projects = (s.projects || []).map(([name, rest]) => {
    const [status = "", url = ""] = rest.split("|").map((x) => x.trim());
    return { name, status, url, commits: Number(pc[name]) || void 0 };
  });
  const avatarPath = await img(s.avatarPath, "avatar");
  let icon;
  if (avatarPath) try {
    const bmp = await createImageBitmap(new Blob([files[avatarPath]]));
    const N = 128, side = Math.min(bmp.width, bmp.height) * 0.75, sx = (bmp.width - side) / 2, sy = (bmp.height - side) * 0.12;
    const cv = new OffscreenCanvas(N, N), cx = cv.getContext("2d");
    cx.beginPath();
    cx.arc(N / 2, N / 2, N / 2, 0, Math.PI * 2);
    cx.clip();
    cx.drawImage(bmp, sx, sy, side, side, 0, 0, N, N);
    files["img/icon.png"] = await (await cv.convertToBlob({ type: "image/png" })).arrayBuffer();
    icon = "img/icon.png";
  } catch {
  }
  const data = {
    // never "Untitled": the handle until they set a name
    name: s.name || s.handle || "Your name",
    handle: s.handle || void 0,
    headline: s.headline,
    theme: s.theme,
    avatar: avatarPath,
    icon,
    banner: await img(s.bannerPath, "banner"),
    links: s.links.filter((l) => l[0] && l[1]),
    properties: s.properties.filter((p) => p[0] && p[1]),
    sections: s.sections,
    stats: { notes: md.length, words, links, activeDays },
    topics: [...tagCounts2.entries()].sort((a, b) => b[1] - a[1]).slice(0, 18),
    daily,
    publicNotes: notesSorted,
    tabs: s.tabs?.length ? s.tabs : void 0,
    summary: s.summary || void 0,
    ...nowOf(s, daily),
    timeline: s.timeline,
    projects,
    heat,
    growth,
    knows,
    inbox: extra.inbox && Array.isArray(extra.inbox.kinds) ? extra.inbox : void 0,
    code: extra.code && typeof extra.code.commits === "number" ? extra.code : void 0,
    ai: extra.ai && typeof extra.ai.total === "number" && Array.isArray(extra.ai.models) ? extra.ai : void 0,
    extraNumbers: Array.isArray(extra.numbers) ? extra.numbers.filter((x) => Array.isArray(x)).map((x) => [String(x[0]), String(x[1])]) : void 0,
    tree,
    graph,
    graphLabel: s.graph?.length ? "Local graph / sized by linked notes" : topTopics.length ? "Topics / sized by notes" : "The vault / sized by notes",
    backlinks,
    backlinkLabel: s.backlinks?.length ? `Backlinks / ${fmtN(linkCount(s.name || ""))} notes link here` : "Public notes",
    asks: s.asks,
    offers: s.offers,
    social,
    updated: (/* @__PURE__ */ new Date()).toISOString(),
    garden: garden.length ? garden : void 0,
    gardenExternal: gardenEnabled() ? s.gardenUrl || void 0 : void 0,
    gardenImages
  };
  Object.assign(files, gardenFiles);
  let modulesReport = [];
  if (s.sections.modules !== false) {
    const mo = await collectModules(app, s.hubUrl || "https://caldera.social");
    if (mo.modules.length) data.modules = mo.modules;
    Object.assign(files, mo.files);
    modulesReport = mo.report;
  }
  let cityPrivate, cityPublicBase;
  if (s.sections.city !== false) {
    try {
      const path = "Caldera/city.json";
      const fg = forgeOf(s.links || []), src = fg && forgeSource(fg);
      let cur;
      try {
        if (await app.vault.adapter.exists(path)) cur = JSON.parse(await app.vault.adapter.read(path));
      } catch {
      }
      const ours = !cur || /^caldera (github|forgejo) /.test(String(cur.source || ""));
      const sig = fg && ours && fg.kind === "github" ? await githubRepoSig(fg.user).catch(() => void 0) : void 0;
      if (fg && ours && (cur?.source !== src || sig && cur?.sig !== sig || Date.now() - Date.parse(cur?.generated || 0) > 6 * 36e5)) {
        const prev = cur?.source === src ? cur : void 0;
        const fresh = await (fg.kind === "github" ? githubCity(fg.user, prev) : forgejoCity(fg, prev)).catch(() => void 0);
        if (fresh && sig) fresh.sig = sig;
        if (fresh) {
          if (!await app.vault.adapter.exists("Caldera")) await app.vault.createFolder("Caldera");
          await app.vault.adapter.write(path, JSON.stringify(fresh, null, 1));
        }
      }
      const priv = new Set(md.filter((f) => app.metadataCache.getFileCache(f)?.frontmatter?.caldera === "private").map((f) => f.path));
      const inVault = (f) => !f.path.startsWith("Caldera/") && !/(^|\/)(templates?|\.trash)\//i.test(f.path) && !priv.has(f.path);
      const raw = await app.vault.adapter.exists(path) ? JSON.parse(await app.vault.adapter.read(path)) : void 0;
      const fromVault = !raw && !fg;
      if (raw || fromVault) {
        const fromGithub = !!raw && /^caldera (github|forgejo) /.test(String(raw.source || ""));
        const repos = raw ? parseCityRepos(raw) : vaultRepos(md.filter(inVault).map((f) => ({ path: f.path, mtime: f.stat.mtime })));
        if (repos.length) {
          const byName = new Map(md.map((f) => [f.basename.toLowerCase(), f.path]));
          const resolved = app.metadataCache.resolvedLinks;
          const notes = (project) => {
            const target = byName.get(project.toLowerCase());
            if (!target) return { n: 0, paths: [] };
            const src2 = md.filter((f) => resolved[f.path]?.[target]).sort((a, b) => b.stat.mtime - a.stat.mtime);
            return { n: src2.length, paths: [target, ...src2.slice(0, 5).map((f) => f.path)] };
          };
          cityPrivate = cityData(repos, notes, typeof raw?.generated === "string" ? raw.generated : (/* @__PURE__ */ new Date()).toISOString());
          if (fromVault) cityPrivate.kind = "vault";
          const bornAt = (f) => {
            const fm = app.metadataCache.getFileCache(f)?.frontmatter || {};
            const ts = [fm.created, fm.date, fm.notion_created, fm.notion_edited, fm.ingested, f.basename.match(/\b(20\d\d-\d\d-\d\d)\b/)?.[1]].map((v) => typeof v === "string" || typeof v === "number" ? Date.parse(String(v)) : NaN).filter((t) => t > 9466848e5 && t < Date.now() + 864e5);
            return Math.min(f.stat.ctime, f.stat.mtime, ...ts);
          };
          const hubs = {};
          for (const d of cityPrivate.districts) {
            const h = byName.get(d.name.toLowerCase());
            if (h) hubs[d.name] = h;
          }
          const gslug = new Map(garden.map((g) => [g.title.toLowerCase(), g.slug]));
          const vault = md.filter(inVault).map((f) => ({ path: f.path, title: f.basename, ctime: bornAt(f), mtime: f.stat.mtime, out: Object.keys(resolved[f.path] || {}) }));
          cityPrivate.under = underground(vault, hubs, (t) => gslug.get(t.toLowerCase()));
          const pub = publicCity(cityPrivate, fromGithub ? cityPrivate.districts.map((d) => d.name) : fromVault ? [] : (s.projects || []).map((p) => p[0]), s.privateRepos || "show", s.hideRepos || []);
          cityPublicBase = pub;
          if (pub.districts.length) data.city = pub;
        }
      }
    } catch (e) {
      console.warn("Caldera city.json unreadable:", e);
    }
  }
  const listed = await collectListings(s);
  if (listed.length) {
    data.apps = listed.filter((l) => l.kind === "app");
    data.websites = listed.filter((l) => l.kind === "site");
    if (!data.apps.length) delete data.apps;
    if (!data.websites.length) delete data.websites;
  }
  if (s.sections.city !== false && (listed.length || s.hideStorefronts?.length)) {
    const hs = s.hideStorefronts || [];
    const pub = withListingsPublic(cityPublicBase || (cityPrivate ? void 0 : { districts: [], private: false }), cityPrivate, listed, s.privateRepos || "show", s.hideRepos || [], hs);
    if (pub?.districts.length) data.city = pub;
    cityPrivate = withListingsPrivate(cityPrivate, listed, hs);
  }
  return { data, files, gardenReport, modulesReport, cityPrivate };
}
async function collectListings(s) {
  const refs = [...parseListings(s.apps || [], "app"), ...parseListings(s.websites || [], "site")];
  if (!refs.length) return [];
  const hub = (s.hubUrl || "https://caldera.social").replace(/\/$/, "");
  let meta = {};
  try {
    const r = await Promise.race([
      (0, import_obsidian6.requestUrl)({ url: `${hub}/v1/listings/resolve`, method: "POST", contentType: "application/json", body: JSON.stringify({ items: refs.map((x) => ({ kind: x.kind, url: x.url })) }), throw: false }),
      new Promise((_, no) => setTimeout(() => no(new Error("timeout")), 2e4))
    ]);
    if (r?.status === 200 && Array.isArray(r.json?.items)) {
      for (const m of r.json.items) if (m && typeof m.key === "string") meta[m.key] = m;
    }
  } catch {
    meta = {};
  }
  return refs.map((x) => toListing(x, meta[x.key], hub));
}
function asList(v) {
  if (Array.isArray(v)) return v.map(String).filter(Boolean).slice(0, 3);
  if (typeof v === "string" && v.trim()) return [v.trim()];
  return [];
}
var IMG_EXT2 = /* @__PURE__ */ new Set(["png", "jpg", "jpeg", "webp"]);
var IMG_MAX = 2e6;
var IMG_TOTAL = 6e6;
function inGarden(path, fm, folder) {
  const flag = String(fm?.caldera ?? "").toLowerCase().trim();
  if (flag === "private" || flag === "friends") return false;
  if (path.startsWith("Caldera/")) return false;
  if (flag === "garden") return true;
  const pre = (folder || "").replace(/^\/+|\/+$/g, "");
  return !!pre && path.startsWith(pre + "/");
}
async function sha256hex(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function collectGarden(app, s, md) {
  const picked = md.filter((f) => inGarden(f.path, app.metadataCache.getFileCache(f)?.frontmatter || {}, s.gardenFolder ?? "Garden"));
  const garden = [], gardenReport = [];
  const gardenFiles = {}, gardenImages = {};
  if (!picked.length) return { garden, gardenImages, gardenFiles, gardenReport };
  const titles = new Map(picked.map((f) => [f.basename.toLowerCase(), f]));
  const used = /* @__PURE__ */ new Set(), slugOf = /* @__PURE__ */ new Map();
  for (const f of picked) {
    let sl = slug(f.basename), k = 2;
    while (used.has(sl)) sl = `${slug(f.basename)}-${k++}`;
    used.add(sl);
    slugOf.set(f, sl);
  }
  const ownerPublic = [s.name, ...(s.links || []).map((l) => l[0]), ...(s.publicTopics || []).map((t) => t[1]), ...(s.projects || []).map((p) => p[0]), ...picked.map((f) => f.basename)].filter(Boolean).map(String);
  const check = publicTextFilter(ownerPublic);
  let imgTotal = 0;
  for (const f of picked) {
    const fm = app.metadataCache.getFileCache(f)?.frontmatter || {};
    const raw = (await app.vault.cachedRead(f)).replace(/^---[\s\S]*?\n---\s*/, "").replace(/%%[\s\S]*?%%/g, "").trim();
    const { text, removed } = redact(raw);
    const out = /* @__PURE__ */ new Set();
    const xlinks = /* @__PURE__ */ new Map();
    for (const m of text.matchAll(/(?<!!)\[\[([^\]|#]+)/g)) {
      const t = m[1].trim(), x = parseXLink(t);
      if (x) {
        xlinks.set(`${x.handle}/${x.slug}`, x);
        continue;
      }
      const hit = titles.get(t.split("/").pop().replace(/\.md$/i, "").toLowerCase());
      if (hit && hit !== f) out.add(slugOf.get(hit));
    }
    for (const m of text.matchAll(/!\[\[([^\]|#]+)/g)) {
      const t = m[1].trim();
      if (gardenImages[t]) continue;
      const dest = app.metadataCache.getFirstLinkpathDest?.(t, f.path) ?? app.vault.getAbstractFileByPath(t);
      if (!(dest instanceof import_obsidian5.TFile) || !IMG_EXT2.has(dest.extension.toLowerCase()) || dest.stat.size > IMG_MAX || imgTotal + dest.stat.size > IMG_TOTAL) continue;
      const outPath = `n/img/${slug(dest.basename)}-${slug(String(dest.stat.size))}.${dest.extension.toLowerCase()}`;
      gardenFiles[outPath] = await app.vault.readBinary(dest);
      imgTotal += dest.stat.size;
      gardenImages[t] = outPath;
    }
    const created = Date.parse(String(fm.created || fm.date || "")) || f.stat.ctime;
    const note = {
      slug: slugOf.get(f),
      title: f.basename,
      stage: normStage(fm.stage ?? fm.status),
      license: normLicense(fm.license),
      created: new Date(Math.min(created, f.stat.mtime)).toISOString(),
      updated: new Date(f.stat.mtime).toISOString(),
      markdown: text,
      sha256: await sha256hex(text),
      words: (text.match(/\S+/g) || []).length,
      excerpt: excerptOf(text),
      out: [...out],
      xlinks: [...xlinks.values()],
      tags: asList(fm.tags).map((t) => t.replace(/^#/, ""))
    };
    garden.push(note);
    const flags = text.split("\n").map((l) => l.trim()).filter((l) => l && !l.startsWith("```")).map((line) => ({ line: line.slice(0, 160), why: check.why(line) || "" })).filter((x) => x.why && x.why !== "name").slice(0, 12);
    gardenReport.push({ path: f.path, title: f.basename, slug: note.slug, stage: note.stage, license: note.license, words: note.words, removed, flags });
  }
  return { garden, gardenImages, gardenFiles, gardenReport };
}
async function growGardenFromJournal(app, s, daily, garden, report) {
  const fresh = daily.filter((d) => d.headline || d.focus?.length || d.wins?.length).map((d) => ({ date: d.date, headline: d.headline, focus: d.focus, wins: d.wins, themes: d.themes }));
  const path = `${app.vault.configDir}/plugins/caldera/journal-garden.json`;
  let kept = {};
  try {
    if (await app.vault.adapter.exists(path)) kept = JSON.parse(await app.vault.adapter.read(path)).days || {};
  } catch {
    kept = {};
  }
  for (const d of fresh) kept[d.date] = d;
  const dates = Object.keys(kept).sort().slice(-3650);
  kept = Object.fromEntries(dates.map((k) => [k, kept[k]]));
  try {
    await app.vault.adapter.write(path, JSON.stringify({ days: kept }));
  } catch {
  }
  const pages = journalGarden(Object.values(kept), (s.projects || []).map((p) => p[0]));
  const used = new Set(garden.map((n) => n.slug));
  for (const pg of pages) {
    const planted = garden.find((n) => n.title.toLowerCase() === pg.title.toLowerCase());
    if (planted) {
      planted.markdown += `

## From my journal

${pg.markdown.replace(/^\*[^\n]*\*\n\n/, "").replace(/^## /gm, "### ")}`;
      planted.sha256 = await sha256hex(planted.markdown);
      planted.words = (planted.markdown.match(/\S+/g) || []).length;
      if (pg.updated > planted.updated) planted.updated = pg.updated;
      continue;
    }
    let sl = slug(pg.title), k = 2;
    while (used.has(sl)) sl = `${slug(pg.title)}-${k++}`;
    used.add(sl);
    const note = {
      slug: sl,
      title: pg.title,
      stage: pg.stage,
      license: "all-rights",
      created: pg.created,
      updated: pg.updated,
      markdown: pg.markdown,
      sha256: await sha256hex(pg.markdown),
      words: (pg.markdown.match(/\S+/g) || []).length,
      excerpt: excerptOf(pg.markdown.replace(/^\*[^\n]*\*\n\n/, "").replace(/^## .*$/gm, "")),
      out: [],
      xlinks: [],
      tags: ["journal"]
    };
    garden.push(note);
    report.push({ path: "(grown from your journal)", title: note.title, slug: note.slug, stage: note.stage, license: note.license, words: note.words, removed: 0, flags: [] });
  }
  const byTitle = new Map(garden.map((n) => [n.title.toLowerCase(), n.slug]));
  for (const n of garden) {
    const out = new Set(n.out);
    for (const m of n.markdown.matchAll(/(?<!!)\[\[([^\]|#]+)/g)) {
      const t = m[1].trim();
      if (parseXLink(t)) continue;
      const sl = byTitle.get(t.split("/").pop().replace(/\.md$/i, "").toLowerCase());
      if (sl && sl !== n.slug) out.add(sl);
    }
    n.out = [...out];
  }
}
function nowOf(s, daily) {
  if (!s.nowAuto && s.now?.length) return { now: s.now };
  const week = daily.slice(-8).reverse().map((d) => (d.wins?.length ? d.wins : d.focus || []).map((x) => String(x).trim()).filter((x) => x.length > 12));
  const words = (t) => new Set(t.toLowerCase().replace(/[^a-z0-9 ]/g, " ").split(/\s+/).filter((w) => w.length > 3));
  const near = (a, b) => {
    const A = words(a), B = words(b);
    let n = 0;
    for (const w of A) if (B.has(w)) n++;
    return n / Math.max(1, Math.min(A.size, B.size)) > 0.5;
  };
  const out = [];
  for (let k = 0; k < 3 && out.length < 4; k++) for (const day of week) {
    const t = day[k];
    if (t && out.length < 4 && !out.some((o) => near(o, t))) out.push(t.replace(/\.?$/, "."));
  }
  return out.length ? { now: out, nowAuto: true } : {};
}

// src/bgtimers.ts
var import_obsidian7 = require("obsidian");
var node = (() => {
  try {
    return import_obsidian7.Platform.isDesktopApp ? window.require?.("timers") ?? null : null;
  } catch {
    return null;
  }
})();
var later = (fn, ms) => node ? node.setTimeout(fn, ms) : window.setTimeout(fn, ms);
var every = (fn, ms) => node ? node.setInterval(fn, ms) : window.setInterval(fn, ms);
var cancel = (t) => {
  if (t == null) return;
  if (node) {
    node.clearTimeout(t);
    node.clearInterval(t);
  } else {
    window.clearTimeout(t);
    window.clearInterval(t);
  }
};

// src/view.ts
var import_obsidian8 = require("obsidian");

// src/owner.ts
var esc5 = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var ago = (iso2, now) => {
  const m = Math.max(0, Math.round((Date.parse(now) - Date.parse(iso2)) / 6e4));
  return m < 60 ? `${m}m ago` : m < 48 * 60 ? `${Math.floor(m / 60)}h ago` : `${Math.floor(m / 1440)} days ago`;
};
var open2 = (r) => `<a class="ow-link" href="#" data-open="${esc5(r.path)}">${esc5(r.title)}</a>`;
var pageName = (p) => p === "index.html" ? "your profile" : p === "garden.html" ? "garden home" : p.replace(/^n\//, "").replace(/\.html$/, "").replace(/-/g, " ");
function renderOwner(o) {
  const out = [];
  const card = (id, title, body, extra = "") => out.push(`<section class="ow-card" id="${id}"><div class="ow-h"><h3>${title}</h3>${extra}</div>${body}</section>`);
  {
    const a = o.activity;
    const when = o.lastLooked ? `since you last looked, ${ago(o.lastLooked, o.now)}` : "in the last 24 hours";
    let body = "";
    if (!a) body = `<p class="ow-muted">Publish your profile to start seeing visits, gravity and links here.</p>`;
    else if ("error" in a) body = `<p class="ow-muted">Couldn't reach the hub (${esc5(a.error)}). Your vault sections below still work offline.</p>`;
    else {
      const num2 = (v) => {
        const n = Number(v);
        return Number.isFinite(n) ? Math.max(0, Math.round(n)) : 0;
      };
      a.views = num2(a.views);
      a.visitors = num2(a.visitors);
      a.totalViews = num2(a.totalViews);
      if (a.viewsAll !== void 0) a.viewsAll = num2(a.viewsAll);
      if (a.viewsWeek !== void 0) a.viewsWeek = num2(a.viewsWeek);
      a.days = (Array.isArray(a.days) ? a.days : []).map((d) => [String(d?.[0] ?? "").slice(0, 10), num2(d?.[1]), num2(d?.[2])]);
      a.pages = (Array.isArray(a.pages) ? a.pages : []).map((x) => [String(x?.[0] ?? ""), num2(x?.[1])]);
      for (const k of ["gravity", "friends", "links"]) if (!Array.isArray(a[k])) a[k] = [];
      const tiles = [[a.views, a.views === 1 ? "page view" : "page views"], [a.visitors, a.visitors === 1 ? "visitor" : "visitors"], [a.gravity.length, "gravity"], [a.friends.length, a.friends.length === 1 ? "new friend" : "new friends"], ...a.kudos?.length ? [[a.kudos.length, "kudos"]] : []].concat(o.pending ? [[o.pending, o.pending === 1 ? "new follower" : "new followers"]] : []);
      body += `<div class="ow-tiles">${tiles.map(([n, l]) => `<div class="ow-tile${Number(n) ? " is-up" : ""}"><b>${n}</b><span>${l}</span></div>`).join("")}</div>`;
      const byDay = new Map(a.days.map((d) => [d[0], d])), t0 = Date.parse(o.now);
      const days14 = Array.from({ length: 14 }, (_, i) => {
        const k = new Date(t0 - (13 - i) * 864e5).toISOString().slice(0, 10);
        return byDay.get(k) || [k, 0, 0];
      });
      const max = Math.max(1, ...days14.map((d) => d[1]));
      if (a.days.length) body += `<div class="ow-spark" title="Page views, last 14 days">${days14.map((d) => `<i style="height:${d[1] ? Math.max(6, Math.round(d[1] / max * 100)) : 2}%;${d[1] ? "" : "opacity:.25"}" title="${esc5(d[0])}: ${d[1]} views, ${d[2]} visitors"></i>`).join("")}</div><div class="ow-muted ow-small">Page views, last 14 days &middot; ${a.totalViews.toLocaleString("en-US")} all time</div>`;
      if (typeof a.viewsAll === "number") body += `<div class="ow-muted ow-small">Your page's view count: <b>${a.viewsAll.toLocaleString("en-US")}</b> all time &middot; <b>${(a.viewsWeek || 0).toLocaleString("en-US")}</b> this week (one per visitor per day)${a.showViews === false ? " &middot; hidden from visitors" : ""}</div>`;
      const lines = [];
      if (a.pages.length) lines.push(`<li>Most read: ${a.pages.slice(0, 4).map(([p, n]) => `${esc5(pageName(p))} (${n})`).join(", ")}</li>`);
      for (const g of a.gravity.slice(0, 5)) lines.push(`<li><b>${g.from ? "@" + esc5(g.from) : "Someone"}</b> gave you gravity${g.reason ? `: &ldquo;${esc5(g.reason)}&rdquo;` : ""} <span class="ow-muted">${ago(g.ts, o.now)}</span></li>`);
      for (const k of (a.kudos || []).slice(0, 6)) lines.push(`<li>${esc5(k.emoji)} <b>${k.from ? "@" + esc5(k.from) : "Someone"}</b> sent you kudos <span class="ow-muted">${ago(k.ts, o.now)}</span></li>`);
      for (const f of a.friends.slice(0, 5)) lines.push(`<li>You and <b>${f.handle ? "@" + esc5(f.handle) : "a new friend"}</b> are now friends <span class="ow-muted">${ago(f.ts, o.now)}</span></li>`);
      if (o.pending) lines.push(`<li><a href="#" data-action="panel" class="ow-link">${o.pending} new follower${o.pending === 1 ? "" : "s"}: follow back</a></li>`);
      if (gardenEnabled() && a.links.length) lines.push(`<li>Other gardens link to you ${a.links.length} time${a.links.length === 1 ? "" : "s"}: ${a.links.slice(0, 3).map((l) => `@${esc5(l.src_handle)}'s &ldquo;${esc5(l.src_title)}&rdquo;`).join(", ")}</li>`);
      body += lines.length ? `<ul class="ow-list">${lines.join("")}</ul>` : `<p class="ow-muted">Quiet so far. Share your invite link from the Caldera panel to bring friends in.</p>`;
    }
    card("ow-since", "Since you last looked", body, `<span class="ow-muted ow-small">${esc5(when)}</span>`);
  }
  if (o.checklist?.some((i) => !i.done)) {
    const items = o.checklist, left = items.filter((i) => !i.done), done = items.length - left.length;
    const act = (a, label) => `<a href="#" class="ow-link ow-act" data-action="${a}">${label}</a>`;
    const how = {
      photo: `${act("pick-photo", "Choose an image")} ${act("prompt-photo", "Copy prompt for my AI")}`,
      banner: `${act("pick-banner", "Choose an image")} ${act("prompt-banner", "Copy prompt for my AI")} <span class="ow-muted ow-small">wide, about 3:1</span>`,
      headline: `<a href="#" class="ow-link ow-act" data-open="Caldera/profile.md">Edit Caldera/profile.md</a> ${act("prompt-edit", "Copy prompt for my AI")}`,
      summary: `<a href="#" class="ow-link ow-act" data-open="Caldera/profile.md">Edit Caldera/profile.md</a> ${act("prompt-edit", "Copy prompt for my AI")}`,
      links: `<a href="#" class="ow-link ow-act" data-open="Caldera/profile.md">Edit Caldera/profile.md</a> ${act("prompt-edit", "Copy prompt for my AI")}`,
      garden: `${act("garden-help", "How to plant a note")}`,
      friend: `${act("panel", "Open the Caldera panel")}`,
      group: `${act("settings", "Join one in settings")} <span class="ow-muted ow-small">try producthunt</span>`,
      email: `${act("settings", "Turn it on in settings")}`
    };
    out.unshift(`<section class="ow-card ow-finish" id="ow-finish"><div class="ow-h"><h3>Finish your page</h3><span class="ow-muted ow-small">${done} of ${items.length} done</span></div>
<div class="ow-bar"><i style="width:${Math.round(done / items.length * 100)}%"></i></div>
<p class="ow-small">${act("finish-form", "Fill it in with a quick form")} <span class="ow-muted">name, photo, masthead and links${gardenEnabled() ? " and a first garden note" : ""} in one go</span></p>
<ul class="ow-list ow-todo">${left.map((i) => `<li><b>${esc5(i.label)}</b> <span class="ow-muted">${esc5(i.why)}</span><div class="ow-acts">${how[i.id] || ""}</div></li>`).join("")}</ul></section>`);
  }
  if (!o.checklist?.some((i) => !i.done) && o.unlock?.some((i) => !i.done)) {
    const items = o.unlock, left = items.filter((i) => !i.done), done = items.length - left.length;
    const act = (a, label) => `<a href="#" class="ow-link ow-act" data-action="${a}">${label}</a>`;
    const how = {
      live: `${act("unlock-live", "Copy prompt for my AI")} ${act("settings", "See my snippets in settings")}`,
      agents: `${act("unlock-agents", "Copy prompt for my AI")} <span class="ow-muted ow-small">paste it into Claude Code on each computer you code on</span>`,
      ai: `${act("unlock-ai", "Copy prompt for my AI")}`,
      private: `${act("settings", "Turn on Private web view in settings")} ${act("unlock-private", "Copy how-to")}`,
      story: `<a href="#" class="ow-link ow-act" data-open="Caldera/profile.md">Edit Caldera/profile.md</a> ${act("unlock-story", "Copy prompt for my AI")}`,
      code: `${act("settings", "Add your GitHub in settings")} ${act("unlock-code", "Copy prompt for my AI")}`
    };
    out.unshift(`<section class="ow-card ow-finish ow-unlock" id="ow-unlock"><div class="ow-h"><h3>Unlock more</h3><span class="ow-muted ow-small">${done} of ${items.length} on</span></div>
<div class="ow-bar"><i style="width:${Math.round(done / items.length * 100)}%"></i></div>
<p class="ow-small ow-muted">Your basics are done. These are what make a Caldera page come alive. ${act("unlock-all", "Copy one prompt for all of them")}</p>
<ul class="ow-list ow-todo">${left.map((i) => `<li><b>${esc5(i.label)}</b> <span class="ow-muted">${esc5(i.why)}</span><div class="ow-acts">${how[i.id] || ""}</div></li>`).join("")}</ul></section>`);
  }
  if (o.sources?.length) {
    const on = o.sources.filter((x) => x.ok).length, all = o.sources.length;
    const nudge = o.promptOutdated ? `<p class="ow-lead">Caldera can track more than your routine was set up for. Copy the setup prompt again and paste it into your AI agent: it upgrades what's there and fills in the rest.</p>` : on < all ? `<p class="ow-muted">Your page shows what your vault is fed. Copy the setup prompt into Claude Code, Codex or Cursor: it connects what it can find on this computer, schedules one routine to keep it fresh, and asks before anything goes public. Paste it again any time.</p>` : "";
    card("ow-sources", "What feeds your page", `${nudge}<ul class="ow-list ow-src">${o.sources.map((x) => `<li>${x.ok ? "&#10003;" : "&#9675;"} <b>${esc5(x.label)}</b>${x.ok ? "" : ` <span class="ow-muted">${esc5(x.hint)}</span>`}</li>`).join("")}</ul>
<p><a href="#" class="ow-link" data-action="prompt"><b>Copy the setup prompt</b></a>${o.promptOutdated ? "" : ` <span class="ow-muted ow-small">safe to paste again</span>`}</p>`, `<span class="ow-muted ow-small">${on} of ${all} connected</span>`);
  }
  {
    const t = o.today;
    const parts = [];
    if (t.headline) parts.push(`<p class="ow-lead">${esc5(t.headline)}</p>`);
    const chips = Object.entries(t.counts || {}).filter(([, n]) => n > 0).map(([k, n]) => `<span class="ow-chip">${k === "linesAdded" ? "+" + n : k === "linesRemoved" ? "-" + n : n} ${esc5(k === "linesAdded" || k === "linesRemoved" ? "lines" : k)}</span>`);
    if (chips.length) parts.push(`<div class="ow-chips">${chips.join("")}</div>`);
    for (const [lab, xs] of [["Focus", t.focus], ["Wins", t.wins]]) if (xs?.length) parts.push(`<div class="ow-small"><b>${lab}:</b> ${xs.map(esc5).join(" &middot; ")}</div>`);
    if (t.timeline.length) parts.push(`<ol class="ow-time">${t.timeline.map((r) => `<li><span class="ow-t">${esc5(r.time || "")}</span>${r.kind === "new" ? '<span class="ow-new">new</span>' : ""}${open2(r)}</li>`).join("")}</ol>`);
    else parts.push(`<p class="ow-muted">Nothing written yet today.</p>`);
    card("ow-today", "Today", parts.join(""), `<span class="ow-muted ow-small">${esc5(t.date)}</span>`);
  }
  if (o.onThisDay.some((d) => d.items.length)) card("ow-otd", "On this day", o.onThisDay.filter((d) => d.items.length).map((d) => `<div class="ow-otd"><div class="ow-small ow-muted">${esc5(d.label)} &middot; ${esc5(d.date)}</div>${d.items.slice(0, 2).map((r) => `<div>${open2(r)}${r.excerpt ? `<p class="ow-x">${esc5(r.excerpt)}</p>` : ""}</div>`).join("")}</div>`).join(""));
  if (o.rediscovered) {
    const r = o.rediscovered;
    card("ow-back", "Brought back", `<div class="ow-big">${open2(r)}</div>${r.excerpt ? `<p class="ow-x">${esc5(r.excerpt)}</p>` : ""}<div class="ow-small ow-muted">${esc5(r.why)}</div>`, `<span class="ow-muted ow-small">changes every 3 hours</span>`);
  }
  if (o.patterns.length) card("ow-pat", "Patterns", `<ul class="ow-list">${o.patterns.map((p) => `<li>${p}</li>`).join("")}</ul>`);
  if (o.goals === null) card("ow-goals", "Goals", `<p class="ow-muted">Track goals here with checkboxes in a note. <a href="#" class="ow-link" data-action="goals">Create Caldera/Goals.md</a></p>`);
  else if (o.goals?.length) card(
    "ow-goals",
    "Goals",
    o.goals.map((g) => {
      const pct = g.total ? Math.round(g.done / g.total * 100) : 0;
      return `<div class="ow-goal"><div class="ow-goal-h"><b>${esc5(g.heading)}</b><span class="ow-muted ow-small">${g.done}/${g.total}</span></div><div class="ow-bar"><i style="width:${pct}%"></i></div>${g.open.length ? `<div class="ow-small ow-muted">Next: ${g.open.slice(0, 2).map(esc5).join(" &middot; ")}</div>` : ""}</div>`;
    }).join(""),
    `<a href="#" class="ow-link ow-small" data-open="Caldera/Goals.md">edit</a>`
  );
  return `<style>${OWNER_CSS}</style><div class="ow" id="owner"><div class="ow-top"><span class="ow-lock">&#128274; Only you can see this</span><span class="ow-muted ow-small">Built from your vault inside Obsidian. None of it is published.</span></div><div class="ow-grid">${out.join("")}</div></div>`;
}
var OWNER_CSS = `
.ow{margin:18px 0 26px;padding:16px;border:1px dashed var(--accent);border-radius:var(--radius-md,10px);background:color-mix(in srgb,var(--accent) 5%,transparent)}
.ow-top{display:flex;flex-wrap:wrap;gap:6px 12px;align-items:baseline;margin-bottom:12px}
.ow-lock{font-family:var(--font-mono);font-size:var(--text-xs,12px);text-transform:uppercase;letter-spacing:.05em;color:var(--accent);font-weight:600}
.ow-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,300px),1fr));gap:12px}
.ow-card{background:var(--bg-raised);border:1px solid var(--line);border-radius:var(--radius-md,10px);padding:14px 16px;min-width:0}
.ow-card#ow-since,.ow-card#ow-today,.ow-card#ow-finish{grid-column:1/-1}
.ow-todo{list-style:none;padding:0;gap:10px}.ow-acts{display:flex;flex-wrap:wrap;gap:4px 14px;margin-top:3px;align-items:baseline}.ow-act{font-weight:600}
.ow-h{display:flex;justify-content:space-between;align-items:baseline;gap:8px;margin-bottom:8px}
.ow-h h3{margin:0;font-size:1rem;font-family:var(--font-sans);font-weight:600;color:var(--text-strong)}
.ow-muted{color:var(--text-muted)}.ow-small{font-size:var(--text-sm,13px)}
.ow-tiles{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px}
.ow-tile{flex:1 1 90px;padding:8px 10px;border-radius:var(--radius-sm,6px);background:var(--bg-sunken);display:flex;flex-direction:column}
.ow-tile b{font-size:1.35rem;font-variant-numeric:tabular-nums;color:var(--text-muted)}.ow-tile.is-up b{color:var(--accent)}
.ow-tile span{font-size:var(--text-xs,12px);color:var(--text-muted)}
.ow-spark{display:flex;align-items:flex-end;gap:3px;height:38px;margin:4px 0}
.ow-spark i{flex:1;background:var(--accent);opacity:.75;border-radius:2px 2px 0 0;min-height:2px}
.ow-list{margin:8px 0 0;padding-left:18px;display:grid;gap:4px}
.ow-link{color:var(--accent);text-decoration:none}.ow-link:hover{text-decoration:underline}
.ow-lead{margin:0 0 8px;font-weight:500}
.ow-chips{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px}
.ow-chip{font-size:var(--text-xs,12px);padding:2px 8px;border-radius:999px;background:var(--bg-sunken);color:var(--text-muted);font-variant-numeric:tabular-nums}
.ow-time{list-style:none;margin:10px 0 0;padding:0;display:grid;gap:3px;max-height:260px;overflow:auto;columns:2}
.ow-time li{display:flex;gap:8px;align-items:baseline;min-width:0}
.ow-time .ow-link{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ow-t{font-family:var(--font-mono);font-size:var(--text-xs,12px);color:var(--text-muted);flex:0 0 40px;font-variant-numeric:tabular-nums}
.ow-new{font-size:10px;text-transform:uppercase;letter-spacing:.05em;color:var(--accent);flex:0 0 auto}
.ow-otd{display:grid;gap:4px;margin-bottom:10px}.ow-otd:last-child{margin-bottom:0}
.ow-x{margin:2px 0 0;font-size:var(--text-sm,13px);color:var(--text-muted);display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.ow-big{font-size:1.1rem;font-weight:600}
.ow-goal{margin-bottom:10px}.ow-goal-h{display:flex;justify-content:space-between;gap:8px}
.ow-bar{height:6px;border-radius:3px;background:var(--bg-sunken);margin:4px 0;overflow:hidden}.ow-bar i{display:block;height:100%;background:var(--accent)}
@media (max-width:600px){.ow{padding:12px}.ow-time{columns:1}}
`;

// src/view.ts
var PROFILE_VIEW = "caldera-profile";
var DAY2 = 864e5;
var ymd = (t) => {
  const d = new Date(t);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
var hm = (t) => {
  const d = new Date(t);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
};
var esc6 = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var SKIP = /^(\.|Caldera\/|templates?\/|_templates\/)/i;
var BRIDGE = `(function(){var P=parent;document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a,[data-open],[data-action]');if(!a||a.hasAttribute('data-invite'))return;
var o=a.getAttribute('data-open'),ac=a.getAttribute('data-action');if(o){e.preventDefault();P.postMessage({caldera:'open',path:o},'*');return}if(ac){e.preventDefault();P.postMessage({caldera:'action',name:ac},'*');return}
var h=a.getAttribute('href');if(!h||h.charAt(0)==='#')return;e.preventDefault();P.postMessage({caldera:/^[a-z][a-z0-9+.-]*:/i.test(h)?'ext':'nav',href:h},'*')},true);
var t;addEventListener('scroll',function(){clearTimeout(t);t=setTimeout(function(){P.postMessage({caldera:'scroll',y:scrollY},'*')},250)});
addEventListener('load',function(){var H=%%HASH%%,Y=%%Y%%;var el=H&&document.getElementById(H);if(el)el.scrollIntoView();else if(Y)scrollTo(0,Y)})})();`;
var ProfileView = class extends import_obsidian8.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
    this.mode = "mine";
    this.current = "index.html";
    this.built = null;
    this.owner = "";
    this.scrollY = 0;
    this.timer = null;
    this.busy = false;
    /** Live traffic for the city in My view: polled from the hub (signed in) and posted into the sandboxed page. */
    this.liveTimer = null;
    /** The sky over My view's city follows the owner's real weather (the hub looks it up from this request, stores nothing),
     *  and an owner without live visitors or agent drones yet gets the one-row setup under the city. */
    this.ownerData = null;
    // last Private view build (the Unlock more tier reads it)
    this.lastLive = null;
    this.wx = null;
  }
  getViewType() {
    return PROFILE_VIEW;
  }
  getDisplayText() {
    return "My profile";
  }
  getIcon() {
    return "user-round";
  }
  async onOpen() {
    const root = this.contentEl;
    root.empty();
    root.addClass("caldera-profile-view");
    const bar = root.createDiv("caldera-pv-bar");
    const seg = bar.createDiv("caldera-pv-seg");
    const pub = seg.createEl("button", { text: "Public view", attr: { "aria-label": "Your live page on the hub, exactly as visitors see it" } });
    const mine = seg.createEl("button", { text: "Private view", attr: { "aria-label": "Your profile built from your vault, with private sections only you see" } });
    const setMode = (m) => {
      this.mode = m;
      mine.toggleClass("is-on", m === "mine");
      pub.toggleClass("is-on", m === "public");
      this.scrollY = 0;
      void this.show();
    };
    mine.onclick = () => setMode("mine");
    pub.onclick = () => setMode("public");
    mine.addClass("is-on");
    this.status = bar.createSpan({ cls: "caldera-pv-status" });
    const btn = (icon, label, fn) => {
      const b = bar.createEl("button", { cls: "clickable-icon", attr: { "aria-label": label } });
      (0, import_obsidian8.setIcon)(b, icon);
      b.onclick = () => fn();
    };
    btn("refresh-cw", "Refresh", () => this.refresh(true));
    btn("external-link", "Open in browser (signed in as you)", () => this.plugin.settings.handle ? void this.plugin.openProfile(this.current === "index.html" ? "" : this.current) : new import_obsidian8.Notice("Publish your profile first"));
    if (this.plugin.settings.privateUrl) btn("lock", "Open my private web view (Tailscale)", async () => {
      await this.plugin.pushPrivate(false);
      window.open(this.plugin.settings.privateUrl);
    });
    btn("picture-in-picture-2", "Pop out my city (a small window that stays on top)", () => void this.popOut());
    btn("key-round", "Sign in another device (phone, other browser)", () => this.plugin.pairDevice());
    btn("upload-cloud", "Publish now", async () => {
      const u = await this.plugin.publish();
      if (u && this.mode === "public") void this.show();
    });
    this.frame = root.createEl("iframe", { cls: "caldera-pv-frame" });
    this.frame.setAttr("sandbox", "allow-scripts allow-popups allow-popups-to-escape-sandbox");
    this.frame.setAttr("allow", "fullscreen");
    this.frame.setAttr("allowfullscreen", "true");
    this.registerDomEvent(window, "message", (e) => this.onMessage(e));
    this.registerEvent(this.app.workspace.on("active-leaf-change", (leaf) => {
      if (leaf === this.leaf) this.markLooked(false);
    }));
    this.markLooked(true);
    await this.refresh(false);
    this.timer = window.setInterval(() => {
      if (this.mode === "mine" && this.contentEl.isShown()) {
        void this.refresh(false);
        void this.pushExtras();
      }
    }, 10 * 6e4);
    this.liveTimer = window.setInterval(() => void this.pushLive(), 1e4);
    this.frame.addEventListener("load", () => window.setTimeout(() => {
      void this.pushLive().then(() => this.pushExtras());
    }, 400));
    let lastPulse = 0;
    this.registerEvent(this.app.vault.on("modify", (f) => {
      if (this.mode !== "mine" || !this.current.startsWith("city.html") || Date.now() - lastPulse < 1500) return;
      lastPulse = Date.now();
      this.frame.contentWindow?.postMessage({ caldera: "note", p: f.path }, "*");
    }));
  }
  async onClose() {
    if (this.timer) window.clearInterval(this.timer);
    if (this.liveTimer) window.clearInterval(this.liveTimer);
  }
  /** Pop the city out into a small window that stays on top (float.ts). My view floats the private city with live traffic;
   *  Public view floats the hub's page. */
  isReady() {
    return !!this.built || this.mode === "public";
  }
  cityMini() {
    return this.built ? this.page("city.html", "").replace(/<head>/i, "<head><script>window.CALDERA_MINI=1<\/script>") : null;
  }
  async popOut() {
    const handle = this.plugin.settings.handle;
    if (this.mode === "mine" && this.built) return this.plugin.floatCity({ html: this.cityMini(), live: true });
    if (!handle) return void new import_obsidian8.Notice("Publish your profile first");
    return this.plugin.floatCity({ src: `${this.plugin.profileUrl()}city.html?caldera=owner#mini` });
  }
  async pushLive() {
    if (this.mode !== "mine" || !this.current.startsWith("city.html") || !this.plugin.settings.traffic?.length || !this.contentEl.isShown()) return;
    try {
      const data = await this.plugin.ownerLive();
      this.lastLive = data;
      this.frame.contentWindow?.postMessage({ caldera: "live", data }, "*");
    } catch {
    }
  }
  async pushExtras() {
    if (this.mode !== "mine" || !this.current.startsWith("city.html") || !this.contentEl.isShown()) return;
    const s = this.plugin.settings, hub = s.hubUrl.replace(/\/$/, "");
    if (!this.wx || Date.now() - this.wx.at > 15 * 6e4) {
      try {
        this.wx = { at: Date.now(), data: await this.plugin.weather() };
      } catch {
        this.wx = { at: Date.now(), data: null };
      }
    }
    const L = this.lastLive, liveOn = !!L && (Object.values(L.today || {}).some((x) => x?.v > 0) || Object.values(L.districts || {}).some((x) => x?.views > 0));
    const agentsOn = !!L && Array.isArray(L.agents) && L.agents.length > 0, sites = (s.traffic || []).map((t) => ({ key: t.key, project: t.project }));
    const owner = s.citySetupDismissed ? null : { liveOff: !liveOn, agentsOff: !agentsOn, hub, sri: TRACK_SRI, sites: liveOn ? [] : sites, agentPrompt: !agentsOn && s.agentKey ? agentSetupPrompt(hub, s.agentKey) : "" };
    this.frame.contentWindow?.postMessage({ caldera: "extras", data: { weather: this.wx?.data || null, owner } }, "*");
  }
  /** "Since you last looked" moves forward when you come back after 30+ minutes away, not on every refresh. */
  markLooked(first) {
    const s = this.plugin.settings, now = Date.now(), last = s.ownerLastLooked ? Date.parse(s.ownerLastLooked) : 0;
    if (first || now - last > 30 * 6e4) {
      this.shownLooked = s.ownerLastLooked;
      s.ownerLastLooked = new Date(now).toISOString();
      void this.plugin.saveSettings();
      if (!first) void this.refresh(false);
    }
  }
  async refresh(loud) {
    if (this.busy) return;
    this.busy = true;
    try {
      this.status.setText("Building from your vault...");
      const { data, text, binaries, cityPrivate } = await this.plugin.build();
      const uris = /* @__PURE__ */ new Map();
      for (const [p, buf] of Object.entries(binaries)) {
        const mime = p.endsWith(".png") ? "image/png" : p.endsWith(".webp") ? "image/webp" : p.endsWith(".svg") ? "image/svg+xml" : "image/jpeg";
        uris.set(p, `data:${mime};base64,${b64.enc(new Uint8Array(buf))}`);
      }
      this.built = { text, data, uris, city: cityPrivate?.districts.length ? renderPrivateCity(data, cityPrivate) : void 0 };
      this.ownerData = await collectOwner(this.app, this.plugin, data, this.shownLooked);
      this.owner = renderOwner(this.ownerData);
      if (this.plugin.floatSpec?.html) this.plugin.floatCity({ html: this.cityMini(), live: true }, false);
      await this.show();
      if (loud) new import_obsidian8.Notice("Profile refreshed");
    } catch (e) {
      this.status.setText("Couldn't build: " + e.message);
    } finally {
      this.busy = false;
    }
  }
  async show() {
    if (this.mode === "public") {
      if (!this.plugin.settings.handle) {
        this.frame.removeAttribute("src");
        this.frame.srcdoc = `<p style="font-family:sans-serif;padding:24px">Publish your profile to see the public view.</p>`;
        return;
      }
      this.frame.removeAttribute("srcdoc");
      this.frame.src = this.plugin.profileUrl() + this.current + (this.current.includes("?") ? "&" : "?") + "caldera=owner";
      this.status.setText("Live on the hub, as visitors see it");
      return;
    }
    if (!this.built) return;
    this.frame.removeAttribute("src");
    this.frame.srcdoc = this.page(this.current.split("#")[0], this.current.split("#")[1] || "");
    const t = /* @__PURE__ */ new Date();
    this.status.setText(`Private view, built ${hm(t.getTime())}. Private sections are only visible here.`);
  }
  page(path, hash) {
    const { text, uris } = this.built;
    let html = path === "city.html" && this.built.city ? this.built.city : text[path] ?? text["index.html"];
    html = html.replace(/<link rel="stylesheet" href="(?:\.\.\/)*(assets\/[\w-]+\.css)">/g, (m, a) => text[a] ? `<style>${text[a]}</style>` : m).replace(/<link rel="(?:icon|apple-touch-icon)"[^>]*>/g, "").replace(/(src|href)="(?:\.\.\/)*([^"#?]+\.(?:png|jpe?g|webp|svg))"/g, (m, k, p) => uris.has(p) ? `${k}="${uris.get(p)}"` : m);
    if (path === "index.html") html = html.replace("<!--caldera:owner-->", this.owner);
    const script = `<script>${BRIDGE.replace("%%HASH%%", JSON.stringify(hash)).replace("%%Y%%", String(hash ? 0 : this.scrollY))}<\/script>`;
    return html.includes("</body>") ? html.replace("</body>", script + "</body>") : html + script;
  }
  onMessage(e) {
    if (e.source !== this.frame?.contentWindow || !e.data || typeof e.data !== "object") return;
    if (e.data.caldera === "popout") return void this.popOut();
    const d = e.data;
    if (d.caldera === "scroll") {
      this.scrollY = Number(d.y) || 0;
      return;
    }
    if (d.caldera === "setup-dismiss") {
      this.plugin.settings.citySetupDismissed = true;
      void this.plugin.saveSettings();
      return;
    }
    if (d.caldera === "open" && d.path) {
      void this.app.workspace.openLinkText(d.path, "", true);
      return;
    }
    if (d.caldera === "action") {
      if (d.name === "panel") void this.plugin.openPanel();
      if (d.name === "finish-form") this.plugin.openFinish();
      if (d.name === "goals") void this.createGoals();
      if (d.name === "prompt") void this.plugin.copyPrompt("setup");
      if (d.name === "prompt-edit") void this.plugin.copyPrompt("edit");
      if (d.name === "pick-banner" || d.name === "pick-photo") void this.plugin.pickImage(d.name === "pick-banner" ? "banner" : "photo").then((ok) => {
        if (ok) void this.refresh(false);
      });
      if (d.name === "prompt-banner" || d.name === "prompt-photo") void this.plugin.copyImagePrompt(d.name === "prompt-banner" ? "banner" : "photo");
      if (d.name === "settings") this.plugin.openSettings();
      if (typeof d.name === "string" && d.name.startsWith("unlock-")) void this.plugin.copyFeaturePrompt(d.name.slice(7));
      if (d.name === "garden-help") new import_obsidian8.Notice(`Put any note in your "${this.plugin.settings.gardenFolder || "Garden"}" folder, or open a note and run "Caldera: Plant this note in my garden". It goes public on the next publish.`, 12e3);
      return;
    }
    if (d.caldera === "ext" && d.href) {
      const f = d.href.match(/^obsidian:\/\/caldera\?friend=([A-Za-z0-9_-]+)/);
      if (f) return void this.plugin.confirmFriend(f[1]);
      if (/^(https?:|mailto:|sms:)/i.test(d.href)) window.open(d.href);
      return;
    }
    if (d.caldera === "nav" && d.href && this.built) {
      const u = new URL(d.href, "https://profile.local/" + this.current.split("#")[0]);
      let p = decodeURIComponent(u.pathname.slice(1));
      if (!p || p.endsWith("/")) p += "index.html";
      if ((this.built.text[p] !== void 0 || p === "city.html" && this.built.city) && p.endsWith(".html")) {
        this.current = p + (u.hash ? u.hash : "");
        this.scrollY = 0;
        void this.show();
      } else if (this.plugin.settings.handle) window.open(this.plugin.profileUrl() + p);
    }
  }
  async createGoals() {
    const p = "Caldera/Goals.md";
    let f = this.app.vault.getAbstractFileByPath(p);
    if (!f) f = await this.app.vault.create(p, "# Goals\n\nOnly you see these, in the My profile tab. One heading per goal, checkboxes for the steps.\n\n## Example goal\n- [ ] First step\n- [ ] Second step\n");
    if (f instanceof import_obsidian8.TFile) await this.app.workspace.getLeaf(true).openFile(f);
  }
};
async function excerpt(app, f, n = 220) {
  try {
    const t = (await app.vault.cachedRead(f)).replace(/^---[\s\S]*?---\s*/, "");
    const para = t.split(/\n\s*\n/).map((x) => x.replace(/^#+\s.*$/gm, "").trim()).find((x) => x.replace(/[^A-Za-z]/g, "").length > 40 && (x.match(/\|/g) || []).length < 2 && !/^(navigation|nav|tags|source|sources|related|see also|aliases|links?)\s*:/i.test(x) && !/^[-*]?\s*\[\[/.test(x)) || "";
    const clean2 = para.replace(/!\[\[[^\]]*\]\]/g, "").replace(/\[\[([^\]|]+)(\|([^\]]+))?\]\]/g, (_m, a, _b, l) => l || a).replace(/\[([^\]]+)\]\([^)]+\)/g, "$1").replace(/^\s*[-*>]\s+/gm, "").replace(/[*_`=~#]/g, "").replace(/\s+/g, " ").trim();
    return clean2.length <= n ? clean2 : clean2.slice(0, n).replace(/\s+\S*$/, "") + "\u2026";
  } catch {
    return "";
  }
}
async function collectOwner(app, plugin, data, lastLooked) {
  const now = Date.now(), today = ymd(now), startToday = /* @__PURE__ */ new Date();
  startToday.setHours(0, 0, 0, 0);
  const files = app.vault.getMarkdownFiles().filter((f) => !SKIP.test(f.path));
  const ref = (f, extra = {}) => ({ title: f.basename, path: f.path, ...extra });
  let activity;
  if (plugin.settings.identity && plugin.settings.handle) {
    try {
      activity = await plugin.ownerActivity(lastLooked || new Date(now - DAY2).toISOString());
    } catch (e) {
      activity = { error: e.message };
    }
  }
  const touched = files.filter((f) => f.stat.mtime >= startToday.getTime()).sort((a, b) => b.stat.mtime - a.stat.mtime);
  const d = data.daily?.[data.daily.length - 1];
  const todayRow = d && d.date === today ? d : void 0;
  const counts = todayRow ? Object.fromEntries(Object.entries(todayRow.counts || {}).filter(([, n]) => typeof n === "number")) : void 0;
  const onThisDay = [];
  for (const [days, label] of [[7, "A week ago"], [30, "A month ago"], [91, "Three months ago"], [365, "A year ago"]]) {
    const date = ymd(now - days * DAY2);
    const named = files.filter((f) => f.basename.includes(date)).sort((a, b) => Number(/digest|daily|journal/i.test(b.path)) - Number(/digest|daily|journal/i.test(a.path)));
    const made = files.filter((f) => ymd(f.stat.ctime) === date && !named.includes(f)).sort((a, b) => b.stat.size - a.stat.size);
    const pick = [...named, ...made].slice(0, 2);
    onThisDay.push({ label, date, items: await Promise.all(pick.map(async (f) => ref(f, { excerpt: await excerpt(app, f) }))) });
  }
  const mc = app.metadataCache;
  const near = /* @__PURE__ */ new Set();
  for (const f of touched.slice(0, 40)) {
    for (const t of Object.keys(mc.resolvedLinks[f.path] || {})) near.add(t);
    for (const t of mc.getFileCache(f)?.tags || []) near.add(t.tag);
  }
  const old = files.filter((f) => f.stat.mtime < now - 60 * DAY2 && f.stat.size > 1500 && !/\d{4}-\d{2}-\d{2}/.test(f.basename));
  const scored2 = old.map((f) => {
    const links = Object.keys(mc.resolvedLinks[f.path] || {}), tags = (mc.getFileCache(f)?.tags || []).map((t) => t.tag);
    const shared = [...links.filter((l) => near.has(l)), ...tags.filter((t) => near.has(t))];
    return { f, shared, score: shared.length + (near.has(f.path) ? 3 : 0) };
  });
  const block = Math.floor(now / (3 * 36e5));
  const pool = scored2.filter((x) => x.score > 0).sort((a, b) => b.score - a.score).slice(0, 24);
  const choice = pool.length ? pool[block % pool.length] : scored2.length ? scored2[block * 7919 % scored2.length] : void 0;
  let rediscovered;
  if (choice) {
    const s = choice.shared[0];
    const why = near.has(choice.f.path) ? "You linked to this today." : s ? `Connects to what you worked on today: ${s.startsWith("#") ? s : s.split("/").pop().replace(/\.md$/, "")}.` : `Last changed ${new Date(choice.f.stat.mtime).toLocaleDateString("en-US", { month: "short", year: "numeric" })}.`;
    let ex = await excerpt(app, choice.f, 320), pick = choice;
    for (let k = 1; !ex && k < Math.min(6, pool.length || scored2.length); k++) {
      const alt = pool.length ? pool[(block + k) % pool.length] : scored2[(block * 7919 + k) % scored2.length];
      ex = await excerpt(app, alt.f, 320);
      if (ex) pick = alt;
    }
    const s2 = pick.shared[0];
    const why2 = pick === choice ? why : near.has(pick.f.path) ? "You linked to this today." : s2 ? `Connects to what you worked on today: ${s2.startsWith("#") ? s2 : s2.split("/").pop().replace(/\.md$/, "")}.` : `Last changed ${new Date(pick.f.stat.mtime).toLocaleDateString("en-US", { month: "short", year: "numeric" })}.`;
    rediscovered = { ...ref(pick.f, { excerpt: ex }), why: why2 };
  }
  const patterns = [];
  const daily = data.daily || [];
  const sum = (xs) => xs.reduce((a, x) => a + (Number(x.counts?.notes) || 0), 0);
  const wk = sum(daily.slice(-7)), prev = sum(daily.slice(-14, -7));
  if (wk) patterns.push(`<b>${wk}</b> notes written or changed this week${prev ? `, ${wk >= prev ? "up" : "down"} ${Math.abs(Math.round((wk - prev) / prev * 100))}% on last week` : ""}.`);
  const hours = new Array(24).fill(0);
  for (const f of files) if (f.stat.mtime > now - 30 * DAY2) hours[new Date(f.stat.mtime).getHours()]++;
  const peak = hours.indexOf(Math.max(...hours));
  if (hours[peak] > 5) patterns.push(`Most of your writing lands around <b>${peak === 0 ? "midnight" : peak < 12 ? peak + "am" : peak === 12 ? "noon" : peak - 12 + "pm"}</b> (last 30 days).`);
  const tally = (lo, hi) => {
    const m = /* @__PURE__ */ new Map();
    for (const f of files) if (f.stat.mtime > now - hi * DAY2 && f.stat.mtime <= now - lo * DAY2) for (const t of Object.keys(mc.resolvedLinks[f.path] || {})) {
      const name = t.split("/").pop().replace(/\.md$/, "");
      if (/\d{4}-\d{2}-\d{2}/.test(name)) continue;
      m.set(name, (m.get(name) || 0) + 1);
    }
    return m;
  };
  const recent = tally(0, 7), before = tally(7, 35);
  const rising = [...recent].map(([k, n]) => [k, n - (before.get(k) || 0) / 4]).filter(([k, s]) => s >= 2 && (recent.get(k) || 0) >= 3).sort((a, b) => b[1] - a[1]).slice(0, 3);
  if (rising.length) patterns.push(`Rising this week: ${rising.map(([k]) => `<b>${esc6(k)}</b>`).join(", ")}.`);
  const heat = data.heat || [];
  if (heat.length) {
    let i = heat.length - 1;
    if (heat[i].n === 0) i--;
    let streak = 0;
    while (i >= 0 && heat[i].n > 0) {
      streak++;
      i--;
    }
    if (streak > 1) patterns.push(`<b>${streak}-day</b> streak of writing in your vault.`);
    const best = heat.reduce((a, b) => b.n > a.n ? b : a);
    const last = heat[heat.length - 1];
    if (last.n > 0 && last.n >= best.n) patterns.push(`Today is your <b>busiest day in 6 months</b> (${last.n} notes touched).`);
    else if (best.n) patterns.push(`Your busiest day in 6 months: ${esc6(best.date)} with ${best.n} notes touched. Today: ${last.n}.`);
  }
  let goals = null;
  const gf = app.vault.getAbstractFileByPath("Caldera/Goals.md");
  if (gf instanceof import_obsidian8.TFile) {
    goals = [];
    let cur = null;
    for (const line of (await app.vault.cachedRead(gf)).split("\n")) {
      const h = line.match(/^#{2,3}\s+(.+)/);
      if (h) {
        cur = { heading: h[1].trim(), done: 0, total: 0, open: [] };
        goals.push(cur);
        continue;
      }
      const c = line.match(/^\s*[-*]\s+\[([ xX])\]\s+(.+)/);
      if (!c) continue;
      if (!cur) {
        cur = { heading: "Goals", done: 0, total: 0, open: [] };
        goals.push(cur);
      }
      cur.total++;
      if (c[1] !== " ") cur.done++;
      else cur.open.push(c[2].trim());
    }
    goals = goals.filter((g) => g.total);
  }
  const last14 = (data.daily || []).slice(-14), has = (k) => last14.some((d2) => Number(d2.counts?.[k]) > 0);
  let act = null;
  try {
    const af = plugin.settings.activityFile || "Caldera/activity.json";
    if (await app.vault.adapter.exists(af)) act = JSON.parse(await app.vault.adapter.read(af));
  } catch {
  }
  const cityOn = !!data.city?.districts.length && data.city.kind !== "vault" || await app.vault.adapter.exists("Caldera/city.json");
  const sources = [
    { label: "Daily journal", ok: last14.some((d2) => d2.headline), hint: "a line a day, written by your AI agent from what you did" },
    { label: "Calendar", ok: has("meetings"), hint: "meetings attended (counts only)" },
    { label: "Email", ok: has("emails"), hint: "emails sent (counts only)" },
    { label: "AI usage", ok: has("prompts") || !!data.ai?.total, hint: "prompts and tokens from Claude Code, Codex" },
    { label: "Code", ok: has("commits") || !!data.code?.commits, hint: "commits, or add your GitHub username or Forgejo / Codeberg profile in settings" },
    { label: "Documents", ok: has("docs"), hint: "documents you produced or filed" },
    { label: "City", ok: cityOn, hint: data.city?.kind === "vault" ? "your city is built from your vault folders; add your GitHub username or Forgejo / Codeberg profile in settings to build it from your repos" : "your repos as a city: add your GitHub username or Forgejo / Codeberg profile in settings" },
    { label: "Page text", ok: !!data.summary, hint: "headline, summary, now, timeline" },
    { label: "Garden", ok: !!data.garden?.length, hint: "a few notes grown in public" }
  ].filter((r) => r.label !== "Garden" || gardenEnabled());
  const promptOutdated = !!act?.days?.length && (Number(act.prompt_version) || 1) < PROMPT_VERSION;
  const checklist = plugin.settings.handle ? pageChecklist({
    photo: !!data.avatar,
    banner: !!data.banner,
    headline: !!data.headline?.trim(),
    summary: !!data.summary?.trim(),
    links: (data.links || []).length > 0,
    garden: !!data.garden?.length,
    friend: plugin.friends.length > 0 || plugin.social.friends > 0,
    group: (plugin.settings.groups || []).length > 0,
    email: activity && !("error" in activity) && typeof activity.emailConfirmed === "boolean" ? activity.emailConfirmed : !!plugin.settings.summaryEmail
  }) : void 0;
  const un = activity && !("error" in activity) && activity.unlock || {};
  const unlock = plugin.settings.handle ? unlockChecklist({
    live: !!un.live,
    agents: !!un.agents,
    ai: !!data.ai?.total,
    private: typeof un.private === "boolean" ? un.private : !!plugin.settings.privateWeb,
    story: (data.timeline?.length || 0) >= 3 && (data.projects || []).some((p) => /^https?:\/\//.test(p.url || "")),
    code: !!data.city?.districts?.length && data.city.kind !== "vault" || !!data.code?.commits
  }) : void 0;
  return {
    sources,
    promptOutdated,
    checklist,
    unlock,
    now: new Date(now).toISOString(),
    lastLooked,
    activity,
    pending: plugin.pending.length,
    today: {
      date: today,
      headline: todayRow?.headline,
      focus: todayRow?.focus,
      wins: todayRow?.wins,
      counts,
      timeline: touched.slice(0, 30).map((f) => ref(f, { time: hm(f.stat.mtime), kind: f.stat.ctime >= startToday.getTime() ? "new" : "edit" }))
    },
    onThisDay,
    rediscovered,
    patterns,
    goals
  };
}

// src/float.ts
var import_obsidian9 = require("obsidian");
var CITY_FLOAT_VIEW = "caldera-city-float";
var W = 420;
var H = 280;
var TITLE = "Caldera city";
var CityFloatView = class extends import_obsidian9.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
    this.frame = null;
    this.liveTimer = null;
  }
  getViewType() {
    return CITY_FLOAT_VIEW;
  }
  getDisplayText() {
    return TITLE;
  }
  getIcon() {
    return "building-2";
  }
  async onOpen() {
    const root = this.contentEl;
    root.empty();
    root.addClass("caldera-float");
    root.createDiv({ cls: "caldera-float-drag", attr: { "aria-hidden": "true" } });
    this.frame = root.createEl("iframe", { cls: "caldera-float-frame" });
    this.frame.setAttr("sandbox", "allow-scripts allow-popups allow-popups-to-escape-sandbox");
    this.frame.addEventListener("load", () => window.setTimeout(() => void this.pushLive(), 400));
    this.liveTimer = window.setInterval(() => void this.pushLive(), 1e4);
    this.showSpec(this.plugin.floatSpec);
    let tries = 0;
    const dress = () => {
      const doc = this.containerEl.doc;
      if (this.containerEl.win !== window) {
        doc.body.addClass("caldera-float-window");
        pinWindow();
        return;
      }
      if (++tries < 20) window.setTimeout(dress, 150);
    };
    window.setTimeout(dress, 100);
  }
  /** Show a new build of the city (the My profile tab rebuilds it every 10 minutes). */
  showSpec(spec) {
    if (!this.frame || !spec) return;
    if (spec.html) {
      this.frame.removeAttribute("src");
      this.frame.srcdoc = spec.html;
    } else if (spec.src) {
      this.frame.removeAttribute("srcdoc");
      this.frame.src = spec.src;
    }
  }
  async pushLive() {
    if (!this.frame || !this.plugin.floatSpec?.live || !this.plugin.settings.traffic?.length) return;
    try {
      const data = await this.plugin.ownerLive();
      this.frame.contentWindow?.postMessage({ caldera: "live", data }, "*");
    } catch {
    }
  }
  async onClose() {
    if (this.liveTimer) window.clearInterval(this.liveTimer);
  }
};
function pinWindow() {
  if (!import_obsidian9.Platform.isDesktopApp) return;
  try {
    const remote = window.require("@electron/remote");
    const bw = remote.BrowserWindow.getAllWindows().find((w) => w.getTitle().startsWith(TITLE));
    if (!bw) return;
    const wa = remote.screen.getDisplayMatching(bw.getBounds()).workArea;
    bw.setAlwaysOnTop(true, "floating");
    bw.setVisibleOnAllWorkspaces?.(true, { visibleOnFullScreen: true });
    bw.setBounds({ x: wa.x + 12, y: wa.y + wa.height - H - 12, width: W, height: H });
  } catch {
  }
}
var FLOAT_SIZE = { width: W, height: H };

// src/links.ts
var QUICK_LINKS = [
  { label: "GitHub", ph: "your GitHub username", hosts: /(^|\.)github\.com$/i, url: (v) => `https://github.com/${v.replace(/^@/, "")}` },
  { label: "Website", ph: "yoursite.com", hosts: /^$/, url: (v) => `https://${v}` },
  { label: "X", ph: "@handle", hosts: /(^|\.)(x|twitter)\.com$/i, url: (v) => `https://x.com/${v.replace(/^@/, "")}` },
  { label: "LinkedIn", ph: "linkedin.com/in/you", hosts: /(^|\.)linkedin\.com$/i, url: (v) => `https://www.linkedin.com/in/${v.replace(/^@/, "").replace(/^in\//, "")}` }
];
function quickLinkUrl(i, raw) {
  const v = raw.trim();
  if (!v) return "";
  if (/^https?:\/\//i.test(v)) return v.replace(/^http:\/\//i, "https://");
  if (/^[\w-]+(\.[\w-]+)+(\/.*)?$/.test(v) && QUICK_LINKS[i].label !== "Website") return "https://" + v.replace(/^www\./, "www.");
  return QUICK_LINKS[i].url(v);
}
var hostOf = (u) => {
  try {
    return new URL(u).hostname;
  } catch {
    return "";
  }
};
function quickLinkIndex(label, url) {
  const l = label.trim().toLowerCase(), h = hostOf(url);
  return QUICK_LINKS.findIndex((q2) => q2.label.toLowerCase() === l || q2.label === "X" && l === "twitter" || !!h && q2.hosts.source !== "^$" && q2.hosts.test(h));
}

// src/suggest.ts
var import_obsidian10 = require("obsidian");
var STRUCTURAL = /^(entity|entities|company|companies|org|orgs|organization|concept|concepts|note|notes|index|moc|hub|stub|other|misc|reference|references|ref|file|files|image|images|img|pdf|doc|docs|document|documents|attachment|attachments|email|emails|mail|report|reports|contract|contracts|proposal|proposals|nda|invoice|invoices|receipt|receipts|data-room|dataroom|deck|decks|pitch-deck|startup-deck|transcript|transcripts|summary|summaries|digest|clip|web-clip|article|articles|bookmark|bookmarks|highlight|highlights|book-notes|imported|import|sync|auto|generated|ai-generated|wiki)$|(^|-)(pdf|email|attachment|digest|deck|transcript|import|imported)(-|$)/i;
var SKIP2 = /^(private|personal|secret|todo|to-do|task|tasks|done|doing|wip|draft|inbox|archive|archived|daily|weekly|monthly|journal|diary|meeting|meetings|1on1|one-on-one|people|person|contact|contacts|family|health|medical|therapy|money|finance|finances|bank|tax|taxes|legal|client|clients|password|passwords|template|templates|excalidraw|status|type|source|sources|clippings|clipping|review|readwise|untagged|todo-later|idea-status)$|^(status|type|source|area|people|person|project-status|log)\//i;
var ACRONYMS = { ai: "AI", ml: "ML", llm: "LLM", llms: "LLMs", ux: "UX", ui: "UI", vc: "VC", saas: "SaaS", api: "API", nlp: "NLP", seo: "SEO", cpg: "CPG", b2b: "B2B", b2c: "B2C", ios: "iOS", pkm: "PKM", gtd: "GTD", dao: "DAO", nft: "NFT", vr: "VR", ar: "AR", iot: "IoT", devops: "DevOps", js: "JS", ts: "TS" };
function labelOf(tag) {
  const last = tag.replace(/^#/, "").split("/").pop() || tag;
  const words = last.replace(/[-_]+/g, " ").replace(/([a-z])([A-Z])/g, "$1 $2").trim().split(/\s+/);
  return words.map((w, i) => ACRONYMS[w.toLowerCase()] || (i === 0 ? w.charAt(0).toUpperCase() + w.slice(1).toLowerCase() : w.toLowerCase())).join(" ").slice(0, 40);
}
function tagCounts(app) {
  const counts = /* @__PURE__ */ new Map();
  for (const f of app.vault.getMarkdownFiles()) {
    if (f.path.startsWith("Caldera/")) continue;
    const cache = app.metadataCache.getFileCache(f);
    if (!cache) continue;
    for (const t of new Set(((0, import_obsidian10.getAllTags)(cache) || []).map((x) => x.replace(/^#/, "").toLowerCase()))) counts.set(t, (counts.get(t) || 0) + 1);
  }
  return counts;
}
function vaultTags(app, limit = 30) {
  return [...tagCounts(app).entries()].filter(([t, n]) => n >= 2 && t.length >= 2 && t.length <= 40 && !SKIP2.test(t) && !STRUCTURAL.test(t) && !/^\d/.test(t) && !/\d{4}/.test(t)).sort((a, b) => b[1] - a[1]).slice(0, limit).map(([tag, count]) => ({ tag, count, label: labelOf(tag) }));
}
function topicsInUse(app, publicTopics) {
  const used = tagCounts(app);
  return publicTopics.filter(([t]) => used.has(t.replace(/^#/, "").toLowerCase())).length;
}
function githubLogin(links) {
  for (const [, u] of links) {
    const m = String(u).match(/^https?:\/\/(?:www\.)?github\.com\/([A-Za-z0-9-]{1,39})\/?$/);
    if (m) return m[1];
  }
  return null;
}
async function githubBio(login) {
  try {
    const r = await (0, import_obsidian10.requestUrl)({ url: `https://api.github.com/users/${encodeURIComponent(login)}`, headers: { accept: "application/vnd.github+json" }, throw: false });
    const bio = r.status === 200 ? String(r.json?.bio || "").replace(/\s+/g, " ").trim() : "";
    return bio ? bio.slice(0, 160) : null;
  } catch {
    return null;
  }
}

// src/main.ts
var VIEW = "caldera-panel";
var CalderaPlugin = class extends import_obsidian11.Plugin {
  constructor() {
    super(...arguments);
    this.pending = [];
    this.sent = [];
    // my requests nobody has answered yet
    this.friends = [];
    this.social = { friends: 0, gravity: 0, credits: 0 };
    this.suggestions = [];
    /** members who asked to meet you (double opt-in introductions waiting for your answer) */
    this.intros = [];
    this.token = null;
    this.timers = [];
    this.unloaded = false;
    // ---------------------------------------------------------------- hub client
    /** "Your GitHub people" (circle logins not on Caldera yet), loaded when the friends panel opens. */
    this.ghPeople = null;
    this.ghPeopleLoading = false;
    // republish shortly after the owner (or their agent) edits Caldera/profile.md or the activity file
    this.publishTimer = null;
    /** true while a publish runs (and for 15 s after): the city.json it writes must not queue another publish */
    this.publishRuns = 0;
    this.publishEnded = 0;
    this.lastPublishError = "";
    /** What the floating city shows; open=false only refreshes a window that's already open. */
    this.floatSpec = null;
  }
  async onload() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    this.addSettingTab(new CalderaSettingTab(this.app, this));
    this.registerView(VIEW, (leaf) => new CalderaView(leaf, this));
    this.registerView(PROFILE_VIEW, (leaf) => new ProfileView(leaf, this));
    this.registerView(CITY_FLOAT_VIEW, (leaf) => new CityFloatView(leaf, this));
    this.addRibbonIcon("flame", "Caldera", () => this.openPanel());
    this.addRibbonIcon("user-round", "My Caldera profile", () => this.openProfileTab());
    this.pending = [...this.settings.pendingRequests || []];
    this.registerObsidianProtocolHandler("caldera", (params) => {
      const friend = String(params.friend || "").replace(/^@/, "").toLowerCase();
      if (friend && /^[a-z0-9][a-z0-9-]{1,30}$/.test(friend) && !this.settings.handle && !this.settings.invitedBy) {
        this.settings.invitedBy = friend;
        void this.saveSettings();
      }
      if (params.group) void this.joinGroup(String(params.group));
      if (friend) void this.confirmFriend(friend);
      if (params.open === "private") void this.openPrivate();
      if (params.open === "finish") void this.openProfileTab();
    });
    this.addCommand({ id: "preview", name: "Preview my public profile", callback: () => this.preview() });
    this.addCommand({ id: "publish", name: "Publish my profile", callback: () => this.publish() });
    this.addCommand({ id: "open", name: "Open my public page (as owner)", callback: () => this.openProfile() });
    this.addCommand({ id: "open-private", name: "Open my private view", callback: () => this.openPrivate() });
    this.addCommand({ id: "profile-tab", name: "Open my profile in Obsidian (Public view + Private view)", callback: () => this.openProfileTab() });
    this.addCommand({ id: "pop-city", name: "Pop out my city (small window that stays on top)", callback: () => void this.popCity() });
    this.addCommand({ id: "pair-device", name: "Sign in another device", callback: () => this.pairDevice() });
    this.addCommand({ id: "masthead", name: "Set my masthead (cover image)", callback: () => this.pickImage("banner") });
    this.addCommand({ id: "masthead-prompt", name: "Copy AI prompt: make my masthead", callback: () => this.copyImagePrompt("banner") });
    this.addCommand({ id: "profile-file", name: "Edit my profile (open profile.md)", callback: () => this.openProfileFile() });
    this.addCommand({ id: "edit-prompt", name: "Copy AI prompt: change my profile", callback: () => this.copyPrompt("edit") });
    this.addCommand({ id: "whats-new", name: "What's new", callback: () => this.checkReleases(true) });
    this.addCommand({ id: "guide", name: "Open the guide", callback: () => window.open(this.settings.hubUrl.replace(/\/$/, "") + "/guide.html") });
    this.registerEvent(this.app.metadataCache.on("changed", (f, _d, cache) => {
      if (f.path === PROFILE_FILE) this.queuePublish("profile");
      else if (/^\d{4}-\d{2}-\d{2}$/.test(f.basename) && cache?.frontmatter && Object.keys(cache.frontmatter).some((k) => k.startsWith("caldera_"))) this.queuePublish("activity");
    }));
    this.registerEvent(this.app.vault.on("modify", (f) => {
      if (f.path === this.settings.activityFile) this.queuePublish("activity");
    }));
    const isModule = (path) => path.startsWith(MODULES_FOLDER + "/") && path.endsWith(".md");
    this.app.workspace.onLayoutReady(() => {
      for (const ev of ["create", "modify", "delete"]) this.registerEvent(this.app.vault.on(ev, (f) => {
        if (isModule(f.path)) this.queuePublish("profile");
      }));
      this.registerEvent(this.app.vault.on("rename", (f, old) => {
        if (isModule(f.path) || isModule(old)) this.queuePublish("profile");
      }));
    });
    if (gardenEnabled()) {
      this.addCommand({ id: "garden-preview", name: "Preview my garden (what goes public + privacy check)", callback: () => this.previewGarden() });
      this.addCommand({ id: "garden-plant", name: "Plant this note in my garden (make it public)", checkCallback: (check) => {
        const f = this.app.workspace.getActiveFile();
        if (!f || f.extension !== "md") return false;
        if (!check) void this.plantNote(f);
        return true;
      } });
    }
    this.addCommand({ id: "welcome", name: "Set up my profile (welcome)", callback: () => new WelcomeModal(this.app, this).open() });
    this.addCommand({ id: "topics", name: "Pick my public topics from my tags", callback: () => this.openTopics() });
    this.addCommand({ id: "finish", name: gardenEnabled() ? "Finish my page (name, photo, masthead, links, first garden note)" : "Finish my page (name, photo, masthead, links)", callback: () => this.openFinish() });
    this.addCommand({ id: "export", name: "Export profile to a vault folder (self-host)", callback: () => this.exportToFolder() });
    this.addCommand({ id: "panel", name: "Open friends panel", callback: () => this.openPanel() });
    this.addCommand({ id: "sync", name: "Sync inbox now", callback: () => this.syncInbox(true) });
    this.addCommand({ id: "share", name: "Share this note with a friend", checkCallback: (check) => {
      const f = this.app.workspace.getActiveFile();
      if (!f) return false;
      if (!check) void this.shareNote(f);
      return true;
    } });
    this.addCommand({ id: "delete", name: "Delete my profile from the hub", callback: () => new ConfirmModal(this.app, "Delete your Caldera profile from the hub? Your page, friendships, asks, offers, gravity and credits on the hub are erased. Your vault is not touched.", async () => {
      try {
        await this.send("profile.delete", {});
        new import_obsidian11.Notice("Your Caldera profile was deleted from the hub.");
      } catch (e) {
        new import_obsidian11.Notice(e.message);
      }
    }).open() });
    this.addCommand({ id: "agent-prompt", name: "Copy the AI setup prompt (connects every source; safe to paste again)", callback: () => this.copyPrompt("setup") });
    this.addCommand({ id: "share-page", name: "Share my page (link preview, invite link)", callback: () => this.openShare() });
    this.app.workspace.onLayoutReady(() => {
      if (this.settings.openProfileOnStartup) void this.openProfileTab();
      this.schedulePrivatePush();
      if (this.settings.privateWeb) this.timers.push(later(() => {
        void this.pushPrivate(false);
      }, 3e4));
      if (this.settings.identity && this.settings.handle) void this.syncInbox(false);
      else if (!this.settings.welcomed) new WelcomeModal(this.app, this).open();
      window.setTimeout(() => {
        void this.checkReleases(false);
      }, 8e3);
      window.setTimeout(() => {
        void this.offerFinish();
      }, 12e3);
      window.setTimeout(() => {
        void this.offerTopics();
      }, 4e4);
      this.timers.push(later(() => {
        if (this.settings.identity && this.settings.handle && this.settings.autoPublishHours > 0 && Date.now() - (this.settings.lastPublished || 0) > 6 * 36e5) void this.publish(true);
      }, 2e4));
    });
    this.timers.push(every(() => {
      if (this.settings.identity) void this.syncInbox(false);
    }, 10 * 6e4));
    this.timers.push(every(() => {
      void this.checkRepos();
    }, 10 * 6e4));
    this.app.workspace.onLayoutReady(() => {
      this.registerEvent(this.app.vault.on("modify", (f) => {
        if (f.path === "Caldera/city.json" && !this.publishing) this.queuePublish("profile");
      }));
      this.timers.push(later(() => {
        void this.checkRepos();
      }, 6e4));
    });
    this.scheduleAutoPublish();
    this.timers.push(later(() => {
      void this.confirmPageClaim();
    }, 3e4));
  }
  // every repeating timer is cleared on unload: an update or reload must not leave the old code publishing in the background
  onunload() {
    this.timers.forEach((t) => cancel(t));
    for (const k of ["_auto", "_priv"]) cancel(this[k]);
    cancel(this.publishTimer);
    this.unloaded = true;
  }
  async saveSettings() {
    await this.saveData(this.settings);
  }
  /** Take over a profile that was started with "Sign up with GitHub" on the hub (one-time code from caldera.social/me). */
  async importGithub(code) {
    if (!/^CAL-[\w-]{6,}$/.test(code)) {
      new import_obsidian11.Notice("Paste the code from your account page (it starts with CAL-).");
      return false;
    }
    const go = async () => {
      if (isPageCode(code)) return this.importPage(code);
      try {
        const r = await this.api("POST", "/v1/github/claim", { code });
        if (!r?.identity?.id || !r.handle) throw new Error("the hub didn't return the profile");
        if (this.settings.identity && this.settings.identity.id !== r.identity.id) this.settings.previousIdentity = this.settings.identity;
        this.settings.identity = r.identity;
        this.settings.handle = r.handle;
        if (!this.settings.name && r.name) this.settings.name = r.name;
        if (!this.settings.headline && r.headline) this.settings.headline = r.headline;
        await this.saveSettings();
        new import_obsidian11.Notice(`@${r.handle} now lives in this vault. Publishing it from your vault...`);
        const url = await this.publish(true);
        if (url) new import_obsidian11.Notice("Published: " + url);
        return true;
      } catch (e) {
        new import_obsidian11.Notice("Couldn't import: " + e.message);
        return false;
      }
    };
    if (this.settings.identity && this.settings.handle) {
      return new Promise((res) => new ConfirmModal(
        this.app,
        `This vault is already @${this.settings.handle}. Importing switches it to the GitHub profile (your current key is kept in settings as a backup, but @${this.settings.handle} stops updating). Continue?`,
        async () => res(await go()),
        "Import",
        "Switch profiles?"
      ).open());
    }
    return go();
  }
  /** A page made on the website (email or Google) moves into this vault. Key saved first, then the hub is told, then publish. */
  async importPage(code) {
    try {
      const r = await this.api("POST", "/v1/page/claim", { code });
      if (!r?.identity?.id || !r.handle) throw new Error("the hub didn't return the page");
      if (this.settings.identity && this.settings.identity.id !== r.identity.id) this.settings.previousIdentity = this.settings.identity;
      this.settings = fillFromPage(this.settings, r.page);
      try {
        const eff = effectiveSettings(this.app, this.settings), plan = photoPlan(eff.avatarPath, this.settings.hubUrl, r.handle, r.page?.photoExt);
        if (plan) {
          const img = await (0, import_obsidian11.requestUrl)({ url: plan.from }), v = this.app.vault;
          if (!v.getAbstractFileByPath("Caldera")) await v.createFolder("Caldera").catch(() => {
          });
          const old = v.getAbstractFileByPath(plan.to);
          if (old instanceof import_obsidian11.TFile) await v.modifyBinary(old, img.arrayBuffer);
          else await v.createBinary(plan.to, img.arrayBuffer);
          this.settings.avatarPath = plan.to;
        }
      } catch (e) {
        console.error("Caldera: couldn't bring the photo over", e?.message);
        new import_obsidian11.Notice("Your photo didn't come over. Add it again in Settings > Caldera.");
      }
      this.settings.identity = r.identity;
      this.settings.handle = r.handle;
      this.settings.pendingPageClaim = code;
      await this.saveSettings();
      await this.confirmPageClaim();
      new import_obsidian11.Notice(`@${r.handle} now lives in this vault. Publishing it from your vault...`);
      const url = await this.publish(true);
      if (url) new import_obsidian11.Notice("Published: " + url);
      return true;
    } catch (e) {
      new import_obsidian11.Notice("Couldn't import: " + e.message);
      return false;
    }
  }
  /** Tell the hub the key is safe here, so it can erase its copy. Retried on load until it lands. */
  async confirmPageClaim() {
    const code = this.settings.pendingPageClaim;
    if (!code) return;
    try {
      await this.api("POST", "/v1/page/claim/confirm", { code });
    } catch (e) {
      if (!/unknown or expired/i.test(String(e?.message))) return;
    }
    delete this.settings.pendingPageClaim;
    await this.saveSettings();
  }
  async ensureIdentity(quiet = false) {
    if (!this.settings.identity) {
      this.settings.identity = newIdentity();
      await this.saveSettings();
      if (!quiet) new import_obsidian11.Notice("Caldera identity created. Export your recovery key from settings and keep it safe.");
    }
    return this.settings.identity;
  }
  scheduleAutoPublish() {
    cancel(this._auto);
    const h = this.settings.autoPublishHours;
    this._auto = h > 0 ? every(() => {
      void this.publish(true);
    }, h * 36e5) : null;
  }
  async loadGithubPeople() {
    const me = this.settings.identity;
    if (!me || !this.settings.handle || this.ghPeopleLoading) return;
    this.ghPeopleLoading = true;
    try {
      this.ghPeople = await this.api("GET", `/v1/owner/${encodeURIComponent(me.id)}/github-people`, void 0, true);
    } catch {
      this.ghPeople = { people: [], message: "", invitesLeft: 0 };
    } finally {
      this.ghPeopleLoading = false;
    }
  }
  async githubInvite(login) {
    const me = this.settings.identity;
    const r = await this.api("POST", `/v1/owner/${encodeURIComponent(me.id)}/github-invite`, { login }, true);
    return String(r?.message || "Invite sent.");
  }
  async api(method, path, body, auth = false) {
    const headers = { "content-type": "application/json" };
    if (auth) headers.authorization = "Bearer " + await this.authToken();
    const r = await (0, import_obsidian11.requestUrl)({ url: this.settings.hubUrl.replace(/\/$/, "") + path, method, headers, body: body ? JSON.stringify(body) : void 0, throw: false });
    if (r.status >= 400) throw new Error(r.json?.error || `hub error ${r.status}`);
    return r.json;
  }
  async send(type, body) {
    return this.api("POST", "/v1/envelopes", sign(await this.ensureIdentity(), type, body));
  }
  async authToken() {
    if (this.token && this.token.until > Date.now()) return this.token.value;
    const me = await this.ensureIdentity();
    const { nonce } = await this.api("POST", "/v1/auth/challenge", { id: me.id });
    const { token, expires_in } = await this.api("POST", "/v1/auth/verify", sign(me, "message", { nonce }));
    this.token = { value: token, until: Date.now() + (expires_in - 60) * 1e3 };
    return token;
  }
  // ---------------------------------------------------------------- profile
  /** Link counts are only right once Obsidian has resolved every link (it re-indexes after a restart). */
  /** Wait until Obsidian has indexed every note (so link counts are right), at most 10s. Obsidian has no public
   *  "resolved" flag and the "resolved" event may already have fired, so check the caches directly. */
  linksResolved() {
    const mc = this.app.metadataCache;
    const ready = () => this.app.vault.getMarkdownFiles().every((f) => mc.getFileCache(f));
    if (ready()) return Promise.resolve();
    return new Promise((r) => {
      const t0 = Date.now();
      const tick = window.setInterval(() => {
        if (ready() || Date.now() - t0 > 1e4) {
          window.clearInterval(tick);
          r();
        }
      }, 250);
    });
  }
  async build() {
    await this.linksResolved();
    const eff = effectiveSettings(this.app, this.settings);
    const { data, files, gardenReport, cityPrivate } = await collectProfile(this.app, eff, eff.sections.social ? this.social : void 0);
    data.hub = this.settings.hubUrl;
    data.id = this.settings.identity?.id;
    const text = renderProfile(data);
    return { data, text, binaries: files, eff, gardenReport, cityPrivate };
  }
  async openProfileFile() {
    const f = await ensureProfileFile(this.app, this.settings, this.settings.hubUrl);
    await this.app.workspace.getLeaf(true).openFile(f);
  }
  /** Did the GitHub in your links gain or lose a repo since the city was built? Then republish (the publish rebuilds the
   *  city). Only for cities the plugin builds itself; a city.json from your own tools republishes when it's rewritten. */
  async checkRepos() {
    if (!this.settings.identity || !this.settings.handle || this.publishing) return;
    try {
      const fg = forgeOf(effectiveSettings(this.app, this.settings).links || []);
      if (!fg || fg.kind !== "github") return;
      const path = "Caldera/city.json";
      let cur;
      try {
        if (await this.app.vault.adapter.exists(path)) cur = JSON.parse(await this.app.vault.adapter.read(path));
      } catch {
      }
      if (cur && !/^caldera github /.test(String(cur.source || ""))) return;
      const sig = await githubRepoSig(fg.user);
      if (!sig) return;
      if (cur?.sig !== sig) this.queuePublish("profile");
    } catch {
    }
  }
  queuePublish(reason) {
    if (!this.settings.identity || !this.settings.handle) return;
    cancel(this.publishTimer);
    this.publishTimer = later(() => {
      this.publishTimer = null;
      void this.publish(true).then((url) => {
        if (url && reason === "profile") new import_obsidian11.Notice("Caldera: your public page was updated.");
      });
    }, 45e3);
  }
  // What's new: the hub's release feed, shown only to the owner, inside Obsidian
  async checkReleases(manual = false) {
    try {
      const r = await (0, import_obsidian11.requestUrl)({ url: this.settings.hubUrl.replace(/\/$/, "") + "/releases.json", throw: false });
      const list = r.status === 200 ? r.json?.releases || [] : [];
      if (!list.length) {
        if (manual) new import_obsidian11.Notice("Couldn't load release notes.");
        return;
      }
      const seen = list.findIndex((x) => x.version === this.settings.lastSeenRelease);
      if (!this.settings.lastSeenRelease && !manual) {
        this.settings.lastSeenRelease = list[0].version;
        await this.saveSettings();
        return;
      }
      const unseen = manual ? list.slice(0, 3) : list.slice(0, seen === -1 ? 1 : seen);
      if (!unseen.length) return;
      const open3 = () => {
        new WhatsNewModal(this.app, this, unseen).open();
        this.settings.lastSeenRelease = list[0].version;
        void this.saveSettings();
      };
      if (manual) return open3();
      const frag = createFragment((f) => {
        f.createEl("b", { text: `Caldera ${unseen[0].version}: ` });
        f.appendText(unseen[0].title + " ");
        f.createEl("u", { text: "See what's new" });
      });
      const n = new import_obsidian11.Notice(frag, 2e4);
      n.noticeEl.addEventListener("click", open3);
    } catch {
      if (manual) new import_obsidian11.Notice("Couldn't load release notes.");
    }
  }
  async preview() {
    const { text, binaries } = await this.build();
    let html = text["index.html"].replace('<link rel="stylesheet" href="assets/theme.css">', `<style>${text["assets/theme.css"]}</style>`).replace('<link rel="stylesheet" href="assets/profile.css">', `<style>${text["assets/profile.css"]}</style>`);
    for (const [p, buf] of Object.entries(binaries)) {
      const mime = p.endsWith(".png") ? "image/png" : p.endsWith(".webp") ? "image/webp" : p.endsWith(".gif") ? "image/gif" : "image/jpeg";
      html = html.split(`src="${p}"`).join(`src="data:${mime};base64,${b64.enc(new Uint8Array(buf))}"`);
    }
    new PreviewModal(this.app, html).open();
  }
  async copyPrompt(kind) {
    const a = this.app.vault.adapter;
    const hub = this.settings.hubUrl.replace(/\/$/, "");
    const extras = this.settings.agentKey ? `
My agent hook (only if I say yes above), exactly as Caldera gave it to me:

${agentSetupPrompt(hub, this.settings.agentKey)}` : "";
    const text = (kind === "edit" ? editPrompt : agentPrompt)({
      extras,
      vaultPath: a instanceof import_obsidian11.FileSystemAdapter ? a.getBasePath() : void 0,
      hubUrl: this.settings.hubUrl,
      handle: this.settings.handle || void 0,
      activityFile: this.settings.activityFile,
      publicTopics: this.settings.publicTopics.map((t) => t[0]),
      installed: true
    });
    try {
      await navigator.clipboard.writeText(text);
      new import_obsidian11.Notice(kind === "edit" ? "Prompt copied. Paste it into your AI agent." : "Setup prompt copied. Paste it into Claude Code, Codex or Cursor: it connects every source it can find, keeps it fresh, and asks before anything goes public.", 8e3);
    } catch {
      new PromptModal(this.app, text).open();
    }
  }
  get publishing() {
    return this.publishRuns > 0 || Date.now() - this.publishEnded < 15e3;
  }
  async publish(quiet = false) {
    this.publishRuns++;
    try {
      return await this.publishNow(quiet);
    } finally {
      this.publishRuns--;
      this.publishEnded = Date.now();
    }
  }
  async publishNow(quiet = false) {
    if (this.unloaded) return null;
    this.lastPublishError = "";
    try {
      if (!this.settings.handle) throw new Error("Set a handle in Caldera settings first");
      const me = await this.ensureIdentity();
      const { data, text, binaries, eff, cityPrivate } = await this.build();
      const manifest = sign(me, "profile.manifest", {
        name: data.name,
        handle: this.settings.handle,
        boxKey: me.boxPublic,
        headline: data.headline || "",
        photos: { avatar: data.avatar, banner: data.banner },
        links: data.links,
        sections: Object.keys(data.sections).filter((k) => data.sections[k]),
        stats: data.stats,
        daily: data.daily.map((d) => ({ date: d.date, score: activityScore(d.counts), headline: d.headline || "", counts: d.counts })),
        topics: data.topics,
        asks: data.asks,
        offers: data.offers,
        listed: eff.listed !== false,
        ...eff.autoConnectRepos === false || eff.autoConnectGithub === false || this.settings.autoConnectRepos === false ? { autoConnectRepos: false, autoConnectGithub: false } : {},
        showViews: this.settings.showViews !== false,
        ...eff.tags?.length ? { tags: eff.tags.slice(0, 12) } : {},
        ...eff.hideTags?.length ? { hideTags: eff.hideTags.slice(0, 40) } : {},
        ...eff.autoTags === false || this.settings.autoTags === false ? { autoTags: false } : {},
        ...eff.privateRepos ? { privateRepos: eff.privateRepos } : {},
        page: "index.html",
        updated: data.updated,
        // the garden: every public note with its stage, license and a sha256 of the published text, signed with the profile
        garden: data.garden?.length && eff.sections.garden !== false ? gardenManifest(data.garden) : void 0,
        gardenUrl: data.gardenExternal,
        groups: groupsFrom((this.settings.groups || []).join(",")),
        languages: data.code?.languages?.slice(0, 6) || [],
        invitedBy: this.settings.invitedBy || void 0
        // the hub only uses it on a profile's first publish
      });
      const files = {};
      for (const [p, t] of Object.entries(text)) files[p] = b64.enc(new TextEncoder().encode(t));
      for (const [p, b] of Object.entries(binaries)) files[p] = b64.enc(new Uint8Array(b));
      await this.api("POST", `/v1/profiles/${encodeURIComponent(me.id)}/bundle`, { manifest, files, v: this.manifest.version });
      this.settings.lastPublished = Date.now();
      await this.saveSettings();
      if (this.settings.privateWeb) void this.pushPrivate(false);
      void this.syncSites(cityPrivate, data.city?.districts.map((d) => d.name) || []);
      const url = this.profileUrl();
      if (!quiet) new import_obsidian11.Notice(`Published: ${url}`);
      if (!eff.name && Date.now() - (this.settings.nameNudgedAt || 0) > 864e5) {
        this.settings.nameNudgedAt = Date.now();
        await this.saveSettings();
        new import_obsidian11.Notice(`Your page shows @${eff.handle || "your handle"} as your name. Add your name in Caldera/profile.md (the "name:" line) or Settings > Caldera.`, 12e3);
      }
      if (!this.settings.sharePrompted && this.settings.welcomed) {
        this.settings.sharePrompted = true;
        await this.saveSettings();
        window.setTimeout(() => this.openShare(), 1500);
      }
      return url;
    } catch (e) {
      this.lastPublishError = e.message;
      if (!quiet) new import_obsidian11.Notice("Caldera publish failed: " + e.message);
      else console.warn("Caldera publish failed:", e.message);
      return null;
    }
  }
  async previewGarden() {
    const { gardenReport, eff } = await this.build();
    new GardenPreviewModal(this.app, gardenReport, eff.gardenFolder ?? "Garden", this.settings.handle ? `${this.profileUrl()}garden.html` : "").open();
  }
  /** Opt a note into the garden: caldera: garden + stage + license (only fills what is missing). */
  async plantNote(f) {
    await this.app.fileManager.processFrontMatter(f, (fm) => {
      fm.caldera = "garden";
      if (!fm.stage) fm.stage = "seedling";
      if (!fm.license) fm.license = "all-rights";
    });
    new import_obsidian11.Notice(`"${f.basename}" is now in your garden as a seedling. It goes public on the next publish; run "Preview my garden" to check it first.`);
  }
  profileUrl() {
    return `${this.settings.hubUrl.replace(/\/$/, "")}/@${this.settings.handle}/`;
  }
  /** Open the public page in the browser signed in as its owner (a one-time link sets an owner cookie on the hub), so the
   *  page shows a "Private view" button instead of the sign-up pitch, and the owner's own visits aren't counted. */
  async openProfile(sub = "") {
    if (!this.settings.handle || !this.settings.identity) return void new WelcomeModal(this.app, this).open();
    try {
      const r = await this.api("POST", `/v1/owner/${encodeURIComponent(this.settings.identity.id)}/link`, {}, true);
      if (typeof r?.url === "string" && r.url.startsWith(this.settings.hubUrl.replace(/\/$/, "") + "/")) return void window.open(sub ? `${r.url}&to=${encodeURIComponent(sub)}` : r.url);
    } catch (e) {
      console.warn("Caldera owner link failed:", e.message);
    }
    window.open(this.profileUrl() + sub);
  }
  /** Approve a sign-in code shown on another device (caldera.social/signin): that browser becomes the owner's. */
  pairDevice() {
    if (!this.settings.identity || !this.settings.handle) return void new import_obsidian11.Notice("Publish your profile first.");
    new PairModal(this.app, async (code) => {
      const r = await this.api("POST", `/v1/owner/${encodeURIComponent(this.settings.identity.id)}/pair`, { code }, true);
      new import_obsidian11.Notice(`Signed in. That device now shows the Private view button on @${r.handle || this.settings.handle}.`, 8e3);
    }, this.profileUrl()).open();
  }
  /** Write the setup form into Caldera/profile.md: name, headline, listed, chosen images (saved as Caldera/photo|banner.ext),
   *  the four quick links (replacing only those, keeping every other link), and plant a first garden note. */
  async applyProfileForm(f) {
    const v = this.app.vault, paths = {};
    for (const kind of ["photo", "banner"]) {
      const im = f.images[kind];
      if (!im) continue;
      if (!v.getAbstractFileByPath("Caldera")) await v.createFolder("Caldera").catch(() => {
      });
      const path = (0, import_obsidian11.normalizePath)(`Caldera/${kind}.${im.ext}`), old = v.getAbstractFileByPath(path);
      if (old instanceof import_obsidian11.TFile) await v.modifyBinary(old, im.buf);
      else await v.createBinary(path, im.buf);
      paths[kind] = path;
    }
    const pf = await ensureProfileFile(this.app, this.settings, this.settings.hubUrl);
    await this.app.fileManager.processFrontMatter(pf, (fm) => {
      fm.name = f.name;
      fm.headline = f.headline;
      fm.listed = f.listed;
      if (paths.photo) fm.photo = paths.photo;
      if (paths.banner) fm.banner = paths.banner;
      const old = Array.isArray(fm.links) ? fm.links.map(String) : [];
      const keep = old.filter((l) => {
        const [a = "", ...b] = l.split("|");
        return quickLinkIndex(a, b.join("|").trim()) < 0;
      });
      fm.links = [...f.links.filter(([, u]) => u).map(([l, u]) => `${l} | ${u}`), ...keep];
    });
    if (f.plant && gardenEnabled()) await this.plantNote(f.plant);
  }
  openSettings() {
    const st = this.app.setting;
    if (!st) return;
    st.open();
    st.openTabById?.(this.manifest.id);
  }
  /** Copy a focused prompt that has the owner's AI agent set a masthead or profile photo. */
  /** "Unlock more": the slice of the setup prompt for one feature (or "all" still off), with this owner's own snippets and agent hook. */
  async copyFeaturePrompt(id) {
    const a = this.app.vault.adapter, s = this.settings, hub = s.hubUrl.replace(/\/$/, "");
    const o = {
      vaultPath: a instanceof import_obsidian11.FileSystemAdapter ? a.getBasePath() : void 0,
      hubUrl: s.hubUrl,
      handle: s.handle || void 0,
      activityFile: s.activityFile,
      agentSetup: s.agentKey ? agentSetupPrompt(hub, s.agentKey) : void 0
    };
    const snippets = (s.traffic || []).map((t) => `- ${t.project}: ${trackTag(hub, t.key)}`).join("\n");
    const withSnippets = (t) => snippets ? `${t}

My snippets, one per district (these are public site keys, fine in page HTML):
${snippets}` : t;
    const ids = ["live", "agents", "ai", "private", "story", "code"];
    let text;
    if (id === "all") {
      const view = this.app.workspace.getLeavesOfType(PROFILE_VIEW)[0]?.view;
      const left = (view?.ownerData?.unlock || []).filter((i) => !i.done).map((i) => i.id).filter((x) => ids.includes(x));
      text = withSnippets(upgradePrompt(left.length ? left : [...ids], o));
      if (o.agentSetup && (!left.length || left.includes("agents"))) text += `

My agent hook, exactly as Caldera gave it to me (keep the key and secret out of any repo):

${o.agentSetup}`;
    } else if (ids.includes(id)) text = id === "live" ? withSnippets(featurePrompt("live", o)) : featurePrompt(id, o);
    else return;
    try {
      await navigator.clipboard.writeText(text);
      new import_obsidian11.Notice("Prompt copied. Paste it into Claude Code, Codex or Cursor.", 6e3);
    } catch {
      new PromptModal(this.app, text).open();
    }
  }
  async copyImagePrompt(kind) {
    const a = this.app.vault.adapter;
    const text = imagePrompt(kind, { vaultPath: a instanceof import_obsidian11.FileSystemAdapter ? a.getBasePath() : void 0, hubUrl: this.settings.hubUrl, handle: this.settings.handle || void 0 });
    try {
      await navigator.clipboard.writeText(text);
      new import_obsidian11.Notice(`Prompt copied. Paste it into your AI agent: it sets your ${kind === "banner" ? "masthead" : "photo"} and the page republishes itself.`, 8e3);
    } catch {
      new PromptModal(this.app, text).open();
    }
  }
  /** Choose an image from disk: copied into the vault as Caldera/<kind>.<ext>, set in Caldera/profile.md (which republishes). */
  pickImage(kind) {
    return new Promise((done) => new ImagePickModal(this.app, kind, async (buf, ext) => {
      const path = (0, import_obsidian11.normalizePath)(`Caldera/${kind}.${ext}`), v = this.app.vault;
      if (!v.getAbstractFileByPath("Caldera")) await v.createFolder("Caldera").catch(() => {
      });
      const old = v.getAbstractFileByPath(path);
      if (old instanceof import_obsidian11.TFile) await v.modifyBinary(old, buf);
      else await v.createBinary(path, buf);
      const pf = await ensureProfileFile(this.app, this.settings, this.settings.hubUrl);
      await this.app.fileManager.processFrontMatter(pf, (fm) => {
        fm[kind === "banner" ? "banner" : "photo"] = path;
      });
      new import_obsidian11.Notice(`${kind === "banner" ? "Masthead" : "Photo"} set. Your page republishes in about a minute.`);
      done(true);
    }, () => done(false)).open());
  }
  /** The private view: the Tailscale web address when this hub gives you one, otherwise My view inside Obsidian. */
  async openPrivate() {
    if (this.settings.privateUrl) {
      void this.pushPrivate(false);
      return void window.open(this.settings.privateUrl);
    }
    await this.openProfileTab();
  }
  async exportToFolder() {
    const { text, binaries } = await this.build();
    const root = "Caldera/site";
    for (const [p, t] of Object.entries(text)) await this.write(`${root}/${p}`, t);
    for (const [p, b] of Object.entries(binaries)) await this.writeBinary(`${root}/${p}`, b);
    new import_obsidian11.Notice(`Exported to ${root}. Upload that folder to any static host.`);
  }
  // ---------------------------------------------------------------- inbox
  /** Add friend / Accept tapped on caldera.social while signed in: the hub queues it (it never holds this vault's key);
   *  this signs and sends it, and the hub clears the queue entry when the request or acceptance lands. */
  async sendQueuedFriends(myId) {
    let list = [];
    try {
      list = (await this.api("GET", `/v1/owner/${encodeURIComponent(myId)}/intents`, void 0, true))?.intents || [];
    } catch {
      return;
    }
    const done = [];
    for (const x of list.slice(0, 20)) {
      try {
        if (x.kind === "accept" && x.request) await this.send("friend.accept", { request: x.request, to: x.id });
        else await this.send("friend.request", { to: x.id, note: "" });
        done.push((x.kind === "accept" ? "accepted @" : "sent a request to @") + (x.handle || "someone"));
      } catch (e) {
        console.warn("Caldera queued friend failed:", e?.message);
      }
    }
    if (done.length) new import_obsidian11.Notice(`Caldera: from your taps on the web, ${done.join(", ")}.`, 8e3);
  }
  async syncInbox(loud) {
    try {
      const me = await this.ensureIdentity();
      const [{ envelopes }, fr, gr, cr, rq] = await Promise.all([
        this.api("GET", `/v1/inbox/${encodeURIComponent(me.id)}?since=${encodeURIComponent(this.settings.lastInboxSync)}`, void 0, true),
        this.api("GET", `/v1/friends/${encodeURIComponent(me.id)}`),
        this.api("GET", `/v1/gravity/${encodeURIComponent(me.id)}`),
        this.api("GET", `/v1/credits/${encodeURIComponent(me.id)}`),
        this.api("GET", `/v1/requests/${encodeURIComponent(me.id)}`, void 0, true).catch(() => null)
      ]);
      this.friends = fr.friends;
      this.social = { friends: fr.friends.length, gravity: gr.gravity, credits: cr.balance };
      const seen = new Set(this.settings.seenRepoFriends || []), fresh = this.friends.filter((f) => (f.kind === "repo" || f.kind === "github") && f.why && !seen.has(f.id));
      if (fresh.length) {
        if (this.settings.seenRepoFriends) for (const f of fresh.slice(0, 3)) new import_obsidian11.Notice(`Caldera: you and ${f.handle ? "@" + f.handle : "a member"} are now connected: ${f.kind === "repo" ? "you both work on " : ""}${f.why}.`, 1e4);
        this.settings.seenRepoFriends = [...seen, ...fresh.map((f) => f.id)].slice(-500);
        await this.saveSettings();
      }
      await this.sendQueuedFriends(me.id);
      let cards = 0;
      for (const e of envelopes) {
        if (!verify(e)) continue;
        if (!rq && e.type === "friend.request" && !this.friends.some((f) => f.id === e.from) && !this.pending.some((x) => x.from === e.from)) {
          let handle;
          try {
            handle = (await this.api("GET", `/v1/profiles/${encodeURIComponent(e.from)}`)).handle;
          } catch {
          }
          this.pending.push({ request: envelopeHash(e), from: e.from, handle, note: e.body.note, ts: e.ts });
          new import_obsidian11.Notice(`Caldera: ${handle ? "@" + handle : "someone new"} followed you. Open the Caldera panel to follow back.`);
        }
        if (e.type === "friend.accept") {
          const f = this.friends.find((x) => x.id === e.from);
          new import_obsidian11.Notice(`Caldera: ${f?.handle ? "@" + f.handle : "someone"} followed you back. You're friends.`);
        }
        if (e.type === "gravity") new import_obsidian11.Notice(`Caldera: someone gave you gravity${e.body.reason ? ': "' + e.body.reason + '"' : ""}`);
        if (e.type === "card") {
          if (await this.receiveCard(e)) cards++;
        }
        if (e.ts > this.settings.lastInboxSync) this.settings.lastInboxSync = e.ts;
      }
      if (rq) {
        const ignored = new Set(this.settings.ignoredRequests || []), seen2 = new Set(this.settings.seenRequests || []);
        this.pending = rq.incoming.filter((r) => !ignored.has(r.request)).map((r) => ({ request: r.request, from: r.id, handle: r.handle || void 0, note: r.note || void 0, ts: r.ts }));
        this.sent = rq.outgoing.map((r) => ({ request: r.request, from: r.id, handle: r.handle || void 0, note: r.note || void 0, ts: r.ts }));
        const fresh2 = this.pending.filter((x) => !seen2.has(x.request));
        if (fresh2.length) new import_obsidian11.Notice(`Caldera: ${fresh2.map((x) => x.handle ? "@" + x.handle : "someone new").join(", ")} followed you. Open the Caldera panel to follow back.`, 1e4);
        this.settings.seenRequests = this.pending.map((x) => x.request);
      }
      this.pending = this.pending.filter((x) => !this.friends.some((f) => f.id === x.from));
      this.settings.pendingRequests = this.pending;
      await this.saveSettings();
      if (this.settings.handle) {
        try {
          this.suggestions = (await this.api("GET", `/v1/suggest/${encodeURIComponent(me.id)}?n=4`)).suggestions || [];
        } catch {
        }
        try {
          const r = await this.api("GET", `/v1/owner/${encodeURIComponent(me.id)}/intros`, void 0, true);
          this.intros = r.intros || [];
          const seen2 = new Set(this.settings.seenIntros || []), fresh2 = this.intros.filter((i) => !seen2.has(i.handle + i.ts));
          if (fresh2.length) new import_obsidian11.Notice(`Caldera: ${fresh2.map((i) => "@" + i.handle).join(", ")} would like to meet you${fresh2[0].tag ? ` (also building ${fresh2[0].tag})` : ""}. Open the Caldera panel to answer.`, 1e4);
          this.settings.seenIntros = this.intros.map((i) => i.handle + i.ts);
        } catch {
        }
        void this.welcomeNewMembers();
        void this.attention();
        void this.kudosNews();
        void this.checkAlerts();
        void this.checkMessages();
        void this.summaryPrompt();
      }
      this.refreshPanel();
      if (loud || cards) new import_obsidian11.Notice(`Caldera: inbox synced${cards ? `, ${cards} shared note(s) received` : ""}`);
    } catch (e) {
      if (loud) new import_obsidian11.Notice("Caldera sync failed: " + e.message);
    }
  }
  async receiveCard(e) {
    const me = this.settings.identity;
    const sealed = e.body.payload?.[me.id];
    const sender = this.friends.find((f) => f.id === e.from);
    if (!sealed || !sender?.box_key) return false;
    const text = open(sealed, sender.box_key, me);
    if (text === null) return false;
    const plain = (v, n) => String(v ?? "").toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, n);
    const who = plain(sender.handle, 40) || plain(e.from.slice(4, 12), 8) || "friend";
    const safe = String(e.body.title || "Shared note").replace(/[\\/:*?"<>|#^[\]\x00-\x1f]/g, " ").replace(/^[.\s]+/, "").trim().slice(0, 80) || "Shared note";
    const fm = `---
caldera_from: "${who}"
caldera_card: "${plain(e.body.id, 64)}"
caldera_version: ${Math.max(1, Math.floor(Number(e.body.version)) || 1)}
caldera_received: ${JSON.stringify(String(e.ts || "").slice(0, 40))}
---
`;
    await this.write(`${this.settings.inboxFolder}/${who}/${safe}.md`, fm + text.replace(/^---[\s\S]*?---\s*/, ""));
    return true;
  }
  async acceptFriend(p) {
    try {
      await this.send("friend.accept", { request: p.request, to: p.from });
    } catch (e) {
      return void new import_obsidian11.Notice("Couldn't accept: " + e.message);
    }
    this.pending = this.pending.filter((x) => x !== p);
    this.settings.pendingRequests = this.pending;
    await this.syncInbox(false);
    new import_obsidian11.Notice(`You and ${p.handle ? "@" + p.handle : "your new friend"} are now friends`);
  }
  async ignoreFriend(p) {
    this.settings.ignoredRequests = [...this.settings.ignoredRequests || [], p.request].slice(-200);
    this.pending = this.pending.filter((x) => x !== p);
    this.settings.pendingRequests = this.pending;
    await this.saveSettings();
    this.refreshPanel();
  }
  /** Join a group (obsidian://caldera?group=): it goes into the next publish, and the group's town lists this profile. */
  async joinGroup(raw) {
    const g = groupsFrom(raw)[0];
    if (!g) return;
    if ((this.settings.groups || []).includes(g)) return void new import_obsidian11.Notice(`You're already in ${g}.`);
    this.settings.groups = [...this.settings.groups || [], g];
    await this.saveSettings();
    if (!this.settings.identity || !this.settings.handle) return void new import_obsidian11.Notice(`You'll join ${g} when you publish your profile.`);
    const url = await this.publish(true);
    new import_obsidian11.Notice(url ? `You joined ${g}. Your city is on ${this.settings.hubUrl.replace(/\/$/, "")}/g/${g}` : `Saved: you'll join ${g} on the next publish.`);
  }
  openFinish() {
    new WelcomeModal(this.app, this, this.settings.handle && this.settings.identity ? "finish" : "welcome").open();
  }
  /** Existing profiles with a bare page (no photo, headline or links): offer the setup form once. */
  async offerFinish() {
    const s = this.settings;
    if (!s.identity || !s.handle || !s.welcomed || s.finishOffered || this.unloaded) return;
    const e = effectiveSettings(this.app, s);
    if (e.avatarPath && e.headline?.trim() && (e.links || []).length) return;
    s.finishOffered = true;
    await this.saveSettings();
    new ConfirmModal(this.app, "Your page is live, but it's still bare. Add a photo, a masthead, a headline and a few links in about a minute - no AI needed.", () => this.openFinish(), "Finish my page", "Finish your page").open();
  }
  openTopics() {
    new TopicsModal(this.app, this).open();
  }
  /** Once: the page shows no topics (none of the allow-listed tags are used in this vault), so offer the vault's own tags. */
  async offerTopics() {
    const s = this.settings;
    if (!s.identity || !s.handle || !s.welcomed || s.topicsOffered || this.unloaded) return;
    const e = effectiveSettings(this.app, s);
    if (topicsInUse(this.app, e.publicTopics) > 0 || vaultTags(this.app, 5).length < 3) return;
    s.topicsOffered = true;
    await this.saveSettings();
    new ConfirmModal(this.app, "Your page doesn't show any topics yet. Pick a few of your own tags to show: only the tags you pick are counted, never note names.", () => this.openTopics(), "Pick topics", "Add topics to your page").open();
  }
  /** Save picked tags as the public topics (Caldera/profile.md wins over settings, so both are written), then republish. */
  async saveTopics(picked) {
    this.settings.publicTopics = picked;
    await this.saveSettings();
    const pf = await ensureProfileFile(this.app, this.settings, this.settings.hubUrl);
    await this.app.fileManager.processFrontMatter(pf, (fm) => {
      fm.topics = picked.map(([t, l]) => `${t} | ${l}`);
    });
  }
  openShare() {
    if (!this.settings.handle) return void new WelcomeModal(this.app, this).open();
    new ShareModal(this.app, this).open();
  }
  /** Daily summary email: the hub sends a confirmation link first. Empty turns it off. */
  async setSummaryEmail(email) {
    try {
      const me = await this.ensureIdentity();
      if (!this.settings.handle) throw new Error("Publish your profile first");
      const r = await this.api("POST", `/v1/owner/${encodeURIComponent(me.id)}/email`, { email: email || null }, true);
      this.settings.summaryEmail = email;
      await this.saveSettings();
      new import_obsidian11.Notice(r.off ? "Daily summary emails are off." : r.message || "Check your inbox for a confirmation link.", 8e3);
    } catch (e) {
      new import_obsidian11.Notice("Couldn't save: " + e.message);
    }
  }
  /** New alerts from Caldera (welcome, release notes, announcements) appear once as a notice; click opens them, signed in. */
  async checkAlerts() {
    const s = this.settings;
    if (!s.identity || !s.handle) return;
    try {
      const r = await this.api("GET", `/v1/owner/${encodeURIComponent(s.identity.id)}/alerts`, void 0, true);
      const pm = r?.privateRepos;
      if (pm && ["show", "anonymous", "hidden", "named"].includes(pm.mode) && String(pm.ts) > (s.privateReposTs || "") && pm.mode !== s.privateRepos) {
        s.privateRepos = pm.mode;
        s.privateReposTs = String(pm.ts);
        await this.saveSettings();
        this.queuePublish("profile");
      }
      const fresh = (r?.alerts || []).filter((x) => !x.read && (!s.lastAlertTs || x.ts > s.lastAlertTs)).slice(0, 2);
      const newest = (r?.alerts || []).reduce((m, x) => x.ts > m ? x.ts : m, s.lastAlertTs || "");
      if (newest !== (s.lastAlertTs || "")) {
        s.lastAlertTs = newest;
        await this.saveSettings();
      }
      for (const x of fresh) {
        const frag = createFragment((f) => {
          f.createEl("b", { text: "Caldera: " });
          f.appendText(String(x.title) + " ");
          f.createEl("u", { text: "Read it" });
        });
        const n = new import_obsidian11.Notice(frag, 2e4);
        n.noticeEl.addEventListener("click", () => void this.openProfile("alerts"));
      }
    } catch {
    }
  }
  /** Unread direct messages on caldera.social: one notice when the count goes up (click: open Messages, signed in). */
  async checkMessages() {
    const s = this.settings;
    if (!s.identity || !s.handle) return;
    try {
      const a = await this.ownerActivity((/* @__PURE__ */ new Date()).toISOString()), m = a?.messages;
      if (!m) return;
      const seen = s.lastMsgUnread || 0;
      if (m.unread !== seen) {
        s.lastMsgUnread = m.unread;
        await this.saveSettings();
      }
      if (!m.unread || m.unread <= seen) return;
      const who = (m.from || []).map((h) => "@" + h).join(", ");
      const frag = createFragment((f) => {
        f.createEl("b", { text: "Caldera: " });
        f.appendText(`${m.unread} unread message${m.unread === 1 ? "" : "s"}${who ? ` from ${who}` : ""}. `);
        f.createEl("u", { text: "Open Messages" });
      });
      const n = new import_obsidian11.Notice(frag, 2e4);
      n.noticeEl.addEventListener("click", () => void this.openProfile("messages"));
    } catch {
    }
  }
  /** At most once a day: if people looked at the page, linked to it or befriended you, say so (click: share it). */
  async attention() {
    const s = this.settings, today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
    if (s.lastAttention?.slice(0, 10) === today) return;
    try {
      const since = s.lastAttention || new Date(Date.now() - 7 * 864e5).toISOString();
      const a = await this.ownerActivity(since);
      s.lastAttention = (/* @__PURE__ */ new Date()).toISOString();
      await this.saveSettings();
      const bits = [], n = (x, one, many = one + "s") => `${x} ${x === 1 ? one : many}`;
      if (a.visitors) bits.push(n(a.visitors, "visitor"));
      if (a.friends?.length) bits.push(n(a.friends.length, "new friend"));
      if (a.gravity?.length) bits.push(n(a.gravity.length, "gift of gravity", "gifts of gravity"));
      if (gardenEnabled() && a.links?.length) bits.push(n(a.links.length, "link into your garden", "links into your garden"));
      if (!bits.length) return;
      const days = Math.max(1, Math.round((Date.now() - Date.parse(since)) / 864e5));
      const frag = createFragment((f) => {
        f.createEl("b", { text: `Caldera, ${days >= 6 ? "this week" : days === 1 ? "since yesterday" : `last ${days} days`}: ` });
        f.appendText(bits.join(", ") + ". ");
        f.createEl("u", { text: "Share your page" });
      });
      const note = new import_obsidian11.Notice(frag, 15e3);
      note.noticeEl.addEventListener("click", () => this.openShare());
    } catch {
    }
  }
  /** Once: members without the daily summary get a notice; clicking it asks for the address right there. */
  async summaryPrompt() {
    const s = this.settings;
    if (s.emailPromptShown || s.summaryEmail || !s.identity || !s.handle) return;
    try {
      const a = await this.ownerActivity((/* @__PURE__ */ new Date()).toISOString());
      if (a.emailConfirmed !== false) return;
      s.emailPromptShown = true;
      await this.saveSettings();
      const frag = createFragment((f) => {
        f.createEl("b", { text: "Caldera: get your daily summary. " });
        f.appendText("Who visited your page, kudos and new followers, people to meet. Only on days something happens. ");
        f.createEl("u", { text: "Add your email" });
      });
      const note = new import_obsidian11.Notice(frag, 2e4);
      note.noticeEl.addEventListener("click", () => new SummaryEmailModal(this.app, this).open());
    } catch {
    }
  }
  /** New kudos since the last sync: a Notice per batch (who sent what). */
  async kudosNews() {
    const s = this.settings, me = s.identity;
    if (!me || !s.handle) return;
    try {
      const since = s.lastKudos || new Date(Date.now() - 864e5).toISOString();
      const r = await this.api("GET", `/v1/owner/${encodeURIComponent(me.id)}/kudos?since=${encodeURIComponent(since)}`, void 0, true);
      const list = r.kudos || [];
      if (!list.length) return;
      s.lastKudos = list[0].ts;
      await this.saveSettings();
      const who = list.slice(0, 3).map((k) => `${k.emoji} ${k.from ? "@" + k.from : "someone"}`).join(", ");
      new import_obsidian11.Notice(`Caldera: kudos from ${who}${list.length > 3 ? ` and ${list.length - 3} more` : ""}`, 12e3);
    } catch {
    }
  }
  /** Send someone kudos from Obsidian (one per person per day). */
  /** answer an introduction (accept -> friends; not now -> closed, they aren't told), or ask to meet someone */
  async introduce(handle, how) {
    const me = this.settings.identity;
    if (!me) return;
    try {
      const r = await this.api("POST", `/v1/owner/${encodeURIComponent(me.id)}/intros/${encodeURIComponent(handle)}`, how === "ask" ? { ask: true } : { accept: how === "accept" }, true);
      this.intros = this.intros.filter((i) => i.handle !== handle);
      new import_obsidian11.Notice(how === "accept" || r.state === "friends" ? `You and @${handle} are now friends` : how === "ask" ? `Asked to meet @${handle}. They can accept or say not now.` : "Closed. They won't be told.");
      if (how === "accept" || r.state === "friends") await this.syncInbox(false);
      else this.refreshPanel();
    } catch (e) {
      new import_obsidian11.Notice(e.message);
    }
  }
  async sendKudos(handle, kind) {
    const me = this.settings.identity;
    if (!me || !this.settings.handle) return void new import_obsidian11.Notice("Publish your page first.");
    try {
      await this.api("POST", `/v1/owner/${encodeURIComponent(me.id)}/kudos`, { to: handle, kind }, true);
      new import_obsidian11.Notice(`Kudos sent to @${handle}`);
    } catch (e) {
      new import_obsidian11.Notice(e.message);
    }
  }
  /** Community hosts: a friend request (with a note) to each person who joins after the option was turned on. */
  async welcomeNewMembers() {
    const s = this.settings;
    if (!s.welcomeNew || !s.identity || !s.handle) return;
    const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10), day = s.welcomeDay?.[0] === today ? s.welcomeDay[1] : 0;
    if (day >= 10) return;
    try {
      const since = s.welcomeSince || (/* @__PURE__ */ new Date()).toISOString(), sent = new Set(s.welcomeSent || []);
      const skip = /* @__PURE__ */ new Set([s.identity.id, ...this.friends.map((f) => f.id), ...this.pending.map((p) => p.from), ...this.sent.map((p) => p.from)]);
      const dir = await this.api("GET", "/v1/directory?sort=new");
      let n = day;
      for (const p of dir.profiles || []) {
        if (n >= 10 || String(p.created) <= since) break;
        const pr = await this.api("GET", `/v1/profiles/${encodeURIComponent(p.handle)}`);
        if (skip.has(pr.id) || sent.has(pr.id)) continue;
        await this.send("friend.request", { to: pr.id, note: (s.welcomeNote || WELCOME_NOTE).slice(0, 200) });
        sent.add(pr.id);
        n++;
      }
      s.welcomeSent = [...sent].slice(-500);
      s.welcomeDay = [today, n];
      await this.saveSettings();
    } catch (e) {
      console.warn("Caldera welcome:", e.message);
    }
  }
  /** "Add as friend" from a profile page (obsidian://caldera?friend=) or the My profile tab: confirm, then request. */
  async confirmFriend(raw) {
    const h = raw.replace(/^@/, "").trim();
    if (!/^[a-z0-9_-]{1,40}$/i.test(h)) return;
    if (!this.settings.identity || !this.settings.handle) {
      new import_obsidian11.Notice(`Publish your Caldera profile first, then click "Follow @${h}" again.`);
      return void new WelcomeModal(this.app, this).open();
    }
    if (h.toLowerCase() === this.settings.handle.toLowerCase()) return void new import_obsidian11.Notice("That's your own profile. Share your invite link from the Caldera panel instead.");
    new ConfirmModal(this.app, `Follow @${h}? If they follow you back, you're friends: you can share notes end-to-end encrypted and give each other gravity.`, async () => {
      try {
        await this.requestFriend(h);
      } catch (e) {
        new import_obsidian11.Notice(e.message);
      }
    }, "Send request", "Add a friend").open();
  }
  /** Live traffic: one site key per city district, registered with the hub (which hands back each site's server key). */
  async syncSites(city, publicNames) {
    if (!city?.districts.length || !this.settings.identity) return;
    try {
      const have = new Map((this.settings.traffic || []).map((t) => [t.project, t.key]));
      const rnd = () => Array.from(crypto.getRandomValues(new Uint8Array(12)), (b) => "abcdefghijklmnopqrstuvwxyz0123456789"[b % 36]).join("") + Date.now().toString(36).slice(-4);
      const sites = city.districts.filter((d) => d.name && d.name !== "Private").map((d) => ({ key: have.get(d.name) || rnd(), project: d.name, public: publicNames.includes(d.name) }));
      const me = await this.ensureIdentity();
      const repos = {};
      for (const d of city.districts) for (const rp of d.repos || []) if (rp.name) repos[await sha16(rp.name.toLowerCase())] = d.name;
      const r = await this.api("POST", `/v1/owner/${encodeURIComponent(me.id)}/sites`, { sites, repos }, true);
      const tok = (v) => typeof v === "string" && /^[A-Za-z0-9_-]{8,80}$/.test(v);
      if (Array.isArray(r.sites)) {
        this.settings.traffic = r.sites.filter((t) => tok(t?.key) && (t.secret === void 0 || tok(t.secret)) && sites.some((x) => x.project === t.project)).map((t) => ({ key: t.key, project: String(t.project), public: !!t.public, ...t.secret ? { secret: t.secret } : {} }));
        if (tok(r.agent?.key) && tok(r.agent?.secret)) this.settings.agentKey = { key: r.agent.key, secret: r.agent.secret };
        await this.saveSettings();
      }
    } catch (e) {
      console.warn("Caldera live-traffic sites:", e.message);
    }
  }
  /** The weather where this computer is (the hub looks it up from this request and keeps nothing), for the city's sky. */
  async weather() {
    return this.api("GET", "/v1/weather");
  }
  async ownerLive() {
    const me = await this.ensureIdentity();
    return this.api("GET", `/v1/owner/${encodeURIComponent(me.id)}/live`, void 0, true);
  }
  /** Private activity for the My view tab: visits, gravity, friends, links in. Signed in with the vault's key. */
  async ownerActivity(since) {
    const me = await this.ensureIdentity();
    return this.api("GET", `/v1/owner/${encodeURIComponent(me.id)}/activity?since=${encodeURIComponent(since)}`, void 0, true);
  }
  /** Private web address (Tailscale): push the owner layer, encrypted at rest on the hub, served only to the owner's tailnet login. */
  async pushPrivate(loud = false) {
    if (this.unloaded || !this.settings.privateWeb || !this.settings.identity || !this.settings.handle) return null;
    try {
      const { data, cityPrivate } = await this.build();
      const vault = encodeURIComponent(this.app.vault.getName());
      const pages = {};
      if (cityPrivate?.districts.length) pages["city.html"] = renderPrivateCity(data, cityPrivate, `obsidian://open?vault=${vault}&file=`);
      const html = renderOwner(await collectOwner(this.app, this, data, this.settings.ownerLastLooked)).replace(/href="#"((?: [\w-]+="[^"]*")*?) data-open="([^"]*)"/g, (_m, attrs, p) => `${attrs.trim()} href="obsidian://open?vault=${vault}&amp;file=${encodeURIComponent(p.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">"))}" target="_blank" rel="noopener"`).replace(/<a href="#"[^>]*data-action="[^"]*"[^>]*>([\s\S]*?)<\/a>/g, "$1").replace("Built from your vault inside Obsidian. None of it is published.", "Pushed from your vault. Only your Tailscale account can see this page.");
      const me = await this.ensureIdentity();
      const r = await this.api("POST", `/v1/owner/${encodeURIComponent(me.id)}/private`, { html, pages, built: (/* @__PURE__ */ new Date()).toISOString(), v: this.manifest.version }, true);
      if (r.url && r.url !== this.settings.privateUrl) {
        this.settings.privateUrl = r.url;
        await this.saveSettings();
      }
      if (loud) new import_obsidian11.Notice("Private view pushed. Open it on any of your Tailscale devices: " + r.url);
      return r.url;
    } catch (e) {
      if (loud) new import_obsidian11.Notice("Couldn't push the private view: " + e.message);
      else console.warn("Caldera private push failed:", e.message);
      return null;
    }
  }
  schedulePrivatePush() {
    cancel(this._priv);
    this._priv = this.settings.privateWeb ? every(() => {
      void this.pushPrivate(false);
    }, 10 * 6e4) : null;
  }
  /** The city in a small always-on-top window: needs the My profile tab (it builds the city), so open it first if needed. */
  async popCity() {
    await this.openProfileTab();
    const v = this.app.workspace.getLeavesOfType(PROFILE_VIEW)[0]?.view;
    if (!v?.popOut) return;
    for (let i = 0; i < 40 && !v.isReady?.(); i++) await new Promise((r) => window.setTimeout(r, 100));
    await v.popOut();
  }
  async floatCity(spec, open3 = true) {
    this.floatSpec = spec;
    const leaf = this.app.workspace.getLeavesOfType(CITY_FLOAT_VIEW)[0];
    if (leaf) {
      leaf.view.showSpec(spec);
      if (open3) leaf.view.containerEl.win.focus();
      return;
    }
    if (!open3) return;
    const pop = this.app.workspace.openPopoutLeaf({ size: FLOAT_SIZE });
    await pop.setViewState({ type: CITY_FLOAT_VIEW, active: true });
  }
  async openProfileTab() {
    const ws = this.app.workspace;
    const existing = ws.getLeavesOfType(PROFILE_VIEW)[0];
    if (existing) return void ws.revealLeaf(existing);
    const leaf = ws.getLeaf("tab");
    await leaf.setViewState({ type: PROFILE_VIEW, active: true });
    ws.revealLeaf(leaf);
  }
  async requestFriend(handleOrId, note = "") {
    const h = handleOrId.trim().replace(/^https?:\/\/[^/]+\/@?/, "").replace(/[/?#].*$/, "").replace(/^@/, "");
    if (!h) throw new Error("Enter a handle, like @orion, or their profile link");
    const pr = await this.api("GET", `/v1/profiles/${encodeURIComponent(h)}`);
    if (pr.id === this.settings.identity?.id) throw new Error("That's your own profile");
    if (this.friends.some((f) => f.id === pr.id)) throw new Error(`You're already friends with @${pr.handle}`);
    await this.send("friend.request", { to: pr.id, note });
    new import_obsidian11.Notice(`You follow @${pr.handle || pr.id}. If they follow you back, you're friends.`);
    await this.syncInbox(false);
  }
  async giveGravity(f, reason) {
    const r = await this.send("gravity", { to: f.id, reason: reason.slice(0, 140) });
    new import_obsidian11.Notice(`Gravity sent. @${f.handle || "friend"} now has ${r.gravity}`);
  }
  async shareNote(file) {
    if (!this.friends.length) await this.syncInbox(false);
    if (!this.friends.length) return new import_obsidian11.Notice("Add a friend first (Caldera panel)");
    new FriendPicker(this.app, this.friends, async (f) => {
      if (!f.box_key) return new import_obsidian11.Notice("That friend has not published a profile yet");
      const me = await this.ensureIdentity();
      const text = await this.app.vault.read(file);
      const version = Date.now();
      await this.send("card", {
        id: "card_" + b58encode(new TextEncoder().encode(file.path)).slice(0, 20),
        title: file.basename,
        to: [f.id],
        payload: { [f.id]: seal(text, f.box_key, me) },
        version
      });
      new import_obsidian11.Notice(`Shared "${file.basename}" with @${f.handle || "friend"} (end-to-end encrypted)`);
    }).open();
  }
  // ---------------------------------------------------------------- utils
  async ensureFolder(path) {
    const parts = (0, import_obsidian11.normalizePath)(path).split("/").slice(0, -1);
    let cur = "";
    for (const p of parts) {
      cur = cur ? `${cur}/${p}` : p;
      if (!this.app.vault.getAbstractFileByPath(cur)) await this.app.vault.createFolder(cur).catch(() => {
      });
    }
  }
  async write(path, text) {
    path = (0, import_obsidian11.normalizePath)(path);
    await this.ensureFolder(path);
    const f = this.app.vault.getAbstractFileByPath(path);
    if (f instanceof import_obsidian11.TFile) await this.app.vault.modify(f, text);
    else await this.app.vault.create(path, text);
  }
  async writeBinary(path, data) {
    path = (0, import_obsidian11.normalizePath)(path);
    await this.ensureFolder(path);
    const f = this.app.vault.getAbstractFileByPath(path);
    if (f instanceof import_obsidian11.TFile) await this.app.vault.modifyBinary(f, data);
    else await this.app.vault.createBinary(path, data);
  }
  async openPanel() {
    let leaf = this.app.workspace.getLeavesOfType(VIEW)[0];
    if (!leaf) {
      leaf = this.app.workspace.getRightLeaf(false);
      await leaf.setViewState({ type: VIEW, active: true });
    }
    void this.app.workspace.revealLeaf(leaf);
  }
  refreshPanel() {
    for (const l of this.app.workspace.getLeavesOfType(VIEW)) l.view.render();
  }
};
var CalderaView = class extends import_obsidian11.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
  }
  getViewType() {
    return VIEW;
  }
  getDisplayText() {
    return "Caldera";
  }
  getIcon() {
    return "flame";
  }
  async onOpen() {
    this.render();
    await this.plugin.syncInbox(false);
  }
  render() {
    const el = this.contentEl;
    el.empty();
    el.addClass("caldera-panel");
    const p = this.plugin, s = p.settings;
    el.createEl("h3", { text: "Caldera" });
    if (!s.identity || !s.handle) {
      el.createEl("p", { text: "Set your name and handle in settings, then publish your profile to join." });
      new import_obsidian11.Setting(el).addButton((b) => b.setButtonText("Open settings").setCta().onClick(() => {
        this.app.setting.open();
        this.app.setting.openTabById("caldera");
      }));
      return;
    }
    const stats = el.createDiv("caldera-stats");
    for (const [v, l] of [[p.social.friends, "friends"], [p.social.gravity, "gravity"], [p.social.credits, "credits"]]) {
      const st = stats.createDiv({ cls: "caldera-stat" });
      st.createEl("b", { text: String(v) });
      st.createSpan({ text: String(l) });
    }
    const actions = el.createDiv("caldera-actions");
    actions.createEl("button", { text: "My profile" }).onclick = () => p.openProfileTab();
    actions.createEl("button", { text: "Publish", cls: "mod-cta" }).onclick = () => p.publish();
    actions.createEl("button", { text: "Sync" }).onclick = () => p.syncInbox(true);
    actions.createEl("button", { text: "Share" }).onclick = () => p.openShare();
    if (p.pending.length) {
      el.createEl("h4", { text: "Following you" });
      for (const r of p.pending) {
        const row = el.createDiv("caldera-row");
        row.createSpan({ text: (r.handle ? "@" + r.handle : r.from.slice(0, 14)) + (r.note ? ` - "${r.note}"` : "") });
        row.createEl("button", { text: "Follow back", cls: "mod-cta" }).onclick = () => p.acceptFriend(r);
        row.createEl("button", { text: "Ignore" }).onclick = () => p.ignoreFriend(r);
      }
    }
    if (p.sent.length) {
      el.createEl("h4", { text: "Waiting for them to accept" });
      for (const r of p.sent) el.createDiv({ cls: "caldera-row", text: (r.handle ? "@" + r.handle : r.from.slice(0, 14)) + ` - sent ${r.ts.slice(0, 10)}` });
    }
    if (p.intros.length) {
      el.createEl("h4", { text: "Introductions" });
      for (const it of p.intros) {
        const row = el.createDiv("caldera-row");
        const who = row.createSpan();
        who.createEl("b", { text: it.name || "@" + it.handle });
        who.appendText(` @${it.handle}`);
        who.createDiv({ cls: "setting-item-description", text: `${it.tag ? `Also building ${it.tag}. ` : ""}Would like to connect.` });
        row.createEl("button", { text: "Accept", cls: "mod-cta" }).onclick = () => void p.introduce(it.handle, "accept");
        row.createEl("button", { text: "Not now" }).onclick = () => void p.introduce(it.handle, "decline");
      }
    }
    el.createEl("h4", { text: "Add a friend" });
    el.createEl("p", { cls: "setting-item-description", text: 'Already on Caldera: enter their handle or paste their profile link. Or click "Follow" on their profile page.' });
    let handle = "";
    new import_obsidian11.Setting(el).addText((t) => t.setPlaceholder("@handle or profile link").onChange((v) => handle = v)).addButton((b) => b.setButtonText("Request").onClick(async () => {
      try {
        await p.requestFriend(handle.trim());
      } catch (e) {
        new import_obsidian11.Notice(e.message);
      }
    }));
    if (p.suggestions.length) {
      el.createEl("h4", { text: "People you might know" });
      for (const sg of p.suggestions) {
        const row = el.createDiv("caldera-row");
        const who = row.createSpan();
        who.createEl("b", { text: sg.name || "@" + sg.handle });
        who.appendText(` @${sg.handle}`);
        who.createDiv({ cls: "setting-item-description", text: sg.why });
        row.createEl("button", { text: "Add" }).onclick = async () => {
          try {
            await p.requestFriend(sg.handle);
            p.suggestions = p.suggestions.filter((x) => x !== sg);
            this.render();
          } catch (e) {
            new import_obsidian11.Notice(e.message);
          }
        };
        row.createEl("button", { text: "View" }).onclick = () => window.open(`${s.hubUrl.replace(/\/$/, "")}/@${sg.handle}/`);
        row.createEl("button", { text: "Kudos" }).onclick = (ev) => kudosMenu(ev, sg.handle, p);
        if (/both building/i.test(sg.why || "")) row.createEl("button", { text: "Introduce me" }).onclick = () => void p.introduce(sg.handle, "ask");
      }
    }
    el.createEl("h4", { text: "Invite someone new" });
    el.createEl("p", { cls: "setting-item-description", text: "Not on Caldera yet: send them this link. It walks them through installing, then they add you with one click." });
    const inv = `${s.hubUrl.replace(/\/$/, "")}/?invite=${encodeURIComponent(s.handle)}#install`;
    new import_obsidian11.Setting(el).addText((t) => {
      t.setValue(inv);
      t.inputEl.readOnly = true;
      t.inputEl.onfocus = () => t.inputEl.select();
    }).addButton((b) => b.setButtonText("Copy").setCta().onClick(async () => {
      await navigator.clipboard.writeText(inv);
      new import_obsidian11.Notice("Invite link copied");
    }));
    if (!p.ghPeople && !p.ghPeopleLoading) void p.loadGithubPeople().then(() => {
      if (p.ghPeople?.people.length) this.render();
    });
    if (p.ghPeople?.people.length) {
      el.createEl("h4", { text: "Your GitHub people" });
      el.createEl("p", { cls: "setting-item-description", text: "People you follow, who follow you, or who work on your repos, who aren't on Caldera yet. When they join, you start out connected." });
      new import_obsidian11.Setting(el).setName("Invite message").setDesc(p.ghPeople.message).addButton((b) => b.setButtonText("Copy").onClick(async () => {
        await navigator.clipboard.writeText(p.ghPeople.message);
        new import_obsidian11.Notice("Invite message copied. Send it to them anywhere.");
      }));
      for (const x of p.ghPeople.people.slice(0, 20)) {
        const row = el.createDiv("caldera-row");
        const who = row.createSpan();
        who.createEl("b", { text: "@" + x.login });
        who.createDiv({ cls: "setting-item-description", text: x.relation });
        row.createEl("button", { text: "GitHub" }).onclick = () => {
          if (/^https:\/\/github\.com\//.test(String(x.url))) window.open(x.url);
        };
        if (x.invited) row.createSpan({ cls: "setting-item-description", text: "invited" });
        else if (x.canEmail) row.createEl("button", { text: "Email invite" }).onclick = async () => {
          try {
            new import_obsidian11.Notice(await p.githubInvite(x.login));
            x.invited = true;
            this.render();
          } catch (e) {
            new import_obsidian11.Notice(e.message);
          }
        };
      }
    }
    el.createEl("h4", { text: `Friends (${p.friends.length})` });
    for (const f of p.friends) {
      const row = el.createDiv("caldera-row");
      row.createSpan({ text: "@" + (f.handle || f.id.slice(4, 12)) + (f.name ? ` - ${f.name}` : "") + (f.why && f.kind === "repo" ? ` (both work on ${f.why})` : f.why && f.kind === "github" ? ` (${f.why})` : "") });
      row.createEl("button", { text: "+ gravity" }).onclick = () => new GravityModal(this.app, f, (r) => p.giveGravity(f, r)).open();
      if (f.handle) row.createEl("button", { text: "Kudos" }).onclick = (ev) => kudosMenu(ev, f.handle, p);
    }
  }
};
function kudosMenu(ev, handle, plugin) {
  const m = new import_obsidian11.Menu();
  for (const [k, em] of [["heart", "\u2764\uFE0F"], ["up", "\u{1F44D}"], ["fire", "\u{1F525}"], ["sparkle", "\u2728"]])
    m.addItem((i) => i.setTitle(`${em}  Send @${handle} ${k === "up" ? "a thumbs up" : k}`).onClick(() => void plugin.sendKudos(handle, k)));
  m.showAtMouseEvent(ev);
}
var PreviewModal = class extends import_obsidian11.Modal {
  constructor(app, html) {
    super(app);
    this.html = html;
  }
  onOpen() {
    this.modalEl.addClass("caldera-preview-modal");
    this.titleEl.setText("Public profile preview (exactly what visitors will see)");
    const frame = this.contentEl.createEl("iframe", { cls: "caldera-preview" });
    frame.setAttr("sandbox", "allow-scripts");
    frame.srcdoc = this.html;
  }
};
var FriendPicker = class extends import_obsidian11.SuggestModal {
  constructor(app, list, pick) {
    super(app);
    this.list = list;
    this.pick = pick;
    this.setPlaceholder("Share with which friend?");
  }
  getSuggestions(q2) {
    return this.list.filter((f) => (f.handle || f.name || f.id).toLowerCase().includes(q2.toLowerCase()));
  }
  renderSuggestion(f, el) {
    el.setText("@" + (f.handle || f.id.slice(4, 12)) + (f.name ? ` - ${f.name}` : ""));
  }
  onChooseSuggestion(f) {
    void this.pick(f);
  }
};
var SummaryEmailModal = class extends import_obsidian11.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
  }
  onOpen() {
    const c = this.contentEl;
    this.titleEl.setText("Where should we send your daily summary?");
    c.createEl("p", { text: "Who visited your page, new friends and kudos, people to meet, and a nudge when your page needs attention. Only on days something happens, with a one-click unsubscribe. We send a confirmation link first.", cls: "setting-item-description" });
    let email = this.plugin.settings.summaryEmail || "";
    new import_obsidian11.Setting(c).setName("Email").addText((t) => {
      t.setPlaceholder("you@example.com").setValue(email).onChange((v) => email = v.trim());
      t.inputEl.type = "email";
    }).addButton((b) => b.setButtonText("Email me").setCta().onClick(async () => {
      if (!email) return;
      await this.plugin.setSummaryEmail(email);
      this.close();
    }));
  }
  onClose() {
    this.contentEl.empty();
  }
};
var GravityModal = class extends import_obsidian11.Modal {
  constructor(app, f, done) {
    super(app);
    this.f = f;
    this.done = done;
  }
  onOpen() {
    this.titleEl.setText(`Add gravity to @${this.f.handle || "friend"}`);
    this.contentEl.createEl("p", { text: "Gravity is positive only. Say what they helped with (optional)." });
    let reason = "";
    new import_obsidian11.Setting(this.contentEl).addText((t) => t.setPlaceholder("They found me an operator").onChange((v) => reason = v)).addButton((b) => b.setButtonText("Add gravity").setCta().onClick(() => {
      void this.done(reason);
      this.close();
    }));
  }
};
var ConfirmModal = class extends import_obsidian11.Modal {
  constructor(app, msg, yes, label = "Delete", title = "Are you sure?") {
    super(app);
    this.msg = msg;
    this.yes = yes;
    this.label = label;
    this.title = title;
  }
  onOpen() {
    this.titleEl.setText(this.title);
    this.contentEl.createEl("p", { text: this.msg });
    new import_obsidian11.Setting(this.contentEl).addButton((b) => b.setButtonText("Cancel").onClick(() => this.close())).addButton((b) => {
      b.setButtonText(this.label).onClick(() => {
        void this.yes();
        this.close();
      });
      if (this.label === "Delete") b.setWarning();
      else b.setCta();
    });
  }
};
var PairModal = class extends import_obsidian11.Modal {
  constructor(app, approve, page2) {
    super(app);
    this.approve = approve;
    this.page = page2;
  }
  onOpen() {
    this.titleEl.setText("Sign in another device");
    this.contentEl.createEl("p", { text: `On your phone or the other browser, open ${this.page}, tap "Owner? Sign in" in the bar at the top, then "Show a code". Type that code here.` });
    this.contentEl.createEl("p", { cls: "setting-item-description", text: "Only approve a code on a screen you're holding yourself: approving signs that browser in as you." });
    let code = "";
    const go = async () => {
      if (code.replace(/[^A-Za-z0-9]/g, "").length !== 6) return void new import_obsidian11.Notice("The code has 6 characters.");
      try {
        await this.approve(code);
        this.close();
      } catch (e) {
        new import_obsidian11.Notice(e.message);
      }
    };
    new import_obsidian11.Setting(this.contentEl).setName("Code").addText((t) => {
      t.setPlaceholder("ABC 123").onChange((v) => code = v);
      t.inputEl.addEventListener("keydown", (e) => {
        if (e.key === "Enter") void go();
      });
      window.setTimeout(() => t.inputEl.focus(), 50);
    }).addButton((b) => b.setButtonText("Sign it in").setCta().onClick(() => void go()));
  }
  onClose() {
    this.contentEl.empty();
  }
};
var ImagePickModal = class extends import_obsidian11.Modal {
  constructor(app, kind, use, cancelled) {
    super(app);
    this.kind = kind;
    this.use = use;
    this.cancelled = cancelled;
    this.chosen = false;
  }
  onOpen() {
    const banner = this.kind === "banner";
    this.titleEl.setText(banner ? "Set your masthead" : "Set your profile photo");
    this.contentEl.createEl("p", { text: banner ? "The wide cover image across the top of your page. Best about 3:1 (for example 1800x600), JPG or WebP, up to 5 MB. It's public." : "Square, at least 400x400: your face or your logo. JPG, PNG or WebP, up to 5 MB. It's public." });
    const input = this.contentEl.createEl("input", { attr: { type: "file", accept: "image/jpeg,image/png,image/webp" } });
    input.setCssStyles({ display: "none" });
    const take = async (f) => {
      if (!f) return;
      const ext = f.type === "image/png" ? "png" : f.type === "image/webp" ? "webp" : f.type === "image/jpeg" ? "jpg" : "";
      if (!ext) return void new import_obsidian11.Notice("Use a JPG, PNG or WebP image.");
      if (f.size > 5 * 1024 * 1024) return void new import_obsidian11.Notice("That image is over 5 MB. Try a smaller one.");
      try {
        this.chosen = true;
        await this.use(await f.arrayBuffer(), ext);
        this.close();
      } catch (e) {
        this.chosen = false;
        new import_obsidian11.Notice("Couldn't set it: " + e.message);
      }
    };
    input.addEventListener("change", () => void take(input.files?.[0]));
    this.contentEl.addEventListener("dragover", (e) => e.preventDefault());
    this.contentEl.addEventListener("drop", (e) => {
      e.preventDefault();
      void take(e.dataTransfer?.files?.[0]);
    });
    new import_obsidian11.Setting(this.contentEl).setDesc("Or drop an image on this window.").addButton((b) => b.setButtonText("Choose an image").setCta().onClick(() => input.click()));
  }
  onClose() {
    this.contentEl.empty();
    if (!this.chosen) this.cancelled();
  }
};
var PromptModal = class extends import_obsidian11.Modal {
  constructor(app, text) {
    super(app);
    this.text = text;
  }
  onOpen() {
    this.titleEl.setText("AI agent setup prompt");
    const ta = this.contentEl.createEl("textarea", { cls: "caldera-prompt" });
    ta.value = this.text;
    ta.rows = 18;
    ta.readOnly = true;
    ta.select();
  }
  onClose() {
    this.contentEl.empty();
  }
};
var NotePickModal = class extends import_obsidian11.SuggestModal {
  constructor(app, pick) {
    super(app);
    this.pick = pick;
    this.setPlaceholder("Type to find a note to plant in your garden");
  }
  getSuggestions(q2) {
    const s = q2.toLowerCase();
    return this.app.vault.getMarkdownFiles().filter((f) => !f.path.startsWith("Caldera/") && f.path.toLowerCase().includes(s)).slice(0, 40);
  }
  renderSuggestion(f, el) {
    el.createEl("div", { text: f.basename });
    el.createEl("small", { text: f.parent?.path && f.parent.path !== "/" ? f.parent.path : "", cls: "caldera-muted" });
  }
  onChooseSuggestion(f) {
    this.pick(f);
  }
};
var TopicsModal = class extends import_obsidian11.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
  }
  onOpen() {
    const s = this.plugin.settings, eff = effectiveSettings(this.app, s), c = this.contentEl;
    this.modalEl.addClass("caldera-welcome");
    this.titleEl.setText("Your public topics");
    c.createEl("p", { text: "These are the tags you use most. Pick the ones you're happy to show: your page shows each as a topic with a note count. Note names and untagged notes never leave your vault." });
    const tags = vaultTags(this.app, 30), current = new Map(eff.publicTopics.map(([t, l]) => [t.replace(/^#/, "").toLowerCase(), l]));
    const on = new Set(tags.filter((t) => current.has(t.tag)).map((t) => t.tag));
    if (!tags.length) {
      c.createEl("p", { text: "No tags used in two or more notes yet. Tag a few notes, then come back.", cls: "setting-item-description" });
      return;
    }
    const box = c.createDiv({ cls: "caldera-topic-chips" }), count = c.createEl("p", { cls: "setting-item-description" });
    const others = eff.publicTopics.filter(([t]) => !tags.some((x) => x.tag === t.replace(/^#/, "").toLowerCase())).length;
    const upd = () => count.setText((on.size ? `${on.size} picked` : "Nothing picked here") + (others ? `, plus ${others} other ${others === 1 ? "topic" : "topics"} already on your page (kept).` : on.size ? "" : ": your page shows no topics."));
    for (const t of tags) {
      const b = box.createEl("button", { cls: "caldera-topic-chip" + (on.has(t.tag) ? " is-on" : "") });
      b.createSpan({ text: "#" + t.tag });
      b.createSpan({ text: String(t.count), cls: "caldera-topic-n" });
      b.setAttr("aria-pressed", String(on.has(t.tag)));
      b.onclick = () => {
        if (on.has(t.tag)) on.delete(t.tag);
        else on.add(t.tag);
        b.toggleClass("is-on", on.has(t.tag));
        b.setAttr("aria-pressed", String(on.has(t.tag)));
        upd();
      };
    }
    upd();
    new import_obsidian11.Setting(c).addButton((b) => b.setButtonText("Cancel").onClick(() => this.close())).addButton((b) => b.setButtonText("Save and publish").setCta().onClick(async () => {
      b.setDisabled(true);
      const keep = eff.publicTopics.filter(([t]) => !tags.some((x) => x.tag === t.replace(/^#/, "").toLowerCase()));
      const picked = [...tags.filter((t) => on.has(t.tag)).map((t) => [t.tag, current.get(t.tag) || labelOf(t.tag)]), ...keep].slice(0, 24);
      await this.plugin.saveTopics(picked);
      this.close();
      const url = await this.plugin.publish(true);
      new import_obsidian11.Notice(url ? `Topics saved: ${picked.length}. Your page is updated.` : "Topics saved. They'll show on your next publish.");
    }));
  }
  onClose() {
    this.contentEl.empty();
  }
};
var WelcomeModal = class extends import_obsidian11.Modal {
  constructor(app, plugin, mode = "welcome") {
    super(app);
    this.plugin = plugin;
    this.mode = mode;
  }
  onOpen() {
    const s = this.plugin.settings, finish = this.mode === "finish" && !!s.handle && !!s.identity;
    const eff = effectiveSettings(this.app, s);
    this.modalEl.addClass("caldera-welcome");
    this.titleEl.setText(finish ? "Finish your page" : "Welcome to Caldera");
    const c = this.contentEl;
    c.createEl("p", { text: finish ? "A few details make your page worth visiting. Fill in what you like - everything is optional, and you can change it later in Caldera/profile.md." : "Set up your page in a minute. Caldera creates your identity on this device and publishes a page that keeps itself fresh from your vault. Nothing private leaves your vault. Private GitHub repos show by name on your city (never their code); change that in Settings." });
    let name = eff.name || "", handle = s.handle || "", headline = eff.headline || "", listed = eff.listed !== false;
    const clean2 = (v) => v.toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 30);
    const status = createDiv({ cls: "caldera-welcome-status" });
    const head2 = (t) => c.createEl("h4", { text: t, cls: "caldera-welcome-h" });
    if (!finish && !s.handle) {
      const hubBase = (s.hubUrl || "https://caldera.social").replace(/\/$/, "");
      head2("Already made your page with GitHub?");
      const d = c.createEl("p", { cls: "setting-item-description" });
      d.appendText("If you signed up on the website, import that page instead of picking a new handle below, so you keep one page. Get your code at ");
      d.createEl("a", { text: `${hubBase.replace(/^https?:\/\//, "")}/settings`, href: `${hubBase}/settings#conn-obsidian` });
      d.appendText(" (Connections > Obsidian > Get my code).");
      let code = "";
      new import_obsidian11.Setting(c).setName("Import my GitHub sign-up").setDesc("Paste the code (it starts with CAL-).").addText((t) => t.setPlaceholder("CAL-...").onChange((v) => code = v.trim())).addButton((b) => b.setButtonText("Import").onClick(async () => {
        b.setDisabled(true);
        const ok = await this.plugin.importGithub(code);
        b.setDisabled(false);
        if (!ok) return;
        s.welcomed = true;
        await this.plugin.saveSettings();
        this.plugin.scheduleAutoPublish();
        this.close();
      }));
      head2("New to Caldera? Make your page");
    }
    head2("You");
    new import_obsidian11.Setting(c).setName("Your name").addText((t) => t.setPlaceholder("Ada Lovelace").setValue(name).onChange((v) => name = v.trim()));
    if (finish) new import_obsidian11.Setting(c).setName("Handle").setDesc(this.plugin.profileUrl());
    else new import_obsidian11.Setting(c).setName("Handle").setDesc(`${s.hubUrl.replace(/^https?:\/\//, "").replace(/\/$/, "")}/@handle`).addText((t) => t.setPlaceholder("ada").setValue(handle).onChange((v) => {
      handle = clean2(v);
      if (v !== handle) t.setValue(handle);
      status.setText("");
    }));
    const examples = ["Designer writing about tools for thought", "Founder building in public", "Researcher: notes on climate and cities"];
    new import_obsidian11.Setting(c).setName("Headline").setDesc("One line about what you do or think about").addText((t) => {
      t.setPlaceholder(examples[Math.floor(Math.random() * examples.length)]).setValue(headline).onChange((v) => headline = v.trim());
      t.inputEl.addClass("caldera-wide");
      const gh = !headline && githubLogin(eff.links || []);
      if (gh) void githubBio(gh).then((bio) => {
        if (bio && !headline && !t.getValue()) {
          headline = bio;
          t.setValue(bio);
          t.inputEl.title = "Suggested from your GitHub bio. Edit or clear it.";
        }
      });
    });
    if (finish) {
      const n = topicsInUse(this.app, eff.publicTopics), tags = vaultTags(this.app, 5);
      if (tags.length) new import_obsidian11.Setting(c).setName("Topics").setDesc(n ? `${n} of your tags show as topics.` : `None yet. Your most used tags: ${tags.slice(0, 3).map((t) => "#" + t.tag).join(", ")}.`).addButton((b) => b.setButtonText(n ? "Change" : "Pick topics").onClick(() => this.plugin.openTopics()));
    }
    head2("Pictures");
    const img = { photo: null, banner: null };
    const picRow = (kind, label, desc, current) => {
      const st = new import_obsidian11.Setting(c).setName(label).setDesc(current ? `${desc} Now: ${current}` : desc);
      st.addButton((b) => b.setButtonText(current ? "Change" : "Choose an image").onClick(() => new ImagePickModal(this.app, kind, async (buf, ext) => {
        img[kind] = { buf, ext };
        st.setDesc(`${desc} Chosen. It's saved when you publish.`);
        b.setButtonText("Change");
      }, () => {
      }).open()));
      if (!current) st.addExtraButton((x) => x.setIcon("x").setTooltip("Skip for now").onClick(() => {
        img[kind] = null;
        st.setDesc(`${desc} Skipped - you can add it later.`);
      }));
    };
    picRow("photo", "Profile photo", "Square: your face or your logo.", eff.avatarPath || "");
    picRow("banner", "Masthead", "The wide cover image across the top (about 3:1).", eff.bannerPath || "");
    head2("Links");
    const have = (eff.links || []).map(([l, u]) => ({ l, u, i: quickLinkIndex(l, u) }));
    const quick = QUICK_LINKS.map((_, i) => have.find((h) => h.i === i)?.u || "");
    QUICK_LINKS.forEach((q2, i) => new import_obsidian11.Setting(c).setName(q2.label).addText((t) => t.setPlaceholder(q2.ph).setValue(quick[i]).onChange((v) => quick[i] = v.trim())));
    let plant = null;
    if (gardenEnabled()) {
      head2("Your garden");
      const gs = new import_obsidian11.Setting(c).setName("Plant your first note").setDesc("Optional. Pick a note to publish as a page in your garden, marked seedling - rough is fine.");
      gs.addButton((b) => b.setButtonText("Pick a note").onClick(() => new NotePickModal(this.app, (f) => {
        plant = f;
        gs.setDesc(`"${f.basename}" goes public as a seedling when you publish.`);
        b.setButtonText("Change");
      }).open()));
    }
    head2("Staying in touch");
    new import_obsidian11.Setting(c).setName("List me in People").setDesc("Your card appears on the public directory. Change it anytime.").addToggle((t) => t.setValue(listed).onChange((v) => listed = v));
    head2("Where should we send your daily summary?");
    let email = s.summaryEmail || "";
    new import_obsidian11.Setting(c).setName("Your email").setDesc("Who visited your page, new friends and kudos, people to meet, and a nudge when your page needs attention. Only on days something happens; one-click unsubscribe.").addText((t) => {
      t.setPlaceholder("you@example.com").setValue(email).onChange((v) => email = v.trim());
      t.inputEl.type = "email";
      t.inputEl.addClass("caldera-email-wide");
    });
    {
      const hubBase = (s.hubUrl || "https://caldera.social").replace(/\/$/, ""), legal = c.createEl("p", { cls: "setting-item-description" });
      legal.appendText("By publishing you agree to the ");
      legal.createEl("a", { text: "Terms", href: `${hubBase}/terms` });
      legal.appendText(" and ");
      legal.createEl("a", { text: "Privacy Policy", href: `${hubBase}/privacy` });
      legal.appendText(" of Caldera (mjonesone, LLC).");
    }
    c.appendChild(status);
    const go = new import_obsidian11.Setting(c).addButton((b) => b.setButtonText("Use my AI agent instead").setTooltip("Copies a setup prompt for Claude Code, Codex or Cursor").onClick(() => this.plugin.copyPrompt("setup"))).addButton((b) => b.setButtonText(finish ? "Save and publish" : "Publish my page").setCta().onClick(async () => {
      if (!name) {
        status.setText("Add your name.");
        return;
      }
      if (!finish && handle.length < 3) {
        status.setText("Handles need at least 3 letters or numbers.");
        return;
      }
      b.setDisabled(true);
      b.setButtonText("Publishing...");
      const fail = (msg) => {
        status.setText(msg);
        b.setDisabled(false);
        b.setButtonText(finish ? "Save and publish" : "Publish my page");
      };
      try {
        const me = await this.plugin.ensureIdentity(true);
        if (!finish) {
          const r = await (0, import_obsidian11.requestUrl)({ url: `${s.hubUrl.replace(/\/$/, "")}/v1/profiles/${handle}`, throw: false });
          if (r.status === 200 && r.json?.id !== me.id) return fail(`@${handle} is taken. If it's yours from signing up with GitHub, import it above instead. Otherwise try another.`);
          s.handle = handle;
          if (!s.autoPublishHours) s.autoPublishHours = 6;
        }
        Object.assign(s, { name, headline, listed });
        await this.plugin.saveSettings();
        await this.plugin.applyProfileForm({ name, headline, listed, images: img, links: quick.map((v, i) => [QUICK_LINKS[i].label, quickLinkUrl(i, v)]), plant });
        const firstRun = !s.welcomed;
        s.welcomed = true;
        s.sharePrompted = true;
        await this.plugin.saveSettings();
        const url = await this.plugin.publish(true);
        if (!url) {
          if (firstRun) {
            s.welcomed = false;
            await this.plugin.saveSettings();
          }
          const why = this.plugin.lastPublishError;
          return fail(why && !/network|fetch|ENOTFOUND|timed out/i.test(why) ? `Publishing failed: ${why}` : "Publishing failed. Check your connection and try again.");
        }
        this.plugin.scheduleAutoPublish();
        if (email && email !== s.summaryEmail) void this.plugin.setSummaryEmail(email);
        this.close();
        new ShareModal(this.app, this.plugin, firstRun).open();
      } catch (e) {
        fail(e.message);
      }
    }));
    go.settingEl.addClass("caldera-welcome-go");
  }
  onClose() {
    this.contentEl.empty();
  }
};
var ShareModal = class extends import_obsidian11.Modal {
  constructor(app, plugin, firstRun = false) {
    super(app);
    this.plugin = plugin;
    this.firstRun = firstRun;
  }
  onOpen() {
    const s = this.plugin.settings, hub = s.hubUrl.replace(/\/$/, ""), url = this.plugin.profileUrl(), invite = `${hub}/?invite=${encodeURIComponent(s.handle)}`;
    this.modalEl.addClass("caldera-share");
    this.titleEl.setText("Your page is live");
    const c = this.contentEl;
    c.createEl("p", { text: "This is what people see when you post your link. Pages that get shared get visitors, followers and kudos." });
    const img = c.createEl("img", { cls: "caldera-share-card", attr: { src: `${url}card.png?t=${Date.now()}`, alt: "Your link preview" } });
    img.onerror = () => img.remove();
    const copy2 = async (t2, msg) => {
      try {
        await navigator.clipboard.writeText(t2);
        new import_obsidian11.Notice(msg);
      } catch {
        new import_obsidian11.Notice(t2, 1e4);
      }
    };
    new import_obsidian11.Setting(c).setName("Your link").setDesc(url).addButton((b) => b.setButtonText("Copy link").setCta().onClick(() => copy2(url, "Link copied")));
    const text = `My page on Caldera: a living profile built from my Obsidian vault, with my work as a little city. ${url}`, t = encodeURIComponent(text);
    new import_obsidian11.Setting(c).setName("Post it").addButton((b) => b.setButtonText("X").onClick(() => window.open(`https://x.com/intent/post?text=${t}`))).addButton((b) => b.setButtonText("Bluesky").onClick(() => window.open(`https://bsky.app/intent/compose?text=${t}`))).addButton((b) => b.setButtonText("LinkedIn").onClick(() => window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`))).addButton((b) => b.setButtonText("Mastodon").onClick(() => window.open(`https://mastodonshare.com/?text=${t}`)));
    new import_obsidian11.Setting(c).setName("Invite a friend").setDesc(`${invite} - they're walked through setup and add you with one click.`).addButton((b) => b.setButtonText("Copy invite link").onClick(() => copy2(invite, "Invite link copied")));
    let email = s.summaryEmail || "";
    new import_obsidian11.Setting(c).setName("Daily summary email").setDesc("Who visited your page, kudos and new followers, people to meet. Only on days something happens.").addText((tx) => tx.setPlaceholder("you@example.com").setValue(email).onChange((v) => email = v.trim())).addButton((b) => b.setButtonText("Email me").onClick(() => {
      if (email) void this.plugin.setSummaryEmail(email);
    }));
    if (this.firstRun) new import_obsidian11.Setting(c).setName("Save your recovery key").setDesc("Your login is a key stored in this vault - no password. Keep a copy in your password manager to recover your page on another device. Anyone with it can act as you.").addButton((b) => b.setButtonText("Copy recovery key").onClick(() => copy2(btoa(JSON.stringify(s.identity)), "Recovery key copied. Paste it into your password manager.")));
    const gh = githubUser(s.links || []);
    if (gh) {
      const md = `[![My GitHub city on Caldera](${hub}/@${s.handle}/badge.svg?style=card)](${hub}/@${s.handle}/city.html)`;
      new import_obsidian11.Setting(c).setName("Put your city in your GitHub README").setDesc(`A badge with your skyline that updates itself. Paste it into github.com/${gh}/${gh} (your profile README).`).addButton((b) => b.setButtonText("Copy Markdown").onClick(() => copy2(md, "Badge Markdown copied. Paste it into your profile README."))).addButton((b) => b.setButtonText("Open README repo").onClick(() => window.open(`https://github.com/${gh}/${gh}`)));
    }
    new import_obsidian11.Setting(c).setName("Caldera is open source").setDesc("A star on GitHub helps other people find it.").addButton((b) => b.setButtonText("Star on GitHub").onClick(() => window.open("https://github.com/schoettle-cmd/caldera")));
    new import_obsidian11.Setting(c).addButton((b) => b.setButtonText("Open my page").onClick(() => void this.plugin.openProfile())).addButton((b) => b.setButtonText("Done").setCta().onClick(() => this.close()));
  }
  onClose() {
    this.contentEl.empty();
  }
};
var WhatsNewModal = class extends import_obsidian11.Modal {
  constructor(app, plugin, releases) {
    super(app);
    this.plugin = plugin;
    this.releases = releases;
  }
  onOpen() {
    this.titleEl.setText("What's new in Caldera");
    const have = this.plugin.manifest.version, newest = this.releases[0]?.version;
    const older = (a, b) => {
      const x = a.split(".").map(Number), y = b.split(".").map(Number);
      for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) < (y[i] || 0);
      return false;
    };
    if (newest && older(have, newest)) {
      const up = this.contentEl.createDiv({ cls: "caldera-release-howto" });
      up.createEl("p", { text: `You have Caldera ${have}. Version ${newest} is out: open Community plugins, click "Check for updates", then update Caldera.` });
      new import_obsidian11.Setting(up).addButton((b) => b.setButtonText("Open Community plugins").setCta().onClick(() => {
        const st = this.app.setting;
        if (st) {
          st.open();
          st.openTabById("community-plugins");
        }
        this.close();
      }));
    }
    for (const r of this.releases) {
      const box = this.contentEl.createDiv({ cls: "caldera-release" });
      box.createDiv({ cls: "caldera-release-meta", text: `${r.version} \xB7 ${r.date}` });
      box.createEl("h3", { text: r.title });
      const ul = box.createEl("ul");
      for (const it of r.items) ul.createEl("li", { text: it });
      if (r.howto) box.createEl("p", { cls: "caldera-release-howto", text: r.howto });
    }
    const hub = this.plugin.settings.hubUrl.replace(/\/$/, "");
    new import_obsidian11.Setting(this.contentEl).addButton((b) => b.setButtonText("All release notes").onClick(() => window.open(hub + "/changelog.html"))).addButton((b) => b.setButtonText("Guide").onClick(() => window.open(hub + "/guide.html"))).addButton((b) => b.setButtonText("Done").setCta().onClick(() => this.close()));
  }
  onClose() {
    this.contentEl.empty();
  }
};
var GardenPreviewModal = class extends import_obsidian11.Modal {
  constructor(app, report, folder, url) {
    super(app);
    this.report = report;
    this.folder = folder;
    this.url = url;
  }
  onOpen() {
    const c = this.contentEl;
    c.empty();
    c.createEl("h2", { text: "Your garden" });
    if (!this.report.length) {
      c.createEl("p", { text: `No garden notes yet. Put notes in the "${this.folder || "(no folder set)"}" folder, or run "Plant this note in my garden" on any note. Nothing is published until you do.` });
      return;
    }
    const words = this.report.reduce((a, r) => a + r.words, 0);
    c.createEl("p", { text: `${this.report.length} notes (${words.toLocaleString()} words) will be public as full pages${this.url ? ` at ${this.url}` : ""}. Email addresses and phone numbers are removed automatically. Lines below were flagged as possibly private: edit them, or add "caldera: private" to keep a note out.` });
    for (const r of this.report) {
      const box = c.createDiv({ cls: "caldera-garden-row" });
      box.createEl("h4", { text: `${r.title}  (${r.stage}, ${LICENSES[r.license]?.short || r.license}, ${r.words} words)` });
      box.createDiv({ text: r.path, cls: "setting-item-description" });
      if (r.removed) box.createDiv({ text: `${r.removed} email/phone value(s) will be removed.` });
      if (!r.flags.length) box.createDiv({ text: "No flagged lines.", cls: "setting-item-description" });
      for (const fl of r.flags) box.createDiv({ text: `[${fl.why}] ${fl.line}` });
    }
  }
};
async function sha16(t) {
  const h = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(t));
  return Array.from(new Uint8Array(h), (b) => b.toString(16).padStart(2, "0")).join("").slice(0, 16);
}
